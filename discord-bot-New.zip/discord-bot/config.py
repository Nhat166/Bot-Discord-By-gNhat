"""Cấu hình trung tâm của bot.

Giá trị mặc định được đọc từ file .env (xem .env.example). Bốn thiết lập ID gồm kênh chào
mừng, kênh log, role Member và kênh thông báo lên cấp có thể được quản trị viên đổi theo
từng máy chủ bằng lệnh `.config`; các giá trị đó được lưu trong SQLite và ưu tiên hơn .env.

Các module khác nên dùng `import config` rồi gọi `config.TEN_BIEN` (không dùng
`from config import ...`) để giá trị luôn là giá trị hiện tại.
"""
from __future__ import annotations

import os

from dotenv import load_dotenv

load_dotenv()


# ---------------------------------------------------------------------------
# Hàm đọc biến môi trường
# ---------------------------------------------------------------------------
def _get_str(name: str, default: str = "") -> str:
    return (os.getenv(name) or default).strip()


def _get_int(name: str, default: int = 0, *, minimum: int | None = None) -> int:
    raw = _get_str(name)
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        raise SystemExit(f"Biến môi trường {name} phải là số nguyên (hiện là {raw!r}).") from None
    if minimum is not None and value < minimum:
        raise SystemExit(f"Biến môi trường {name} phải >= {minimum} (hiện là {value}).")
    return value


def _get_bool(name: str, default: bool) -> bool:
    raw = _get_str(name).lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "y", "on", "bat", "bật"}


def _get_id_list(name: str) -> list[int]:
    ids: list[int] = []
    for part in _get_str(name).replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            ids.append(int(part))
        except ValueError:
            raise SystemExit(f"Biến môi trường {name} chỉ được chứa ID dạng số, cách nhau bằng dấu phẩy.") from None
    return ids


def _get_color(name: str, default: int) -> int:
    raw = _get_str(name).lstrip("#")
    if not raw:
        return default
    try:
        return int(raw, 16)
    except ValueError:
        raise SystemExit(f"Biến môi trường {name} phải là mã màu hex, ví dụ 5865F2.") from None


# ---------------------------------------------------------------------------
# Thiết lập chung
# ---------------------------------------------------------------------------
TOKEN = _get_str("DISCORD_TOKEN")
PREFIX = _get_str("COMMAND_PREFIX", ".")
# Nếu đặt GUILD_ID, bot chỉ hoạt động trong máy chủ đó. Để trống = hoạt động ở mọi máy chủ.
GUILD_ID = _get_int("GUILD_ID")
DATABASE_PATH = _get_str("DATABASE_PATH", "data/bot.db")

# ID mặc định (có thể được ghi đè theo từng máy chủ bằng lệnh .config). 0 = chưa đặt.
WELCOME_CHANNEL_ID = _get_int("WELCOME_CHANNEL_ID")
LOG_CHANNEL_ID = _get_int("LOG_CHANNEL_ID")
MEMBER_ROLE_ID = _get_int("MEMBER_ROLE_ID")
LEVELUP_CHANNEL_ID = _get_int("LEVELUP_CHANNEL_ID")
# ---------------------------------------------------------------------------
# Chào mừng thành viên mới
# Các biến dùng được: {user} (mention), {name}, {server}, {count}
# ---------------------------------------------------------------------------
WELCOME_TITLE = _get_str("WELCOME_TITLE", "Chào mừng {name}! 🎉")
WELCOME_MESSAGE = _get_str(
    "WELCOME_MESSAGE",
    "Xin chào {user}, chào mừng bạn đến với **{server}**!\nBạn là thành viên thứ **{count}** của chúng ta.",
)
WELCOME_COLOR = _get_color("WELCOME_COLOR", 0x5865F2)

# ---------------------------------------------------------------------------
# Phát nhạc
# ---------------------------------------------------------------------------
MUSIC_MAX_QUEUE = _get_int("MUSIC_MAX_QUEUE", 50, minimum=1)
MUSIC_DEFAULT_VOLUME = min(100, _get_int("MUSIC_DEFAULT_VOLUME", 50, minimum=0))
MUSIC_IDLE_TIMEOUT = _get_int("MUSIC_IDLE_TIMEOUT", 300, minimum=10)  # giây
YTDLP_COOKIES_FILE = _get_str("YTDLP_COOKIES_FILE")  # tùy chọn, xem README

# ---------------------------------------------------------------------------
# Chống spam
# Bị coi là spam khi gửi NHIỀU HƠN SPAM_MESSAGE_LIMIT tin nhắn trong SPAM_WINDOW_SECONDS giây.
# ---------------------------------------------------------------------------
SPAM_ENABLED = _get_bool("SPAM_ENABLED", True)
SPAM_MESSAGE_LIMIT = _get_int("SPAM_MESSAGE_LIMIT", 23, minimum=1)
SPAM_WINDOW_SECONDS = _get_int("SPAM_WINDOW_SECONDS", 30, minimum=1)
SPAM_CHANNEL_IDS = _get_id_list("SPAM_CHANNEL_IDS")  # rỗng = kiểm tra mọi kênh
SPAM_EXEMPT_ROLE_IDS = _get_id_list("SPAM_EXEMPT_ROLE_IDS")  # role được miễn kiểm tra
SPAM_DELETE_MESSAGES = _get_bool("SPAM_DELETE_MESSAGES", True)
SPAM_TIMEOUT_AFTER = _get_int("SPAM_TIMEOUT_AFTER", 3, minimum=0)  # số lần vi phạm; 0 = không timeout
SPAM_VIOLATION_WINDOW_SECONDS = _get_int("SPAM_VIOLATION_WINDOW_SECONDS", 600, minimum=1)
SPAM_TIMEOUT_MINUTES = min(40320, _get_int("SPAM_TIMEOUT_MINUTES", 10, minimum=1))  # tối đa 28 ngày

# ---------------------------------------------------------------------------
# Hệ thống XP
# ---------------------------------------------------------------------------
XP_MIN = _get_int("XP_MIN", 15, minimum=1)
XP_MAX = _get_int("XP_MAX", 25, minimum=1)
XP_COOLDOWN_SECONDS = _get_int("XP_COOLDOWN_SECONDS", 2, minimum=0)
XP_MIN_LENGTH = _get_int("XP_MIN_LENGTH", 2, minimum=1)  # độ dài tối thiểu của tin nhắn hợp lệ
XP_REPEAT_LIMIT = _get_int("XP_REPEAT_LIMIT", 5, minimum=2)  # lặp lại N lần ...
XP_REPEAT_WINDOW_SECONDS = _get_int("XP_REPEAT_WINDOW_SECONDS", 15, minimum=1)  # ... trong N giây thì không có XP

if XP_MIN > XP_MAX:
    raise SystemExit("XP_MIN không được lớn hơn XP_MAX.")

# Bảng cấp bậc: (tên, tổng XP tối thiểu để đạt cấp bậc đó).
# "Phàm Nhân" là mốc xuất phát (0 XP) cho thành viên chưa đạt 100 XP.
LEVELS: list[tuple[str, int]] = [
    ("Phàm Nhân", 0),
    ("Luyện Khí Kỳ", 100),
    ("Trúc Cơ Kỳ", 300),
    ("Kết Đan Kỳ", 600),
    ("Nguyên Anh Kỳ", 1_500),
    ("Hoá Thần Kỳ", 5_500),
    ("Luyện Hư Kỳ", 21_000),
    ("Hợp Thể Kỳ", 127_500),
    ("Đại Thường Kỳ", 1_000_000),
]
