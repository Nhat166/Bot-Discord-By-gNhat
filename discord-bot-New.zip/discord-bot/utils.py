"""Hàm tiện ích dùng chung: định dạng số, đọc thiết lập theo máy chủ, gửi nhật ký quản trị."""
from __future__ import annotations

import logging
from typing import Optional

import discord

import config
from database import db

log = logging.getLogger("bot.utils")

# Các thiết lập có thể đổi bằng lệnh `.config`: khóa -> (tên hiển thị, loại)
SETTINGS: dict[str, tuple[str, str]] = {
    "welcome_channel": ("Kênh chào mừng", "channel"),
    "log_channel": ("Kênh log quản trị", "channel"),
    "levelup_channel": ("Kênh thông báo lên cấp", "channel"),
    "member_role": ("Role Member tự động", "role"),
}


def _default_setting(key: str) -> int:
    return {
        "welcome_channel": config.WELCOME_CHANNEL_ID,
        "log_channel": config.LOG_CHANNEL_ID,
        "levelup_channel": config.LEVELUP_CHANNEL_ID,
        "member_role": config.MEMBER_ROLE_ID,
    }.get(key, 0)


async def get_setting_id(guild_id: int, key: str) -> int:
    """ID đã cấu hình cho `key`: ưu tiên giá trị lưu trong SQLite, sau đó đến .env. 0 = chưa đặt."""
    raw = await db.get_setting(guild_id, key)
    if raw is not None:
        try:
            return int(raw)
        except ValueError:
            log.warning("Thiết lập %s của máy chủ %s có giá trị không hợp lệ: %r", key, guild_id, raw)
    return _default_setting(key)


def guild_allowed(guild: Optional[discord.Guild]) -> bool:
    """Nếu GUILD_ID được đặt thì bot chỉ phục vụ máy chủ đó."""
    if guild is None:
        return False
    return not config.GUILD_ID or guild.id == config.GUILD_ID


# ---------------------------------------------------------------------------
# Định dạng
# ---------------------------------------------------------------------------
def fmt_int(value: int) -> str:
    """12345 -> '12.345' (dấu chấm ngăn cách hàng nghìn như tiếng Việt)."""
    return f"{int(value):,}".replace(",", ".")


def fmt_percent(value: float) -> str:
    """83.33 -> '83,3' (dấu phẩy thập phân)."""
    return f"{value:.1f}".replace(".", ",")


def fmt_duration(seconds: Optional[float]) -> str:
    if seconds is None:
        return "?"
    seconds = int(seconds)
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


class _SafeDict(dict):
    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


def render_template(template: str, **values: object) -> str:
    """Điền {user}, {name}, ... vào mẫu; biến lạ được giữ nguyên thay vì gây lỗi."""
    try:
        return template.format_map(_SafeDict(**values))
    except (ValueError, IndexError, AttributeError):
        return template


# ---------------------------------------------------------------------------
# Nhật ký quản trị
# ---------------------------------------------------------------------------
async def send_log(
    guild: discord.Guild,
    *,
    title: str,
    description: str = "",
    color: int = 0x5865F2,
    fields: Optional[list[tuple[str, object, bool]]] = None,
) -> bool:
    """Ghi một sự kiện vào kênh log đã cấu hình. Không bao giờ ném lỗi; trả về True nếu đã gửi."""
    log.info("[máy chủ %s] %s - %s", guild.id, title, description)
    channel_id = await get_setting_id(guild.id, "log_channel")
    if not channel_id:
        return False
    channel = guild.get_channel(channel_id)
    if channel is None or not hasattr(channel, "send"):
        log.warning("Không tìm thấy kênh log (ID %s) trong máy chủ %s.", channel_id, guild.id)
        return False
    embed = discord.Embed(
        title=title[:256],
        description=description[:4000],
        color=color,
        timestamp=discord.utils.utcnow(),
    )
    for name, value, inline in fields or []:
        embed.add_field(name=name[:256], value=(str(value) or "-")[:1024], inline=inline)
    try:
        await channel.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
        return True
    except (discord.Forbidden, discord.HTTPException) as exc:
        log.warning("Không gửi được nhật ký vào kênh %s: %s", channel_id, exc)
        return False
