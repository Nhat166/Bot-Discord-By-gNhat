"""Phát nhạc từ YouTube trong kênh thoại: hàng chờ, tạm dừng, bỏ qua, âm lượng.

Nguồn nhạc dùng yt-dlp để lấy luồng âm thanh và FFmpeg để phát. Đây là cách phổ biến nhưng
KHÔNG phải API chính thức của YouTube; hãy đọc phần "Lưu ý về nguồn nhạc" trong README.
Toàn bộ phần lấy nguồn nằm trong `build_target`, `extract_info`, `make_track` nên dễ thay
bằng nguồn khác (ví dụ file nhạc cục bộ) mà không phải sửa phần điều khiển.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from collections import deque
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

import discord
import yt_dlp
from discord.ext import commands

import config
from utils import fmt_duration

log = logging.getLogger("bot.music")

MUSIC_COLOR = 0xE91E63
YOUTUBE_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
    "youtu.be", "www.youtu.be",
}
STREAM_URL_TTL = 15 * 60  # giây; link luồng cũ hơn mức này sẽ được lấy lại trước khi phát
EMPTY_CHANNEL_TIMEOUT = 60  # giây chờ trước khi rời kênh thoại không còn người thật
PROGRESS_BAR_LENGTH = 15
PROGRESS_UPDATE_INTERVAL = 5  # giây giữa hai lần làm mới thanh tiến độ (không nên < 5 để tránh bị Discord giới hạn)
FFMPEG_OPTIONS = {
    "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
    "options": "-vn",
}


class MusicError(Exception):
    """Lỗi có nội dung thân thiện, gửi thẳng được cho người dùng."""


# ---------------------------------------------------------------------------
# Lấy nguồn nhạc
# ---------------------------------------------------------------------------
def _ytdl_options() -> dict:
    options = {
        "format": "bestaudio/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "source_address": "0.0.0.0",
        "socket_timeout": 15,
        "retries": 2,
        "cachedir": False,
    }
    if config.YTDLP_COOKIES_FILE:
        options["cookiefile"] = config.YTDLP_COOKIES_FILE
    return options


def build_target(query: str) -> str:
    """Biến yêu cầu của người dùng thành đầu vào cho yt-dlp.

    Đường dẫn chỉ được chấp nhận nếu thuộc YouTube; mọi thứ khác được coi là từ khóa tìm kiếm.
    """
    query = query.strip().strip("<>").strip()
    if not query:
        raise MusicError("Bạn chưa nhập tên bài hát hoặc đường dẫn YouTube.")
    if re.match(r"^https?://", query, re.IGNORECASE):
        host = (urlparse(query).hostname or "").lower()
        if host not in YOUTUBE_HOSTS:
            raise MusicError("Chỉ hỗ trợ đường dẫn YouTube (youtube.com, youtu.be, music.youtube.com).")
        return query
    return f"ytsearch1:{query}"


def _friendly_error(exc: Exception) -> str:
    text = str(exc).lower()
    if "sign in to confirm" in text or "not a bot" in text:
        return ("YouTube đang yêu cầu xác minh (chặn bot). Hãy thử lại sau, cập nhật yt-dlp "
                "hoặc cấu hình cookies (xem README).")
    if "private video" in text:
        return "Video này ở chế độ riêng tư."
    if "confirm your age" in text or "age-restricted" in text or "age restricted" in text:
        return "Video bị giới hạn độ tuổi, bot không phát được."
    if "premiere" in text or "live event will begin" in text:
        return "Buổi phát trực tiếp hoặc công chiếu này chưa bắt đầu."
    if "unavailable" in text or "not available" in text or "removed" in text or "blocked" in text:
        return "Video không khả dụng (đã bị xóa hoặc bị chặn ở khu vực của bot)."
    return "Không lấy được nguồn nhạc từ YouTube. Hãy thử bài khác hoặc thử lại sau."


def _extract_sync(target: str) -> dict:
    with yt_dlp.YoutubeDL(_ytdl_options()) as ydl:
        info = ydl.extract_info(target, download=False)
    if info is None:
        raise MusicError("Không tìm thấy kết quả nào.")
    if "entries" in info:
        entries = [entry for entry in info["entries"] if entry]
        if not entries:
            raise MusicError("Không tìm thấy kết quả nào cho từ khóa này.")
        info = entries[0]
    return info


async def extract_info(target: str) -> dict:
    loop = asyncio.get_running_loop()
    try:
        return await asyncio.wait_for(loop.run_in_executor(None, _extract_sync, target), timeout=60)
    except asyncio.TimeoutError:
        raise MusicError("YouTube phản hồi quá lâu, hãy thử lại.") from None
    except MusicError:
        raise
    except yt_dlp.utils.YoutubeDLError as exc:
        log.warning("yt-dlp lỗi với %r: %s", target, exc)
        raise MusicError(_friendly_error(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - không để lỗi lạ làm sập lệnh
        log.exception("Lỗi không mong muốn khi lấy nguồn nhạc %r", target)
        raise MusicError("Có lỗi khi lấy nguồn nhạc, hãy thử lại.") from exc


def _pick_stream_url(info: dict) -> str:
    url = info.get("url")
    if url:
        return url
    candidates = [f for f in info.get("formats") or [] if f.get("url") and f.get("acodec") not in (None, "none")]
    if candidates:
        return candidates[-1]["url"]
    raise MusicError("Không tìm thấy luồng âm thanh để phát.")


@dataclass
class Track:
    title: str
    webpage_url: str
    stream_url: str
    duration: Optional[int]
    thumbnail: Optional[str]
    is_live: bool
    requester_id: int
    requester_name: str
    resolved_at: float


def make_track(info: dict, requester: discord.abc.User) -> Track:
    video_id = info.get("id")
    webpage_url = (info.get("webpage_url") or info.get("original_url")
                   or (f"https://www.youtube.com/watch?v={video_id}" if video_id else ""))
    if not webpage_url:
        raise MusicError("Không xác định được đường dẫn của bài hát.")
    duration = info.get("duration")
    return Track(
        title=info.get("title") or "Không rõ tên",
        webpage_url=webpage_url,
        stream_url=_pick_stream_url(info),
        duration=int(duration) if duration else None,
        thumbnail=info.get("thumbnail"),
        is_live=bool(info.get("is_live")),
        requester_id=requester.id,
        requester_name=requester.display_name,
        resolved_at=time.monotonic(),
    )


def clean_title(title: str, limit: int = 80) -> str:
    title = discord.utils.escape_markdown(title)
    return title if len(title) <= limit else title[: limit - 1] + "…"


def _length_text(track: Track) -> str:
    return "LIVE" if track.is_live else fmt_duration(track.duration)


def _log_future(future) -> None:
    if future.cancelled():
        return
    exc = future.exception()
    if exc is not None:
        log.error("Lỗi khi chuyển bài", exc_info=exc)


# ---------------------------------------------------------------------------
# Trạng thái phát nhạc theo từng máy chủ
# ---------------------------------------------------------------------------
class GuildPlayer:
    def __init__(self) -> None:
        self.queue: deque[Track] = deque()
        self.current: Optional[Track] = None
        self.volume: float = config.MUSIC_DEFAULT_VOLUME / 100
        self.text_channel: Optional[discord.abc.Messageable] = None
        self.end_reason: Optional[str] = None  # "skip" | "stop" | "error" | None (hết bài tự nhiên)
        self.lock = asyncio.Lock()
        self.idle_task: Optional[asyncio.Task] = None   # chờ rời kênh khi hết nhạc
        self.empty_task: Optional[asyncio.Task] = None  # chờ rời kênh khi không còn người thật
        self.control_message: Optional[discord.Message] = None
        self.started_at: float = 0.0
        self.paused_at: Optional[float] = None
        self.paused_total: float = 0.0
        self.progress_task: Optional[asyncio.Task] = None  # tự làm mới thời gian trên embed


class MusicControlView(discord.ui.View):
    """Các nút điều khiển gắn dưới Embed nhạc."""

    def __init__(self, cog: "Music", guild_id: int):
        super().__init__(timeout=6 * 60 * 60)
        self.cog = cog
        self.guild_id = guild_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.guild is None:
            await interaction.response.send_message("❌ Nút này chỉ dùng trong máy chủ.", ephemeral=True)
            return False
        vc = interaction.guild.voice_client
        voice = getattr(interaction.user, "voice", None)
        if vc is None or not vc.is_connected():
            await interaction.response.send_message("❌ Bot không ở trong kênh thoại.", ephemeral=True)
            return False
        if voice is None or voice.channel is None or voice.channel.id != vc.channel.id:
            await interaction.response.send_message("🔒 Bạn cần ở cùng kênh thoại với bot để điều khiển nhạc.", ephemeral=True)
            return False
        return True

    @discord.ui.button(emoji="⏯️", label="Tạm dừng / Phát tiếp", style=discord.ButtonStyle.primary, row=0)
    async def pause_resume(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client
        player = self.cog.get_player(self.guild_id)
        if vc.is_playing():
            self.cog._pause(player, vc)
            await interaction.response.send_message("⏸️ Đã tạm dừng nhạc.", ephemeral=True)
        elif vc.is_paused():
            self.cog._resume(player, vc)
            await interaction.response.send_message("▶️ Tiếp tục phát nhạc.", ephemeral=True)
        else:
            await interaction.response.send_message("ℹ️ Hiện không có bài đang phát.", ephemeral=True)
            return
        await self.cog._update_player_embed(self.guild_id)

    @discord.ui.button(emoji="⏭️", label="Bỏ qua", style=discord.ButtonStyle.secondary, row=0)
    async def skip_track(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client
        player = self.cog.get_player(self.guild_id)
        if player.current is None or not (vc.is_playing() or vc.is_paused()):
            await interaction.response.send_message("ℹ️ Không có bài nào để bỏ qua.", ephemeral=True)
            return
        title = clean_title(player.current.title)
        player.end_reason = "skip"
        vc.stop()
        await interaction.response.send_message(f"⏭️ Đã bỏ qua **{title}**.", ephemeral=True)

    @discord.ui.button(emoji="🔉", label="-10%", style=discord.ButtonStyle.secondary, row=0)
    async def volume_down(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.cog._change_volume(interaction, -0.1)

    @discord.ui.button(emoji="🔊", label="+10%", style=discord.ButtonStyle.success, row=0)
    async def volume_up(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.cog._change_volume(interaction, 0.1)

    @discord.ui.button(emoji="⏹️", label="Dừng", style=discord.ButtonStyle.danger, row=0)
    async def stop_track(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client
        player = self.cog.get_player(self.guild_id)
        count = len(player.queue)
        player.queue.clear()
        if vc.is_playing() or vc.is_paused():
            player.end_reason = "stop"
            vc.stop()
        player.current = None
        await interaction.response.send_message(f"⏹️ Đã dừng nhạc và xóa {count} bài trong hàng chờ.", ephemeral=True)
        await self.cog._update_player_embed(self.guild_id, stopped=True)

    @discord.ui.button(emoji="📃", label="Hàng chờ", style=discord.ButtonStyle.secondary, row=1)
    async def show_queue(self, interaction: discord.Interaction, button: discord.ui.Button):
        player = self.cog.get_player(self.guild_id)
        if not player.queue:
            text = "📭 Hàng chờ đang trống."
        else:
            lines = [f"`{i}.` {clean_title(track.title, 70)} ({_length_text(track)})"
                     for i, track in enumerate(list(player.queue)[:10], 1)]
            if len(player.queue) > 10:
                lines.append(f"… và {len(player.queue) - 10} bài nữa.")
            text = "\n".join(lines)
        await interaction.response.send_message(text, ephemeral=True)


class Music(commands.Cog):
    """Phát nhạc YouTube."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.players: dict[int, GuildPlayer] = {}

    def cog_check(self, ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        return True

    async def cog_unload(self) -> None:
        for player in self.players.values():
            self._cancel_idle(player)
            self._cancel_empty(player)
            self._cancel_progress(player)
        for vc in list(self.bot.voice_clients):
            try:
                await vc.disconnect(force=True)
            except discord.HTTPException:
                pass

    # -- tiện ích -----------------------------------------------------------
    def get_player(self, guild_id: int) -> GuildPlayer:
        player = self.players.get(guild_id)
        if player is None:
            player = self.players[guild_id] = GuildPlayer()
        return player

    def _reset_player(self, guild_id: int) -> None:
        player = self.players.pop(guild_id, None)
        if player is not None:
            self._cancel_idle(player)
            self._cancel_empty(player)
            self._cancel_progress(player)
            player.queue.clear()
            player.current = None

    async def _say(self, player: GuildPlayer, content: str) -> None:
        channel = player.text_channel
        if channel is None:
            return
        try:
            await channel.send(content, allowed_mentions=discord.AllowedMentions.none())
        except (discord.Forbidden, discord.HTTPException) as exc:
            log.warning("Không gửi được thông báo nhạc: %s", exc)

    def _music_embed(self, player: GuildPlayer, *, stopped: bool = False) -> discord.Embed:
        track = player.current
        if track is None:
            embed = discord.Embed(
                title="⏹️ Đã dừng phát nhạc" if stopped else "🎵 Trình phát TKTL",
                description="Hàng chờ đã được xóa." if stopped else "Hiện không có bài hát đang phát.",
                color=0xE74C3C if stopped else MUSIC_COLOR,
            )
            embed.set_footer(text="TKTL • Music Player")
            return embed

        status = "⏸️ ĐANG TẠM DỪNG" if player.paused_at is not None else "♫ NOW PLAYING"
        embed = discord.Embed(
            title=f"{status} · {clean_title(track.title, 180)}",
            url=track.webpage_url,
            description=self._progress_line(player, track) + f"🔊 **Âm lượng: {round(player.volume * 100)}%**",
            color=0xA855F7,
        )
        if track.thumbnail:
            embed.set_thumbnail(url=track.thumbnail)
        embed.add_field(name="👤 Người yêu cầu", value=discord.utils.escape_markdown(track.requester_name), inline=True)
        embed.add_field(name="⏱️ Thời lượng", value=_length_text(track), inline=True)
        embed.add_field(name="🎧 Nguồn", value=f"[YouTube]({track.webpage_url})", inline=True)
        embed.set_footer(text="TKTL • Music Player | Dùng các nút bên dưới để điều khiển")
        return embed

    def _elapsed(self, player: GuildPlayer) -> float:
        """Số giây đã phát (không tính thời gian tạm dừng)."""
        now = player.paused_at if player.paused_at is not None else time.monotonic()
        return max(0.0, now - player.started_at - player.paused_total)

    def _progress_line(self, player: GuildPlayer, track: Track) -> str:
        """Dòng thời gian + thanh tiến độ (kèm xuống dòng); rỗng nếu không biết thời lượng."""
        if track.is_live:
            return "🔴 **LIVE**\n"
        if not track.duration:
            return ""
        elapsed = min(self._elapsed(player), float(track.duration))
        filled = round(PROGRESS_BAR_LENGTH * elapsed / track.duration)
        bar = "▰" * filled + "▱" * (PROGRESS_BAR_LENGTH - filled)
        return f"`{fmt_duration(elapsed)}` {bar} `{fmt_duration(track.duration)}`\n"

    # -- tạm dừng / phát tiếp: dùng chung cho nút bấm và lệnh, để trạng thái luôn khớp --------
    def _pause(self, player: GuildPlayer, vc: discord.VoiceClient) -> None:
        vc.pause()
        player.paused_at = time.monotonic()

    def _resume(self, player: GuildPlayer, vc: discord.VoiceClient) -> None:
        vc.resume()
        if player.paused_at is not None:
            player.paused_total += time.monotonic() - player.paused_at
            player.paused_at = None

    async def _retire_control_message(self, player: GuildPlayer, finished: Optional[Track],
                                      reason: Optional[str]) -> None:
        """Bài cũ đã kết thúc: đổi tin nhắn điều khiển của nó thành 'đã phát xong' và gỡ các nút."""
        message, player.control_message = player.control_message, None
        if message is None or finished is None:
            return
        label = {"skip": "⏭️ Đã bỏ qua", "stop": "⏹️ Đã dừng", "error": "⚠️ Lỗi khi phát"}.get(reason, "✅ Đã phát xong")
        embed = discord.Embed(title=f"{label} · {clean_title(finished.title, 180)}",
                              url=finished.webpage_url, color=0x6B7280)
        try:
            await message.edit(embed=embed, view=None)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as exc:
            log.debug("Không cập nhật được tin nhắn điều khiển cũ: %s", exc)

    async def _update_player_embed(self, guild_id: int, *, stopped: bool = False,
                                   refresh_view: bool = True) -> bool:
        """Sửa embed nhạc. Trả về False nếu tin nhắn không còn (đã bị xóa hoặc không sửa được).

        `refresh_view=False` chỉ sửa embed và giữ nguyên các nút hiện có (dùng cho việc tự làm mới
        mỗi vài giây, tránh tạo View mới liên tục).
        """
        player = self.get_player(guild_id)
        message = player.control_message
        if message is None:
            return False
        kwargs: dict = {"embed": self._music_embed(player, stopped=stopped)}
        if stopped:
            kwargs["view"] = None
        elif refresh_view:
            kwargs["view"] = MusicControlView(self, guild_id)
        try:
            await message.edit(**kwargs)
            return True
        except discord.NotFound:
            player.control_message = None
            return False
        except (discord.Forbidden, discord.HTTPException) as exc:
            log.debug("Không cập nhật được Embed nhạc: %s", exc)
            return True  # lỗi tạm thời (ví dụ giới hạn tốc độ): vòng lặp thử lại ở lần sau

    # -- tự làm mới thời gian trên embed --------------------------------------
    def _cancel_progress(self, player: GuildPlayer) -> None:
        if player.progress_task is not None and not player.progress_task.done():
            player.progress_task.cancel()
        player.progress_task = None

    def _start_progress(self, guild_id: int, player: GuildPlayer, track: Track) -> None:
        self._cancel_progress(player)
        player.progress_task = asyncio.create_task(self._progress_loop(guild_id, track))

    async def _progress_loop(self, guild_id: int, track: Track) -> None:
        """Cứ PROGRESS_UPDATE_INTERVAL giây sửa embed một lần cho đến khi bài kết thúc."""
        try:
            while True:
                await asyncio.sleep(PROGRESS_UPDATE_INTERVAL)
                player = self.players.get(guild_id)
                if player is None or player.current is not track:
                    return  # bài đã đổi, dừng hoặc bot đã rời kênh
                if player.paused_at is not None:
                    continue  # đang tạm dừng: thời gian đứng yên, không cần sửa
                if not await self._update_player_embed(guild_id, refresh_view=False):
                    return  # tin nhắn embed đã bị xóa
        except asyncio.CancelledError:
            return
        except Exception:  # noqa: BLE001 - không để tác vụ nền chết im lặng
            log.exception("Lỗi khi làm mới thanh tiến độ nhạc")

    async def _change_volume(self, interaction: discord.Interaction, delta: float) -> None:
        player = self.get_player(interaction.guild.id)
        player.volume = max(0.0, min(1.0, round(player.volume + delta, 2)))
        vc = interaction.guild.voice_client
        if vc is not None and vc.source is not None and hasattr(vc.source, "volume"):
            vc.source.volume = player.volume
        await interaction.response.send_message(
            f"{'🔊' if delta > 0 else '🔉'} Âm lượng hiện tại: **{round(player.volume * 100)}%**.",
            ephemeral=True,
        )
        await self._update_player_embed(interaction.guild.id)

    async def _control_vc(self, ctx: commands.Context) -> Optional[discord.VoiceClient]:
        """Trả về voice client nếu người dùng đang ở cùng kênh thoại với bot, ngược lại báo lỗi và trả None."""
        vc = ctx.guild.voice_client
        if vc is None or not vc.is_connected():
            await ctx.send("Bot chưa ở trong kênh thoại nào.")
            return None
        voice = getattr(ctx.author, "voice", None)
        if voice is None or voice.channel is None or voice.channel.id != vc.channel.id:
            await ctx.send(f"Bạn cần ở cùng kênh thoại với bot ({vc.channel.mention}) để dùng lệnh này.")
            return None
        return vc

    # -- chuyển bài ---------------------------------------------------------
    async def _ensure_stream(self, track: Track) -> None:
        if track.stream_url and time.monotonic() - track.resolved_at < STREAM_URL_TTL:
            return
        info = await extract_info(track.webpage_url)
        track.stream_url = _pick_stream_url(info)
        track.resolved_at = time.monotonic()

    async def _advance(self, guild: discord.Guild) -> None:
        """Kết thúc bài hiện tại (nếu có) và phát bài tiếp theo trong hàng chờ."""
        player = self.get_player(guild.id)
        async with player.lock:
            vc = guild.voice_client
            if vc is None or not vc.is_connected():
                player.queue.clear()
                player.current = None
                return
            if vc.is_playing() or vc.is_paused():
                return

            finished, reason = player.current, player.end_reason
            player.current, player.end_reason = None, None
            self._cancel_progress(player)
            await self._retire_control_message(player, finished, reason)

            if finished is not None and reason is None:
                notice = f"✅ Đã phát xong: **{clean_title(finished.title)}**."
                if not player.queue:
                    notice += " Hàng chờ đã trống."
                await self._say(player, notice)

            while player.queue:
                track = player.queue.popleft()
                try:
                    await self._ensure_stream(track)
                except MusicError as exc:
                    await self._say(player, f"⚠️ Bỏ qua **{clean_title(track.title)}**: {exc}")
                    continue
                try:
                    source = discord.PCMVolumeTransformer(
                        discord.FFmpegPCMAudio(track.stream_url, **FFMPEG_OPTIONS),
                        volume=player.volume,
                    )
                except discord.ClientException:
                    player.queue.clear()
                    await self._say(player, "⚠️ Không khởi động được FFmpeg. Hãy cài FFmpeg và thêm vào PATH (xem README).")
                    return
                player.current = track
                try:
                    vc.play(source, after=lambda error, g=guild: self._after_play(g, error))
                except discord.ClientException as exc:
                    log.error("Không phát được: %s", exc)
                    player.current = None
                    await self._say(player, "⚠️ Không phát được bài này, hãy thử lại.")
                    return
                self._cancel_idle(player)
                player.started_at = time.monotonic()
                player.paused_at = None
                player.paused_total = 0.0
                embed = self._music_embed(player)
                view = MusicControlView(self, guild.id)
                channel = player.text_channel
                if channel is not None:
                    try:
                        player.control_message = await channel.send(embed=embed, view=view)
                    except (discord.Forbidden, discord.HTTPException) as exc:
                        log.warning("Không gửi được bảng điều khiển nhạc: %s", exc)
                self._start_progress(guild.id, player, track)
                return

            self._schedule_idle(guild, player)

    def _after_play(self, guild: discord.Guild, error: Optional[Exception]) -> None:
        """Được gọi từ luồng phát âm thanh khi một bài kết thúc."""
        future = asyncio.run_coroutine_threadsafe(self._on_track_end(guild, error), self.bot.loop)
        future.add_done_callback(_log_future)

    async def _on_track_end(self, guild: discord.Guild, error: Optional[Exception]) -> None:
        if error is not None:
            log.error("Lỗi khi phát nhạc ở máy chủ %s: %s", guild.id, error)
            player = self.get_player(guild.id)
            player.end_reason = "error"
            await self._say(player, "⚠️ Gặp lỗi khi phát bài hiện tại, chuyển sang bài tiếp theo.")
        await self._advance(guild)

    # -- tự rời kênh khi rảnh -------------------------------------------------
    def _cancel_idle(self, player: GuildPlayer) -> None:
        if player.idle_task is not None and not player.idle_task.done():
            player.idle_task.cancel()
        player.idle_task = None

    def _schedule_idle(self, guild: discord.Guild, player: GuildPlayer) -> None:
        self._cancel_idle(player)
        player.idle_task = asyncio.create_task(self._idle_disconnect(guild, player))

    async def _idle_disconnect(self, guild: discord.Guild, player: GuildPlayer) -> None:
        try:
            await asyncio.sleep(config.MUSIC_IDLE_TIMEOUT)
        except asyncio.CancelledError:
            return
        vc = guild.voice_client
        if vc is not None and vc.is_connected() and not vc.is_playing() and not vc.is_paused():
            await self._say(player, "👋 Bot rời kênh thoại vì không hoạt động.")
            await vc.disconnect()

    # -- tự rời kênh khi không còn người thật -----------------------------------
    def _cancel_empty(self, player: GuildPlayer) -> None:
        if player.empty_task is not None and not player.empty_task.done():
            player.empty_task.cancel()
        player.empty_task = None

    def _schedule_empty(self, guild: discord.Guild, player: GuildPlayer) -> None:
        self._cancel_empty(player)  # luôn chỉ có một bộ đếm cho mỗi máy chủ
        player.empty_task = asyncio.create_task(self._empty_disconnect(guild, player))

    async def _empty_disconnect(self, guild: discord.Guild, player: GuildPlayer) -> None:
        try:
            await asyncio.sleep(EMPTY_CHANNEL_TIMEOUT)
        except asyncio.CancelledError:
            return
        # Tự gỡ khỏi player để việc dọn dẹp khi bot rời kênh không hủy chính tác vụ này giữa chừng.
        player.empty_task = None
        vc = guild.voice_client
        if vc is not None and vc.is_connected() and not any(not m.bot for m in vc.channel.members):
            player.queue.clear()
            await self._say(player, "👋 Kênh thoại không còn ai, bot đã rời kênh.")
            await vc.disconnect()

    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState,
                                    after: discord.VoiceState) -> None:
        guild = member.guild

        # Chính bot rời/bị đuổi khỏi kênh thoại: dọn trạng thái.
        if self.bot.user is not None and member.id == self.bot.user.id:
            if after.channel is None:
                self._reset_player(guild.id)
            return

        # Bot khác đổi trạng thái (mute/deafen/stream...) không được ảnh hưởng đến bộ đếm rời kênh.
        if member.bot:
            return

        vc = guild.voice_client
        if vc is None or vc.channel is None:
            return
        player = self.get_player(guild.id)

        # Có người vào kênh của bot: hủy việc chờ rời kênh ngay.
        if after.channel is not None and after.channel.id == vc.channel.id:
            self._cancel_empty(player)
            return

        # Có người rời kênh của bot và kênh không còn người thật: bắt đầu đếm.
        if before.channel is not None and before.channel.id == vc.channel.id:
            if not any(not m.bot for m in vc.channel.members):
                self._schedule_empty(guild, player)

    # ------------------------------------------------------------------
    # Lệnh
    # ------------------------------------------------------------------
    @commands.command(name="play", aliases=["p"], help="Phát nhạc YouTube. Dùng: .play <tên bài hát hoặc URL>")
    async def play(self, ctx: commands.Context, *, query: str) -> None:
        voice = ctx.author.voice
        if voice is None or voice.channel is None:
            await ctx.send("🎧 Bạn cần vào một kênh thoại trước khi dùng `.play`.")
            return
        channel = voice.channel
        perms = channel.permissions_for(ctx.guild.me)
        if not (perms.view_channel and perms.connect and perms.speak):
            await ctx.send(f"⚠️ Bot thiếu quyền **Connect/Speak** ở {channel.mention}.")
            return

        player = self.get_player(ctx.guild.id)
        vc = ctx.guild.voice_client
        busy = vc is not None and (vc.is_playing() or vc.is_paused() or bool(player.queue))
        if busy and vc.channel.id != channel.id:
            await ctx.send(f"Bot đang phát nhạc ở {vc.channel.mention}. Hãy vào kênh đó để thêm bài.")
            return
        if len(player.queue) >= config.MUSIC_MAX_QUEUE:
            await ctx.send(f"⚠️ Hàng chờ đã đầy ({config.MUSIC_MAX_QUEUE} bài).")
            return

        async with ctx.typing():
            try:
                info = await extract_info(build_target(query))
                track = make_track(info, ctx.author)
            except MusicError as exc:
                await ctx.send(f"⚠️ {exc}")
                return

        # Trạng thái có thể đã đổi trong lúc chờ YouTube phản hồi, nên kiểm tra lại.
        vc = ctx.guild.voice_client
        try:
            if vc is None:
                vc = await channel.connect(self_deaf=True)
            elif not vc.is_connected():
                await vc.disconnect(force=True)
                vc = await channel.connect(self_deaf=True)
            elif vc.channel.id != channel.id:
                if vc.is_playing() or vc.is_paused() or player.queue:
                    await ctx.send(f"Bot đang phát nhạc ở {vc.channel.mention}. Hãy vào kênh đó để thêm bài.")
                    return
                await vc.move_to(channel)
        except (asyncio.TimeoutError, discord.ClientException, discord.Forbidden, discord.HTTPException) as exc:
            log.error("Không vào được kênh thoại %s: %s", channel.id, exc)
            await ctx.send("⚠️ Bot không vào được kênh thoại. Hãy kiểm tra quyền Connect/Speak rồi thử lại.")
            return

        player = self.get_player(ctx.guild.id)  # có thể vừa được reset khi bot đổi kênh
        self._cancel_empty(player)  # có người yêu cầu nhạc nên kênh đang có người
        player.text_channel = ctx.channel
        player.queue.append(track)

        if vc.is_playing() or vc.is_paused():
            await ctx.send(
                f"➕ Đã thêm vào hàng chờ (vị trí **#{len(player.queue)}**): "
                f"**{clean_title(track.title)}** ({_length_text(track)})",
                allowed_mentions=discord.AllowedMentions.none(),
            )
        else:
            await self._advance(ctx.guild)

    @commands.command(name="dung", help="Tạm dừng nhạc.")
    async def dung(self, ctx: commands.Context) -> None:
        vc = await self._control_vc(ctx)
        if vc is None:
            return
        if vc.is_playing():
            self._pause(self.get_player(ctx.guild.id), vc)
            await ctx.send("⏸️ Đã tạm dừng. Dùng `.again` để phát tiếp.")
            await self._update_player_embed(ctx.guild.id)
        elif vc.is_paused():
            await ctx.send("Nhạc đang được tạm dừng rồi. Dùng `.again` để phát tiếp.")
        else:
            await ctx.send("Hiện không có bài nào đang phát.")

    @commands.command(name="again", help="Tiếp tục phát nhạc.")
    async def again(self, ctx: commands.Context) -> None:
        vc = await self._control_vc(ctx)
        if vc is None:
            return
        if vc.is_paused():
            self._resume(self.get_player(ctx.guild.id), vc)
            await ctx.send("▶️ Tiếp tục phát nhạc.")
            await self._update_player_embed(ctx.guild.id)
        elif vc.is_playing():
            await ctx.send("Nhạc đang phát rồi.")
        else:
            await ctx.send("Không có bài nào đang tạm dừng.")

    @commands.command(name="skip", help="Bỏ qua bài hiện tại.")
    async def skip(self, ctx: commands.Context) -> None:
        vc = await self._control_vc(ctx)
        if vc is None:
            return
        player = self.get_player(ctx.guild.id)
        if not (vc.is_playing() or vc.is_paused()) or player.current is None:
            await ctx.send("Hiện không có bài nào để bỏ qua.")
            return
        title = clean_title(player.current.title)
        player.end_reason = "skip"
        vc.stop()  # kích hoạt callback `after` => tự phát bài kế tiếp
        await ctx.send(f"⏭️ Đã bỏ qua: **{title}**", allowed_mentions=discord.AllowedMentions.none())

    @commands.command(name="stop", help="Dừng nhạc và xóa hàng chờ.")
    async def stop(self, ctx: commands.Context) -> None:
        vc = await self._control_vc(ctx)
        if vc is None:
            return
        player = self.get_player(ctx.guild.id)
        had_queue = len(player.queue)
        player.queue.clear()
        if vc.is_playing() or vc.is_paused():
            player.end_reason = "stop"
            player.current = None  # để embed "đã dừng" không hiện lại bài cũ (giống nút Dừng)
            vc.stop()
        await ctx.send(f"⏹️ Đã dừng nhạc và xóa hàng chờ ({had_queue} bài).")
        await self._update_player_embed(ctx.guild.id, stopped=True)

    @commands.command(name="danhsach", aliases=["queue", "q"], help="Xem danh sách bài hát đang chờ.")
    async def danhsach(self, ctx: commands.Context) -> None:
        player = self.get_player(ctx.guild.id)
        if player.current is None and not player.queue:
            await ctx.send("📭 Hàng chờ đang trống. Dùng `.play <tên bài hát hoặc URL>` để thêm nhạc.")
            return
        embed = discord.Embed(title="🎶 Hàng chờ phát nhạc", color=MUSIC_COLOR)
        if player.current is not None:
            current = player.current
            embed.add_field(
                name="Đang phát",
                value=(f"**{clean_title(current.title)}** ({_length_text(current)}) "
                       f"· yêu cầu bởi {discord.utils.escape_markdown(current.requester_name)}"),
                inline=False,
            )
        if player.queue:
            lines = [
                f"`{index}.` {clean_title(track.title, 60)} ({_length_text(track)})"
                for index, track in enumerate(list(player.queue)[:10], start=1)
            ]
            if len(player.queue) > 10:
                lines.append(f"… và {len(player.queue) - 10} bài nữa")
            embed.add_field(name=f"Tiếp theo ({len(player.queue)} bài)", value="\n".join(lines), inline=False)
            total = sum(t.duration or 0 for t in player.queue)
            embed.set_footer(text=f"Tổng thời lượng hàng chờ: {fmt_duration(total)}")
        await ctx.send(embed=embed)

    @commands.command(name="nowplay", aliases=["np"], help="Xem bài hát đang phát.")
    async def nowplay(self, ctx: commands.Context) -> None:
        player = self.get_player(ctx.guild.id)
        track = player.current
        if track is None:
            await ctx.send("Hiện không có bài nào đang phát.")
            return
        await ctx.send(embed=self._music_embed(player), view=MusicControlView(self, ctx.guild.id))

    @commands.command(name="volume", aliases=["vol"], help="Chỉnh âm lượng. Dùng: .volume <0-100>")
    async def volume(self, ctx: commands.Context, level: Optional[str] = None) -> None:
        player = self.get_player(ctx.guild.id)
        if level is None:
            await ctx.send(f"🔊 Âm lượng hiện tại: **{round(player.volume * 100)}%**. Đổi bằng `.volume <0-100>`.")
            return
        vc = ctx.guild.voice_client
        if vc is not None and vc.is_connected():
            if await self._control_vc(ctx) is None:
                return
        try:
            value = int(level.strip().rstrip("%"))
        except ValueError:
            await ctx.send("⚠️ Âm lượng phải là số nguyên từ 0 đến 100.")
            return
        if not 0 <= value <= 100:
            await ctx.send("⚠️ Âm lượng phải nằm trong khoảng 0 đến 100.")
            return
        player.volume = value / 100
        if vc is not None and vc.source is not None and hasattr(vc.source, "volume"):
            vc.source.volume = player.volume
        await ctx.send(f"🔊 Đã đặt âm lượng **{value}%**.")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Music(bot))
