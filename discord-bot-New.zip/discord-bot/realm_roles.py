"""Role tự động theo cảnh giới: lên cấp thì nhận role mới và mất role cảnh giới cũ."""
from __future__ import annotations

import asyncio
import logging
import time

import discord
from discord.ext import commands

import config
import xp_bank
from utils import guild_allowed, send_log

log = logging.getLogger("bot.realm_roles")

# Màu cho từng cảnh giới (theo thứ tự trong config.LEVELS, thiếu thì dùng màu mặc định)
REALM_COLORS = [0x95A5A6, 0x2ECC71, 0x1ABC9C, 0x3498DB, 0x9B59B6,
                0xE91E63, 0xE67E22, 0xF1C40F, 0xE74C3C]

_create_lock = asyncio.Lock()  # tránh tạo trùng role khi nhiều người lên cấp cùng lúc

WARN_INTERVAL = 600  # giây: cùng một cảnh báo chỉ gửi vào kênh log một lần trong khoảng này
_last_warn: dict[tuple[int, str], float] = {}


async def _warn(guild: discord.Guild, text: str) -> None:
    """Gửi cảnh báo vào kênh log nhưng không lặp lại cùng nội dung quá thường xuyên (chống tràn log)."""
    key, now = (guild.id, text), time.monotonic()
    if now - _last_warn.get(key, -1e9) < WARN_INTERVAL:
        return
    _last_warn[key] = now
    await send_log(guild, title="⚠️ Không gán được role cảnh giới", description=text, color=0xF1C40F)


def realm_names() -> list[str]:
    return [name for name, _ in config.LEVELS]


async def sync_member(member: discord.Member, level_index: int) -> bool:
    """Gán role cảnh giới đúng với level_index, gỡ các role cảnh giới khác.

    Trả về True nếu có thay đổi. Không bao giờ ném lỗi.
    """
    guild = member.guild
    me = guild.me
    names = realm_names()
    if not 0 <= level_index < len(names):
        return False
    target_name = names[level_index]

    # Kiểm tra nhanh (không gọi API): đã đúng role và không dư role cảnh giới nào thì thôi.
    realm_roles_now = [r for r in member.roles if r.name in names]
    if len(realm_roles_now) == 1 and realm_roles_now[0].name == target_name:
        return False

    if not me.guild_permissions.manage_roles:
        await _warn(guild, "Bot thiếu quyền **Manage Roles** nên không đổi được role cảnh giới.")
        return False

    try:
        target = discord.utils.get(guild.roles, name=target_name)
        if target is None:
            async with _create_lock:
                target = discord.utils.get(guild.roles, name=target_name)  # kiểm tra lại
                if target is None:
                    color = REALM_COLORS[level_index] if level_index < len(REALM_COLORS) else 0x5865F2
                    target = await guild.create_role(
                        name=target_name, colour=discord.Colour(color), hoist=True,
                        reason="Tạo role cảnh giới tự động",
                    )
        if target.managed or target >= me.top_role:
            await _warn(guild, f"Role {target.mention} cao hơn hoặc ngang role bot. Hãy kéo role bot lên trên.")
            return False

        to_remove = [r for r in realm_roles_now if r != target and not r.managed and r < me.top_role]
        if target not in member.roles:
            await member.add_roles(target, reason="Role cảnh giới tự động")
        if to_remove:
            await member.remove_roles(*to_remove, reason="Gỡ role cảnh giới cũ")
        return True
    except (discord.Forbidden, discord.HTTPException) as exc:
        log.warning("Không đồng bộ được role cho %s: %s", member.id, exc)
        return False


class RealmRoles(commands.Cog):
    """Đồng bộ role cảnh giới."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.command(name="syncroles", help="Gán lại role cảnh giới cho toàn bộ thành viên (quản trị viên).")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def syncroles(self, ctx: commands.Context) -> None:
        if not guild_allowed(ctx.guild):
            return
        members = [m for m in ctx.guild.members if not m.bot]
        await ctx.send(f"⏳ Đang đồng bộ role cho {len(members)} thành viên...")
        changed = 0
        for member in members:
            xp = await xp_bank.get_xp(member.id, ctx.guild.id)
            if await sync_member(member, xp_bank.level_for_xp(xp).index):
                changed += 1
                await asyncio.sleep(0.5)  # tránh bị Discord giới hạn tốc độ
        await ctx.send(f"✅ Xong. Đã cập nhật role cho **{changed}** thành viên.")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(RealmRoles(bot))