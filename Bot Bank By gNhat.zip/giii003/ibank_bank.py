"""Ngân hàng của ItachiBank: tài khoản, nộp/rút/chuyển, vay tiền, thu/thêm tiền. Không phụ thuộc discord.

Mọi thao tác đổi tiền chạy trong MỘT giao dịch cơ sở dữ liệu (xem Database.transaction), nên không thể âm tiền hay
trừ hai lần dù bấm nút đồng thời. Tiền mặt nằm trong ví (ibank_store.WalletStore), tiền ngân hàng nằm trong bảng accounts.
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

import ibank_config as config
from ibank_database import Database
from ibank_money import MAX_AMOUNT, format_vnd
from ibank_store import InsufficientFunds, WalletError, WalletStore, _utc_text

_DIGITS = re.compile(r"^\d+$")


class BankError(WalletError):
    """Lỗi nghiệp vụ ngân hàng, nội dung hiện thẳng cho người dùng."""


@dataclass(frozen=True)
class Account:
    number: str
    owner_id: int
    holder: str
    balance: int
    created_at: str


@dataclass(frozen=True)
class Loan:
    id: int
    lender_id: int
    borrower_id: int
    amount: int
    repaid: int
    days: int
    status: str
    created_at: str
    decided_at: Optional[str]
    due_at: Optional[str]
    notified_overdue: int

    @property
    def remaining(self) -> int:
        return self.amount - self.repaid

    @property
    def due(self) -> Optional[datetime]:
        return parse_utc(self.due_at) if self.due_at else None


@dataclass(frozen=True)
class TransferResult:
    sender: Account          # tài khoản gửi sau khi trừ tiền
    recipient: Account       # tài khoản nhận sau khi cộng tiền
    amount: int
    reason: str


@dataclass(frozen=True)
class HistoryEntry:
    when: datetime
    kind: str                # start, daily, deposit, withdraw, transfer_out, transfer_in, loan_*, admin_*
    amount: int              # có dấu: + tiền vào, - tiền ra (nộp/rút chỉ là chuyển giữa ví và ngân hàng)
    detail: str


@dataclass(frozen=True)
class CollectEvent:
    loan: Loan               # trạng thái sau khi thu
    paid: int                # số tiền vừa thu (có thể 0)
    first_overdue: bool      # lần đầu quá hạn: báo cho hai bên


def parse_utc(text: str) -> datetime:
    return datetime.strptime(text, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)


def _loan(row: sqlite3.Row) -> Loan:
    return Loan(row["id"], row["lender_id"], row["borrower_id"], row["amount"], row["repaid"], row["days"],
                row["status"], row["created_at"], row["decided_at"], row["due_at"], row["notified_overdue"])


def _account(row: sqlite3.Row) -> Account:
    return Account(row["number"], row["owner_id"], row["holder"], row["balance"], row["created_at"])


def normalize_holder(text: str) -> str:
    holder = " ".join(text.split())
    if not config.HOLDER_MIN <= len(holder) <= config.HOLDER_MAX:
        raise BankError(f"Họ và tên phải dài {config.HOLDER_MIN}–{config.HOLDER_MAX} ký tự.")
    if not all(ch.isalpha() or ch == " " for ch in holder):
        raise BankError("Họ và tên chỉ gồm chữ cái và khoảng trắng.")
    return holder


def normalize_number(text: str) -> str:
    number = re.sub(r"[\s.\-]", "", text or "")
    if not _DIGITS.match(number) or not config.ACCOUNT_NUMBER_MIN <= len(number) <= config.ACCOUNT_NUMBER_MAX:
        raise BankError(f"Số tài khoản phải gồm {config.ACCOUNT_NUMBER_MIN}–{config.ACCOUNT_NUMBER_MAX} chữ số.")
    return number


class BankStore:
    def __init__(self, database: Database, wallets: WalletStore) -> None:
        self.db, self.wallets = database, wallets

    def _now(self) -> datetime:
        return self.wallets.clock()

    # -- cài đặt máy chủ -------------------------------------------------------------------------
    async def get_setting(self, guild_id: int, key: str) -> Optional[str]:
        row = await self.db.fetchone("SELECT value FROM settings WHERE guild_id = ? AND key = ?", (guild_id, key))
        return row["value"] if row else None

    async def set_setting(self, guild_id: int, key: str, value: Optional[str]) -> None:
        def work(conn: sqlite3.Connection) -> None:
            if value is None:
                conn.execute("DELETE FROM settings WHERE guild_id = ? AND key = ?", (guild_id, key))
            else:
                conn.execute("INSERT INTO settings (guild_id, key, value) VALUES (?, ?, ?) "
                             "ON CONFLICT (guild_id, key) DO UPDATE SET value = excluded.value", (guild_id, key, value))
        await self.db.transaction(work)

    # -- tài khoản ---------------------------------------------------------------------------------
    async def create_account(self, user_id: int, holder: str, number: str) -> Account:
        holder, number = normalize_holder(holder), normalize_number(number)
        now = self._now()

        def work(conn: sqlite3.Connection) -> Account:
            count = conn.execute("SELECT COUNT(*) AS n FROM accounts WHERE owner_id = ?", (user_id,)).fetchone()["n"]
            if count >= config.MAX_ACCOUNTS:
                raise BankError(f"Mỗi người chỉ mở tối đa {config.MAX_ACCOUNTS} tài khoản.")
            if conn.execute("SELECT 1 FROM accounts WHERE number = ?", (number,)).fetchone():
                raise BankError("Số tài khoản này đã có người dùng. Hãy chọn số khác.")
            conn.execute("INSERT INTO accounts (number, owner_id, holder, balance, created_at) VALUES (?, ?, ?, 0, ?)",
                         (number, user_id, holder, _utc_text(now)))
            return _account(conn.execute("SELECT * FROM accounts WHERE number = ?", (number,)).fetchone())
        return await self.db.transaction(work)

    async def accounts_of(self, user_id: int) -> list[Account]:
        rows = await self.db.fetchall("SELECT * FROM accounts WHERE owner_id = ? ORDER BY created_at, number", (user_id,))
        return [_account(r) for r in rows]

    async def get_account(self, number: str) -> Optional[Account]:
        row = await self.db.fetchone("SELECT * FROM accounts WHERE number = ?", (number,))
        return _account(row) if row else None

    async def bank_total(self, user_id: int) -> int:
        row = await self.db.fetchone("SELECT COALESCE(SUM(balance), 0) AS t FROM accounts WHERE owner_id = ?", (user_id,))
        return row["t"]

    @staticmethod
    def _own_account(conn: sqlite3.Connection, user_id: int, number: str) -> sqlite3.Row:
        row = conn.execute("SELECT * FROM accounts WHERE number = ?", (number,)).fetchone()
        if row is None or row["owner_id"] != user_id:
            raise BankError("Không tìm thấy tài khoản này trong danh sách của bạn.")
        return row

    @staticmethod
    def _log_transfer(conn: sqlite3.Connection, kind: str, from_acc: Optional[str], to_acc: Optional[str],
                      from_user: Optional[int], to_user: Optional[int], amount: int, note: str, now: datetime) -> None:
        conn.execute("INSERT INTO transfers (kind, from_account, to_account, from_user, to_user, amount, note, created_at) "
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                     (kind, from_acc, to_acc, from_user, to_user, amount, note[:200], _utc_text(now)))

    async def deposit(self, user_id: int, number: str, amount: Optional[int]):
        """Nộp tiền mặt (ví) vào tài khoản; amount=None là nộp TẤT CẢ tiền mặt. Trả (tài khoản mới, ví mới, số đã nộp)."""
        now = self._now()

        def work(conn: sqlite3.Connection):
            self.wallets._ensure(conn, user_id, now)
            acc = self._own_account(conn, user_id, number)
            moved = amount
            if moved is None:
                moved = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (user_id,)).fetchone()["cash"]
                if moved <= 0:
                    raise BankError("Ví của bạn không có tiền mặt để nộp.")
            if acc["balance"] + moved > MAX_AMOUNT:
                raise BankError("Số dư tài khoản sẽ vượt mức tối đa cho phép.")
            self.wallets._apply(conn, user_id, -moved, "deposit", f"Nộp vào tài khoản {number}", now)
            conn.execute("UPDATE accounts SET balance = balance + ? WHERE number = ?", (moved, number))
            self._log_transfer(conn, "deposit", None, number, user_id, user_id, moved, "", now)
            return (_account(conn.execute("SELECT * FROM accounts WHERE number = ?", (number,)).fetchone()),
                    self.wallets._row_to_wallet(conn.execute("SELECT * FROM wallets WHERE user_id = ?", (user_id,)).fetchone()),
                    moved)
        return await self.db.transaction(work)

    async def withdraw(self, user_id: int, number: str, amount: Optional[int]):
        """Rút từ tài khoản về ví; amount=None là rút TẤT CẢ số dư. Trả (tài khoản mới, ví mới, số đã rút)."""
        now = self._now()

        def work(conn: sqlite3.Connection):
            self.wallets._ensure(conn, user_id, now)
            acc = self._own_account(conn, user_id, number)
            moved = acc["balance"] if amount is None else amount
            if moved <= 0:
                raise BankError("Tài khoản không còn tiền để rút.")
            if acc["balance"] < moved:
                raise BankError(f"Tài khoản chỉ còn {format_vnd(acc['balance'])}, không đủ để rút {format_vnd(moved)}.")
            conn.execute("UPDATE accounts SET balance = balance - ? WHERE number = ?", (moved, number))
            self.wallets._apply(conn, user_id, moved, "withdraw", f"Rút từ tài khoản {number}", now)
            self._log_transfer(conn, "withdraw", number, None, user_id, user_id, moved, "", now)
            return (_account(conn.execute("SELECT * FROM accounts WHERE number = ?", (number,)).fetchone()),
                    self.wallets._row_to_wallet(conn.execute("SELECT * FROM wallets WHERE user_id = ?", (user_id,)).fetchone()),
                    moved)
        return await self.db.transaction(work)

    async def transfer(self, user_id: int, from_number: str, to_number: str, amount: Optional[int],
                       reason: str = "") -> TransferResult:
        """Chuyển tiền từ tài khoản của mình sang tài khoản (của ai cũng được); amount=None là chuyển TẤT CẢ số dư."""
        to_number = normalize_number(to_number)
        reason = " ".join((reason or "").split())[:100]
        if amount is not None and amount < config.MIN_TRANSFER:
            raise BankError(f"Số tiền chuyển tối thiểu là {format_vnd(config.MIN_TRANSFER)}.")
        if from_number == to_number:
            raise BankError("Không thể chuyển cho chính tài khoản đang dùng.")
        now = self._now()

        def work(conn: sqlite3.Connection) -> TransferResult:
            src = self._own_account(conn, user_id, from_number)
            dst = conn.execute("SELECT * FROM accounts WHERE number = ?", (to_number,)).fetchone()
            if dst is None:
                raise BankError(f"Không tìm thấy tài khoản nhận `{to_number}`. Hãy kiểm tra lại số tài khoản.")
            moved = src["balance"] if amount is None else amount
            if moved < config.MIN_TRANSFER:
                raise BankError(f"Số dư {format_vnd(moved)} chưa đạt mức chuyển tối thiểu {format_vnd(config.MIN_TRANSFER)}.")
            if src["balance"] < moved:
                raise BankError(f"Tài khoản chỉ còn {format_vnd(src['balance'])}, không đủ để chuyển {format_vnd(moved)}.")
            if dst["balance"] + moved > MAX_AMOUNT:
                raise BankError("Tài khoản nhận sẽ vượt mức số dư tối đa cho phép.")
            conn.execute("UPDATE accounts SET balance = balance - ? WHERE number = ?", (moved, from_number))
            conn.execute("UPDATE accounts SET balance = balance + ? WHERE number = ?", (moved, to_number))
            self._log_transfer(conn, "transfer", from_number, to_number, user_id, dst["owner_id"], moved, reason, now)
            return TransferResult(
                _account(conn.execute("SELECT * FROM accounts WHERE number = ?", (from_number,)).fetchone()),
                _account(conn.execute("SELECT * FROM accounts WHERE number = ?", (to_number,)).fetchone()),
                moved, reason)
        return await self.db.transaction(work)

    async def history(self, user_id: int, limit: int, offset: int = 0) -> tuple[list[HistoryEntry], int]:
        """Lịch sử giao dịch của một người (mới nhất trước): sổ cái tiền mặt (mở ví, daily, nộp, rút, vay, admin)
        cộng với chuyển/nhận tiền giữa các tài khoản. Trả (các dòng của trang, tổng số dòng)."""
        union = ("SELECT created_at AS ts, kind AS k, delta AS amt, note AS detail, id AS rid, 0 AS src "
                 "FROM ledger WHERE user_id = ? "
                 "UNION ALL SELECT created_at, 'transfer_out', -amount, "
                 "'→ ' || COALESCE(to_account, '') || CASE WHEN note != '' THEN ' · ' || note ELSE '' END, id, 1 "
                 "FROM transfers WHERE kind = 'transfer' AND from_user = ? "
                 "UNION ALL SELECT created_at, 'transfer_in', amount, "
                 "'← ' || COALESCE(from_account, '') || CASE WHEN note != '' THEN ' · ' || note ELSE '' END, id, 2 "
                 "FROM transfers WHERE kind = 'transfer' AND to_user = ?")
        args = (user_id, user_id, user_id)
        total = (await self.db.fetchone(f"SELECT COUNT(*) AS n FROM ({union})", args))["n"]
        rows = await self.db.fetchall(f"SELECT * FROM ({union}) ORDER BY ts DESC, src, rid DESC LIMIT ? OFFSET ?",
                                      args + (limit, offset))
        return [HistoryEntry(parse_utc(r["ts"]), r["k"], r["amt"], r["detail"] or "") for r in rows], total

    # -- bảng xếp hạng ----------------------------------------------------------------------------------------
    # "giau": tổng tài sản = tiền mặt + mọi tài khoản ngân hàng - tiền nợ.
    # "lai":  lãi ròng từ game = tổng thay đổi tiền mặt của mọi lần cược / thắng / hoàn cược (chỉ tính người đang lãi).
    _WEALTH = ("SELECT w.user_id AS user_id, w.cash + COALESCE((SELECT SUM(a.balance) FROM accounts a WHERE a.owner_id = w.user_id), 0) "
               "- w.debt AS score FROM wallets w")
    _PROFIT = ("SELECT user_id, SUM(delta) AS score FROM ledger WHERE kind IN "
               "('taixiu_bet', 'taixiu_win', 'taixiu_refund', 'baucua_bet', 'baucua_win', 'baucua_refund') GROUP BY user_id HAVING SUM(delta) > 0")

    def _board_sql(self, mode: str) -> str:
        if mode == "giau":
            return self._WEALTH
        if mode == "lai":
            return self._PROFIT
        raise BankError("Loại bảng xếp hạng không hợp lệ.")

    async def leaderboard(self, mode: str, limit: int = 10) -> list[tuple[int, int]]:
        """Top người chơi: [(user_id, điểm)], điểm cao nhất trước."""
        rows = await self.db.fetchall(f"SELECT user_id, score FROM ({self._board_sql(mode)}) ORDER BY score DESC, user_id LIMIT ?", (limit,))
        return [(r["user_id"], r["score"]) for r in rows]

    async def rank_of(self, mode: str, user_id: int) -> Optional[tuple[int, int]]:
        """(hạng, điểm) của một người; None nếu chưa có trong bảng (chưa có ví / chưa có lãi)."""
        sql = self._board_sql(mode)
        row = await self.db.fetchone(f"SELECT score FROM ({sql}) WHERE user_id = ?", (user_id,))
        if row is None:
            return None
        better = await self.db.fetchone(f"SELECT COUNT(*) AS n FROM ({sql}) WHERE score > ? OR (score = ? AND user_id < ?)",
                                        (row["score"], row["score"], user_id))
        return better["n"] + 1, row["score"]

    # -- admin / nhà cái -----------------------------------------------------------------------------
    async def admin_add(self, target_id: int, amount: int, by_id: int, reason: str = ""):
        """Thêm tiền mặt vào ví (tiền được tạo ra). Trả ví mới."""
        now = self._now()
        note = f"Thêm tiền bởi {by_id}: {reason}"[:200]

        def work(conn: sqlite3.Connection):
            self.wallets._ensure(conn, target_id, now)
            cash = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (target_id,)).fetchone()["cash"]
            if cash + amount > MAX_AMOUNT:
                raise BankError("Tiền mặt của người này sẽ vượt mức tối đa cho phép.")
            self.wallets._apply(conn, target_id, amount, "admin_add", note, now)
            return self.wallets._row_to_wallet(conn.execute("SELECT * FROM wallets WHERE user_id = ?", (target_id,)).fetchone())
        return await self.db.transaction(work)

    async def admin_take(self, target_id: int, amount: int, by_id: int, reason: str = ""):
        """Thu tiền mặt trong ví (tiền biến mất). Thu tối đa số tiền đang có. Trả (số tiền đã thu, ví mới)."""
        now = self._now()
        note = f"Thu tiền bởi {by_id}: {reason}"[:200]

        def work(conn: sqlite3.Connection):
            self.wallets._ensure(conn, target_id, now)
            cash = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (target_id,)).fetchone()["cash"]
            taken = min(cash, amount)
            if taken <= 0:
                raise BankError("Người này không có tiền mặt trong ví để thu.")
            self.wallets._apply(conn, target_id, -taken, "admin_take", note, now)
            return taken, self.wallets._row_to_wallet(conn.execute("SELECT * FROM wallets WHERE user_id = ?", (target_id,)).fetchone())
        return await self.db.transaction(work)

    async def stats(self) -> dict:
        """Số liệu toàn hệ thống cho admin: tổng tiền, tiền sinh ra và thu về hôm nay (giờ Việt Nam)."""
        from ibank_store import VN_TZ
        now = self._now()
        day_start = now.astimezone(VN_TZ).replace(hour=0, minute=0, second=0, microsecond=0)
        since = _utc_text(day_start)

        def work(conn: sqlite3.Connection) -> dict:
            one = lambda sql, args=(): conn.execute(sql, args).fetchone()[0]
            return {
                "wallets": one("SELECT COUNT(*) FROM wallets"),
                "cash": one("SELECT COALESCE(SUM(cash), 0) FROM wallets"),
                "bank": one("SELECT COALESCE(SUM(balance), 0) FROM accounts"),
                "debt": one("SELECT COALESCE(SUM(amount - repaid), 0) FROM loans WHERE status = 'active'"),
                "minted_today": one("SELECT COALESCE(SUM(delta), 0) FROM ledger WHERE delta > 0 AND created_at >= ? "
                                    "AND kind IN ('start', 'daily', 'admin_add')", (since,)),
                "burned_today": one("SELECT COALESCE(-SUM(delta), 0) FROM ledger WHERE delta < 0 AND created_at >= ? "
                                    "AND kind = 'admin_take'", (since,)),
            }
        return await self.db.transaction(work)

    # -- vay tiền -------------------------------------------------------------------------------------
    @staticmethod
    def _recalc_debt(conn: sqlite3.Connection, user_id: int) -> None:
        conn.execute("UPDATE wallets SET debt = (SELECT COALESCE(SUM(amount - repaid), 0) FROM loans "
                     "WHERE borrower_id = ? AND status = 'active') WHERE user_id = ?", (user_id, user_id))

    @staticmethod
    def _get_loan(conn: sqlite3.Connection, loan_id: int) -> sqlite3.Row:
        row = conn.execute("SELECT * FROM loans WHERE id = ?", (loan_id,)).fetchone()
        if row is None:
            raise BankError("Không tìm thấy khoản vay này.")
        return row

    async def request_loan(self, borrower_id: int, lender_id: int, amount: int, days: int) -> Loan:
        if borrower_id == lender_id:
            raise BankError("Bạn không thể tự gửi đơn vay cho chính mình.")
        if amount < config.LOAN_MIN:
            raise BankError(f"Số tiền vay tối thiểu là {format_vnd(config.LOAN_MIN)}.")
        if not 1 <= days <= config.LOAN_MAX_DAYS:
            raise BankError(f"Thời hạn vay từ 1 đến {config.LOAN_MAX_DAYS} ngày.")
        now = self._now()

        def work(conn: sqlite3.Connection) -> Loan:
            self.wallets._ensure(conn, borrower_id, now)
            self._expire(conn, now)
            pending = conn.execute("SELECT COUNT(*) FROM loans WHERE borrower_id = ? AND status = 'pending'",
                                   (borrower_id,)).fetchone()[0]
            if pending >= config.MAX_PENDING_LOANS:
                raise BankError(f"Bạn đang có {pending} đơn xin vay chờ duyệt, hãy chờ họ trả lời hoặc đơn tự hủy sau "
                                f"{config.LOAN_PENDING_HOURS} giờ.")
            if conn.execute("SELECT 1 FROM loans WHERE borrower_id = ? AND lender_id = ? AND status = 'pending'",
                            (borrower_id, lender_id)).fetchone():
                raise BankError("Bạn đã gửi đơn vay cho người này và họ chưa trả lời.")
            active = conn.execute("SELECT COUNT(*) FROM loans WHERE borrower_id = ? AND status = 'active'",
                                  (borrower_id,)).fetchone()[0]
            if active >= config.MAX_ACTIVE_LOANS:
                raise BankError(f"Bạn đang nợ {active} khoản, hãy trả bớt (lệnh `/tratien`) trước khi vay thêm.")
            cur = conn.execute("INSERT INTO loans (lender_id, borrower_id, amount, days, status, created_at) "
                               "VALUES (?, ?, ?, ?, 'pending', ?)", (lender_id, borrower_id, amount, days, _utc_text(now)))
            return _loan(self._get_loan(conn, cur.lastrowid))
        return await self.db.transaction(work)

    @staticmethod
    def _expire(conn: sqlite3.Connection, now: datetime) -> int:
        limit = _utc_text(now - timedelta(hours=config.LOAN_PENDING_HOURS))
        return conn.execute("UPDATE loans SET status = 'expired', decided_at = ? WHERE status = 'pending' AND created_at <= ?",
                            (_utc_text(now), limit)).rowcount

    async def expire_pending(self) -> int:
        now = self._now()
        return await self.db.transaction(lambda conn: self._expire(conn, now))

    async def pending_for_lender(self, lender_id: int) -> list[Loan]:
        now = self._now()

        def work(conn: sqlite3.Connection) -> list[Loan]:
            self._expire(conn, now)
            rows = conn.execute("SELECT * FROM loans WHERE lender_id = ? AND status = 'pending' ORDER BY id", (lender_id,)).fetchall()
            return [_loan(r) for r in rows]
        return await self.db.transaction(work)

    async def respond_loan(self, loan_id: int, lender_id: int, accept: bool) -> Loan:
        """Người cho vay chấp nhận / từ chối. Chấp nhận thì chuyển tiền mặt từ ví người cho vay sang ví người vay."""
        now = self._now()

        def work(conn: sqlite3.Connection) -> Loan:
            row = self._get_loan(conn, loan_id)
            if row["lender_id"] != lender_id:
                raise BankError("Đơn vay này không gửi cho bạn.")
            if row["status"] != "pending":
                raise BankError("Đơn vay này đã được xử lý hoặc đã hết hạn.")
            if row["created_at"] <= _utc_text(now - timedelta(hours=config.LOAN_PENDING_HOURS)):
                raise BankError("Đơn vay này đã hết hạn duyệt.")  # vòng dọn dẹp sẽ đánh dấu hết hạn

            if not accept:
                conn.execute("UPDATE loans SET status = 'declined', decided_at = ? WHERE id = ?", (_utc_text(now), loan_id))
                return _loan(self._get_loan(conn, loan_id))
            borrower_id, amount = row["borrower_id"], row["amount"]
            self.wallets._ensure(conn, lender_id, now)
            self.wallets._ensure(conn, borrower_id, now)
            active = conn.execute("SELECT COUNT(*) FROM loans WHERE borrower_id = ? AND status = 'active'",
                                  (borrower_id,)).fetchone()[0]
            if active >= config.MAX_ACTIVE_LOANS:
                raise BankError("Người vay đang nợ quá số khoản cho phép nên chưa thể cho vay thêm.")
            borrower_cash = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (borrower_id,)).fetchone()["cash"]
            if borrower_cash + amount > MAX_AMOUNT:
                raise BankError("Tiền mặt của người vay sẽ vượt mức tối đa cho phép.")
            self.wallets._apply(conn, lender_id, -amount, "loan_out", f"Cho <@{borrower_id}> vay (#{loan_id})", now)
            self.wallets._apply(conn, borrower_id, amount, "loan_in", f"Vay từ <@{lender_id}> (#{loan_id})", now)
            due = _utc_text(now + timedelta(days=row["days"]))
            conn.execute("UPDATE loans SET status = 'active', decided_at = ?, due_at = ? WHERE id = ?",
                         (_utc_text(now), due, loan_id))
            self._recalc_debt(conn, borrower_id)
            return _loan(self._get_loan(conn, loan_id))
        return await self.db.transaction(work)

    async def active_loans(self, borrower_id: int) -> list[Loan]:
        rows = await self.db.fetchall("SELECT * FROM loans WHERE borrower_id = ? AND status = 'active' ORDER BY due_at, id",
                                      (borrower_id,))
        return [_loan(r) for r in rows]

    async def repay(self, loan_id: int, borrower_id: int, amount: Optional[int] = None):
        """Trả nợ. amount=None: trả hết khoản vay. Trả (số đã trả, khoản vay mới, ví mới)."""
        now = self._now()

        def work(conn: sqlite3.Connection):
            row = self._get_loan(conn, loan_id)
            if row["borrower_id"] != borrower_id or row["status"] != "active":
                raise BankError("Không tìm thấy khoản nợ này của bạn (có thể đã trả xong).")
            remaining = row["amount"] - row["repaid"]
            pay = remaining if amount is None else min(amount, remaining)
            self.wallets._ensure(conn, row["lender_id"], now)
            self.wallets._apply(conn, borrower_id, -pay, "loan_repay", f"Trả nợ <@{row['lender_id']}> (#{loan_id})", now)
            self.wallets._apply(conn, row["lender_id"], pay, "loan_repaid_in", f"<@{borrower_id}> trả nợ (#{loan_id})", now)
            done = pay == remaining
            conn.execute("UPDATE loans SET repaid = repaid + ?, status = ? WHERE id = ?",
                         (pay, "repaid" if done else "active", loan_id))
            self._recalc_debt(conn, borrower_id)
            return (pay, _loan(self._get_loan(conn, loan_id)),
                    self.wallets._row_to_wallet(conn.execute("SELECT * FROM wallets WHERE user_id = ?", (borrower_id,)).fetchone()))
        return await self.db.transaction(work)

    async def collect_overdue(self) -> list[CollectEvent]:
        """Khoản vay quá hạn: tự trừ tiền mặt trong ví người vay (tối đa số có) trả cho người cho vay."""
        now = self._now()

        def work(conn: sqlite3.Connection) -> list[CollectEvent]:
            events: list[CollectEvent] = []
            rows = conn.execute("SELECT * FROM loans WHERE status = 'active' AND due_at <= ? ORDER BY id", (_utc_text(now),)).fetchall()
            for row in rows:
                remaining = row["amount"] - row["repaid"]
                self.wallets._ensure(conn, row["borrower_id"], now)
                self.wallets._ensure(conn, row["lender_id"], now)
                cash = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (row["borrower_id"],)).fetchone()["cash"]
                pay = min(cash, remaining)
                if pay > 0:
                    self.wallets._apply(conn, row["borrower_id"], -pay, "loan_auto", f"Tự trừ nợ quá hạn (#{row['id']})", now)
                    self.wallets._apply(conn, row["lender_id"], pay, "loan_repaid_in", f"Thu nợ quá hạn (#{row['id']})", now)
                    conn.execute("UPDATE loans SET repaid = repaid + ?, status = ? WHERE id = ?",
                                 (pay, "repaid" if pay == remaining else "active", row["id"]))
                first = row["notified_overdue"] == 0
                if first:
                    conn.execute("UPDATE loans SET notified_overdue = 1 WHERE id = ?", (row["id"],))
                self._recalc_debt(conn, row["borrower_id"])
                if pay > 0 or first:
                    events.append(CollectEvent(_loan(self._get_loan(conn, row["id"])), pay, first))
            return events
        return await self.db.transaction(work)
