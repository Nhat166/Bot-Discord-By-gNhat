"""Hệ thống cấp bậc: nhận XP khi chat, .rank, .leaderboard, .level, .xp-admin."""
from __future__ import annotations

import logging
import random
import re
import time
from collections import deque
from typing import Optional

import discord
from discord.ext import commands

import config
import xp_bank
from utils import fmt_int, fmt_percent, get_setting_id, guild_allowed, send_log

log = logging.getLogger("bot.leveling")

EMBED_COLOR = 0x6D3FE8
BAR_LENGTH = 20
_MENTION_RE = re.compile(r"<[^>\s]+>")  # mention, kênh, emoji tùy chỉnh
_admin_only = commands.has_guild_permissions(administrator=True)


def progress_bar(percent: float, length: int = BAR_LENGTH) -> str:
    filled = max(0, min(length, round(length * percent / 100)))
    return "▰" * filled + "▱" * (length - filled)


class Leveling(commands.Cog):
    """XP, cấp bậc và bảng xếp hạng."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._cooldowns: dict[tuple[int, int], float] = {}
        self._recent: dict[tuple[int, int], deque] = {}
        self._last_cleanup = time.monotonic()

    # ------------------------------------------------------------------
    # Nhận XP từ tin nhắn
    # ------------------------------------------------------------------
    def _cleanup(self, now: float) -> None:
        if now - self._last_cleanup < 600:
            return
        self._last_cleanup = now
        for key in [k for k, t in self._cooldowns.items() if now - t > max(config.XP_COOLDOWN_SECONDS, 1)]:
            del self._cooldowns[key]
        for key in [k for k, dq in self._recent.items()
                    if not dq or now - dq[-1][0] > config.XP_REPEAT_WINDOW_SECONDS]:
            del self._recent[key]

    def _is_repeated(self, key: tuple[int, int], now: float, text: str) -> bool:
        """True nếu cùng một nội dung đã lặp lại XP_REPEAT_LIMIT lần trong XP_REPEAT_WINDOW_SECONDS giây."""
        normalized = re.sub(r"\s+", " ", text.lower())
        window = self._recent.get(key)
        if window is None:
            window = self._recent[key] = deque(maxlen=max(config.XP_REPEAT_LIMIT * 2, 10))
        window.append((now, normalized))
        while window and now - window[0][0] > config.XP_REPEAT_WINDOW_SECONDS:
            window.popleft()
        return sum(1 for _, content in window if content == normalized) >= config.XP_REPEAT_LIMIT

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        guild = message.guild
        if guild is None or message.author.bot or message.webhook_id is not None:
            return
        if message.type not in (discord.MessageType.default, discord.MessageType.reply):
            return
        if not guild_allowed(guild):
            return

        # Lệnh của bot không tính XP.
        ctx = await self.bot.get_context(message)
        if ctx.command is not None:
            return

        # Chỉ tính tin nhắn văn bản đủ dài (bỏ mention/emoji khi đếm).
        clean = _MENTION_RE.sub("", message.content).strip()
        if len(clean) < config.XP_MIN_LENGTH:
            return

        key = (guild.id, message.author.id)
        now = time.monotonic()
        self._cleanup(now)

        if self._is_repeated(key, now, clean):
            return
        moderation = self.bot.get_cog("Moderation")
        if moderation is not None and moderation.is_flagged(*key):
            return
        last = self._cooldowns.get(key)
        if last is not None and now - last < config.XP_COOLDOWN_SECONDS:
            return
        self._cooldowns[key] = now  # đặt trước khi await để tin nhắn đến cùng lúc không nhận XP đôi

        amount = random.randint(config.XP_MIN, config.XP_MAX)
        try:
            change = await xp_bank.add_xp(
                message.author.id,
                guild.id,
                amount,
                "Tin nhắn hợp lệ",
                source="chat",
                ref=str(message.id),
            )
        except Exception:
            log.exception("Không cộng được XP cho %s trong máy chủ %s", message.author.id, guild.id)
            return
        if change.leveled_up:
            await self._announce_level_up(guild, message.author, message.channel, change)

    async def _announce_level_up(self, guild: discord.Guild, member: discord.Member,
                                 fallback_channel: discord.abc.Messageable,
                                 change: xp_bank.XPChange) -> None:
        channel = None
        channel_id = await get_setting_id(guild.id, "levelup_channel")
        if channel_id:
            channel = guild.get_channel(channel_id)
        if channel is None or not hasattr(channel, "send"):
            channel = fallback_channel
        level = change.new_level
        embed = discord.Embed(
            title="🎉 Đột phá cấp bậc!",
            description=(f"{member.mention} đã đạt **{level.name}** (Cấp độ {level.index}) "
                         f"với **{fmt_int(change.new_xp)} XP**."),
            color=EMBED_COLOR,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        try:
            await channel.send(embed=embed, allowed_mentions=discord.AllowedMentions(users=[member]))
        except (discord.Forbidden, discord.HTTPException) as exc:
            log.warning("Không gửi được thông báo lên cấp: %s", exc)

    # ------------------------------------------------------------------
    # Giao diện thẻ cấp bậc
    # ------------------------------------------------------------------
    async def build_rank_embed(self, member: discord.Member) -> discord.Embed:
        progress = await xp_bank.get_xp_progress(member.id, member.guild.id)
        rank = await xp_bank.get_rank(member.id, member.guild.id)
        level = progress.level
        rank_text = f"Rank #{rank}" if rank else "Chưa có hạng"

        lines = [f"Cấp độ {level.index} · {level.name} · {rank_text}"]
        if progress.remaining is None:
            lines.append(f"**{fmt_int(progress.xp)} XP** · đã đạt cấp bậc cao nhất")
            footer = "100% tiến độ"
        else:
            lines.append(f"**{fmt_int(progress.xp)} / {fmt_int(level.next_xp)} XP**")
            footer = (f"{fmt_percent(progress.percent)}% tiến độ · "
                      f"Còn {fmt_int(progress.remaining)} XP để lên {level.next_name}")
        lines.append(progress_bar(progress.percent))
        lines.append(footer)

        embed = discord.Embed(
            title=discord.utils.escape_markdown(member.display_name),
            description="\n".join(lines),
            color=EMBED_COLOR,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        return embed

    # ------------------------------------------------------------------
    # Lệnh cho thành viên
    # ------------------------------------------------------------------
    @commands.command(name="rank", help="Xem XP, cấp độ và tiến độ lên cấp. Dùng: .rank [@thành_viên]")
    @commands.guild_only()
    async def rank(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        if member.bot:
            await ctx.send("Bot không có XP.")
            return
        await ctx.send(embed=await self.build_rank_embed(member))

    @commands.command(name="leaderboard", aliases=["lb", "top"], help="Xem bảng xếp hạng XP của máy chủ.")
    @commands.guild_only()
    async def leaderboard(self, ctx: commands.Context) -> None:
        rows = await xp_bank.get_leaderboard(ctx.guild.id, 10)
        if not rows:
            await ctx.send("Chưa có ai có XP. Hãy bắt đầu trò chuyện nhé!")
            return
        medals = {1: "🥇", 2: "🥈", 3: "🥉"}
        lines = []
        for position, (user_id, xp) in enumerate(rows, start=1):
            member = ctx.guild.get_member(user_id)
            name = discord.utils.escape_markdown(member.display_name) if member else f"<@{user_id}>"
            level = xp_bank.level_for_xp(xp)
            marker = medals.get(position, f"`#{position}`")
            lines.append(f"{marker} **{name}** — {fmt_int(xp)} XP · {level.name}")
        embed = discord.Embed(title="🏆 Bảng xếp hạng XP", description="\n".join(lines), color=EMBED_COLOR)
        my_rank = await xp_bank.get_rank(ctx.author.id, ctx.guild.id)
        embed.set_footer(text=f"Hạng của bạn: #{my_rank}" if my_rank else "Bạn chưa có hạng")
        await ctx.send(embed=embed)

    @commands.command(name="level", aliases=["levels"], help="Xem thông tin về hệ thống cấp độ.")
    @commands.guild_only()
    async def level(self, ctx: commands.Context) -> None:
        tiers = [
            f"**Cấp {index} · {name}** — từ {fmt_int(required)} XP"
            for index, (name, required) in enumerate(config.LEVELS)
        ]
        embed = discord.Embed(title="📜 Hệ thống cấp độ", description="\n".join(tiers), color=EMBED_COLOR)
        embed.add_field(
            name="Cách nhận XP",
            value=(f"• Mỗi tin nhắn hợp lệ nhận ngẫu nhiên **{config.XP_MIN}–{config.XP_MAX} XP**.\n"
                   f"• Cách nhau tối thiểu **{config.XP_COOLDOWN_SECONDS} giây** giữa hai lần nhận.\n"
                   f"• Tin quá ngắn (dưới {config.XP_MIN_LENGTH} ký tự), tin lặp lại {config.XP_REPEAT_LIMIT} lần "
                   f"trong {config.XP_REPEAT_WINDOW_SECONDS} giây, tin spam và tin của bot không có XP."),
            inline=False,
        )
        embed.add_field(
            name="Công thức tiến độ",
            value="`(XP hiện có − XP đầu cấp) / (XP cấp tiếp theo − XP đầu cấp) × 100%`",
            inline=False,
        )
        embed.add_field(
            name="Lệnh",
            value=f"`{ctx.prefix}rank [@thành_viên]` · `{ctx.prefix}leaderboard` · `{ctx.prefix}level`",
            inline=False,
        )
        await ctx.send(embed=embed)

    # ------------------------------------------------------------------
    # Lệnh quản trị XP
    # LƯU Ý: với group đặt invoke_without_command=True, kiểm tra quyền của group KHÔNG áp dụng
    # cho lệnh con, nên mỗi lệnh con đều phải có @_admin_only riêng.
    # ------------------------------------------------------------------
    @commands.group(name="xp-admin", invoke_without_command=True,
                    help="Quản lý XP (chỉ quản trị viên). Dùng: .xp-admin add|remove <@thành_viên> <số_xp>")
    @commands.guild_only()
    @_admin_only
    async def xp_admin(self, ctx: commands.Context) -> None:
        await ctx.send(f"Cách dùng: `{ctx.prefix}xp-admin add <@thành_viên> <số_xp>` hoặc "
                       f"`{ctx.prefix}xp-admin remove <@thành_viên> <số_xp>`")

    @xp_admin.command(name="add", help="Cộng XP cho thành viên.")
    @commands.guild_only()
    @_admin_only
    async def xp_admin_add(self, ctx: commands.Context, member: discord.Member, amount: int) -> None:
        if member.bot:
            await ctx.send("❌ Không thể cộng XP cho bot.")
            return
        try:
            change = await xp_bank.add_xp(
                member.id, ctx.guild.id, amount,
                f"Quản trị viên {ctx.author} cộng XP",
                source="admin", actor_id=ctx.author.id,
            )
        except xp_bank.XPError as exc:
            await ctx.send(f"❌ {exc}")
            return
        await ctx.send(
            f"✅ Đã cộng **{fmt_int(change.applied)} XP** cho {member.mention}. "
            f"Tổng: **{fmt_int(change.new_xp)} XP** ({change.new_level.name}).",
            allowed_mentions=discord.AllowedMentions.none(),
        )
        await send_log(
            ctx.guild,
            title="➕ Quản trị viên cộng XP",
            description=f"{ctx.author.mention} cộng **{fmt_int(change.applied)} XP** cho {member.mention}.",
            color=0x2ECC71,
        )
        if change.leveled_up:
            await self._announce_level_up(ctx.guild, member, ctx.channel, change)

    @xp_admin.command(name="remove", help="Trừ XP của thành viên.")
    @commands.guild_only()
    @_admin_only
    async def xp_admin_remove(self, ctx: commands.Context, member: discord.Member, amount: int) -> None:
        if member.bot:
            await ctx.send("❌ Không thể trừ XP của bot.")
            return
        try:
            change = await xp_bank.remove_xp(
                member.id, ctx.guild.id, amount,
                f"Quản trị viên {ctx.author} trừ XP",
                source="admin", actor_id=ctx.author.id,
            )
        except xp_bank.XPError as exc:
            await ctx.send(f"❌ {exc}")
            return
        if change.applied == 0:
            await ctx.send(f"ℹ️ {member.mention} hiện không có XP để trừ.",
                           allowed_mentions=discord.AllowedMentions.none())
            return
        await ctx.send(
            f"✅ Đã trừ **{fmt_int(change.applied)} XP** của {member.mention}. "
            f"Tổng: **{fmt_int(change.new_xp)} XP** ({change.new_level.name}).",
            allowed_mentions=discord.AllowedMentions.none(),
        )
        await send_log(
            ctx.guild,
            title="➖ Quản trị viên trừ XP",
            description=f"{ctx.author.mention} trừ **{fmt_int(change.applied)} XP** của {member.mention}.",
            color=0xE67E22,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Leveling(bot))
