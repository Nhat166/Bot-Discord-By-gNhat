# Discord Bot đa chức năng

Bot viết bằng Python (`discord.py`): phát nhạc YouTube, quản trị máy chủ (chào mừng, gán role, chống spam, nhật ký) và hệ thống cấp độ XP với ngân hàng XP dùng chung lưu bằng SQLite. Lệnh dùng tiền tố `.`

## 1. Cấu trúc

```
discord-bot/
├── main.py          # Khởi chạy bot, nạp module, xử lý lỗi lệnh
├── music.py         # Phát nhạc YouTube, hàng chờ
├── moderation.py    # Chống spam, nhật ký, lệnh .config
├── welcome.py       # Chào mừng, tự gán role Member, .addrole
├── leveling.py      # Nhận XP khi chat, .rank .leaderboard .level .xp-admin
├── xp_bank.py       # Ngân hàng XP: get/add/remove_xp, cấp bậc, tiến độ
├── database.py      # SQLite: tạo bảng, truy vấn, giao dịch
├── utils.py         # Định dạng số, đọc thiết lập, gửi nhật ký
├── config.py        # Toàn bộ cấu hình (đọc từ .env)
├── requirements.txt
├── .env.example     # Mẫu file cấu hình; đổi tên thành .env
└── .gitignore
```

## 2. Danh sách lệnh

| Nhóm | Lệnh | Chức năng |
|---|---|---|
| Nhạc | `.play <tên bài hoặc URL>` | Phát nhạc / thêm vào hàng chờ (bot tự vào kênh thoại của bạn) |
| | `.dung` / `.again` | Tạm dừng / tiếp tục |
| | `.skip` | Bỏ qua bài hiện tại |
| | `.stop` | Dừng nhạc và xóa hàng chờ |
| | `.danhsach` | Xem hàng chờ |
| | `.nowplay` | Xem bài đang phát |
| | `.volume <0-100>` | Chỉnh âm lượng |
| Quản trị | `.addrole <tên role hoặc ID> <@thành viên hoặc ID>` | Gán role (cần quyền Manage Roles) |
| | `.config` | Xem / đổi kênh chào mừng, kênh log, kênh lên cấp, role Member (cần quyền Manage Server) |
| | `.testwelcome` | Gửi thử lời chào mừng |
| XP | `.rank [@thành viên]` | Xem XP, cấp độ, tiến độ |
| | `.leaderboard` | Bảng xếp hạng top 10 |
| | `.level` | Thông tin hệ thống cấp độ |
| | `.xp-admin add <@thành viên> <số XP>` | Cộng XP (chỉ quản trị viên) |
| | `.xp-admin remove <@thành viên> <số XP>` | Trừ XP (chỉ quản trị viên) |

Dùng `.help` để xem danh sách ngay trong Discord. Khi bạn dùng lệnh nhạc, bạn phải ở cùng kênh thoại với bot.

## 3. Tạo bot trên Discord Developer Portal

1. Vào https://discord.com/developers/applications → **New Application** → đặt tên.
2. Mở tab **Bot** → **Reset Token** → sao chép token (chỉ hiện một lần) và dán vào `.env`.
3. Vẫn ở tab **Bot**, kéo xuống **Privileged Gateway Intents** và **bật cả hai**:
   - **Server Members Intent** (chào mừng, gán role)
   - **Message Content Intent** (đọc lệnh `.`, đếm XP, chống spam)
4. Mời bot vào máy chủ. Thay `YOUR_CLIENT_ID` bằng *Application ID* (tab **General Information**) trong đường dẫn sau:

   ```
   https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot&permissions=1099783302144
   ```

   Đường dẫn này cấp các quyền: View Channels, Send Messages, Embed Links, Read Message History, Manage Messages (xóa tin spam), Manage Roles (gán role), Moderate Members (timeout), Connect, Speak (nhạc).
5. **Quan trọng:** trong Discord vào *Cài đặt máy chủ → Vai trò (Roles)* và kéo role của bot **lên trên** role `Member`. Bot không thể gán hoặc xử lý role/thành viên nằm cao hơn nó.

## 4. Cấu hình ID máy chủ, kênh, role

1. Bật chế độ nhà phát triển: *Cài đặt người dùng → Nâng cao → Chế độ nhà phát triển*.
2. Chuột phải vào máy chủ / kênh / role → **Sao chép ID**.
3. Có hai cách cấu hình:
   - **Trong file `.env`:** điền `GUILD_ID`, `WELCOME_CHANNEL_ID`, `LOG_CHANNEL_ID`, `MEMBER_ROLE_ID`, `LEVELUP_CHANNEL_ID`.
   - **Ngay trong Discord (khuyên dùng, không cần khởi động lại):**
     ```
     .config welcome_channel #chao-mung
     .config log_channel #nhat-ky
     .config member_role @Member
     .config levelup_channel #thong-bao-cap
     ```
     Dùng `off` để tắt, `reset` để quay về giá trị trong `.env`. Giá trị đặt bằng `.config` được lưu vào SQLite và **ưu tiên hơn** `.env`.

`GUILD_ID` (tùy chọn): nếu điền, bot chỉ hoạt động trong máy chủ đó. Các thiết lập khác (ngưỡng spam, XP, âm lượng mặc định...) nằm trong `.env`, xem chú thích trong `.env.example`.

## 5. Chạy bot

Yêu cầu: **Python 3.10 trở lên** và **FFmpeg** (bắt buộc cho phát nhạc).

```bash
# 1. Cài FFmpeg
#    Windows:  winget install Gyan.FFmpeg      (rồi mở lại terminal)
#    macOS:    brew install ffmpeg
#    Ubuntu:   sudo apt install ffmpeg
ffmpeg -version          # kiểm tra đã cài

# 2. Tạo môi trường và cài thư viện
python -m venv venv
venv\Scripts\activate           # Windows
source venv/bin/activate        # macOS / Linux
pip install -r requirements.txt

# 3. Tạo file cấu hình
copy .env.example .env          # Windows  (macOS/Linux: cp .env.example .env)
# mở .env và điền DISCORD_TOKEN

# 4. Chạy
python main.py
```

Lần chạy đầu bot tự tạo thư mục `data/` và file `data/bot.db` (XP, cấp độ, thiết lập). **Nhớ sao lưu file này.** Nhật ký chạy được ghi vào `bot.log`.

**Chạy trên hosting/VPS:** cần máy hỗ trợ Python 3.10+, cài được FFmpeg, kết nối ra internet và có ổ đĩa lưu trữ lâu dài để giữ `data/bot.db` (nếu ổ đĩa bị xóa mỗi lần khởi động lại thì XP sẽ mất). Đặt token bằng biến môi trường hoặc file `.env`, chạy bằng `python main.py` và dùng systemd/pm2/supervisor để tự khởi động lại khi bot dừng. Lưu ý: YouTube thường chặn các IP của trung tâm dữ liệu, nên nhạc có thể chạy ổn trên máy cá nhân nhưng lỗi trên VPS (xem mục 8).

## 6. Cách hoạt động của các chức năng chính

**Chống spam.** Một thành viên bị coi là spam khi gửi **nhiều hơn 23 tin nhắn** trong **30 giây** (`SPAM_MESSAGE_LIMIT`, `SPAM_WINDOW_SECONDS`). Khi đó bot xóa các tin trong đợt spam, cảnh báo thành viên (tin cảnh báo tự xóa sau 20 giây) và ghi vào kênh log. Sau **3 lần vi phạm trong 10 phút** (`SPAM_TIMEOUT_AFTER`, `SPAM_VIOLATION_WINDOW_SECONDS`) thành viên bị timeout 10 phút. Quản trị viên, bot và các role trong `SPAM_EXEMPT_ROLE_IDS` được miễn; có thể giới hạn kênh bằng `SPAM_CHANNEL_IDS`. Con số 23 được lấy đúng theo tài liệu; nếu muốn bot nhạy hơn, hạ `SPAM_MESSAGE_LIMIT` (ví dụ 8).

**Nhạc: tự rời kênh.** Bot rời kênh thoại sau `MUSIC_IDLE_TIMEOUT` giây (mặc định 300) khi hết nhạc, hoặc sau 60 giây khi kênh không còn người thật (quay lại kịp thì bot ở lại).

**XP và cấp bậc.** Mỗi tin nhắn hợp lệ cho 15–25 XP, cách nhau tối thiểu 2 giây (`XP_COOLDOWN_SECONDS`; tăng giá trị này nếu muốn hạn chế việc cày cấp). Không tính XP cho: tin của bot, lệnh của bot, tin dưới 2 ký tự (`XP_MIN_LENGTH`), tin lặp lại 5 lần trong 15 giây, và thành viên vừa bị phát hiện spam.

| Cấp | Tên | Tổng XP tối thiểu |
|---|---|---|
| 0 | Phàm Nhân (mốc xuất phát) | 0 |
| 1 | Luyện Khí Kỳ | 100 |
| 2 | Trúc Cơ Kỳ | 300 |
| 3 | Kết Đan Kỳ | 600 |
| 4 | Nguyên Anh Kỳ | 1.500 |
| 5 | Hoá Thần Kỳ | 5.500 |
| 6 | Luyện Hư Kỳ | 21.000 |
| 7 | Hợp Thể Kỳ | 127.500 |
| 8 | Đại Thường Kỳ | 505.000 |

Tiến độ = (XP hiện có − XP đầu cấp) / (XP cấp tiếp theo − XP đầu cấp) × 100%. Ví dụ thành viên có 10.000 XP đang ở Hoá Thần Kỳ: (10.000 − 5.500) / (21.000 − 5.500) = 29,0%, còn 11.000 XP để lên Luyện Hư Kỳ.

**Ngân hàng XP (`xp_bank.py`).** Mọi module muốn cộng/trừ XP đều phải gọi `add_xp` / `remove_xp` để chỉ có một nguồn dữ liệu. Mỗi giao dịch ghi vào bảng `xp_transactions` (người nhận, số XP, lý do, thời gian, nguồn, người thực hiện). Giao dịch chạy trong transaction của SQLite, XP không bao giờ âm, và tham số `ref` (ví dụ ID tin nhắn) giúp **không cộng trùng**. Ví dụ dùng cho một sự kiện mới:

```python
import xp_bank
await xp_bank.add_xp(user_id, guild_id, 50, "Thắng sự kiện đoán số",
                     source="event", ref="doan-so-2026-10-11")
```

Các hàm trong `xp_bank.py` không tự kiểm tra quyền, vì chúng chỉ dành cho code của bot. Lệnh dành cho người dùng (như `.xp-admin`) kiểm tra quyền quản trị trước khi gọi.

## 7. Hướng dẫn kiểm thử từng chức năng

Làm theo thứ tự, ở một máy chủ thử:

1. **Khởi động:** chạy `python main.py`, log phải hiện `Đã nạp module: music, welcome, moderation, leveling` và `Đã đăng nhập`. Gõ `.help` trong Discord.
2. **Cấu hình:** gõ `.config` để xem thiết lập, rồi đặt kênh log, kênh chào mừng, role Member như mục 4.
3. **Chào mừng:** gõ `.testwelcome` (gửi thử vào kênh chào mừng). Để thử thật, dùng một tài khoản phụ vào máy chủ: phải có lời chào và tài khoản đó nhận role Member. Nếu thiếu quyền hoặc role đặt sai, lỗi sẽ xuất hiện ở kênh log.
4. **`.addrole`:** `.addrole VIP @tài_khoản_phụ` (thử cả bằng ID role/ID thành viên). Thử với role cao hơn bot để thấy thông báo từ chối.
5. **XP:** chat vài tin nhắn (mỗi tin cách nhau hơn 2 giây, dài từ 2 ký tự), gõ `.rank` để thấy XP tăng. Thử `.xp-admin add @bạn 100` (cần quyền Administrator), `.leaderboard`, `.level`. Dùng tài khoản thường gõ `.xp-admin add ...` để chắc chắn bị từ chối.
6. **Lưu dữ liệu:** tắt bot, bật lại, gõ `.rank`, XP phải còn nguyên.
7. **Chống spam (dùng tài khoản phụ không phải admin):** để thử nhanh, tạm đặt `SPAM_MESSAGE_LIMIT=5` trong `.env`, khởi động lại rồi gửi liên tục 6 tin. Bot phải xóa tin, cảnh báo và ghi log; lần vi phạm thứ 3 sẽ bị timeout. Nhớ đặt lại giá trị sau khi thử.
8. **Nhạc:** vào kênh thoại, gõ `.play lofi hip hop`, `.nowplay`, `.volume 30`, `.dung`, `.again`, `.play <một URL YouTube>` (vào hàng chờ), `.danhsach`, `.skip`, `.stop`.

## 8. Xử lý lỗi thường gặp

| Hiện tượng | Cách xử lý |
|---|---|
| `Chưa bật Privileged Intents` khi chạy | Bật **Server Members Intent** và **Message Content Intent** ở tab Bot (mục 3.3). |
| `Token không hợp lệ` | Reset token trong Developer Portal, dán lại vào `.env`, không có dấu ngoặc hoặc khoảng trắng thừa. |
| Bot online nhưng không trả lời lệnh | Thường do chưa bật Message Content Intent, hoặc bot thiếu quyền *View Channel / Send Messages* ở kênh đó, hoặc `GUILD_ID` điền sai máy chủ. Xem `bot.log`. |
| Không gán được role Member | Role của bot phải nằm **trên** role Member; bot cần quyền Manage Roles; kiểm tra `.config`. Lỗi cụ thể được ghi ở kênh log. |
| Không xóa được tin spam / không timeout | Cấp bot quyền Manage Messages / Moderate Members. Bot không timeout được chủ máy chủ hoặc người có role cao hơn bot. |
| `.play` báo "Không khởi động được FFmpeg" | Chưa cài FFmpeg hoặc chưa thêm vào PATH: chạy `ffmpeg -version` để kiểm tra. |
| Bot vào kênh thoại rồi rớt ngay / không có tiếng | Cập nhật thư viện: `pip install -U "discord.py[voice]"` (Discord thỉnh thoảng đổi giao thức thoại). Kiểm tra quyền Connect/Speak của bot ở kênh đó. |
| `.play` báo YouTube yêu cầu xác minh / chặn bot / không lấy được nguồn | Chạy `pip install -U yt-dlp` rồi khởi động lại bot. Nếu vẫn lỗi, thường do IP máy chủ bị YouTube hạn chế: thử chạy trên máy cá nhân, hoặc xuất `cookies.txt` từ trình duyệt đã đăng nhập (dùng tài khoản phụ) và đặt `YTDLP_COOKIES_FILE=cookies.txt` trong `.env`. |
| Video "không khả dụng" | Video bị xóa, riêng tư, giới hạn độ tuổi hoặc bị chặn theo khu vực. Thử bài khác. |
| Lệnh slash không thấy | Bot dùng lệnh tiền tố `.`, không phải lệnh slash `/`. |
| XP bị mất sau khi triển khai lại | `data/bot.db` nằm trên ổ đĩa tạm. Đặt `DATABASE_PATH` sang ổ lưu trữ lâu dài và sao lưu định kỳ. |

## 9. Lưu ý về nguồn nhạc

Bot lấy luồng âm thanh YouTube bằng **yt-dlp** rồi phát qua FFmpeg. Đây là cách phổ biến, hoạt động tốt, nhưng **không phải API chính thức của YouTube** và có thể không phù hợp với điều khoản dịch vụ của YouTube; YouTube cũng thường xuyên thay đổi khiến yt-dlp cần cập nhật. Hãy dùng cho máy chủ riêng/cá nhân, không dùng thương mại, và tự cân nhắc rủi ro. Vì vậy phần nguồn nhạc được tách riêng (`build_target`, `extract_info`, `make_track` trong `music.py`) để bạn dễ thay bằng nguồn khác (ví dụ file nhạc bạn có quyền sử dụng) mà không phải viết lại phần điều khiển. Bot chỉ chấp nhận đường dẫn thuộc YouTube; mọi đường dẫn khác bị từ chối.

## 10. Bảo mật

- Không chia sẻ `DISCORD_TOKEN`, không đưa `.env` lên GitHub (đã có trong `.gitignore`). Nếu lỡ lộ token, hãy Reset Token ngay.
- `.xp-admin` yêu cầu quyền Administrator; `.addrole` yêu cầu Manage Roles và tôn trọng thứ bậc role; `.config` yêu cầu Manage Server.
