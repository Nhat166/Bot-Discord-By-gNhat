"""Quản lý kênh chat: .lock, .unlock và .clear.

    .lock [#kênh] [lý do]     # đóng kênh: @everyone không gửi được tin (mặc định là kênh đang gõ lệnh)
    .unlock [#kênh] [lý do]   # mở lại kênh
    .clear <số> [@thành_viên] # xóa <số> tin nhắn gần nhất trong kênh (tối đa 100)

Cách .lock hoạt động: đặt quyền "Gửi tin nhắn" của @everyone trong kênh thành ✖. Quyền được cấp
riêng cho một role ngay trong kênh (ví dụ role Mod có dấu ✔ Gửi tin nhắn ở kênh này) vẫn được
giữ, nên đó là cách để cho phép một nhóm vẫn chat khi kênh đóng. Quản trị viên luôn chat được.
Bot cần quyền Manage Roles (để sửa quyền kênh) và được tự thêm quyền gửi tin riêng cho nó
trong kênh, nếu không chính bot cũng bị khóa theo @everyone.
"""
from __future__ import annotations

import logging
from datetime import timedelta
from typing import Optional

import discord
from discord.ext import commands

import ui
from database import db
from utils import send_log

log = logging.getLogger("bot.channel_tools")

MAX_CLEAR = 100
BULK_DELETE_DAYS = 14  # Discord chỉ xóa hàng loạt được tin nhắn chưa quá 14 ngày


def _key(channel_id: int) -> str:
    return f"lock_prev:{channel_id}"


class ChannelTools(commands.Cog):
    """Đóng/mở kênh và dọn tin nhắn."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # Tiện ích
    # ------------------------------------------------------------------
    @staticmethod
    def _check_permissions(ctx: commands.Context, channel: discord.TextChannel) -> Optional[str]:
        """Thông báo lỗi nếu người gọi hoặc bot không đủ quyền TRONG KÊNH ĐÓ, ngược lại None."""
        if not channel.permissions_for(ctx.author).manage_channels:
            return f"Bạn không có quyền **Manage Channels** ở {channel.mention}."
        me_perms = channel.permissions_for(ctx.guild.me)
        if not me_perms.manage_roles:
            return f"Bot thiếu quyền **Manage Roles** ở {channel.mention} (cần để sửa quyền của kênh)."
        return None

    @staticmethod
    def _reason(ctx: commands.Context, reason: Optional[str]) -> str:
        text = (reason or "").strip()
        return text or f"Không có lý do (bởi {ctx.author})"

    @staticmethod
    def _bypass_roles(channel: discord.TextChannel) -> list[discord.Role]:
        """Các role đang được cho phép gửi tin riêng trong kênh (vẫn chat được khi kênh bị khóa)."""
        roles = []
        for target, overwrite in channel.overwrites.items():
            if isinstance(target, discord.Role) and not target.is_default() and overwrite.send_messages is True:
                roles.append(target)
        return roles

    # ------------------------------------------------------------------
    # .lock
    # ------------------------------------------------------------------
    @commands.command(name="lock", help="Đóng kênh chat, không cho thành viên gửi tin. Dùng: .lock [#kênh] [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def lock(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None, *,
                   reason: Optional[str] = None) -> None:
        channel = channel or ctx.channel
        if not isinstance(channel, discord.TextChannel):
            await ctx.send(embed=ui.error("Chỉ khóa được kênh chat văn bản.", ctx=ctx))
            return
        problem = self._check_permissions(ctx, channel)
        if problem:
            await ctx.send(embed=ui.error(problem, ctx=ctx))
            return

        guild = ctx.guild
        everyone = guild.default_role
        overwrite = channel.overwrites_for(everyone)
        if overwrite.send_messages is False:
            await ctx.send(embed=ui.info(f"{channel.mention} đã bị khóa rồi. Dùng `{ctx.prefix}unlock` để mở.",
                                         title="🔒 Đã khóa sẵn", ctx=ctx))
            return

        full_reason = self._reason(ctx, reason)
        audit = f"Lock bởi {ctx.author} ({ctx.author.id}): {full_reason}"[:512]
        try:
            # 1) Bot tự cấp quyền gửi tin cho mình trước, nếu không bot cũng bị khóa theo @everyone.
            me = guild.me
            if not me.guild_permissions.administrator:
                mine = channel.overwrites_for(me)
                if mine.send_messages is not True:
                    mine.send_messages = True
                    await channel.set_permissions(me, overwrite=mine, reason="Giữ quyền gửi tin của bot khi lock")
            # 2) Nhớ trạng thái cũ của @everyone để .unlock trả về đúng.
            await db.set_setting(guild.id, _key(channel.id), "1" if overwrite.send_messages is True else "n")
            overwrite.send_messages = False
            await channel.set_permissions(everyone, overwrite=overwrite, reason=audit)
        except discord.Forbidden:
            await ctx.send(embed=ui.error(
                "Discord từ chối: bot thiếu quyền sửa quyền của kênh này "
                "(kiểm tra Manage Roles và quyền riêng của kênh).", ctx=ctx))
            return
        except discord.HTTPException as exc:
            await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
            return

        bypass = self._bypass_roles(channel)
        embed = ui.make("🔒 Đã khóa kênh", f"{channel.mention} đã đóng, thành viên không gửi được tin nhắn.",
                        color=ui.Color.WARNING, ctx=ctx)
        embed.add_field(name="🛡️ Thực hiện bởi", value=ctx.author.mention, inline=True)
        embed.add_field(name="📝 Lý do", value=full_reason[:1024], inline=False)
        if bypass:
            embed.add_field(
                name="ℹ️ Vẫn chat được",
                value=("Các role được cấp quyền gửi tin riêng trong kênh: "
                       + " ".join(r.mention for r in bypass[:10])),
                inline=False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

        # Báo cho thành viên ngay trong kênh bị khóa (nếu lệnh gõ ở kênh khác).
        if channel.id != ctx.channel.id:
            notice = ui.make("🔒 Kênh đã bị khóa", f"Kênh này tạm đóng.\n**Lý do:** {full_reason[:500]}",
                             color=ui.Color.WARNING)
            try:
                await channel.send(embed=notice, allowed_mentions=discord.AllowedMentions.none())
            except (discord.Forbidden, discord.HTTPException) as exc:
                log.warning("Không gửi được thông báo khóa vào %s: %s", channel.id, exc)

        await send_log(guild, title="🔒 Khóa kênh",
                       description=f"{ctx.author.mention} đã khóa {channel.mention}.",
                       color=0xF39C12, fields=[("Lý do", full_reason, False)])

    # ------------------------------------------------------------------
    # .unlock
    # ------------------------------------------------------------------
    @commands.command(name="unlock", help="Mở lại kênh chat. Dùng: .unlock [#kênh] [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def unlock(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None, *,
                     reason: Optional[str] = None) -> None:
        channel = channel or ctx.channel
        if not isinstance(channel, discord.TextChannel):
            await ctx.send(embed=ui.error("Chỉ mở được kênh chat văn bản.", ctx=ctx))
            return
        problem = self._check_permissions(ctx, channel)
        if problem:
            await ctx.send(embed=ui.error(problem, ctx=ctx))
            return

        guild = ctx.guild
        everyone = guild.default_role
        overwrite = channel.overwrites_for(everyone)
        if overwrite.send_messages is not False:
            await ctx.send(embed=ui.info(f"{channel.mention} đang mở sẵn, không cần mở.",
                                         title="🔓 Không cần mở", ctx=ctx))
            return

        full_reason = self._reason(ctx, reason)
        audit = f"Unlock bởi {ctx.author} ({ctx.author.id}): {full_reason}"[:512]
        previous = await db.get_setting(guild.id, _key(channel.id))
        overwrite.send_messages = True if previous == "1" else None  # None = trở về "kế thừa"
        try:
            # Overwrite trống hoàn toàn thì xóa hẳn dòng quyền của @everyone cho gọn.
            if overwrite.is_empty():
                await channel.set_permissions(everyone, overwrite=None, reason=audit)
            else:
                await channel.set_permissions(everyone, overwrite=overwrite, reason=audit)
        except discord.Forbidden:
            await ctx.send(embed=ui.error("Discord từ chối: bot thiếu quyền sửa quyền của kênh này.", ctx=ctx))
            return
        except discord.HTTPException as exc:
            await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
            return
        await db.delete_setting(guild.id, _key(channel.id))

        embed = ui.make("🔓 Đã mở kênh", f"{channel.mention} đã mở, thành viên chat lại được.",
                        color=ui.Color.SUCCESS, ctx=ctx)
        embed.add_field(name="🛡️ Thực hiện bởi", value=ctx.author.mention, inline=True)
        embed.add_field(name="📝 Lý do", value=full_reason[:1024], inline=False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

        if channel.id != ctx.channel.id:
            notice = ui.make("🔓 Kênh đã được mở lại", "Bạn có thể chat bình thường.", color=ui.Color.SUCCESS)
            try:
                await channel.send(embed=notice, allowed_mentions=discord.AllowedMentions.none())
            except (discord.Forbidden, discord.HTTPException) as exc:
                log.warning("Không gửi được thông báo mở vào %s: %s", channel.id, exc)

        await send_log(guild, title="🔓 Mở kênh",
                       description=f"{ctx.author.mention} đã mở {channel.mention}.",
                       color=0x2ECC71, fields=[("Lý do", full_reason, False)])

    # ------------------------------------------------------------------
    # .clear
    # ------------------------------------------------------------------
    @commands.command(name="clear", aliases=["purge"],
                      help="Xóa N tin nhắn gần nhất trong kênh (tối đa 100). Dùng: .clear <số> [@thành_viên]")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_messages=True)
    @commands.bot_has_guild_permissions(manage_messages=True, read_message_history=True)
    async def clear(self, ctx: commands.Context, amount: int, member: Optional[discord.Member] = None) -> None:
        channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            await ctx.send(embed=ui.error("Chỉ dọn được tin nhắn trong kênh chat văn bản.", ctx=ctx))
            return
        # has_guild_permissions chỉ xét quyền toàn máy chủ; kiểm tra thêm quyền thật tại kênh này.
        if not channel.permissions_for(ctx.author).manage_messages:
            await ctx.send(embed=ui.error("Bạn không có quyền **Manage Messages** ở kênh này.", ctx=ctx))
            return
        my_perms = channel.permissions_for(ctx.guild.me)
        if not (my_perms.manage_messages and my_perms.read_message_history):
            await ctx.send(embed=ui.error("Bot thiếu quyền **Manage Messages** hoặc **Read Message History** "
                                          "ở kênh này.", ctx=ctx))
            return
        if not 1 <= amount <= MAX_CLEAR:
            await ctx.send(embed=ui.error(f"Số tin nhắn phải từ **1** đến **{MAX_CLEAR}**.", ctx=ctx))
            return

        # Xóa tin lệnh trước để nó không bị tính vào số tin cần dọn.
        try:
            await ctx.message.delete()
        except (discord.Forbidden, discord.NotFound, discord.HTTPException):
            pass

        # Duyệt từ tin MỚI nhất lùi về trước, dừng ở mốc 14 ngày (giới hạn xóa hàng loạt của Discord).
        oldest = discord.utils.utcnow() - timedelta(days=BULK_DELETE_DAYS) + timedelta(minutes=5)
        try:
            if member is None:
                deleted = await channel.purge(limit=amount, after=oldest, oldest_first=False, bulk=True)
            else:
                deleted = await self._purge_member(channel, amount, member, oldest)
        except discord.Forbidden:
            await channel.send(embed=ui.error("Discord từ chối: bot không xóa được tin nhắn ở kênh này.", ctx=ctx),
                               delete_after=10)
            return
        except discord.HTTPException as exc:
            await channel.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx), delete_after=10)
            return

        count = len(deleted)
        text = f"Đã xóa **{count}** tin nhắn" + (f" của {member.mention}" if member else "") + "."
        if count < amount:
            text += (f"\n*Ít hơn {amount} tin vì kênh không đủ tin, hoặc tin đã quá {BULK_DELETE_DAYS} ngày "
                     "(Discord không cho xóa hàng loạt).*")
        await channel.send(embed=ui.success(text, title="🧹 Đã dọn kênh", ctx=ctx), delete_after=6,
                           allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="🧹 Dọn tin nhắn",
                       description=f"{ctx.author.mention} đã xóa {count} tin nhắn ở {channel.mention}"
                                   + (f" của {member.mention}." if member else "."),
                       color=0x95A5A6)

    @staticmethod
    async def _purge_member(channel: discord.TextChannel, amount: int, member: discord.Member,
                            oldest) -> list[discord.Message]:
        """Xóa tối đa `amount` tin gần nhất CỦA `member` (quét tối đa 500 tin gần đây)."""
        targets: list[discord.Message] = []
        async for message in channel.history(limit=500, after=oldest, oldest_first=False):
            if message.author.id == member.id:
                targets.append(message)
                if len(targets) >= amount:
                    break
        if len(targets) == 1:
            await targets[0].delete()
        elif targets:
            await channel.delete_messages(targets)
        return targets


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ChannelTools(bot))
