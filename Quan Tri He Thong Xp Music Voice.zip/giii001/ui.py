"""Giao diện dùng chung cho các lệnh: màu sắc, biểu tượng cảnh giới, embed thành công/lỗi, thanh tiến độ.

Mọi lệnh nên tạo embed qua các hàm ở đây để bot có một phong cách thống nhất:

    ui.success("Đã lưu.", ctx=ctx)
    ui.error("Không tìm thấy role.", ctx=ctx)
    ui.make("Tiêu đề", "Nội dung", color=ui.Color.INFO, ctx=ctx)

Muốn đổi biểu tượng cảnh giới hoặc màu chủ đạo, chỉ cần sửa file này.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import discord

from utils import fmt_int, fmt_percent

if TYPE_CHECKING:  # chỉ để gợi ý kiểu, không import thật (tránh vòng lặp)
    from discord.ext import commands

    from xp_bank import LevelInfo, XPProgress


class Color:
    BRAND = 0x6D3FE8
    INFO = 0x5865F2
    SUCCESS = 0x2ECC71
    WARNING = 0xF39C12
    ERROR = 0xE74C3C
    XP_UP = 0x2ECC71
    XP_DOWN = 0xE67E22
    GOLD = 0xF1C40F


# Biểu tượng cho từng cảnh giới, theo thứ tự trong config.LEVELS (thiếu thì dùng ✨).
REALM_ICONS = ["🌱", "🍃", "🌊", "🔥", "🌙", "⚡", "🌌", "☯️", "👑"]

# Đặt False để KHÔNG hiện icon cảnh giới ở bất kỳ đâu (chỉ còn tên cảnh giới).
SHOW_REALM_ICONS = False


def realm_prefix(index: int) -> str:
    """'🌊 ' (kèm khoảng trắng) hoặc '' khi tắt icon: dùng để ghép trước tên cảnh giới."""
    if not SHOW_REALM_ICONS:
        return ""
    return (REALM_ICONS[index] if 0 <= index < len(REALM_ICONS) else "✨") + " "


def realm_label(level: "LevelInfo") -> str:
    """'🌊 Trúc Cơ Kỳ' hoặc 'Trúc Cơ Kỳ' khi tắt icon."""
    return f"{realm_prefix(level.index)}{level.name}"


def progress_bar(percent: float, length: int = 20) -> str:
    filled = max(0, min(length, round(length * percent / 100)))
    return "▰" * filled + "▱" * (length - filled)


def progress_text(progress: "XPProgress", length: int = 16) -> str:
    """Thanh tiến độ + dòng 'còn bao nhiêu XP để lên cấp'."""
    if progress.remaining is None:
        return f"{progress_bar(100, length)} **100%**\nĐã đạt cảnh giới cao nhất"
    return (f"{progress_bar(progress.percent, length)} **{fmt_percent(progress.percent)}%**\n"
            f"Còn **{fmt_int(progress.remaining)} XP** để lên **{progress.level.next_name}**")


def make(
    title: str,
    description: str = "",
    *,
    color: int = Color.INFO,
    ctx: Optional["commands.Context"] = None,
    thumbnail: Optional[str] = None,
    footer: Optional[str] = None,
    timestamp: bool = True,
) -> discord.Embed:
    """Embed chuẩn: tiêu đề, mô tả, chân trang 'Yêu cầu bởi ...' (nếu có ctx) và thời gian."""
    embed = discord.Embed(title=title[:256], description=description[:4000], color=color)
    if timestamp:
        embed.timestamp = discord.utils.utcnow()
    if thumbnail:
        embed.set_thumbnail(url=thumbnail)
    if ctx is not None or footer is not None:
        text = footer if footer is not None else f"Yêu cầu bởi {ctx.author.display_name}"
        icon = ctx.author.display_avatar.url if ctx is not None else None
        embed.set_footer(text=text[:2048], icon_url=icon)
    return embed


def success(description: str, *, title: str = "✅ Thành công", **kwargs) -> discord.Embed:
    return make(title, description, color=Color.SUCCESS, **kwargs)


def error(description: str, *, title: str = "❌ Không thực hiện được", **kwargs) -> discord.Embed:
    return make(title, description, color=Color.ERROR, **kwargs)


def warning(description: str, *, title: str = "⚠️ Lưu ý", **kwargs) -> discord.Embed:
    return make(title, description, color=Color.WARNING, **kwargs)


def info(description: str, *, title: str = "ℹ️ Thông tin", **kwargs) -> discord.Embed:
    return make(title, description, color=Color.INFO, **kwargs)
