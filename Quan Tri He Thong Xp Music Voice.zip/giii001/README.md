# Discord Bot đa chức năng

Bot viết bằng Python (`discord.py`): phát nhạc YouTube, quản trị máy chủ (chào mừng, gán role, chống spam, nhật ký) và hệ thống cấp độ XP với ngân hàng XP dùng chung lưu bằng SQLite. Lệnh dùng tiền tố `.`

## 1. Cấu trúc

```
discord-bot/
├── main.py               # Khởi chạy bot, nạp module, xử lý lỗi lệnh
├── music.py              # Phát nhạc YouTube, hàng chờ, bảng điều khiển có nút bấm
├── moderation.py         # Chống spam, nhật ký, lệnh .config
├── moderation_actions.py # Xử lý thành viên: .kick .ban .unban .mute .unmute .warn .warnings .clearwarns
├── channel_tools.py      # Quản lý kênh: .lock .unlock .clear
├── weather.py            # Thời tiết: .thoitiet (Open-Meteo, không cần API key)
├── voice_rooms.py        # Phòng thoại riêng "vào để tạo phòng" + bảng nút điều khiển: .vcsetup .vcpanel .vcrooms .vcoff
├── info.py               # Thông tin: .infouser .infoserver
├── welcome.py            # Chào mừng, tự gán role Member, .addrole
├── leveling.py           # Nhận XP khi chat, .rank .leaderboard(+Week/Month) .level .xp-admin
├── realm_roles.py        # Role tự động theo cảnh giới (lên cấp nhận role mới, mất role cũ), .syncroles
├── help_cog.py           # Lệnh .help (thành viên) và .helpadmin (quản trị), chia nhóm
├── ui.py                 # Giao diện dùng chung: màu, embed thành công/lỗi, thanh tiến độ
├── xp_bank.py            # Ngân hàng XP: get/add/remove_xp, cấp bậc, tiến độ
├── database.py           # SQLite: tạo bảng, truy vấn, giao dịch
├── utils.py              # Định dạng số, đọc thiết lập, gửi nhật ký
├── config.py             # Toàn bộ cấu hình (đọc từ .env)
├── requirements.txt
├── .env.example     # Mẫu file cấu hình; đổi tên thành .env
└── .gitignore
```

## 2. Danh sách lệnh

| Nhóm | Lệnh | Chức năng |
|---|---|---|
| Nhạc | `.play <tên bài hoặc URL>` | Phát nhạc / thêm vào hàng chờ (bot tự vào kênh thoại của bạn) |
| | `.dung` / `.again` | Tạm dừng / tiếp tục |
| | `.skip` | Bỏ qua bài hiện tại |
| | `.stop` | Dừng nhạc và xóa hàng chờ |
| | `.danhsach` | Xem hàng chờ |
| | `.nowplay` | Xem bài đang phát |
| | `.volume <0-100>` | Chỉnh âm lượng |
| Quản trị | `.addrole <tên role hoặc ID> <@thành viên hoặc ID>` | Gán role (cần quyền Manage Roles) |
| | `.config` | Xem / đổi kênh chào mừng, kênh log, kênh lên cấp, role Member (cần quyền Manage Server) |
| | `.testwelcome` | Gửi thử lời chào mừng |
| | `.kick <@thành viên> [lý do]` | Kick khỏi máy chủ (cần quyền Kick Members) |
| | `.ban <@thành viên> [lý do]` | Ban vĩnh viễn, xóa tin nhắn 24 giờ gần nhất (cần quyền Ban Members) |
| | `.unban <ID> [lý do]` hoặc `.unban <tên> \| [lý do]` | Gỡ ban |
| | `.mute <@thành viên> [thời gian] [lý do]` | Timeout thành viên, ví dụ `.mute @ai 10m spam` (cần quyền Moderate Members) |
| | `.unmute <@thành viên> [lý do]` | Gỡ timeout |
| | `.lock [#kênh] [lý do]` / `.unlock [#kênh] [lý do]` | Đóng / mở kênh chat (cần quyền Manage Channels; bot cần Manage Roles) |
| | `.vcsetup [#kênh thoại]` / `.vcpanel` / `.vcrooms` / `.vcoff` | Bật / đăng lại bảng điều khiển / xem / tắt phòng thoại riêng (Administrator; bot cần Manage Channels, Move Members, Manage Roles) |
| | `.clear <số> [@thành viên]` | Xóa tối đa 100 tin gần nhất trong kênh, hoặc của một thành viên (cần Manage Messages) |
| | `.warn <@thành viên> [lý do]` | Cảnh cáo và lưu lịch sử (cần quyền Moderate Members) |
| | `.warnings [@thành viên]` | Xem lịch sử cảnh cáo (xem người khác cần quyền Moderate Members) |
| | `.clearwarns <@thành viên>` | Xóa toàn bộ cảnh cáo của thành viên (cần quyền Moderate Members) |
| Thông tin | `.infouser [@thành viên]` | Thông tin thành viên: ngày tạo/vào máy chủ, role, cảnh giới, XP, hạng |
| | `.infoserver` | Thông tin máy chủ: chủ sở hữu, số thành viên, kênh, role, boost |
| Thời tiết | `.thoitiet <địa điểm> [7 ngày tới \| 16 ngày tới]` | Thời tiết hiện tại (nhiệt độ, cảm giác như, độ ẩm, gió, khả năng mưa) và dự báo tối đa 16 ngày |
| XP | `.rank [@thành viên]` | Xem XP, cấp độ, tiến độ |
| | `.leaderboard` (hoặc `.lb`, `.top`) | Bảng xếp hạng top 10 (tổng XP) |
| | `.leaderboardWeek` (hoặc `.lbweek`, `.lbw`) | Bảng xếp hạng tuần: XP kiếm được từ thứ Hai đến Chủ nhật của tuần này |
| | `.leaderboardMonth` (hoặc `.lbmonth`, `.lbm`) | Bảng xếp hạng tháng: XP kiếm được từ ngày 1 đến cuối tháng này |
| | `.level` | Thông tin hệ thống cấp độ |
| | `.xp-admin add <@thành viên> <số XP>` | Cộng XP (chỉ quản trị viên) |
| | `.xp-admin remove <@thành viên> <số XP>` | Trừ XP (chỉ quản trị viên) |
| | `.syncroles` | Gán lại role cảnh giới cho toàn bộ thành viên theo XP hiện có (chỉ quản trị viên) |

Dùng `.help` để xem các lệnh dành cho thành viên và `.helpadmin` để xem các lệnh quản trị (cả hai chỉ hiện lệnh bạn có quyền dùng). `.help <lệnh>` / `.helpadmin <lệnh>` xem chi tiết một lệnh, `.help <nhóm>` xem theo nhóm, ví dụ `.help nhạc`, `.helpadmin xử lý`. Khi bạn dùng lệnh nhạc, bạn phải ở cùng kênh thoại với bot. Mỗi khi bắt đầu một bài, bot gửi một bảng điều khiển có thanh tiến độ và các nút bấm (tạm dừng/phát tiếp, bỏ qua, âm lượng ±10%, dừng, xem hàng chờ); khi bài kết thúc, bảng cũ được đổi thành "đã phát xong" và gỡ nút.

## 3. Tạo bot trên Discord Developer Portal

1. Vào https://discord.com/developers/applications → **New Application** → đặt tên.
2. Mở tab **Bot** → **Reset Token** → sao chép token (chỉ hiện một lần) và dán vào `.env`.
3. Vẫn ở tab **Bot**, kéo xuống **Privileged Gateway Intents** và **bật cả hai**:
   - **Server Members Intent** (chào mừng, gán role)
   - **Message Content Intent** (đọc lệnh `.`, đếm XP, chống spam)
4. Mời bot vào máy chủ. Thay `YOUR_CLIENT_ID` bằng *Application ID* (tab **General Information**) trong đường dẫn sau:

   ```
   https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot&permissions=1099800079382
   ```

   Đường dẫn này cấp các quyền: View Channels, Send Messages, Embed Links, Read Message History, Manage Messages (xóa tin spam), Manage Roles (gán role), Moderate Members (timeout), Kick Members, Ban Members, Connect, Speak (nhạc), **Manage Channels** và **Move Members** (phòng thoại riêng). Nếu bot đã có trong máy chủ từ trước, hãy cấp thêm **Kick Members**, **Ban Members**, **Manage Channels** và **Move Members** cho role của bot trong *Cài đặt máy chủ → Vai trò*.
5. **Quan trọng:** trong Discord vào *Cài đặt máy chủ → Vai trò (Roles)* và kéo role của bot **lên trên** role `Member`. Bot không thể gán hoặc xử lý role/thành viên nằm cao hơn nó.

## 4. Cấu hình ID máy chủ, kênh, role

1. Bật chế độ nhà phát triển: *Cài đặt người dùng → Nâng cao → Chế độ nhà phát triển*.
2. Chuột phải vào máy chủ / kênh / role → **Sao chép ID**.
3. Có hai cách cấu hình:
   - **Trong file `.env`:** điền `GUILD_ID`, `WELCOME_CHANNEL_ID`, `LOG_CHANNEL_ID`, `MEMBER_ROLE_ID`, `LEVELUP_CHANNEL_ID`.
   - **Ngay trong Discord (khuyên dùng, không cần khởi động lại):**
     ```
     .config welcome_channel #chao-mung
     .config log_channel #nhat-ky
     .config member_role @Member
     .config levelup_channel #thong-bao-cap
     ```
     Dùng `off` để tắt, `reset` để quay về giá trị trong `.env`. Giá trị đặt bằng `.config` được lưu vào SQLite và **ưu tiên hơn** `.env`.

`GUILD_ID` (tùy chọn): nếu điền, bot chỉ hoạt động trong máy chủ đó. Các thiết lập khác (ngưỡng spam, XP, âm lượng mặc định, `LEADERBOARD_UTC_OFFSET`...) nằm trong `.env`, xem chú thích trong `.env.example`.

## 5. Chạy bot

Yêu cầu: **Python 3.10 trở lên** và **FFmpeg** (bắt buộc cho phát nhạc).

```bash
# 1. Cài FFmpeg
#    Windows:  winget install Gyan.FFmpeg      (rồi mở lại terminal)
#    macOS:    brew install ffmpeg
#    Ubuntu:   sudo apt install ffmpeg
ffmpeg -version          # kiểm tra đã cài

# 2. Tạo môi trường và cài thư viện
python -m venv venv
venv\Scripts\activate           # Windows
source venv/bin/activate        # macOS / Linux
pip install -r requirements.txt

# 3. Tạo file cấu hình
copy .env.example .env          # Windows  (macOS/Linux: cp .env.example .env)
# mở .env và điền DISCORD_TOKEN

# 4. Chạy
python main.py
```

Lần chạy đầu bot tự tạo thư mục `data/` và file `data/bot.db` (XP, cấp độ, thiết lập). **Nhớ sao lưu file này.** Nhật ký chạy được ghi vào `bot.log`.

**Chạy trên hosting/VPS:** cần máy hỗ trợ Python 3.10+, cài được FFmpeg, kết nối ra internet và có ổ đĩa lưu trữ lâu dài để giữ `data/bot.db` (nếu ổ đĩa bị xóa mỗi lần khởi động lại thì XP sẽ mất). Đặt token bằng biến môi trường hoặc file `.env`, chạy bằng `python main.py` và dùng systemd/pm2/supervisor để tự khởi động lại khi bot dừng. Lưu ý: YouTube thường chặn các IP của trung tâm dữ liệu, nên nhạc có thể chạy ổn trên máy cá nhân nhưng lỗi trên VPS (xem mục 8).

## 6. Cách hoạt động của các chức năng chính

**Chống spam.** Một thành viên bị coi là spam khi gửi **nhiều hơn 23 tin nhắn** trong **30 giây** (`SPAM_MESSAGE_LIMIT`, `SPAM_WINDOW_SECONDS`). Khi đó bot xóa các tin trong đợt spam, cảnh báo thành viên (tin cảnh báo tự xóa sau 20 giây) và ghi vào kênh log. Sau **3 lần vi phạm trong 10 phút** (`SPAM_TIMEOUT_AFTER`, `SPAM_VIOLATION_WINDOW_SECONDS`) thành viên bị timeout 10 phút. Quản trị viên, bot và các role trong `SPAM_EXEMPT_ROLE_IDS` được miễn; có thể giới hạn kênh bằng `SPAM_CHANNEL_IDS`. Con số 23 được lấy đúng theo tài liệu; nếu muốn bot nhạy hơn, hạ `SPAM_MESSAGE_LIMIT` (ví dụ 8).

**Xử lý thành viên (`moderation_actions.py`).** Mọi lệnh đều kiểm tra thứ bậc role: không xử lý được chủ máy chủ, chính bạn, bot, người có role cao hơn hoặc ngang bạn (chủ máy chủ được bỏ qua điều kiện này) và người có role cao hơn hoặc ngang bot. Bot gửi tin nhắn riêng (DM) cho người bị xử lý nếu họ cho phép nhận; nếu hành động thất bại thì DM đó bị thu hồi. Mọi hành động đều ghi vào kênh log.
- Thời gian của `.mute`: `s` = giây, `m` = phút, `h` = giờ, `d` = ngày, ghép được như `1h30m`; số trơn như `30` hiểu là phút. Gõ sai thời gian (ví dụ `10min`, `5p`) bot báo lỗi chứ không mute.
- `.mute @ai` không kèm thời gian dùng timeout dài nhất Discord cho phép (khoảng 28 ngày, tối đa 27 ngày 23 giờ 59 phút) và tự hết hạn; dùng `.unmute` để mở sớm. Discord không có mute vô thời hạn bằng timeout, nên muốn khóa lâu hơn hãy dùng `.ban`.
- Thành viên đang bị timeout muốn đổi thời gian thì `.unmute` trước rồi `.mute` lại.

**Bảng xếp hạng tuần / tháng.** `.leaderboardWeek` và `.leaderboardMonth` cộng tất cả XP một thành viên **kiếm được** trong khoảng thời gian hiện tại (đọc từ bảng `xp_transactions`). Tuần chạy từ 00:00 thứ Hai đến hết Chủ nhật, tháng từ 00:00 ngày 1 đến hết ngày cuối tháng; sang tuần/tháng mới thì điểm tính lại từ đầu mà không cần làm gì thêm, và XP tổng của thành viên không bị ảnh hưởng. Ranh giới tuần/tháng tính theo múi giờ `LEADERBOARD_UTC_OFFSET` trong `.env` (mặc định `7` = giờ Việt Nam). Chỉ tính giao dịch **cộng** XP: XP bị trừ và XP do quản trị viên cộng tay bằng `.xp-admin add` không được tính vào bảng tuần/tháng (vẫn tính vào tổng XP và cảnh giới). Chỉ có dữ liệu từ khi bảng `xp_transactions` được ghi, nên bảng tuần/tháng của kỳ đang chạy lúc cập nhật bot chỉ gồm XP từ lúc đó.

**Khóa kênh (`.lock` / `.unlock`) và dọn tin (`.clear`).** `.lock` đặt quyền *Gửi tin nhắn* của `@everyone` trong kênh thành ✖ (kênh mặc định là kênh đang gõ lệnh, hoặc `.lock #kênh`), bot tự cấp quyền gửi tin riêng cho nó để vẫn trả lời được, và nhớ trạng thái cũ để `.unlock` trả về đúng. Role nào được cấp ✔ *Gửi tin nhắn* riêng trong kênh (ví dụ role Mod) vẫn chat được khi kênh khóa; quản trị viên luôn chat được. Role `Member` có ✔ riêng trong kênh sẽ **không** bị khóa, hãy bỏ dấu ✔ đó nếu muốn khóa cả nhóm này. `.clear` xóa N tin mới nhất (không tính tin lệnh), chỉ xóa được tin chưa quá 14 ngày; thêm `@thành_viên` để chỉ xóa tin của người đó (quét 500 tin gần nhất).

**Phòng thoại riêng (`voice_rooms.py`).** Quản trị viên gõ `.vcsetup` một lần: bot tạo danh mục **🎙️ PHÒNG THOẠI** gồm kênh thoại **➕ Tạo phòng** và kênh chat **🎛️・điều-khiển-phòng** có bảng nút (hoặc `.vcsetup #kênh_thoại` để dùng sẵn một kênh thoại làm cổng). Thành viên vào **➕ Tạo phòng** thì bot tạo phòng **🔊 Phòng của <tên>**, chuyển họ vào và trao quyền chủ phòng; phòng trống thì tự xóa, phòng còn sót khi bot tắt được dọn lại sau 5 phút. Khi đang ở trong phòng của mình, chủ phòng dùng 15 nút: **Tên, Giới hạn, Riêng tư** (công khai / khóa / ẩn), **Chat** bật/tắt, **Vùng** máy chủ thoại; **Tin cậy, Bỏ tin cậy, Mời, Đuổi, Thông tin**; **Chặn, Bỏ chặn, Nhận phòng** (khi chủ phòng đã rời), **Chuyển chủ, Xóa**. Chủ phòng không có quyền Manage Channels: mọi thay đổi đều đi qua bot nên không đụng được kênh khác. Người có quyền Manage Channels dùng được các nút ở bất kỳ phòng nào họ đang ở. Mỗi người một phòng, tối đa 50 phòng mỗi máy chủ, đổi tên bị Discord giới hạn 2 lần mỗi 10 phút. Bot cần **Manage Channels, Move Members, Manage Roles**. `.vcrooms` xem các phòng đang có, `.vcpanel` đăng lại bảng điều khiển nếu lỡ xóa, `.vcoff` tắt chức năng (các kênh đã tạo giữ nguyên).

**Thời tiết (`weather.py`).** `.thoitiet Hà Nội`, `.thoitiet Ba Vì, Hà Nội` (thêm tỉnh/thành sau dấu phẩy để chọn đúng nơi trùng tên), `.thoitiet Đà Nẵng 7 ngày tới`, `.thoitiet Đà Nẵng 16 ngày tới` (số ngày nào từ 1 đến 16 cũng được). Bot dùng Open-Meteo: tìm địa điểm theo tên để lấy tọa độ rồi lấy thời tiết, không cần API key và không tự đoán số liệu. Open-Meteo chỉ dự báo tối đa **16 ngày**, nên nhập nhiều hơn 16 ngày (hoặc `1 tháng tới`) vẫn chỉ ra 16 ngày. Mỗi người dùng lệnh cách nhau 5 giây. Máy chạy bot cần ra internet được tới `open-meteo.com`.

**Cảnh cáo (`.warn`).** Mỗi lần cảnh cáo được lưu vào bảng `warnings` (người bị cảnh cáo, người thực hiện, lý do, thời gian), gửi DM cho thành viên, ghi vào kênh log và báo tổng số lần cảnh cáo hiện có. Bot chưa tự xử phạt khi đủ số lần cảnh cáo; quản trị viên xem `.warnings @thành_viên` rồi quyết định (`.mute`, `.kick`, `.ban`). `.infouser` hiện số lần cảnh cáo, nhưng chỉ cho người có quyền Moderate Members thấy.

**Nhạc: tự rời kênh.** Bot rời kênh thoại sau `MUSIC_IDLE_TIMEOUT` giây (mặc định 300) khi hết nhạc, hoặc sau 60 giây khi kênh không còn người thật (quay lại kịp thì bot ở lại).

**XP và cấp bậc.** Mỗi tin nhắn hợp lệ cho 15–25 XP, cách nhau tối thiểu 2 giây (`XP_COOLDOWN_SECONDS`; tăng giá trị này nếu muốn hạn chế việc cày cấp). Không tính XP cho: tin của bot, lệnh của bot, tin dưới 2 ký tự (`XP_MIN_LENGTH`), tin lặp lại 5 lần trong 15 giây, và thành viên vừa bị phát hiện spam.

| Cấp | Tên | Tổng XP tối thiểu |
|---|---|---|
| 0 | Phàm Nhân (mốc xuất phát) | 0 |
| 1 | Luyện Khí Kỳ | 100 |
| 2 | Trúc Cơ Kỳ | 300 |
| 3 | Kết Đan Kỳ | 600 |
| 4 | Nguyên Anh Kỳ | 1.500 |
| 5 | Hoá Thần Kỳ | 5.500 |
| 6 | Luyện Hư Kỳ | 21.000 |
| 7 | Hợp Thể Kỳ | 127.500 |
| 8 | Đại Thường Kỳ | 1.000.000 |

Tiến độ = (XP hiện có − XP đầu cấp) / (XP cấp tiếp theo − XP đầu cấp) × 100%. Ví dụ thành viên có 10.000 XP đang ở Hoá Thần Kỳ: (10.000 − 5.500) / (21.000 − 5.500) = 29,0%, còn 11.000 XP để lên Luyện Hư Kỳ.

**Role theo cảnh giới (`realm_roles.py`).** Khi thành viên nhận XP lần đầu hoặc lên cấp, bot gán role trùng tên cảnh giới (ví dụ "Trúc Cơ Kỳ") và gỡ các role cảnh giới cũ. Chỉ các role có tên nằm trong bảng cấp bậc bị đụng tới, nên role `Member` và mọi role khác được giữ nguyên. Nếu server chưa có role đó, bot tự tạo (màu riêng cho từng cảnh giới, bật "hiển thị thành viên riêng" để cấp bậc hiện ngay trong danh sách thành viên). Bị trừ XP làm tụt cấp thì role cũng đổi lại. Yêu cầu: bot có quyền **Manage Roles** và role của bot nằm **trên** các role cảnh giới; nếu không, bot ghi cảnh báo vào kênh log (mỗi cảnh báo nhiều nhất 10 phút một lần). Dùng `.syncroles` (quản trị viên) để gán role cho thành viên đang có sẵn XP; thành viên mới vào sẽ nhận role khi nhắn tin lần đầu.

**Ngân hàng XP (`xp_bank.py`).** Mọi module muốn cộng/trừ XP đều phải gọi `add_xp` / `remove_xp` để chỉ có một nguồn dữ liệu. Mỗi giao dịch ghi vào bảng `xp_transactions` (người nhận, số XP, lý do, thời gian, nguồn, người thực hiện). Giao dịch chạy trong transaction của SQLite, XP không bao giờ âm, và tham số `ref` (ví dụ ID tin nhắn) giúp **không cộng trùng**. Ví dụ dùng cho một sự kiện mới:

```python
import xp_bank
await xp_bank.add_xp(user_id, guild_id, 50, "Thắng sự kiện đoán số",
                     source="event", ref="doan-so-2026-10-11")
```

Các hàm trong `xp_bank.py` không tự kiểm tra quyền, vì chúng chỉ dành cho code của bot. Lệnh dành cho người dùng (như `.xp-admin`) kiểm tra quyền quản trị trước khi gọi.

## 7. Hướng dẫn kiểm thử từng chức năng

Làm theo thứ tự, ở một máy chủ thử:

1. **Khởi động:** chạy `python main.py`, log phải hiện `Đã nạp module` cho đủ 11 module (`music`, `welcome`, `moderation`, `leveling`, `realm_roles`, `help_cog`, `moderation_actions`, `info`, `channel_tools`, `weather`, `voice_rooms`) và `Đã đăng nhập`. Gõ `.help` trong Discord.
2. **Cấu hình:** gõ `.config` để xem thiết lập, rồi đặt kênh log, kênh chào mừng, role Member như mục 4.
3. **Chào mừng:** gõ `.testwelcome` (gửi thử vào kênh chào mừng). Để thử thật, dùng một tài khoản phụ vào máy chủ: phải có lời chào và tài khoản đó nhận role Member. Nếu thiếu quyền hoặc role đặt sai, lỗi sẽ xuất hiện ở kênh log.
4. **`.addrole`:** `.addrole VIP @tài_khoản_phụ` (thử cả bằng ID role/ID thành viên). Thử với role cao hơn bot để thấy thông báo từ chối.
5. **XP:** chat vài tin nhắn (mỗi tin cách nhau hơn 2 giây, dài từ 2 ký tự), gõ `.rank` để thấy XP tăng. Thử `.xp-admin add @bạn 100` (cần quyền Administrator), `.leaderboard`, `.level`. Dùng tài khoản thường gõ `.xp-admin add ...` để chắc chắn bị từ chối. Thử `.xp-admin add @bạn 300` rồi kiểm tra bạn nhận role cảnh giới mới và mất role cũ (role Member vẫn còn); `.xp-admin remove` để thấy role đổi lại; `.syncroles` để gán role cho mọi thành viên.
   **Xử lý thành viên** (dùng tài khoản phụ có role thấp hơn bot và bạn): `.mute @phụ 1m thử`, kiểm tra tài khoản phụ không nhắn được rồi `.unmute @phụ`; thử `.mute @phụ 10min` phải báo lỗi thời gian; thử `.kick` / `.ban` + `.unban <ID>` rồi mời tài khoản phụ vào lại; thử với người có role cao hơn bạn để thấy thông báo từ chối.
   **Bảng xếp hạng tuần/tháng:** chat vài tin rồi gõ `.leaderboardWeek` và `.leaderboardMonth`, bạn phải thấy mình trong bảng cùng dòng "Làm mới ..." và hạng ở chân embed. Thử `.xp-admin add @bạn 500` rồi gõ lại: điểm tuần/tháng không đổi (XP quản trị viên cộng tay không tính). Để thử việc sang tuần mới, đổi `LEADERBOARD_UTC_OFFSET` để mốc rơi vào thời điểm vừa qua hoặc đợi tới thứ Hai.
   **Khóa kênh và dọn tin:** `.lock` ở một kênh thử, dùng tài khoản phụ nhắn thử (phải bị chặn), `.unlock` rồi nhắn lại. `.clear 5` phải xóa 5 tin gần nhất, `.clear 5 @phụ` chỉ xóa tin của tài khoản phụ.
   **Cảnh cáo và thông tin:** `.warn @phụ spam` rồi `.warnings @phụ` (phải thấy 1 cảnh cáo, tài khoản phụ nhận DM), `.clearwarns @phụ`; thử `.warnings @người_khác` bằng tài khoản thường để thấy bị từ chối. `.infouser`, `.infouser @phụ` và `.infoserver` phải hiện đầy đủ các mục.
6. **Lưu dữ liệu:** tắt bot, bật lại, gõ `.rank`, XP phải còn nguyên.
7. **Chống spam (dùng tài khoản phụ không phải admin):** để thử nhanh, tạm đặt `SPAM_MESSAGE_LIMIT=5` trong `.env`, khởi động lại rồi gửi liên tục 6 tin. Bot phải xóa tin, cảnh báo và ghi log; lần vi phạm thứ 3 sẽ bị timeout. Nhớ đặt lại giá trị sau khi thử.
8. **Nhạc:** vào kênh thoại, gõ `.play lofi hip hop`, `.nowplay`, `.volume 30`, `.dung`, `.again`, `.play <một URL YouTube>` (vào hàng chờ), `.danhsach`, `.skip`, `.stop`.

## 8. Xử lý lỗi thường gặp

| Hiện tượng | Cách xử lý |
|---|---|
| `Chưa bật Privileged Intents` khi chạy | Bật **Server Members Intent** và **Message Content Intent** ở tab Bot (mục 3.3). |
| `Token không hợp lệ` | Reset token trong Developer Portal, dán lại vào `.env`, không có dấu ngoặc hoặc khoảng trắng thừa. |
| Bot online nhưng không trả lời lệnh | Thường do chưa bật Message Content Intent, hoặc bot thiếu quyền *View Channel / Send Messages* ở kênh đó, hoặc `GUILD_ID` điền sai máy chủ. Xem `bot.log`. |
| Không có role cảnh giới / role không đổi | Role của bot phải nằm **trên** các role cảnh giới (kéo trong Cài đặt máy chủ → Vai trò) và bot cần quyền Manage Roles. Lý do cụ thể được ghi ở kênh log. |
| Không gán được role Member | Role của bot phải nằm **trên** role Member; bot cần quyền Manage Roles; kiểm tra `.config`. Lỗi cụ thể được ghi ở kênh log. |
| Không xóa được tin spam / không timeout | Cấp bot quyền Manage Messages / Moderate Members. Bot không timeout được chủ máy chủ hoặc người có role cao hơn bot. |
| `.kick` / `.ban` / `.mute` báo thiếu quyền hoặc "role cao hơn" | Cấp bot quyền Kick Members / Ban Members / Moderate Members và kéo role của bot **lên trên** role của người bị xử lý. Bot không thể xử lý quản trị viên bằng timeout. |
| `.mute` báo Discord từ chối thời gian | Timeout tối đa 28 ngày; hãy chọn thời gian ngắn hơn hoặc dùng `.ban`. |
| `.play` báo "Không khởi động được FFmpeg" | Chưa cài FFmpeg hoặc chưa thêm vào PATH: chạy `ffmpeg -version` để kiểm tra. |
| Bot vào kênh thoại rồi rớt ngay / không có tiếng | Cập nhật thư viện: `pip install -U "discord.py[voice]"` (Discord thỉnh thoảng đổi giao thức thoại). Kiểm tra quyền Connect/Speak của bot ở kênh đó. |
| `.play` báo YouTube yêu cầu xác minh / chặn bot / không lấy được nguồn | Chạy `pip install -U yt-dlp` rồi khởi động lại bot. Nếu vẫn lỗi, thường do IP máy chủ bị YouTube hạn chế: thử chạy trên máy cá nhân, hoặc xuất `cookies.txt` từ trình duyệt đã đăng nhập (dùng tài khoản phụ) và đặt `YTDLP_COOKIES_FILE=cookies.txt` trong `.env`. |
| Video "không khả dụng" | Video bị xóa, riêng tư, giới hạn độ tuổi hoặc bị chặn theo khu vực. Thử bài khác. |
| Lệnh slash không thấy | Bot dùng lệnh tiền tố `.`, không phải lệnh slash `/`. |
| XP bị mất sau khi triển khai lại | `data/bot.db` nằm trên ổ đĩa tạm. Đặt `DATABASE_PATH` sang ổ lưu trữ lâu dài và sao lưu định kỳ. |

## 9. Lưu ý về nguồn nhạc

Bot lấy luồng âm thanh YouTube bằng **yt-dlp** rồi phát qua FFmpeg. Đây là cách phổ biến, hoạt động tốt, nhưng **không phải API chính thức của YouTube** và có thể không phù hợp với điều khoản dịch vụ của YouTube; YouTube cũng thường xuyên thay đổi khiến yt-dlp cần cập nhật. Hãy dùng cho máy chủ riêng/cá nhân, không dùng thương mại, và tự cân nhắc rủi ro. Vì vậy phần nguồn nhạc được tách riêng (`build_target`, `extract_info`, `make_track` trong `music.py`) để bạn dễ thay bằng nguồn khác (ví dụ file nhạc bạn có quyền sử dụng) mà không phải viết lại phần điều khiển. Bot chỉ chấp nhận đường dẫn thuộc YouTube; mọi đường dẫn khác bị từ chối.

## 10. Bảo mật

- Không chia sẻ `DISCORD_TOKEN`, không đưa `.env` lên GitHub (đã có trong `.gitignore`). Nếu lỡ lộ token, hãy Reset Token ngay.
- `.xp-admin` và `.syncroles` yêu cầu quyền Administrator; `.addrole` yêu cầu Manage Roles và tôn trọng thứ bậc role; `.config` yêu cầu Manage Server; `.lock`/`.unlock` (Manage Channels), `.clear` (Manage Messages), `.kick`, `.ban`/`.unban`, `.mute`/`.unmute`, `.warn`/`.clearwarns` yêu cầu lần lượt Kick Members, Ban Members, Moderate Members và đều tôn trọng thứ bậc role. `.infouser`, `.infoserver`, `.warnings` (của chính mình) và các bảng xếp hạng ai cũng dùng được.
