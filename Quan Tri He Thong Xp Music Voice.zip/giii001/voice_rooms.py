"""Phòng thoại riêng ("vào để tạo phòng"), điều khiển bằng bảng nút.

Cách dùng
    .vcsetup [#kênh_thoại]  # (admin) tạo danh mục + kênh "➕ Tạo phòng" + kênh bảng điều khiển
                            #          hoặc dùng sẵn một kênh thoại làm cổng tạo phòng
    .vcpanel                # (admin) đăng lại bảng điều khiển vào kênh đang gõ lệnh
    .vcrooms                # (admin) xem các phòng đang có
    .vcoff                  # (admin) tắt chức năng

Thành viên chỉ cần vào kênh "➕ Tạo phòng": bot tạo kênh thoại riêng, chuyển họ vào và trao quyền chủ phòng.
Phòng trống thì tự xóa. Chủ phòng dùng các nút ở bảng điều khiển (khi đang ở trong phòng của mình):
    Tên · Giới hạn · Riêng tư (mở/khóa/ẩn) · Chat · Vùng máy chủ thoại
    Tin cậy · Bỏ tin cậy · Mời · Đuổi · Thông tin
    Chặn · Bỏ chặn · Nhận phòng (khi chủ phòng đã rời) · Chuyển chủ · Xóa
    Mật khẩu (chủ phòng đặt/gỡ) · Nhập mật khẩu (ai cũng dùng được để vào phòng có mật khẩu)

Bot cần quyền: Manage Channels, Move Members, Manage Roles (cần cấp khi mời bot).
Chủ phòng KHÔNG được cấp quyền Manage Channels: mọi thay đổi đều đi qua bot, nên không thể xóa/đổi kênh khác.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
import os
import time
from dataclasses import dataclass
from typing import Awaitable, Callable, Optional

import discord
from discord.ext import commands, tasks

import ui
from database import db
from utils import guild_allowed

log = logging.getLogger("bot.voice_rooms")

SETTING_CREATOR = "vc_creator"    # ID kênh thoại cổng "➕ Tạo phòng"
SETTING_PANEL = "vc_panel"        # ID kênh chứa bảng điều khiển
DEFAULT_NAME = "🔊 Phòng của {name}"
CREATOR_NAME = "➕ Tạo phòng"
CATEGORY_NAME = "🎙️ PHÒNG THOẠI"
PANEL_NAME = "🎛️・điều-khiển-phòng"
MAX_ROOMS_PER_GUILD = 45  # danh mục chứa tối đa 50 kênh, chừa chỗ cho cổng + kênh điều khiển
CREATE_COOLDOWN = 5.0     # giây giữa hai lần tạo phòng của cùng một người
SWEEP_GRACE = 30.0        # phòng mới tạo trong ngần này giây thì chưa bị dọn
NAME_MAX = 100
LIMIT_MAX = 99
NO_PING = discord.AllowedMentions.none()
PW_MIN, PW_MAX = 4, 32
PW_MAX_FAILS = 5          # sai quá số lần này trong PW_FAIL_WINDOW thì bị khóa thử tạm thời
PW_FAIL_WINDOW = 600.0    # giây
PW_MAX_GRANTS = 40        # số người tối đa được cấp quyền vào bằng mật khẩu cho mỗi phòng

REGIONS: list[tuple[str, str]] = [  # (nhãn, mã vùng; "auto" = tự động)
    ("Tự động", "auto"), ("Singapore", "singapore"), ("Hồng Kông", "hongkong"), ("Nhật Bản", "japan"),
    ("Ấn Độ", "india"), ("Sydney", "sydney"), ("Rotterdam", "rotterdam"), ("Nga", "russia"),
    ("Nam Phi", "southafrica"), ("Brazil", "brazil"), ("Mỹ - Đông", "us-east"), ("Mỹ - Tây", "us-west"),
    ("Mỹ - Trung", "us-central"), ("Mỹ - Nam", "us-south"),
]

SCHEMA = """
CREATE TABLE IF NOT EXISTS voice_rooms (
    channel_id INTEGER PRIMARY KEY,
    guild_id   INTEGER NOT NULL,
    owner_id   INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_voice_rooms_guild ON voice_rooms (guild_id);
CREATE TABLE IF NOT EXISTS voice_room_passwords (
    channel_id INTEGER PRIMARY KEY,
    salt       BLOB NOT NULL,
    hash       BLOB NOT NULL
);
CREATE TABLE IF NOT EXISTS voice_room_access (
    channel_id INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    PRIMARY KEY (channel_id, user_id)
);
"""


class RoomError(Exception):
    """Lỗi có nội dung thân thiện, hiện thẳng cho người dùng."""


@dataclass
class Room:
    channel_id: int
    guild_id: int
    owner_id: int
    created_at: int


async def _reply(interaction: discord.Interaction, *, embed: Optional[discord.Embed] = None,
                 content: Optional[str] = None, view: Optional[discord.ui.View] = None) -> None:
    """Trả lời ẩn (chỉ người bấm thấy), dùng được cả khi đã trả lời/defer."""
    kwargs: dict = {"ephemeral": True, "allowed_mentions": NO_PING}
    if embed is not None:
        kwargs["embed"] = embed
    if content is not None:
        kwargs["content"] = content
    if view is not None:
        kwargs["view"] = view
    if interaction.response.is_done():
        await interaction.followup.send(**kwargs)
    else:
        await interaction.response.send_message(**kwargs)


def _edit_overwrite(channel: discord.VoiceChannel, target, **changes) -> discord.PermissionOverwrite:
    overwrite = channel.overwrites_for(target)
    for name, value in changes.items():
        setattr(overwrite, name, value)
    return overwrite


async def _apply(channel: discord.VoiceChannel, target, reason: str, **changes) -> None:
    """Sửa một vài quyền của `target` trong kênh mà KHÔNG làm mất các quyền khác đã có."""
    overwrite = _edit_overwrite(channel, target, **changes)
    await channel.set_permissions(target, overwrite=None if overwrite.is_empty() else overwrite, reason=reason)


def _hash_password(password: str, salt: bytes) -> bytes:
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)


# ---------------------------------------------------------------------------
# Khung nhập, hộp chọn
# ---------------------------------------------------------------------------
class NameModal(discord.ui.Modal):
    def __init__(self, cog: "VoiceRooms", channel: discord.VoiceChannel) -> None:
        super().__init__(title="Đổi tên phòng", timeout=300)
        self.cog, self.channel_id = cog, channel.id
        self.name_input = discord.ui.TextInput(label="Tên phòng", default=channel.name[:NAME_MAX], max_length=NAME_MAX)
        self.add_item(self.name_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            channel, _ = self.cog.room_for(interaction)
            if channel.id != self.channel_id:
                raise RoomError("Bạn không còn ở phòng đó nữa.")
            name = " ".join(self.name_input.value.split())
            if not name:
                raise RoomError("Tên phòng không được để trống.")
            await interaction.response.defer(ephemeral=True)
            try:
                # Discord giới hạn đổi tên kênh 2 lần / 10 phút: không chờ quá lâu.
                await asyncio.wait_for(channel.edit(name=name[:NAME_MAX], reason=f"{interaction.user} đổi tên phòng"), 10)
            except asyncio.TimeoutError:
                raise RoomError("Discord giới hạn đổi tên kênh (2 lần mỗi 10 phút). Bạn thử lại sau nhé.") from None
            await _reply(interaction, embed=ui.success(f"Đã đổi tên phòng thành **{discord.utils.escape_markdown(name)}**."))
        await self.cog.guard(interaction, work)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi khung đổi tên phòng", exc_info=error)
        await _reply(interaction, embed=ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))


class LimitModal(discord.ui.Modal):
    def __init__(self, cog: "VoiceRooms", channel: discord.VoiceChannel) -> None:
        super().__init__(title="Giới hạn số người", timeout=300)
        self.cog, self.channel_id = cog, channel.id
        self.limit_input = discord.ui.TextInput(label="Số người tối đa (0 = không giới hạn)", max_length=2,
                                                default=str(channel.user_limit or 0))
        self.add_item(self.limit_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            channel, _ = self.cog.room_for(interaction)
            if channel.id != self.channel_id:
                raise RoomError("Bạn không còn ở phòng đó nữa.")
            raw = self.limit_input.value.strip()
            if not raw.isdigit() or not 0 <= int(raw) <= LIMIT_MAX:
                raise RoomError(f"Hãy nhập một số từ 0 đến {LIMIT_MAX}.")
            await interaction.response.defer(ephemeral=True)
            await channel.edit(user_limit=int(raw), reason=f"{interaction.user} đặt giới hạn phòng")
            text = "Đã bỏ giới hạn số người." if int(raw) == 0 else f"Phòng giờ chứa tối đa **{int(raw)}** người."
            await _reply(interaction, embed=ui.success(text))
        await self.cog.guard(interaction, work)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi khung giới hạn phòng", exc_info=error)
        await _reply(interaction, embed=ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))


class PasswordSetModal(discord.ui.Modal):
    def __init__(self, cog: "VoiceRooms", channel: discord.VoiceChannel) -> None:
        super().__init__(title="Mật khẩu phòng", timeout=300)
        self.cog, self.channel_id = cog, channel.id
        self.pw_input = discord.ui.TextInput(
            label=f"Mật khẩu mới ({PW_MIN}-{PW_MAX} ký tự)", required=False, max_length=PW_MAX,
            placeholder="Để trống rồi gửi = gỡ mật khẩu")
        self.add_item(self.pw_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            channel, _ = self.cog.room_for(interaction)
            if channel.id != self.channel_id:
                raise RoomError("Bạn không còn ở phòng đó nữa.")
            password = self.pw_input.value.strip()
            await interaction.response.defer(ephemeral=True)
            if not password:
                if channel.id not in self.cog.protected:
                    raise RoomError("Phòng này chưa có mật khẩu.")
                await self.cog.clear_password(channel, f"{interaction.user} gỡ mật khẩu")
                await _reply(interaction, embed=ui.success(
                    "Đã **gỡ mật khẩu**; những người từng vào bằng mật khẩu bị thu hồi quyền vào phòng.\n"
                    "Phòng vẫn ở chế độ hiện tại, dùng nút **Riêng tư** nếu muốn mở lại cho mọi người."))
                return
            if len(password) < PW_MIN:
                raise RoomError(f"Mật khẩu cần ít nhất {PW_MIN} ký tự.")
            await self.cog.set_password(channel, password, str(interaction.user))
            await _reply(interaction, embed=ui.success(
                "Đã đặt mật khẩu. Phòng được **khóa**: người lạ bấm **Nhập mật khẩu** ở bảng điều khiển và nhập đúng "
                "mới vào được. Người đã vào bằng mật khẩu cũ (nếu có) bị thu hồi quyền.\n"
                "Đừng gửi mật khẩu vào kênh chat công khai. Phòng ở chế độ **Ẩn** thì người khác không thấy để nhập mật khẩu."))
        await self.cog.guard(interaction, work)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi khung đặt mật khẩu phòng", exc_info=error)
        await _reply(interaction, embed=ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))


class PasswordEnterModal(discord.ui.Modal):
    def __init__(self, cog: "VoiceRooms", channel: discord.VoiceChannel) -> None:
        super().__init__(title="Nhập mật khẩu phòng", timeout=300)
        self.cog, self.channel_id = cog, channel.id
        self.pw_input = discord.ui.TextInput(label=f"Mật khẩu của {channel.name}"[:45], max_length=PW_MAX)
        self.add_item(self.pw_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            await interaction.response.defer(ephemeral=True)
            text = await self.cog.try_password(interaction, self.channel_id, self.pw_input.value.strip())
            await _reply(interaction, embed=ui.success(text))
        await self.cog.guard(interaction, work)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi khung nhập mật khẩu phòng", exc_info=error)
        await _reply(interaction, embed=ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))


class PasswordRoomView(discord.ui.View):
    """Chọn phòng có mật khẩu muốn vào (chỉ người bấm dùng được)."""

    def __init__(self, cog: "VoiceRooms", user_id: int, channels: list[discord.VoiceChannel]) -> None:
        super().__init__(timeout=90)
        self.cog, self.user_id = cog, user_id
        select = discord.ui.Select(placeholder="Chọn phòng có mật khẩu…", options=[
            discord.SelectOption(label=c.name[:100], value=str(c.id), emoji="🔑",
                                 description=f"{len([m for m in c.members if not m.bot])} người trong phòng")
            for c in channels[:25]])
        select.callback = self._on_select
        self.add_item(select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Bảng này không phải của bạn.", ephemeral=True)
            return False
        return True

    async def _on_select(self, interaction: discord.Interaction) -> None:
        channel_id = int(interaction.data["values"][0])

        async def work() -> None:
            channel = interaction.guild.get_channel(channel_id)
            if channel_id not in self.cog.protected or not isinstance(channel, discord.VoiceChannel):
                raise RoomError("Phòng này không còn mật khẩu hoặc đã bị xóa.")
            await interaction.response.send_modal(PasswordEnterModal(self.cog, channel))
        await self.cog.guard(interaction, work)


class _OwnedView(discord.ui.View):
    """View ẩn chỉ người bấm nút dùng được; hết thời gian thì vô hiệu."""

    def __init__(self, cog: "VoiceRooms", user_id: int, channel_id: int) -> None:
        super().__init__(timeout=90)
        self.cog, self.user_id, self.channel_id = cog, user_id, channel_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Bảng này không phải của bạn.", ephemeral=True)
            return False
        return True

    def _same_room(self, interaction: discord.Interaction, owner_required: bool = True) -> discord.VoiceChannel:
        channel, _ = self.cog.room_for(interaction, owner=owner_required)
        if channel.id != self.channel_id:
            raise RoomError("Bạn không còn ở phòng đó nữa.")
        return channel


class PrivacyView(_OwnedView):
    def __init__(self, cog: "VoiceRooms", user_id: int, channel_id: int) -> None:
        super().__init__(cog, user_id, channel_id)
        select = discord.ui.Select(placeholder="Chọn chế độ riêng tư…", options=[
            discord.SelectOption(label="Công khai", value="public", emoji="🔓", description="Ai cũng thấy và vào được"),
            discord.SelectOption(label="Khóa", value="locked", emoji="🔒",
                                 description="Ai cũng thấy nhưng chỉ người được mời/tin cậy mới vào"),
            discord.SelectOption(label="Ẩn", value="hidden", emoji="🙈",
                                 description="Chỉ người được mời/tin cậy mới thấy và vào"),
        ])
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction) -> None:
        mode = interaction.data["values"][0]

        async def work() -> None:
            channel = self._same_room(interaction)
            await interaction.response.defer(ephemeral=True)
            had_password = channel.id in self.cog.protected
            await self.cog.set_privacy(channel, mode, str(interaction.user))
            label = {"public": "🔓 Công khai", "locked": "🔒 Khóa", "hidden": "🙈 Ẩn"}[mode]
            note = " Mật khẩu của phòng đã được gỡ." if mode == "public" and had_password else ""
            await interaction.edit_original_response(content=None, embed=ui.success(f"Phòng giờ ở chế độ **{label}**.{note}"),
                                                     view=None)
        await self.cog.guard(interaction, work)


class RegionView(_OwnedView):
    def __init__(self, cog: "VoiceRooms", user_id: int, channel_id: int) -> None:
        super().__init__(cog, user_id, channel_id)
        select = discord.ui.Select(placeholder="Chọn vùng máy chủ thoại…", options=[
            discord.SelectOption(label=label, value=code) for label, code in REGIONS])
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction) -> None:
        code = interaction.data["values"][0]

        async def work() -> None:
            channel = self._same_room(interaction)
            await interaction.response.defer(ephemeral=True)
            try:
                await channel.edit(rtc_region=None if code == "auto" else code, reason=f"{interaction.user} đổi vùng")
            except discord.HTTPException:
                raise RoomError("Discord không nhận vùng này. Hãy thử vùng khác hoặc chọn Tự động.") from None
            label = next(l for l, c in REGIONS if c == code)
            await interaction.edit_original_response(content=None, embed=ui.success(f"Đã đổi vùng thành **{label}**."),
                                                     view=None)
        await self.cog.guard(interaction, work)


UserAction = Callable[[discord.Interaction, discord.VoiceChannel, "Room", discord.Member], Awaitable[str]]


class UserPickView(_OwnedView):
    """Chọn một thành viên rồi thực hiện hành động (tin cậy, mời, đuổi, chặn, chuyển chủ...)."""

    def __init__(self, cog: "VoiceRooms", user_id: int, channel_id: int, placeholder: str, action: UserAction) -> None:
        super().__init__(cog, user_id, channel_id)
        self.action = action
        select = discord.ui.UserSelect(placeholder=placeholder, min_values=1, max_values=1)
        select.callback = self._on_select
        self.select = select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction) -> None:
        picked = self.select.values[0]

        async def work() -> None:
            channel = self._same_room(interaction)
            room = self.cog.rooms[channel.id]
            member = picked if isinstance(picked, discord.Member) else interaction.guild.get_member(picked.id)
            if member is None:
                raise RoomError("Người này không có trong máy chủ.")
            if member.bot:
                raise RoomError("Không thể áp dụng cho bot.")
            await interaction.response.defer(ephemeral=True)
            text = await self.action(interaction, channel, room, member)
            await interaction.edit_original_response(content=None, embed=ui.success(text), view=None)
        await self.cog.guard(interaction, work)


class ConfirmDeleteView(_OwnedView):
    @discord.ui.button(label="Xóa phòng", emoji="🗑️", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        async def work() -> None:
            channel = self._same_room(interaction)
            await interaction.response.edit_message(content=None, embed=ui.success("Đã xóa phòng."), view=None)
            await self.cog.delete_room(channel, f"{interaction.user} xóa phòng")
        await self.cog.guard(interaction, work)

    @discord.ui.button(label="Hủy", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.edit_message(content="Đã hủy.", embed=None, view=None)


# ---------------------------------------------------------------------------
# Bảng điều khiển (nút bền vững: vẫn dùng được sau khi bot khởi động lại)
# ---------------------------------------------------------------------------
class PanelView(discord.ui.View):
    def __init__(self, cog: "VoiceRooms") -> None:
        super().__init__(timeout=None)
        self.cog = cog

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.guild is None or not guild_allowed(interaction.guild):
            await interaction.response.send_message("Chỉ dùng được trong máy chủ.", ephemeral=True)
            return False
        return True

    # hàng 1
    @discord.ui.button(label="Tên", emoji="✏️", custom_id="vc:name", row=0)
    async def b_name(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_name(interaction))

    @discord.ui.button(label="Giới hạn", emoji="👥", custom_id="vc:limit", row=0)
    async def b_limit(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_limit(interaction))

    @discord.ui.button(label="Riêng tư", emoji="🔒", custom_id="vc:privacy", row=0)
    async def b_privacy(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_privacy(interaction))

    @discord.ui.button(label="Chat", emoji="💬", custom_id="vc:chat", row=0)
    async def b_chat(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_chat(interaction))

    @discord.ui.button(label="Vùng", emoji="🌐", custom_id="vc:region", row=0)
    async def b_region(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_region(interaction))

    # hàng 2
    @discord.ui.button(label="Tin cậy", emoji="🤝", custom_id="vc:trust", row=1)
    async def b_trust(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_pick(interaction, "Chọn người để tin cậy…", self.cog.a_trust))

    @discord.ui.button(label="Bỏ tin cậy", emoji="➖", custom_id="vc:untrust", row=1)
    async def b_untrust(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_pick(interaction, "Chọn người để bỏ tin cậy…", self.cog.a_reset))

    @discord.ui.button(label="Mời", emoji="📞", custom_id="vc:invite", row=1)
    async def b_invite(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_pick(interaction, "Chọn người để mời…", self.cog.a_invite))

    @discord.ui.button(label="Đuổi", emoji="👢", custom_id="vc:kick", row=1)
    async def b_kick(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_pick(interaction, "Chọn người để đuổi khỏi phòng…", self.cog.a_kick))

    @discord.ui.button(label="Thông tin", emoji="ℹ️", custom_id="vc:info", row=1)
    async def b_info(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_info(interaction))

    # hàng 3
    @discord.ui.button(label="Chặn", emoji="🚫", custom_id="vc:block", row=2)
    async def b_block(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_pick(interaction, "Chọn người để chặn…", self.cog.a_block))

    @discord.ui.button(label="Bỏ chặn", emoji="✅", custom_id="vc:unblock", row=2)
    async def b_unblock(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_pick(interaction, "Chọn người để bỏ chặn…", self.cog.a_reset))

    @discord.ui.button(label="Nhận phòng", emoji="👑", style=discord.ButtonStyle.primary, custom_id="vc:claim", row=2)
    async def b_claim(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_claim(interaction))

    @discord.ui.button(label="Chuyển chủ", emoji="🔁", custom_id="vc:transfer", row=2)
    async def b_transfer(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_pick(interaction, "Chọn chủ phòng mới (đang ở trong phòng)…",
                                                                  self.cog.a_transfer))

    @discord.ui.button(label="Xóa", emoji="🗑️", style=discord.ButtonStyle.danger, custom_id="vc:delete", row=2)
    async def b_delete(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_delete(interaction))

    # hàng 4
    @discord.ui.button(label="Mật khẩu", emoji="🔑", custom_id="vc:password", row=3)
    async def b_password(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_password(interaction))

    @discord.ui.button(label="Nhập mật khẩu", emoji="🔐", style=discord.ButtonStyle.success, custom_id="vc:enterpw", row=3)
    async def b_enterpw(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.h_enter_password(interaction))


def panel_embed() -> discord.Embed:
    embed = ui.make(
        "🎛️ Bảng điều khiển phòng thoại",
        f"Vào kênh **{CREATOR_NAME}** để có phòng thoại riêng. Khi đang ở trong phòng của mình, "
        "bấm các nút bên dưới để điều khiển.",
        color=ui.Color.BRAND, timestamp=False)
    embed.add_field(name="Phòng", inline=False, value=(
        "✏️ **Tên** · 👥 **Giới hạn** · 🔒 **Riêng tư** (công khai / khóa / ẩn) · 💬 **Chat** bật/tắt · 🌐 **Vùng**"))
    embed.add_field(name="Thành viên", inline=False, value=(
        "🤝 **Tin cậy** (luôn vào được) · ➖ **Bỏ tin cậy** · 📞 **Mời** · 👢 **Đuổi** · 🚫 **Chặn** · ✅ **Bỏ chặn**"))
    embed.add_field(name="Khác", inline=False, value=(
        "ℹ️ **Thông tin** · 👑 **Nhận phòng** (khi chủ phòng đã rời) · 🔁 **Chuyển chủ** · 🗑️ **Xóa** phòng"))
    embed.add_field(name="Mật khẩu", inline=False, value=(
        "🔑 **Mật khẩu**: chủ phòng đặt hoặc gỡ mật khẩu cho phòng của mình\n"
        "🔐 **Nhập mật khẩu**: bấm rồi chọn phòng và nhập mật khẩu để được vào (không cần đang ở trong phòng nào)"))
    embed.set_footer(text="Phòng trống sẽ tự xóa.")
    return embed


# ---------------------------------------------------------------------------
# Cog
# ---------------------------------------------------------------------------
class VoiceRooms(commands.Cog):
    """Phòng thoại tạm do thành viên tự tạo."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.rooms: dict[int, Room] = {}
        self._busy: set[int] = set()
        self._last_create: dict[int, float] = {}
        self.protected: set[int] = set()                     # kênh đang có mật khẩu
        self._pw_fails: dict[tuple[int, int], list[float]] = {}  # (kênh, người) -> các lần nhập sai

    # -- vòng đời ------------------------------------------------------------
    async def cog_load(self) -> None:
        for statement in SCHEMA.split(";"):
            if statement.strip():
                await db.execute(statement.strip())
        for row in await db.fetchall("SELECT channel_id, guild_id, owner_id, created_at FROM voice_rooms"):
            self.rooms[row["channel_id"]] = Room(row["channel_id"], row["guild_id"], row["owner_id"], row["created_at"])
        self.protected = {row["channel_id"] for row in await db.fetchall("SELECT channel_id FROM voice_room_passwords")
                          if row["channel_id"] in self.rooms}
        self.bot.add_view(PanelView(self))
        self.sweep.start()

    async def cog_unload(self) -> None:
        self.sweep.cancel()

    @tasks.loop(minutes=5)
    async def sweep(self) -> None:
        """Dọn phòng đã mất kênh hoặc đang trống (phòng sót lại khi bot tắt)."""
        for room in list(self.rooms.values()):
            channel = self.bot.get_channel(room.channel_id)
            if channel is None:
                await self._forget(room.channel_id)
            elif not [m for m in channel.members if not m.bot] and time.time() - room.created_at > SWEEP_GRACE:
                await self.delete_room(channel, "Phòng trống")

    @sweep.before_loop
    async def _before_sweep(self) -> None:
        await self.bot.wait_until_ready()

    # -- lưu trữ ---------------------------------------------------------------
    async def _remember(self, room: Room) -> None:
        self.rooms[room.channel_id] = room
        await db.execute("INSERT OR REPLACE INTO voice_rooms (channel_id, guild_id, owner_id, created_at) VALUES (?, ?, ?, ?)",
                         (room.channel_id, room.guild_id, room.owner_id, room.created_at))

    async def _forget(self, channel_id: int) -> None:
        self.rooms.pop(channel_id, None)
        self.protected.discard(channel_id)
        for key in [k for k in self._pw_fails if k[0] == channel_id]:
            self._pw_fails.pop(key, None)
        await db.execute("DELETE FROM voice_rooms WHERE channel_id = ?", (channel_id,))
        await db.execute("DELETE FROM voice_room_passwords WHERE channel_id = ?", (channel_id,))
        await db.execute("DELETE FROM voice_room_access WHERE channel_id = ?", (channel_id,))

    async def delete_room(self, channel: discord.abc.GuildChannel, reason: str) -> None:
        await self._forget(channel.id)
        try:
            await channel.delete(reason=reason)
        except discord.NotFound:
            pass
        except discord.HTTPException as exc:
            log.warning("Không xóa được phòng %s: %s", channel.id, exc)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        if channel.id in self.rooms:
            await self._forget(channel.id)

    # -- sự kiện thoại ----------------------------------------------------------
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState,
                                    after: discord.VoiceState) -> None:
        if member.bot or before.channel == after.channel or not guild_allowed(member.guild):
            return
        try:
            if before.channel is not None and before.channel.id in self.rooms:
                await self._on_leave(before.channel, member)
            if after.channel is not None:
                creator = await db.get_setting(member.guild.id, SETTING_CREATOR)
                if creator and str(after.channel.id) == creator:
                    await self._create_room(member, after.channel)
        except Exception:  # noqa: BLE001 - lỗi ở đây không được làm hỏng bot
            log.exception("Lỗi xử lý sự kiện thoại của %s", member)

    async def _on_leave(self, channel: discord.VoiceChannel, member: discord.Member) -> None:
        room = self.rooms.get(channel.id)
        if room is None:
            return
        if not [m for m in channel.members if not m.bot]:
            await self.delete_room(channel, "Phòng trống")
        elif room.owner_id == member.id:
            await self._say(channel, "👑 Chủ phòng đã rời đi. Ai đang ở trong phòng có thể bấm **Nhận phòng** ở bảng điều khiển.")

    @staticmethod
    async def _say(channel: discord.VoiceChannel, text: str) -> None:
        try:
            await channel.send(text, allowed_mentions=NO_PING)
        except (discord.Forbidden, discord.HTTPException):
            pass

    async def _create_room(self, member: discord.Member, hub: discord.VoiceChannel) -> None:
        guild = member.guild
        if member.id in self._busy:
            return
        # Đã có phòng thì đưa về phòng cũ thay vì tạo thêm.
        for room in self.rooms.values():
            if room.guild_id == guild.id and room.owner_id == member.id:
                existing = guild.get_channel(room.channel_id)
                if existing is not None:
                    try:
                        await member.move_to(existing)
                    except discord.HTTPException:
                        pass
                    return
        if sum(1 for r in self.rooms.values() if r.guild_id == guild.id) >= MAX_ROOMS_PER_GUILD:
            log.warning("Máy chủ %s đã đạt giới hạn %d phòng.", guild.id, MAX_ROOMS_PER_GUILD)
            return
        self._busy.add(member.id)
        try:
            # Chống tạo phòng dồn dập: nếu vừa tạo xong thì chờ cho hết thời gian chờ rồi mới tạo tiếp.
            wait = CREATE_COOLDOWN - (time.monotonic() - self._last_create.get(member.id, 0.0))
            if wait > 0:
                await asyncio.sleep(wait)
                if member.voice is None or member.voice.channel != hub:  # đã rời cổng trong lúc chờ
                    return
            self._last_create[member.id] = time.monotonic()
            overwrites = dict(hub.category.overwrites) if hub.category else {}
            overwrites[member] = discord.PermissionOverwrite(view_channel=True, connect=True, speak=True, send_messages=True)
            overwrites[guild.me] = discord.PermissionOverwrite(view_channel=True, connect=True, send_messages=True,
                                                               manage_channels=True, move_members=True)
            name = DEFAULT_NAME.format(name=member.display_name)[:NAME_MAX]
            try:
                channel = await guild.create_voice_channel(
                    name, category=hub.category, overwrites=overwrites, bitrate=min(hub.bitrate, guild.bitrate_limit),
                    reason=f"Phòng thoại riêng của {member}")
            except discord.Forbidden:
                log.warning("Bot thiếu quyền tạo phòng ở máy chủ %s (cần Manage Channels, Move Members, Manage Roles).", guild.id)
                return
            await self._remember(Room(channel.id, guild.id, member.id, int(time.time())))
            try:
                await member.move_to(channel)
            except discord.HTTPException:  # người dùng đã rời cổng trước khi kịp chuyển
                await self.delete_room(channel, "Chủ phòng đã rời trước khi vào phòng")
                return
            panel_id = await db.get_setting(guild.id, SETTING_PANEL)
            hint = f" Dùng bảng điều khiển ở <#{panel_id}>." if panel_id else ""
            await self._say(channel, f"👑 {member.mention} là chủ phòng.{hint}")
        finally:
            self._busy.discard(member.id)

    # -- tìm phòng của người bấm ---------------------------------------------------
    def room_for(self, interaction: discord.Interaction, *, owner: bool = True) -> tuple[discord.VoiceChannel, Room]:
        member = interaction.user
        voice = getattr(member, "voice", None)
        channel = voice.channel if voice else None
        room = self.rooms.get(channel.id) if channel is not None else None
        if room is None:
            raise RoomError("Bạn cần **đang ở trong phòng thoại riêng** của mình để dùng nút này. "
                            f"Hãy vào kênh **{CREATOR_NAME}** để tạo phòng.")
        if owner and room.owner_id != member.id and not member.guild_permissions.manage_channels:
            raise RoomError(f"Chỉ chủ phòng (<@{room.owner_id}>) mới dùng được nút này.")
        return channel, room

    async def guard(self, interaction: discord.Interaction, work: Callable[[], Awaitable[None]]) -> None:
        try:
            await work()
        except RoomError as exc:
            await _reply(interaction, embed=ui.error(str(exc)))
        except discord.Forbidden:
            await _reply(interaction, embed=ui.error("Bot thiếu quyền để làm việc này (cần Manage Channels, Move Members, "
                                                     "Manage Roles). Hãy báo quản trị viên."))
        except discord.HTTPException as exc:
            log.warning("Lỗi Discord khi xử lý nút phòng thoại: %s", exc)
            await _reply(interaction, embed=ui.error("Discord báo lỗi, bạn thử lại sau nhé."))
        except Exception:  # noqa: BLE001
            log.exception("Lỗi không mong muốn ở bảng điều khiển phòng thoại")
            await _reply(interaction, embed=ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))

    # -- xử lý từng nút ---------------------------------------------------------------
    async def h_name(self, interaction: discord.Interaction) -> None:
        channel, _ = self.room_for(interaction)
        await interaction.response.send_modal(NameModal(self, channel))

    async def h_limit(self, interaction: discord.Interaction) -> None:
        channel, _ = self.room_for(interaction)
        await interaction.response.send_modal(LimitModal(self, channel))

    async def h_privacy(self, interaction: discord.Interaction) -> None:
        channel, _ = self.room_for(interaction)
        await _reply(interaction, content="Chọn chế độ riêng tư cho phòng:",
                     view=PrivacyView(self, interaction.user.id, channel.id))

    async def h_region(self, interaction: discord.Interaction) -> None:
        channel, _ = self.room_for(interaction)
        await _reply(interaction, content="Chọn vùng máy chủ thoại (đổi khi chất lượng âm thanh kém):",
                     view=RegionView(self, interaction.user.id, channel.id))

    async def h_chat(self, interaction: discord.Interaction) -> None:
        channel, _ = self.room_for(interaction)
        await interaction.response.defer(ephemeral=True)
        everyone = interaction.guild.default_role
        closed = channel.overwrites_for(everyone).send_messages is False
        await _apply(channel, everyone, f"{interaction.user} {'bật' if closed else 'tắt'} chat", send_messages=None if closed else False)
        await _reply(interaction, embed=ui.success("💬 Đã **bật** chat trong phòng." if closed
                                                   else "🔇 Đã **tắt** chat trong phòng (chủ phòng vẫn chat được)."))

    async def h_pick(self, interaction: discord.Interaction, placeholder: str, action: UserAction) -> None:
        channel, _ = self.room_for(interaction)
        await _reply(interaction, content="Chọn một thành viên:",
                     view=UserPickView(self, interaction.user.id, channel.id, placeholder, action))

    async def h_password(self, interaction: discord.Interaction) -> None:
        channel, _ = self.room_for(interaction)
        await interaction.response.send_modal(PasswordSetModal(self, channel))

    async def h_enter_password(self, interaction: discord.Interaction) -> None:
        member = interaction.user
        channels = []
        for channel_id in self.protected:
            channel = interaction.guild.get_channel(channel_id)
            room = self.rooms.get(channel_id)
            if not isinstance(channel, discord.VoiceChannel) or room is None or room.guild_id != interaction.guild.id:
                continue
            if room.owner_id == member.id or not channel.permissions_for(member).view_channel:
                continue
            channels.append(channel)
        if not channels:
            raise RoomError("Hiện không có phòng nào có mật khẩu mà bạn nhìn thấy. "
                            "Phòng ở chế độ **Ẩn** chỉ hiện với người được mời.")
        channels.sort(key=lambda c: c.name.casefold())
        await _reply(interaction, content="Chọn phòng bạn muốn vào:", view=PasswordRoomView(self, member.id, channels))

    async def h_claim(self, interaction: discord.Interaction) -> None:
        channel, room = self.room_for(interaction, owner=False)
        if room.owner_id == interaction.user.id:
            raise RoomError("Bạn đã là chủ phòng rồi.")
        if any(m.id == room.owner_id for m in channel.members):
            raise RoomError(f"Chủ phòng (<@{room.owner_id}>) vẫn đang ở trong phòng. "
                            "Chỉ nhận phòng được khi chủ phòng đã rời đi.")
        await interaction.response.defer(ephemeral=True)
        await self._set_owner(channel, room, interaction.user, f"{interaction.user} nhận phòng")
        await self._say(channel, f"👑 {interaction.user.mention} đã nhận quyền chủ phòng.")
        await _reply(interaction, embed=ui.success("Bạn là chủ phòng mới."))

    async def h_delete(self, interaction: discord.Interaction) -> None:
        channel, _ = self.room_for(interaction)
        await _reply(interaction, content=f"Xóa phòng **{discord.utils.escape_markdown(channel.name)}**? "
                                          "Mọi người trong phòng sẽ bị ngắt kết nối.",
                     view=ConfirmDeleteView(self, interaction.user.id, channel.id))

    async def h_info(self, interaction: discord.Interaction) -> None:
        channel, room = self.room_for(interaction, owner=False)
        everyone = channel.overwrites_for(interaction.guild.default_role)
        privacy = ("🙈 Ẩn" if everyone.view_channel is False else "🔒 Khóa" if everyone.connect is False else "🔓 Công khai")
        trusted, blocked = [], []
        for target, ow in channel.overwrites.items():
            if not isinstance(target, discord.Member) or target.bot or target.id == room.owner_id:
                continue
            if ow.connect is True:
                trusted.append(target.mention)
            elif ow.connect is False:
                blocked.append(target.mention)
        limit = f"{channel.user_limit} người" if channel.user_limit else "Không giới hạn"
        embed = ui.make(f"ℹ️ {channel.name}"[:256], "", color=ui.Color.INFO, timestamp=False)
        embed.add_field(name="Chủ phòng", value=f"<@{room.owner_id}>", inline=True)
        embed.add_field(name="Đang trong phòng", value=str(len([m for m in channel.members if not m.bot])), inline=True)
        embed.add_field(name="Giới hạn", value=limit, inline=True)
        embed.add_field(name="Riêng tư", value=privacy, inline=True)
        embed.add_field(name="Chat", value="Tắt" if everyone.send_messages is False else "Bật", inline=True)
        embed.add_field(name="Vùng", value=channel.rtc_region or "Tự động", inline=True)
        embed.add_field(name="Mật khẩu", value="🔑 Có" if channel.id in self.protected else "Không", inline=True)
        embed.add_field(name="🤝 Tin cậy / được mời", value=(", ".join(trusted)[:1000] or "Không có"), inline=False)
        embed.add_field(name="🚫 Bị chặn", value=(", ".join(blocked)[:1000] or "Không có"), inline=False)
        await _reply(interaction, embed=embed)

    # -- hành động lên một thành viên -----------------------------------------------------
    @staticmethod
    def _check_target(room: Room, actor: discord.abc.User, target: discord.Member, *, allow_self: bool = False) -> None:
        if target.id == room.owner_id:
            raise RoomError("Không thể áp dụng cho chủ phòng.")
        if target.id == actor.id and not allow_self:
            raise RoomError("Bạn không thể tự làm việc này với chính mình.")

    async def a_trust(self, interaction, channel, room, target) -> str:
        self._check_target(room, interaction.user, target)
        await _apply(channel, target, f"{interaction.user} tin cậy {target}", connect=True, view_channel=True)
        return f"{target.mention} giờ luôn vào được phòng, kể cả khi phòng khóa hoặc ẩn."

    async def a_reset(self, interaction, channel, room, target) -> str:
        """Bỏ tin cậy / bỏ chặn: xóa quyền riêng của người đó về mặc định."""
        self._check_target(room, interaction.user, target)
        ow = channel.overwrites_for(target)
        if ow.connect is None and ow.view_channel is None:
            raise RoomError(f"{target.mention} không nằm trong danh sách tin cậy hoặc chặn của phòng.")
        await _apply(channel, target, f"{interaction.user} bỏ tin cậy/chặn {target}", connect=None, view_channel=None)
        return f"Đã đưa {target.mention} về quyền bình thường."

    async def a_invite(self, interaction, channel, room, target) -> str:
        self._check_target(room, interaction.user, target)
        await _apply(channel, target, f"{interaction.user} mời {target}", connect=True, view_channel=True)
        try:
            await target.send(f"📞 {interaction.user.display_name} mời bạn vào phòng thoại {channel.mention} "
                              f"trong **{channel.guild.name}**.", allowed_mentions=NO_PING)
            return f"Đã mời {target.mention} (đã nhắn riêng cho họ)."
        except (discord.Forbidden, discord.HTTPException):
            return f"Đã cho phép {target.mention} vào phòng (không nhắn riêng được, hãy báo họ tự vào)."

    async def a_kick(self, interaction, channel, room, target) -> str:
        self._check_target(room, interaction.user, target)
        if target.voice is None or target.voice.channel != channel:
            raise RoomError(f"{target.mention} không ở trong phòng này.")
        await target.move_to(None, reason=f"{interaction.user} đuổi khỏi phòng")
        return f"Đã đuổi {target.mention} khỏi phòng."

    async def a_block(self, interaction, channel, room, target) -> str:
        self._check_target(room, interaction.user, target)
        if target.guild_permissions.administrator:
            raise RoomError("Không thể chặn quản trị viên (họ luôn vào được mọi phòng).")
        await _apply(channel, target, f"{interaction.user} chặn {target}", connect=False, view_channel=False)
        if target.voice is not None and target.voice.channel == channel:
            await target.move_to(None, reason="Bị chặn khỏi phòng")
        return f"Đã chặn {target.mention}: họ không thấy và không vào được phòng này."

    async def a_transfer(self, interaction, channel, room, target) -> str:
        self._check_target(room, interaction.user, target)
        if target.voice is None or target.voice.channel != channel:
            raise RoomError(f"{target.mention} phải đang ở trong phòng mới nhận quyền được.")
        await self._set_owner(channel, room, target, f"{interaction.user} chuyển chủ phòng")
        await self._say(channel, f"👑 Quyền chủ phòng đã chuyển cho {target.mention}.")
        return f"Đã chuyển quyền chủ phòng cho {target.mention}."

    async def _set_owner(self, channel: discord.VoiceChannel, room: Room, new_owner: discord.Member, reason: str) -> None:
        old = channel.guild.get_member(room.owner_id)
        if old is not None and old.id != new_owner.id:  # chủ cũ trở thành người được tin cậy
            await _apply(channel, old, reason, speak=None, send_messages=None, connect=True, view_channel=True)
        await _apply(channel, new_owner, reason, speak=True, send_messages=True, connect=True, view_channel=True)
        room.owner_id = new_owner.id
        await db.execute("UPDATE voice_rooms SET owner_id = ? WHERE channel_id = ?", (new_owner.id, channel.id))

    # -- mật khẩu ---------------------------------------------------------------------------
    async def _revoke_password_access(self, channel: discord.VoiceChannel, reason: str) -> None:
        """Thu hồi quyền vào của những người từng vào bằng mật khẩu."""
        rows = await db.fetchall("SELECT user_id FROM voice_room_access WHERE channel_id = ?", (channel.id,))
        room = self.rooms.get(channel.id)
        for row in rows:
            member = channel.guild.get_member(row["user_id"])
            if member is None or (room is not None and member.id == room.owner_id):
                continue
            ow = channel.overwrites_for(member)
            if ow.connect is True:  # chỉ gỡ nếu vẫn là quyền cho phép (không đụng tới người đã bị chặn)
                await _apply(channel, member, reason, connect=None, view_channel=None)
        await db.execute("DELETE FROM voice_room_access WHERE channel_id = ?", (channel.id,))

    async def set_password(self, channel: discord.VoiceChannel, password: str, actor: str) -> None:
        salt = os.urandom(16)
        digest = await asyncio.to_thread(_hash_password, password, salt)
        await self._revoke_password_access(channel, f"{actor} đổi mật khẩu")
        await db.execute("INSERT OR REPLACE INTO voice_room_passwords (channel_id, salt, hash) VALUES (?, ?, ?)",
                         (channel.id, salt, digest))
        self.protected.add(channel.id)
        for key in [k for k in self._pw_fails if k[0] == channel.id]:
            self._pw_fails.pop(key, None)
        if channel.overwrites_for(channel.guild.default_role).connect is not False:  # mật khẩu thì phải khóa phòng
            await _apply(channel, channel.guild.default_role, f"{actor} đặt mật khẩu", connect=False)

    async def clear_password(self, channel: discord.VoiceChannel, reason: str) -> None:
        self.protected.discard(channel.id)
        await db.execute("DELETE FROM voice_room_passwords WHERE channel_id = ?", (channel.id,))
        await self._revoke_password_access(channel, reason)

    async def try_password(self, interaction: discord.Interaction, channel_id: int, password: str) -> str:
        """Kiểm tra mật khẩu; đúng thì cấp quyền vào phòng. Trả về lời nhắn thành công, sai thì ném RoomError."""
        member = interaction.user
        channel = interaction.guild.get_channel(channel_id)
        room = self.rooms.get(channel_id)
        if channel_id not in self.protected or room is None or not isinstance(channel, discord.VoiceChannel):
            raise RoomError("Phòng này không còn mật khẩu hoặc đã bị xóa.")
        if room.owner_id == member.id:
            raise RoomError("Bạn là chủ phòng này, không cần mật khẩu.")
        if channel.overwrites_for(member).connect is False:
            raise RoomError("Chủ phòng đã chặn bạn khỏi phòng này.")
        now = time.monotonic()
        key = (channel_id, member.id)
        fails = [t for t in self._pw_fails.get(key, []) if now - t < PW_FAIL_WINDOW]
        if len(fails) >= PW_MAX_FAILS:
            wait = int(PW_FAIL_WINDOW - (now - fails[0])) + 1
            self._pw_fails[key] = fails
            raise RoomError(f"Bạn nhập sai quá nhiều lần. Thử lại sau khoảng {wait // 60 + 1} phút.")
        row = await db.fetchone("SELECT salt, hash FROM voice_room_passwords WHERE channel_id = ?", (channel_id,))
        if row is None:
            raise RoomError("Phòng này không còn mật khẩu.")
        digest = await asyncio.to_thread(_hash_password, password, bytes(row["salt"]))
        if not hmac.compare_digest(digest, bytes(row["hash"])):
            fails.append(now)
            self._pw_fails[key] = fails
            left = PW_MAX_FAILS - len(fails)
            raise RoomError("Sai mật khẩu." + (f" Bạn còn {left} lần thử." if left > 0 else " Bạn bị khóa thử tạm thời."))
        self._pw_fails.pop(key, None)
        granted = await db.fetchone("SELECT COUNT(*) AS n FROM voice_room_access WHERE channel_id = ?", (channel_id,))
        already = await db.fetchone("SELECT 1 FROM voice_room_access WHERE channel_id = ? AND user_id = ?",
                                    (channel_id, member.id))
        if already is None and granted["n"] >= PW_MAX_GRANTS:
            raise RoomError("Phòng này đã đủ số người vào bằng mật khẩu. Hãy nhờ chủ phòng mời bạn.")
        if channel.overwrites_for(member).connect is not True:
            await _apply(channel, member, f"{member} nhập đúng mật khẩu", connect=True, view_channel=True)
        await db.execute("INSERT OR IGNORE INTO voice_room_access (channel_id, user_id) VALUES (?, ?)", (channel_id, member.id))
        voice = getattr(member, "voice", None)
        if voice is not None and voice.channel is not None:
            try:
                await member.move_to(channel, reason="Nhập đúng mật khẩu phòng")
                return f"Đúng mật khẩu. Đã chuyển bạn vào {channel.mention}."
            except discord.HTTPException:
                return f"Đúng mật khẩu, nhưng chưa vào được (phòng có thể đã đầy). Bạn tự vào {channel.mention} nhé."
        return f"Đúng mật khẩu. Giờ bạn vào được {channel.mention}, bấm vào kênh đó để tham gia."

    async def set_privacy(self, channel: discord.VoiceChannel, mode: str, actor: str) -> None:
        values = {"public": dict(connect=None, view_channel=None),
                  "locked": dict(connect=False, view_channel=None),
                  "hidden": dict(connect=False, view_channel=False)}[mode]
        await _apply(channel, channel.guild.default_role, f"{actor} đặt riêng tư: {mode}", **values)
        if mode == "public" and channel.id in self.protected:  # công khai thì mật khẩu vô nghĩa
            await self.clear_password(channel, f"{actor} mở công khai phòng")

    # -- lệnh quản trị -------------------------------------------------------------------------
    @commands.command(name="vcsetup", help="Bật phòng thoại riêng: tạo kênh '➕ Tạo phòng' + bảng điều khiển. "
                                           "Dùng: .vcsetup [#kênh_thoại_làm_cổng]")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    @commands.bot_has_guild_permissions(manage_channels=True, move_members=True, manage_roles=True)
    async def vcsetup(self, ctx: commands.Context, hub: Optional[discord.VoiceChannel] = None) -> None:
        guild = ctx.guild
        if (old := await db.get_setting(guild.id, SETTING_CREATOR)) and guild.get_channel(int(old)):
            await ctx.send(embed=ui.warning(f"Phòng thoại riêng đã được bật (cổng: <#{old}>). "
                                            f"Dùng `{ctx.prefix}vcoff` để tắt rồi cài lại.", ctx=ctx))
            return
        async with ctx.typing():
            category = hub.category if hub else await guild.create_category(CATEGORY_NAME, reason="Phòng thoại riêng")
            if hub is None:
                hub = await guild.create_voice_channel(CREATOR_NAME, category=category, reason="Cổng tạo phòng thoại riêng")
            panel_overwrites = {guild.default_role: discord.PermissionOverwrite(send_messages=False, add_reactions=False),
                                guild.me: discord.PermissionOverwrite(send_messages=True, embed_links=True)}
            panel_channel = await guild.create_text_channel(PANEL_NAME, category=category, overwrites=panel_overwrites,
                                                            reason="Bảng điều khiển phòng thoại riêng")
            await panel_channel.send(embed=panel_embed(), view=PanelView(self))
            await db.set_setting(guild.id, SETTING_CREATOR, str(hub.id))
            await db.set_setting(guild.id, SETTING_PANEL, str(panel_channel.id))
        await ctx.send(embed=ui.success(
            f"Thành viên vào {hub.mention} sẽ có phòng thoại riêng.\nBảng điều khiển: {panel_channel.mention}\n"
            "Bạn có thể đổi tên, di chuyển hoặc chỉnh quyền hai kênh này tùy ý.", ctx=ctx))

    @commands.command(name="vcpanel", help="Đăng lại bảng điều khiển phòng thoại vào kênh này. Dùng: .vcpanel")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    async def vcpanel(self, ctx: commands.Context) -> None:
        if not await db.get_setting(ctx.guild.id, SETTING_CREATOR):
            await ctx.send(embed=ui.error(f"Chưa bật phòng thoại riêng. Hãy dùng `{ctx.prefix}vcsetup` trước.", ctx=ctx))
            return
        await ctx.send(embed=panel_embed(), view=PanelView(self))
        await db.set_setting(ctx.guild.id, SETTING_PANEL, str(ctx.channel.id))

    @commands.command(name="vcrooms", help="Xem các phòng thoại riêng đang có. Dùng: .vcrooms")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    async def vcrooms(self, ctx: commands.Context) -> None:
        rooms = [r for r in self.rooms.values() if r.guild_id == ctx.guild.id]
        if not rooms:
            await ctx.send(embed=ui.info("Hiện không có phòng nào.", ctx=ctx))
            return
        lines = []
        for room in rooms[:40]:
            channel = ctx.guild.get_channel(room.channel_id)
            count = len([m for m in channel.members if not m.bot]) if channel else 0
            lines.append(f"<#{room.channel_id}> · chủ phòng <@{room.owner_id}> · {count} người")
        await ctx.send(embed=ui.info("\n".join(lines), title=f"🎙️ {len(rooms)} phòng thoại riêng", ctx=ctx),
                       allowed_mentions=NO_PING)

    @commands.command(name="vcoff", help="Tắt phòng thoại riêng (các kênh đã tạo giữ nguyên). Dùng: .vcoff")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    async def vcoff(self, ctx: commands.Context) -> None:
        if await db.get_setting(ctx.guild.id, SETTING_CREATOR) is None:
            await ctx.send(embed=ui.info("Phòng thoại riêng chưa được bật.", ctx=ctx))
            return
        await db.delete_setting(ctx.guild.id, SETTING_CREATOR)
        await db.delete_setting(ctx.guild.id, SETTING_PANEL)
        await ctx.send(embed=ui.success("Đã tắt. Kênh **➕ Tạo phòng** và kênh điều khiển vẫn còn, bạn có thể xóa tay. "
                                        "Các phòng đang có vẫn dùng được và tự xóa khi trống.", ctx=ctx))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(VoiceRooms(bot))
