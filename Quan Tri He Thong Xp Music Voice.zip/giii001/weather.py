"""Lệnh xem thời tiết: .thoitiet

    .thoitiet Hà Nội                   -> thời tiết hiện tại
    .thoitiet Ba Vì, Hà Nội            -> thêm tỉnh/thành sau dấu phẩy để chọn đúng nơi trùng tên
    .thoitiet Đà Nẵng 16 ngày tới      -> hiện tại + dự báo 16 ngày (dài nhất có thể)
    .thoitiet Đà Nẵng 7 ngày tới       -> hiện tại + dự báo 7 ngày (số ngày nào cũng được, tối đa 16)

Nguồn dữ liệu: Open-Meteo (https://open-meteo.com), miễn phí, không cần API key.
  - Tìm địa điểm theo tên:  geocoding-api.open-meteo.com  (tên -> tọa độ)
  - Lấy thời tiết:           api.open-meteo.com            (tọa độ -> thời tiết)

Ghi chú: Open-Meteo chỉ dự báo tối đa 16 ngày. Bot KHÔNG tự suy đoán thêm, nên yêu cầu "1 tháng tới"
được cắt còn 16 ngày và hiện là "16 ngày tới".
"""
from __future__ import annotations

import asyncio
import logging
import re
import unicodedata
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import aiohttp
import discord
from discord.ext import commands

import ui

log = logging.getLogger("bot.weather")

GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
MAX_FORECAST_DAYS = 16  # giới hạn của Open-Meteo
HTTP_TIMEOUT = aiohttp.ClientTimeout(total=10)
MAX_QUERY_LENGTH = 100

# Mã thời tiết WMO -> (mô tả tiếng Việt, emoji)
WEATHER_CODES: dict[int, tuple[str, str]] = {
    0: ("Trời quang, nắng", "☀️"),
    1: ("Gần như quang mây", "🌤️"),
    2: ("Có mây rải rác", "⛅"),
    3: ("Nhiều mây", "☁️"),
    45: ("Sương mù", "🌫️"),
    48: ("Sương mù đóng băng", "🌫️"),
    51: ("Mưa phùn nhẹ", "🌦️"),
    53: ("Mưa phùn", "🌦️"),
    55: ("Mưa phùn dày", "🌦️"),
    56: ("Mưa phùn lạnh nhẹ", "🌧️"),
    57: ("Mưa phùn lạnh", "🌧️"),
    61: ("Mưa nhỏ", "🌦️"),
    63: ("Mưa vừa", "🌧️"),
    65: ("Mưa to", "🌧️"),
    66: ("Mưa lạnh nhẹ", "🌧️"),
    67: ("Mưa lạnh to", "🌧️"),
    71: ("Tuyết rơi nhẹ", "🌨️"),
    73: ("Tuyết rơi vừa", "🌨️"),
    75: ("Tuyết rơi dày", "❄️"),
    77: ("Hạt tuyết", "🌨️"),
    80: ("Mưa rào nhẹ", "🌦️"),
    81: ("Mưa rào", "🌧️"),
    82: ("Mưa rào rất to", "⛈️"),
    85: ("Mưa tuyết nhẹ", "🌨️"),
    86: ("Mưa tuyết to", "❄️"),
    95: ("Dông", "⛈️"),
    96: ("Dông kèm mưa đá nhỏ", "⛈️"),
    99: ("Dông kèm mưa đá lớn", "⛈️"),
}
WEEKDAYS = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]

# Cách người Việt hay gọi -> tên Open-Meteo tìm được
ALIASES = {
    "ho chi minh": "Ho Chi Minh City", "hcm": "Ho Chi Minh City", "tphcm": "Ho Chi Minh City",
    "sai gon": "Ho Chi Minh City", "saigon": "Ho Chi Minh City", "sg": "Ho Chi Minh City",
    "hue": "Hue", "hn": "Hanoi", "ha noi": "Hanoi", "hanoi": "Hanoi",
    "da nang": "Da Nang", "hai phong": "Haiphong", "can tho": "Can Tho",
}

_FORECAST_RE = re.compile(
    r"^(?P<place>.*?)[\s,]*(?P<n>\d{1,3})\s*(?P<unit>ngày|ngay|tuần|tuan|tháng|thang)"
    r"(?:\s*(?:tới|toi|tiếp|tiep|nữa|nua|sau|kế tiếp|ke tiep|nay))?\s*$",
    re.IGNORECASE,
)
_UNIT_DAYS = {"ngày": 1, "ngay": 1, "tuần": 7, "tuan": 7, "tháng": 30, "thang": 30}
_PREFIX_RE = re.compile(r"^(?:thành phố|thanh pho|tp\.?|t\.p\.?|tỉnh|tinh)\s+", re.IGNORECASE)


class WeatherError(Exception):
    """Lỗi có nội dung thân thiện, gửi thẳng được cho người dùng."""


def normalize(text: str) -> str:
    """'Hà Nội' -> 'ha noi' (bỏ dấu, thường hóa) để so khớp."""
    text = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", text).strip().lower()


def parse_query(text: str) -> tuple[str, int]:
    """Tách 'Hà Nội 7 ngày tới' thành ('Hà Nội', 7). Số ngày 0 = chỉ thời tiết hiện tại."""
    text = text.strip()
    match = _FORECAST_RE.match(text)
    if not match:
        return text, 0
    days = int(match.group("n")) * _UNIT_DAYS[match.group("unit").lower()]
    return match.group("place").strip(" ,"), days


def search_names(place: str) -> tuple[list[str], str]:
    """(danh sách tên thử lần lượt trên API, gợi ý tỉnh/thành để chọn đúng nơi trùng tên)."""
    name, _, hint = place.partition(",")
    name = _PREFIX_RE.sub("", name.strip())
    plain = normalize(name)
    candidates = [name]
    if plain in ALIASES:
        candidates.insert(0, ALIASES[plain])
    if plain != name.lower():
        candidates.append(plain)
    seen: set[str] = set()
    ordered = [c for c in candidates if c and not (c in seen or seen.add(c))]
    return ordered, normalize(_PREFIX_RE.sub("", hint.strip()))


def pick_location(results: list[dict], hint: str) -> dict:
    """Chọn kết quả tốt nhất: khớp gợi ý tỉnh/thành trước, rồi ưu tiên Việt Nam."""
    pool = results
    if hint:
        matched = [r for r in results
                   if hint in normalize(" ".join(str(r.get(k, "")) for k in ("name", "admin1", "admin2", "admin3")))]
        pool = matched or results
    vietnam = [r for r in pool if r.get("country_code") == "VN"]
    return (vietnam or pool)[0]


def describe(code: Optional[int]) -> tuple[str, str]:
    return WEATHER_CODES.get(int(code), ("Không rõ", "❔")) if code is not None else ("Không rõ", "❔")


def _fmt_num(value: Any, digits: int = 0) -> str:
    if value is None:
        return "?"
    return f"{value:.{digits}f}".replace(".", ",")


def place_title(location: dict) -> str:
    parts: list[str] = []
    for key in ("name", "admin2", "admin1", "country"):
        value = location.get(key)
        if value and value not in parts:
            parts.append(value)
    return ", ".join(parts)


class Weather(commands.Cog):
    """Thời tiết theo địa điểm (Open-Meteo)."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._session: Optional[aiohttp.ClientSession] = None

    async def cog_unload(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()

    # ------------------------------------------------------------------
    # Gọi API
    # ------------------------------------------------------------------
    async def _get_json(self, url: str, params: dict) -> dict:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=HTTP_TIMEOUT,
                                                  headers={"User-Agent": "discord-bot-weather/1.0"})
        try:
            async with self._session.get(url, params=params) as response:
                if response.status != 200:
                    log.warning("Open-Meteo trả về HTTP %s cho %s", response.status, url)
                    raise WeatherError("Dịch vụ thời tiết đang gặp sự cố, bạn thử lại sau ít phút nhé.")
                return await response.json(content_type=None)
        except asyncio.TimeoutError:
            raise WeatherError("Dịch vụ thời tiết phản hồi quá lâu, bạn thử lại sau nhé.") from None
        except (aiohttp.ClientError, ValueError) as exc:
            log.warning("Lỗi kết nối Open-Meteo: %s", exc)
            raise WeatherError("Không kết nối được tới dịch vụ thời tiết, bạn thử lại sau nhé.") from None

    async def geocode(self, place: str) -> dict:
        names, hint = search_names(place)
        for name in names:
            data = await self._get_json(GEOCODE_URL, {"name": name, "count": 10, "language": "vi", "format": "json"})
            results = data.get("results") or []
            if results:
                return pick_location(results, hint)
        raise WeatherError("Không tìm thấy địa điểm này. Hãy kiểm tra lại tên rồi nhập lại, "
                           "ví dụ `.thoitiet Hà Nội` hoặc `.thoitiet Ba Vì, Hà Nội`.")

    async def fetch_weather(self, location: dict, days: int) -> dict:
        params = {
            "latitude": location["latitude"],
            "longitude": location["longitude"],
            "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day",
            "hourly": "precipitation_probability",
            "daily": ("weather_code,temperature_2m_max,temperature_2m_min,"
                      "precipitation_probability_max,wind_speed_10m_max"),
            "timezone": "auto",
            "wind_speed_unit": "kmh",
            "temperature_unit": "celsius",
            "forecast_days": max(1, min(days, MAX_FORECAST_DAYS)),
        }
        data = await self._get_json(FORECAST_URL, params)
        if not data.get("current"):
            raise WeatherError("Dịch vụ thời tiết không trả về dữ liệu cho địa điểm này.")
        return data

    # ------------------------------------------------------------------
    # Hiển thị
    # ------------------------------------------------------------------
    @staticmethod
    def rain_chance_now(data: dict) -> Optional[int]:
        """Khả năng mưa của giờ hiện tại; thiếu thì dùng mức cao nhất trong ngày hôm nay."""
        hourly = data.get("hourly") or {}
        current_time = (data["current"].get("time") or "")[:13]  # 'YYYY-MM-DDTHH'
        for stamp, value in zip(hourly.get("time", []), hourly.get("precipitation_probability", [])):
            if stamp[:13] == current_time and value is not None:
                return int(value)
        daily = (data.get("daily") or {}).get("precipitation_probability_max") or []
        return int(daily[0]) if daily and daily[0] is not None else None

    @staticmethod
    def updated_at(data: dict) -> Optional[datetime]:
        raw = data["current"].get("time")
        if not raw:
            return None
        try:
            local = datetime.fromisoformat(raw)
        except ValueError:
            return None
        offset = timedelta(seconds=int(data.get("utc_offset_seconds") or 0))
        return (local - offset).replace(tzinfo=timezone.utc)

    def build_embed(self, ctx: commands.Context, location: dict, data: dict, days: int,
                    capped: bool) -> discord.Embed:
        current = data["current"]
        text, icon = describe(current.get("weather_code"))
        if current.get("weather_code") == 0 and current.get("is_day") == 0:
            text, icon = "Trời quang", "🌙"
        embed = ui.make(f"{icon} Thời tiết · {place_title(location)}", f"**{text}**",
                        color=ui.Color.INFO, ctx=ctx)

        rain = self.rain_chance_now(data)
        embed.add_field(name="🌡️ Nhiệt độ", value=f"**{_fmt_num(current.get('temperature_2m'), 1)}°C**", inline=True)
        embed.add_field(name="🤒 Cảm giác như", value=f"{_fmt_num(current.get('apparent_temperature'), 1)}°C",
                        inline=True)
        embed.add_field(name="☁️ Trạng thái", value=f"{icon} {text}", inline=True)
        embed.add_field(name="💧 Độ ẩm", value=f"{_fmt_num(current.get('relative_humidity_2m'))}%", inline=True)
        embed.add_field(name="💨 Gió", value=f"{_fmt_num(current.get('wind_speed_10m'), 1)} km/h", inline=True)
        embed.add_field(name="🌧️ Khả năng mưa", value=f"{rain}%" if rain is not None else "Không có dữ liệu",
                        inline=True)

        updated = self.updated_at(data)
        if updated is not None:
            embed.add_field(name="🕒 Cập nhật",
                            value=f"{discord.utils.format_dt(updated, 'f')} ({discord.utils.format_dt(updated, 'R')})",
                            inline=False)

        if days > 0:
            self._add_forecast(embed, data)
        embed.set_footer(text=f"Nguồn: Open-Meteo · Yêu cầu bởi {ctx.author.display_name}",
                         icon_url=ctx.author.display_avatar.url)
        return embed

    @staticmethod
    def _add_forecast(embed: discord.Embed, data: dict) -> None:
        daily = data.get("daily") or {}
        dates = daily.get("time") or []
        lines: list[str] = []
        for i, stamp in enumerate(dates):
            try:
                day = datetime.fromisoformat(stamp)
            except ValueError:
                continue
            _, icon = describe((daily.get("weather_code") or [None] * len(dates))[i])
            low = (daily.get("temperature_2m_min") or [None] * len(dates))[i]
            high = (daily.get("temperature_2m_max") or [None] * len(dates))[i]
            rain = (daily.get("precipitation_probability_max") or [None] * len(dates))[i]
            wind = (daily.get("wind_speed_10m_max") or [None] * len(dates))[i]
            rain_text = f"{int(rain)}%" if rain is not None else "?"
            lines.append(f"`{WEEKDAYS[day.weekday()]} {day:%d/%m}` {icon} **{_fmt_num(low)}–{_fmt_num(high)}°C** "
                         f"· 🌧️ {rain_text} · 💨 {_fmt_num(wind)} km/h")
        if not lines:
            return
        # Mỗi field tối đa 1024 ký tự: chia thành nhiều field khi dự báo dài.
        chunks: list[list[str]] = [[]]
        for line in lines:
            if len("\n".join(chunks[-1] + [line])) > 1000:
                chunks.append([])
            chunks[-1].append(line)
        for index, chunk in enumerate(chunks):
            name = f"📅 {len(lines)} ngày tới" if index == 0 else "📅 Tiếp theo"
            embed.add_field(name=name, value="\n".join(chunk), inline=False)

    # ------------------------------------------------------------------
    # Lệnh
    # ------------------------------------------------------------------
    @commands.command(
        name="thoitiet", aliases=["weather", "tt"],
        help="Xem thời tiết. Dùng: .thoitiet <địa điểm> [7 ngày tới | 16 ngày tới]",
        usage="<địa điểm> [7 ngày tới | 16 ngày tới]",
    )
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def thoitiet(self, ctx: commands.Context, *, query: Optional[str] = None) -> None:
        no_ping = discord.AllowedMentions.none()
        if not query or not query.strip():
            await ctx.send(embed=ui.info(
                f"`{ctx.prefix}thoitiet Hà Nội`\n`{ctx.prefix}thoitiet Ba Vì, Hà Nội`\n"
                f"`{ctx.prefix}thoitiet Đà Nẵng 7 ngày tới`\n`{ctx.prefix}thoitiet Quảng Ngãi 16 ngày tới`",
                title="🌤️ Cách dùng .thoitiet", ctx=ctx), allowed_mentions=no_ping)
            ctx.command.reset_cooldown(ctx)
            return
        if len(query) > MAX_QUERY_LENGTH:
            await ctx.send(embed=ui.error("Tên địa điểm quá dài, bạn nhập ngắn lại nhé.", ctx=ctx))
            return

        place, days = parse_query(query)
        if not place:
            await ctx.send(embed=ui.error("Bạn chưa nhập địa điểm. Ví dụ: `.thoitiet Hà Nội 7 ngày tới`.", ctx=ctx))
            ctx.command.reset_cooldown(ctx)
            return
        capped = days > MAX_FORECAST_DAYS
        days = min(days, MAX_FORECAST_DAYS)

        async with ctx.typing():
            try:
                location = await self.geocode(place)
                data = await self.fetch_weather(location, days)
                embed = self.build_embed(ctx, location, data, days, capped)
            except WeatherError as exc:
                await ctx.send(embed=ui.error(str(exc), title="🌧️ Không xem được thời tiết", ctx=ctx),
                               allowed_mentions=no_ping)
                return
            except Exception:  # noqa: BLE001 - dữ liệu lạ từ API không được làm sập lệnh
                log.exception("Lỗi không mong muốn khi xem thời tiết %r", query)
                await ctx.send(embed=ui.error("Có lỗi khi xử lý dữ liệu thời tiết, bạn thử lại sau nhé.", ctx=ctx))
                return
        await ctx.send(embed=embed, allowed_mentions=no_ping)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Weather(bot))
