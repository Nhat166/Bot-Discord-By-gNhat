"""Lệnh .help tiếng Việt đầy đủ, chia nhóm bằng embed.

    .help               -> tổng quan các lệnh dành cho THÀNH VIÊN, xếp theo nhóm
    .help <nhóm>        -> chi tiết cả nhóm: cách dùng, tên gọi tắt, lệnh con     (.help nhạc)
    .help <lệnh>        -> chi tiết một lệnh, kể cả lệnh con                       (.help rank, .help xp-admin add)
    .helpadmin          -> tổng quan các lệnh QUẢN TRỊ (🔒 = bạn chưa đủ quyền dùng)
    .helpadmin <nhóm/lệnh> -> chi tiết như trên                                    (.helpadmin xử lý, .helpadmin kick)

Tìm kiếm không phân biệt hoa/thường và có hay không dấu: ".help nhac", ".help quan tri" đều được.
Gõ sai tên sẽ được gợi ý lệnh gần giống.

Muốn thêm lệnh mới vào nhóm: sửa CATEGORIES (lệnh cho thành viên, hiện ở .help) hoặc ADMIN_CATEGORIES
(lệnh quản trị, hiện ở .helpadmin); từ khóa tìm nhóm cách nhau bằng dấu "|".
Lệnh chưa có trong nhóm nào tự rơi vào "Khác" của .help nên không bao giờ bị sót: nhớ xếp lệnh quản trị mới
vào ADMIN_CATEGORIES.
Phần mô tả và cách dùng lấy từ `help=` của từng lệnh: viết "Mô tả. Dùng: .lệnh <tham_số>" là hiển thị đẹp nhất.
"""
from __future__ import annotations

import difflib
import logging
import re
import unicodedata
from typing import Iterable, Optional

import discord
from discord.ext import commands

import config

log = logging.getLogger("bot.help")

# (tên hiển thị, các từ khóa tìm nhóm cách nhau bằng "|", danh sách tên lệnh)
# Đừng đặt từ khóa trùng tên một lệnh (ví dụ "rank"), để ".help rank" ra chi tiết lệnh đó.
# CATEGORIES: lệnh cho thành viên bình thường (hiện ở .help).
CATEGORIES: list[tuple[str, str, list[str]]] = [
    ("🎵 Âm nhạc", "nhạc|âm nhạc|music", ["play", "dung", "again", "skip", "stop", "danhsach", "nowplay", "volume"]),
    ("⚔️ Role XP", "xp|cấp độ|role xp|cảnh giới",
     ["rank", "leaderboard", "leaderboardWeek", "leaderboardMonth", "level"]),
    ("👤 Thông tin", "thông tin|info", ["infouser", "infoserver", "warnings"]),
    ("🌤️ Thời tiết", "thời tiết", ["thoitiet"]),
    ("📖 Trợ giúp", "trợ giúp", ["help"]),
]

# ADMIN_CATEGORIES: lệnh dành cho admin/quản trị viên (hiện ở .helpadmin).
ADMIN_CATEGORIES: list[tuple[str, str, list[str]]] = [
    ("🛡️ Quản trị", "quản trị|admin|moderation", ["config", "xp-admin", "syncroles", "verifysetup", "verifyoff"]),
    ("🔨 Xử lý thành viên", "xử lý|kiểm duyệt|mod",
     ["kick", "ban", "unban", "mute", "unmute", "warn", "clearwarns"]),
    ("📢 Quản lý kênh", "kênh|channel", ["lock", "unlock", "clear"]),
    ("🏷️ Role & chào mừng", "role|chào mừng|welcome", ["addrole", "testwelcome"]),
    ("⏰ Tự động", "tự động|lịch|hẹn giờ", ["auto"]),
    ("🎙️ Phòng thoại", "phòng thoại|voice|thoại", ["vcsetup", "vcpanel", "vcrooms", "vcoff"]),
]
OTHER_TITLE = "📦 Khác"
OTHER_KEYWORDS = "khác|other"
# Lệnh không hiện trong .help (cũng không gợi ý, không tra được bằng .help): thành viên không cần biết.
HIDDEN_FROM_HELP = {"helpadmin"}
HELP_COLOR = 0x5865F2

# Giới hạn của Discord: field.value <= 1024, tối đa 25 field/embed, tổng chữ <= 6000/tin nhắn, <= 10 embed/tin.
FIELD_VALUE_LIMIT = 1024
EMBED_BUDGET = 5000       # ngân sách chữ cho một embed (chừa chỗ cho chân trang)
MESSAGE_BUDGET = 5800     # ngân sách chữ cho mọi embed trong một tin nhắn
MAX_FIELDS = 25
MAX_EMBEDS_PER_MESSAGE = 10

_USAGE_RE = re.compile(r"\s*Dùng:\s*(.+)$", re.S)


# ---------------------------------------------------------------------------
# Hàm phụ
# ---------------------------------------------------------------------------
def _fold(text: str) -> str:
    """'Quản Trị' -> 'quan tri' (bỏ dấu, thường hóa, gọn khoảng trắng) để so khớp."""
    text = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", text).strip().casefold()


def _title_words(title: str) -> list[str]:
    """'⚔️ Role XP' -> ['role', 'xp'] (bỏ emoji)."""
    return _fold(re.sub(r"[^\w\s&-]", " ", title)).replace("&", " ").split()


def _tick(text: str) -> str:
    """Dùng an toàn bên trong dấu ` `."""
    return text.replace("`", "'").replace("\n", " ")


def _with_prefix(text: str, prefix: str) -> str:
    """Trong help= các lệnh viết sẵn dấu '.', đổi sang tiền tố thực tế nếu khác."""
    if prefix == ".":
        return text
    return re.sub(r"(?<![\w.])\.(?=[A-Za-z])", prefix.replace("\\", "\\\\"), text)


def _split_help(command: commands.Command) -> tuple[str, str]:
    """(mô tả, cách dùng viết sẵn trong help=). Thiếu thì trả chuỗi rỗng cho cách dùng."""
    text = (command.help or "").strip()
    match = _USAGE_RE.search(text)
    if match:
        return (text[:match.start()].strip() or "Chưa có mô tả."), match.group(1).strip()
    return (text or "Chưa có mô tả."), ""


def _short(command: commands.Command) -> str:
    description, _ = _split_help(command)
    return description.splitlines()[0].strip()[:110]


def _usage(prefix: str, command: commands.Command) -> str:
    _, written = _split_help(command)
    if written:
        return _tick(_with_prefix(written, prefix))
    return _tick(f"{prefix}{command.qualified_name} {command.signature}".strip())


def _subcommands(command: commands.Command) -> list[commands.Command]:
    walker = getattr(command, "walk_commands", None)
    if walker is None:
        return []
    return sorted((c for c in walker() if not c.hidden), key=lambda c: c.qualified_name)


async def _check(ctx: commands.Context, command: commands.Command) -> tuple[bool, str]:
    """(dùng được không, lý do nếu không)."""
    try:
        return bool(await command.can_run(ctx)), ""
    except commands.MissingPermissions as exc:
        names = ", ".join(p.replace("_", " ").title() for p in exc.missing_permissions)
        return False, f"cần quyền **{names}**"
    except commands.CommandError:
        return False, "bạn chưa đủ điều kiện để dùng lệnh này"
    except Exception:  # check lỗi bất ngờ: coi như không chạy được
        log.exception("Kiểm tra quyền lệnh %s lỗi", command.qualified_name)
        return False, ""


def _lock(ok: bool) -> str:
    return "" if ok else "🔒 "


def _split_field(name: str, value: str) -> list[tuple[str, str]]:
    """Cắt một field dài thành nhiều field <= 1024 ký tự, không bỏ sót dòng nào."""
    name = name[:240]
    lines = [line[:FIELD_VALUE_LIMIT - 24] for line in value.split("\n")] or [""]
    chunks: list[str] = [""]
    for line in lines:
        candidate = f"{chunks[-1]}\n{line}" if chunks[-1] else line
        if len(candidate) > FIELD_VALUE_LIMIT:
            chunks.append(line)
        else:
            chunks[-1] = candidate
    return [(name if i == 0 else f"{name} (tiếp)", chunk or "​") for i, chunk in enumerate(chunks)]


def _paginate(title: str, description: str, fields: Iterable[tuple[str, str]], footer: str
              ) -> list[tuple[discord.Embed, int]]:
    """Dựng danh sách embed (kèm cỡ chữ) từ các field, tự sang embed mới khi gần chạm giới hạn."""
    pages: list[list] = []  # [embed, số chữ]

    def new_page() -> None:
        first = not pages
        page_title = title if first else f"{title} (tiếp)"
        embed = discord.Embed(title=page_title[:256], description=(description if first else None), color=HELP_COLOR)
        pages.append([embed, len(page_title) + (len(description) if first else 0), 0])

    for name, value in fields:
        for chunk_name, chunk_value in _split_field(name, value):
            need = len(chunk_name) + len(chunk_value)
            if not pages or pages[-1][2] >= MAX_FIELDS or pages[-1][1] + need > EMBED_BUDGET:
                new_page()
            page = pages[-1]
            page[0].add_field(name=chunk_name, value=chunk_value, inline=False)
            page[1] += need
            page[2] += 1
    if not pages:
        new_page()
    last = pages[-1]
    last[0].set_footer(text=footer[:2000])
    last[1] += len(footer)
    return [(embed, size) for embed, size, _ in pages]


async def _send_pages(ctx: commands.Context, pages: list[tuple[discord.Embed, int]]) -> None:
    """Gửi các embed, gộp vào cùng tin nhắn khi còn trong giới hạn của Discord."""
    no_mentions = discord.AllowedMentions.none()
    batch: list[discord.Embed] = []
    total = 0
    for embed, size in pages:
        if batch and (total + size > MESSAGE_BUDGET or len(batch) >= MAX_EMBEDS_PER_MESSAGE):
            await ctx.send(embeds=batch, allowed_mentions=no_mentions)
            batch, total = [], 0
        batch.append(embed)
        total += size
    if batch:
        await ctx.send(embeds=batch, allowed_mentions=no_mentions)


Entry = tuple[commands.Command, bool]  # (lệnh, người gọi dùng được không)
Group = tuple[str, list[str], list[Entry]]  # (tên hiển thị, từ khóa đã bỏ dấu, các lệnh)


class VietHelp(commands.Cog):
    """Lệnh .help đầy đủ, chia nhóm."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # -- dữ liệu --------------------------------------------------------------
    async def _grouped(self, ctx: commands.Context) -> tuple[list[Group], list[Group]]:
        """(nhóm cho thành viên, nhóm quản trị), kèm cờ 'dùng được'. Nhóm rỗng bị bỏ."""
        visible = {c.qualified_name: c for c in self.bot.commands if not c.hidden}
        flags = {name: (await _check(ctx, c))[0] for name, c in visible.items()}

        def build(categories: list[tuple[str, str, list[str]]]) -> list[Group]:
            result: list[Group] = []
            for title, keywords, names in categories:
                entries = [(visible[n], flags[n]) for n in names if n in visible]
                if entries:
                    result.append((title, [_fold(k) for k in keywords.split("|")], entries))
            return result

        member_groups, admin_groups = build(CATEGORIES), build(ADMIN_CATEGORIES)
        listed = {n for _, _, names in CATEGORIES + ADMIN_CATEGORIES for n in names}
        rest = [(c, flags[n]) for n, c in sorted(visible.items()) if n not in listed and n not in HIDDEN_FROM_HELP]
        if rest:
            member_groups.append((OTHER_TITLE, [_fold(k) for k in OTHER_KEYWORDS.split("|")], rest))
        return member_groups, admin_groups

    def _find_command(self, text: str) -> Optional[commands.Command]:
        """Tìm lệnh/lệnh con theo tên hoặc tên gọi tắt, không phân biệt hoa-thường và dấu."""
        command = self.bot.get_command(text)
        if command is not None and not command.hidden:
            return command
        wanted = _fold(text)
        for candidate in self.bot.walk_commands():
            if candidate.hidden:
                continue
            parent = candidate.full_parent_name
            names = [candidate.qualified_name] + [f"{parent} {a}".strip() for a in candidate.aliases]
            if wanted in (_fold(n) for n in names):
                return candidate
        return None

    # -- embed ----------------------------------------------------------------
    def _overview(self, prefix: str, groups: list[Group], *, admin: bool = False) -> list[tuple[discord.Embed, int]]:
        fields: list[tuple[str, str]] = []
        total = 0
        subtotal = 0
        for title, _, entries in groups:
            lines: list[str] = []
            for command, ok in entries:
                line = f"{_lock(ok)}`{prefix}{command.qualified_name}` · {_short(command)}"
                subs = _subcommands(command)
                if subs:
                    names = " · ".join(s.qualified_name.removeprefix(command.qualified_name + " ") for s in subs)
                    line += f"\n└ lệnh con: {names}"
                    subtotal += len(subs)
                lines.append(line)
                total += 1
            fields.append((f"{title} ({len(entries)})", "\n".join(lines)))
        home = "helpadmin" if admin else "help"
        topics = ", ".join(f"`{prefix}{home} {kw.split('|')[0]}`"
                           for _, kw, _ in (ADMIN_CATEGORIES if admin else CATEGORIES)[:4])
        description = (f"Tiền tố lệnh: `{prefix}`\n"
                       f"• `{prefix}{home} <lệnh>` xem chi tiết một lệnh · `{prefix}{home} <nhóm>` xem cả nhóm "
                       f"(ví dụ {topics})\n"
                       f"• `<tham_số>` là bắt buộc, `[tham_số]` là tùy chọn · 🔒 là lệnh bạn chưa đủ quyền dùng")
        footer = f"{total} lệnh" + (f" · {subtotal} lệnh con" if subtotal else "")
        return _paginate("🛠️ Lệnh quản trị" if admin else "📖 Hướng dẫn sử dụng bot", description, fields, footer)

    def _group_pages(self, prefix: str, title: str, entries: list[Entry], *, admin: bool = False
                     ) -> list[tuple[discord.Embed, int]]:
        fields: list[tuple[str, str]] = []
        for command, ok in entries:
            description, _ = _split_help(command)
            parts = [description, f"**Dùng:** `{_usage(prefix, command)}`"]
            if command.aliases:
                parts.append("**Gọi tắt:** " + ", ".join(f"`{prefix}{a}`" for a in command.aliases))
            for sub in _subcommands(command):
                parts.append(f"└ `{_usage(prefix, sub)}` · {_short(sub)}")
            fields.append((f"{_lock(ok)}{prefix}{command.qualified_name}", "\n".join(parts)))
        home = "helpadmin" if admin else "help"
        return _paginate(title, "", fields, f"Gõ {prefix}{home} để quay lại tổng quan · 🔒 = bạn chưa đủ quyền")

    async def _command_embed(self, ctx: commands.Context, prefix: str, command: commands.Command) -> discord.Embed:
        description, _ = _split_help(command)
        ok, reason = await _check(ctx, command)
        embed = discord.Embed(title=f"📌 {prefix}{command.qualified_name}", description=description[:2000],
                              color=HELP_COLOR)
        embed.add_field(name="Cách dùng", value=f"`{_usage(prefix, command)}`", inline=False)
        if command.aliases:
            embed.add_field(name="Tên gọi tắt", value=", ".join(f"`{prefix}{a}`" for a in command.aliases),
                            inline=False)
        subs = _subcommands(command)
        if subs:
            lines = [f"`{_usage(prefix, s)}` · {_short(s)}" for s in subs]
            for name, value in _split_field("Lệnh con", "\n".join(lines)):
                embed.add_field(name=name, value=value, inline=False)
        embed.add_field(
            name="Quyền",
            value="✅ Bạn dùng được lệnh này." if ok else
                  f"🔒 Bạn chưa dùng được lệnh này{': ' + reason if reason else '.'}",
            inline=False,
        )
        embed.set_footer(text=f"Gõ {prefix}help để xem tất cả lệnh.")
        return embed

    # -- lệnh -----------------------------------------------------------------
    async def _handle(self, ctx: commands.Context, query: Optional[str], *, admin: bool) -> None:
        prefix = ctx.prefix or config.PREFIX
        member_groups, admin_groups = await self._grouped(ctx)
        admin_titles = {title for title, _, _ in admin_groups}
        groups = admin_groups if admin else member_groups
        # Tra cứu trong .help tìm được cả nhóm quản trị (ví dụ ".help quản trị" chỉ sang nhóm đó).
        searchable = admin_groups if admin else member_groups + admin_groups
        no_mentions = discord.AllowedMentions.none()
        home = "helpadmin" if admin else "help"

        if not query or not query.strip():
            await _send_pages(ctx, self._overview(prefix, groups, admin=admin))
            return

        raw = query.strip().removeprefix(prefix).strip()
        wanted = _fold(raw)

        # 1) khớp chính xác tên nhóm hoặc từ khóa của nhóm
        for title, keywords, entries in searchable:
            if wanted == " ".join(_title_words(title)) or wanted in keywords:
                await _send_pages(ctx, self._group_pages(prefix, title, entries, admin=title in admin_titles))
                return

        # 2) tên lệnh, tên gọi tắt hoặc lệnh con ("xp-admin add")
        command = self._find_command(raw)
        if command is not None and not admin and command.qualified_name in HIDDEN_FROM_HELP:
            command = None
        if command is not None:
            await ctx.send(embed=await self._command_embed(ctx, prefix, command), allowed_mentions=no_mentions)
            return

        # 3) khớp một từ lẻ trong tên nhóm (".help xp" -> "Role XP")
        for title, _, entries in searchable:
            if wanted in _title_words(title):
                await _send_pages(ctx, self._group_pages(prefix, title, entries, admin=title in admin_titles))
                return

        # 4) không thấy: gợi ý tên gần giống
        pool: dict[str, str] = {}
        for candidate in self.bot.walk_commands():
            if candidate.hidden or (not admin and candidate.qualified_name in HIDDEN_FROM_HELP):
                continue
            for name in [candidate.qualified_name, *candidate.aliases]:
                pool.setdefault(_fold(name), f"{prefix}{name}")
        for title, keywords, _ in searchable:
            pool.setdefault(keywords[0], f"{prefix}{home} {keywords[0]}")
        close = difflib.get_close_matches(wanted, list(pool), n=3, cutoff=0.6)
        hint = ("\nÝ bạn là: " + ", ".join(f"`{pool[c]}`" for c in close) + "?") if close else ""
        await ctx.send(
            f"❌ Không tìm thấy lệnh hoặc nhóm `{discord.utils.escape_markdown(raw)[:50]}`.{hint}\n"
            f"Gõ `{prefix}{home}` để xem danh sách đầy đủ.",
            allowed_mentions=no_mentions,
        )

    @commands.command(name="help", aliases=["h", "trogiup", "lenh"],
                      help="Xem các lệnh dành cho thành viên. Dùng: .help [lệnh hoặc nhóm]")
    async def help_cmd(self, ctx: commands.Context, *, query: Optional[str] = None) -> None:
        await self._handle(ctx, query, admin=False)

    @commands.command(name="helpadmin", aliases=["ha", "adminhelp"],
                      help="Xem các lệnh quản trị (🔒 = bạn chưa đủ quyền). Dùng: .helpadmin [lệnh hoặc nhóm]")
    async def helpadmin_cmd(self, ctx: commands.Context, *, query: Optional[str] = None) -> None:
        await self._handle(ctx, query, admin=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(VietHelp(bot))
