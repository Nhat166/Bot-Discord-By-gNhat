"""Ngân hàng XP dùng chung.

Mọi module (leveling, moderation, sự kiện, tính năng sau này) phải cộng/trừ XP qua các hàm
trong file này để chỉ có MỘT nguồn dữ liệu XP duy nhất:

    get_xp(user_id, guild_id)
    add_xp(user_id, guild_id, amount, reason)
    remove_xp(user_id, guild_id, amount, reason)
    get_level(user_id, guild_id)
    get_xp_progress(user_id, guild_id)

Mỗi giao dịch được ghi vào bảng `xp_transactions` (người nhận, số XP thay đổi, lý do,
thời gian, nguồn phát sinh). Các hàm này KHÔNG tự kiểm tra quyền: chỉ module đáng tin cậy
mới được import chúng, còn lệnh dành cho người dùng (ví dụ `.xp-admin`) phải tự kiểm tra
quyền quản trị trước khi gọi.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import config
from database import db

MAX_AMOUNT_PER_TRANSACTION = 1_000_000_000
MAX_TOTAL_XP = 10**15


class XPError(ValueError):
    """Dữ liệu đầu vào không hợp lệ cho một giao dịch XP."""


@dataclass(frozen=True)
class LevelInfo:
    index: int
    name: str
    start_xp: int  # XP đầu cấp (tổng XP tối thiểu của cấp bậc này)
    next_xp: int | None  # XP cấp tiếp theo; None nếu đã ở cấp cao nhất
    next_name: str | None


@dataclass(frozen=True)
class XPProgress:
    xp: int
    level: LevelInfo
    percent: float  # 0..100
    remaining: int | None  # XP còn thiếu để lên cấp; None nếu đã ở cấp cao nhất


@dataclass(frozen=True)
class XPChange:
    guild_id: int
    user_id: int
    requested: int
    applied: int  # số XP thực sự thay đổi (có thể < requested khi trừ về 0)
    old_xp: int
    new_xp: int
    duplicate: bool = False  # True nếu giao dịch (cùng source + ref) đã được ghi trước đó

    @property
    def old_level(self) -> LevelInfo:
        return level_for_xp(self.old_xp)

    @property
    def new_level(self) -> LevelInfo:
        return level_for_xp(self.new_xp)

    @property
    def leveled_up(self) -> bool:
        return self.new_level.index > self.old_level.index


# ---------------------------------------------------------------------------
# Tính cấp bậc và tiến độ (hàm thuần, không đụng tới cơ sở dữ liệu)
# ---------------------------------------------------------------------------
def level_for_xp(xp: int) -> LevelInfo:
    levels = config.LEVELS
    index = 0
    for i, (_, required) in enumerate(levels):
        if xp >= required:
            index = i
        else:
            break
    name, start = levels[index]
    if index + 1 < len(levels):
        next_name, next_xp = levels[index + 1]
    else:
        next_name, next_xp = None, None
    return LevelInfo(index, name, start, next_xp, next_name)


def progress_for_xp(xp: int) -> XPProgress:
    """Tiến độ = (XP hiện có - XP đầu cấp) / (XP cấp tiếp theo - XP đầu cấp) x 100%."""
    xp = max(0, int(xp))
    level = level_for_xp(xp)
    if level.next_xp is None:
        return XPProgress(xp, level, 100.0, None)
    span = level.next_xp - level.start_xp
    percent = (xp - level.start_xp) / span * 100
    return XPProgress(xp, level, min(100.0, max(0.0, percent)), level.next_xp - xp)


# ---------------------------------------------------------------------------
# Kiểm tra dữ liệu đầu vào
# ---------------------------------------------------------------------------
def _check_id(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise XPError(f"{label} không hợp lệ.")
    return value


def _check_amount(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise XPError("Số XP phải là số nguyên.")
    if value <= 0:
        raise XPError("Số XP phải lớn hơn 0.")
    if value > MAX_AMOUNT_PER_TRANSACTION:
        raise XPError(f"Số XP mỗi giao dịch tối đa là {MAX_AMOUNT_PER_TRANSACTION:,}.")
    return value


def _check_text(value: object, label: str, limit: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise XPError(f"{label} không được để trống.")
    return value.strip()[:limit]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Giao dịch XP
# ---------------------------------------------------------------------------
async def _apply(
    user_id: int,
    guild_id: int,
    delta: int,
    reason: str,
    source: str,
    actor_id: int | None,
    ref: str | None,
) -> XPChange:
    requested = abs(delta)
    now = _now()

    def run(conn: sqlite3.Connection) -> XPChange:
        row = conn.execute(
            "SELECT xp FROM users WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
        ).fetchone()
        old_xp = row["xp"] if row else 0
        new_xp = max(0, old_xp + delta)
        if new_xp > MAX_TOTAL_XP:
            raise XPError("Tổng XP vượt quá giới hạn cho phép.")
        applied = abs(new_xp - old_xp)
        if applied == 0:  # trừ khi đã hết XP: không có gì để ghi
            return XPChange(guild_id, user_id, requested, 0, old_xp, old_xp)
        try:
            conn.execute(
                "INSERT INTO xp_transactions "
                "(guild_id, user_id, delta, balance_after, reason, source, actor_id, ref, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (guild_id, user_id, new_xp - old_xp, new_xp, reason, source, actor_id, ref, now),
            )
        except sqlite3.IntegrityError:
            # Cùng (guild, user, source, ref) đã được ghi: bỏ qua để không cộng trùng.
            return XPChange(guild_id, user_id, requested, 0, old_xp, old_xp, duplicate=True)
        conn.execute(
            "INSERT INTO users (guild_id, user_id, xp, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = excluded.xp, updated_at = excluded.updated_at",
            (guild_id, user_id, new_xp, now),
        )
        return XPChange(guild_id, user_id, requested, applied, old_xp, new_xp)

    return await db.transaction(run)


async def add_xp(
    user_id: int,
    guild_id: int,
    amount: int,
    reason: str,
    *,
    source: str = "manual",
    actor_id: int | None = None,
    ref: str | None = None,
) -> XPChange:
    """Cộng XP và ghi lý do.

    `ref` là mã duy nhất của sự kiện sinh ra XP (ví dụ ID tin nhắn). Nếu cùng `source` và
    `ref` đã được ghi cho thành viên đó thì giao dịch bị bỏ qua (`duplicate=True`).
    """
    _check_id(user_id, "ID thành viên")
    _check_id(guild_id, "ID máy chủ")
    _check_amount(amount)
    reason = _check_text(reason, "Lý do", 200)
    source = _check_text(source, "Nguồn", 50)
    if actor_id is not None:
        _check_id(actor_id, "ID người thực hiện")
    if ref is not None:
        ref = _check_text(ref, "Mã tham chiếu", 100)
    return await _apply(user_id, guild_id, amount, reason, source, actor_id, ref)


async def remove_xp(
    user_id: int,
    guild_id: int,
    amount: int,
    reason: str,
    *,
    source: str = "manual",
    actor_id: int | None = None,
    ref: str | None = None,
) -> XPChange:
    """Trừ XP và ghi lý do. Tổng XP không bao giờ xuống dưới 0."""
    _check_id(user_id, "ID thành viên")
    _check_id(guild_id, "ID máy chủ")
    _check_amount(amount)
    reason = _check_text(reason, "Lý do", 200)
    source = _check_text(source, "Nguồn", 50)
    if actor_id is not None:
        _check_id(actor_id, "ID người thực hiện")
    if ref is not None:
        ref = _check_text(ref, "Mã tham chiếu", 100)
    return await _apply(user_id, guild_id, -amount, reason, source, actor_id, ref)


# ---------------------------------------------------------------------------
# Truy vấn
# ---------------------------------------------------------------------------
async def get_xp(user_id: int, guild_id: int) -> int:
    _check_id(user_id, "ID thành viên")
    _check_id(guild_id, "ID máy chủ")
    row = await db.fetchone("SELECT xp FROM users WHERE guild_id = ? AND user_id = ?", (guild_id, user_id))
    return row["xp"] if row else 0


async def get_level(user_id: int, guild_id: int) -> LevelInfo:
    return level_for_xp(await get_xp(user_id, guild_id))


async def get_xp_progress(user_id: int, guild_id: int) -> XPProgress:
    return progress_for_xp(await get_xp(user_id, guild_id))


async def get_rank(user_id: int, guild_id: int) -> int | None:
    """Thứ hạng (bắt đầu từ 1) trong máy chủ; None nếu thành viên chưa có XP."""
    xp = await get_xp(user_id, guild_id)
    if xp <= 0:
        return None
    row = await db.fetchone(
        "SELECT COUNT(*) AS ahead FROM users "
        "WHERE guild_id = ? AND (xp > ? OR (xp = ? AND user_id < ?))",
        (guild_id, xp, xp, user_id),
    )
    return int(row["ahead"]) + 1


def period_bounds(kind: str, now: datetime | None = None,
                  utc_offset_hours: int | None = None) -> tuple[datetime, datetime]:
    """(bắt đầu, kết thúc) của tuần hoặc tháng hiện tại, trả về giờ UTC. kind = "week" | "month".

    Tuần chạy từ 00:00 thứ Hai đến hết Chủ nhật, tháng từ 00:00 ngày 1 đến hết ngày cuối tháng,
    tính theo múi giờ config.LEADERBOARD_UTC_OFFSET. Khoảng thời gian là [bắt đầu, kết thúc).
    """
    hours = config.LEADERBOARD_UTC_OFFSET if utc_offset_hours is None else utc_offset_hours
    local = (now or datetime.now(timezone.utc)).astimezone(timezone(timedelta(hours=hours)))
    midnight = local.replace(hour=0, minute=0, second=0, microsecond=0)
    if kind == "week":
        start = midnight - timedelta(days=midnight.weekday())
        end = start + timedelta(days=7)
    elif kind == "month":
        start = midnight.replace(day=1)
        end = (start.replace(year=start.year + 1, month=1) if start.month == 12
               else start.replace(month=start.month + 1))
    else:
        raise ValueError(f"kind phải là 'week' hoặc 'month' (nhận được {kind!r}).")
    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


# XP "kiếm được" trong một khoảng: chỉ tính giao dịch cộng XP, không tính XP quản trị viên cộng tay.
_PERIOD_FILTER = ("guild_id = ? AND created_at >= ? AND created_at < ? "
                  "AND delta > 0 AND source <> 'admin'")


def _iso(moment: datetime) -> str:
    return moment.astimezone(timezone.utc).isoformat(timespec="seconds")


async def get_period_leaderboard(guild_id: int, start: datetime, end: datetime,
                                 limit: int = 10) -> list[tuple[int, int]]:
    """Danh sách (user_id, XP kiếm được trong [start, end)) xếp từ cao xuống thấp."""
    _check_id(guild_id, "ID máy chủ")
    limit = max(1, min(int(limit), 100))
    rows = await db.fetchall(
        f"SELECT user_id, SUM(delta) AS gained FROM xp_transactions WHERE {_PERIOD_FILTER} "
        "GROUP BY user_id ORDER BY gained DESC, user_id ASC LIMIT ?",
        (guild_id, _iso(start), _iso(end), limit),
    )
    return [(int(r["user_id"]), int(r["gained"])) for r in rows]


async def get_period_standing(user_id: int, guild_id: int, start: datetime,
                              end: datetime) -> tuple[int, int | None]:
    """(XP kiếm được, thứ hạng) của một thành viên trong [start, end). Hạng là None nếu chưa kiếm được XP."""
    _check_id(user_id, "ID thành viên")
    _check_id(guild_id, "ID máy chủ")
    args = (guild_id, _iso(start), _iso(end))
    row = await db.fetchone(
        f"SELECT COALESCE(SUM(delta), 0) AS gained FROM xp_transactions WHERE {_PERIOD_FILTER} AND user_id = ?",
        (*args, user_id),
    )
    gained = int(row["gained"])
    if gained <= 0:
        return 0, None
    ahead = await db.fetchone(
        f"SELECT COUNT(*) AS ahead FROM (SELECT user_id, SUM(delta) AS g FROM xp_transactions "
        f"WHERE {_PERIOD_FILTER} GROUP BY user_id HAVING g > ? OR (g = ? AND user_id < ?))",
        (*args, gained, gained, user_id),
    )
    return gained, int(ahead["ahead"]) + 1


async def get_leaderboard(guild_id: int, limit: int = 10) -> list[tuple[int, int]]:
    """Danh sách (user_id, xp) xếp từ cao xuống thấp."""
    _check_id(guild_id, "ID máy chủ")
    limit = max(1, min(int(limit), 100))
    rows = await db.fetchall(
        "SELECT user_id, xp FROM users WHERE guild_id = ? AND xp > 0 "
        "ORDER BY xp DESC, user_id ASC LIMIT ?",
        (guild_id, limit),
    )
    return [(int(r["user_id"]), int(r["xp"])) for r in rows]
