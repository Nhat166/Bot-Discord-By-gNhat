"""Lệnh .auto: tự động chạy một lệnh của bot vào giờ hẹn, gửi kết quả vào kênh bạn chọn.

    .auto <lệnh> #kênh <thời gian>

Ví dụ (giờ Việt Nam, UTC+7):
    .auto .thoitiet Quảng Ngãi #thời-tiết 06:30      -> mỗi ngày lúc 06:30
    .auto .leaderboardWeek #bảng-xếp-hạng 20:00      -> mỗi ngày lúc 20:00
    .auto .thoitiet Hà Nội #thời-tiết mỗi 2 giờ      -> cứ 2 giờ một lần
    .auto .leaderboardWeek #bxh cuối tuần            -> Chủ nhật hằng tuần (mặc định 20:00)
    .auto .leaderboardMonth #bxh cuối tháng 21:00    -> ngày cuối cùng của mỗi tháng lúc 21:00
    .auto list                                       -> xem các lịch đang có
    .auto remove 3 | pause 3 | resume 3 | run 3      -> xóa / tạm dừng / bật lại / chạy thử ngay

Quyền: chỉ quản trị viên (Administrator) dùng được mọi lệnh .auto.
Số thứ tự lịch (#1, #2...) tính riêng cho từng máy chủ; xóa một lịch thì các lịch phía sau được đánh số lại liền mạch.

Cách viết thời gian:
    06:30, 6h30, 6h, 18g, "6 giờ 30"   -> mỗi ngày vào giờ đó
    mỗi 30 phút, mỗi 2 giờ, every 1h   -> lặp theo khoảng (tối thiểu 10 phút, tối đa 7 ngày)
    cuối tuần [giờ]                    -> Chủ nhật hằng tuần (không ghi giờ = 20:00)
    cuối tháng [giờ]                   -> ngày cuối cùng của mỗi tháng (28/29/30/31), không ghi giờ = 20:00

Cách hoạt động:
  * Lịch được lưu trong SQLite (bảng auto_tasks, tự tạo) nên khởi động lại bot vẫn còn.
  * Bot KHÔNG gửi tin nhắn lệnh thật. Nó tạo một "tin nhắn giả" mang tên người tạo lịch rồi chạy thẳng lệnh,
    nên lệnh chạy với đúng quyền của người tạo (mất quyền thì lệnh sẽ bị từ chối).
  * Bot đang tắt đúng giờ hẹn: lần đó bị bỏ qua (nếu trễ quá 10 phút), lần sau chạy bình thường.
  * Lệnh lỗi 3 lần liên tiếp thì lịch tự tắt và báo vào kênh log; dùng `.auto resume <id>` để bật lại.
"""
from __future__ import annotations

import asyncio
import calendar
import logging
import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

import discord
from discord.ext import commands, tasks

import config
import ui
from database import db
from utils import send_log

log = logging.getLogger("bot.auto")

VN_TZ = timezone(timedelta(hours=7))  # Việt Nam không có giờ mùa hè nên cố định UTC+7 là đủ
UTC = timezone.utc
TS_FORMAT = "%Y-%m-%d %H:%M:%S"  # lưu giờ UTC dạng chuỗi để so sánh theo thứ tự chữ cái

MAX_TASKS_PER_GUILD = 10
MIN_INTERVAL_MINUTES = 10
MAX_INTERVAL_MINUTES = 7 * 24 * 60
MAX_COMMAND_LENGTH = 200
MAX_FAILURES = 3  # lỗi liên tiếp tối đa trước khi lịch tự tắt
LATE_GRACE = timedelta(minutes=10)  # trễ hơn mức này (bot tắt) thì bỏ qua lần chạy đó
TICK_SECONDS = 15

# Lệnh không được lên lịch (tránh tự gọi vòng lặp). Thêm tên lệnh gốc vào đây nếu muốn chặn thêm.
BLOCKED_COMMANDS = {"auto"}

# Mọi lệnh .auto chỉ dành cho quản trị viên (quyền Administrator).
_admin_only = commands.has_guild_permissions(administrator=True)


class AutoError(Exception):
    """Lỗi có nội dung thân thiện, gửi thẳng được cho người dùng."""


# ---------------------------------------------------------------------------
# Thời gian
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Schedule:
    # "daily": mỗi ngày | "every": lặp theo khoảng | "week_end": Chủ nhật hằng tuần | "month_end": ngày cuối tháng
    kind: str
    value: int  # với "every": số phút giữa hai lần; các loại còn lại: số phút kể từ 00:00

    def describe(self) -> str:
        clock = f"{self.value // 60:02d}:{self.value % 60:02d}"
        if self.kind == "daily":
            return f"hằng ngày lúc **{clock}**"
        if self.kind == "week_end":
            return f"**cuối tuần** (Chủ nhật) lúc **{clock}**"
        if self.kind == "month_end":
            return f"**ngày cuối tháng** lúc **{clock}**"
        return f"mỗi **{fmt_interval(self.value)}**"


def fmt_interval(minutes: int) -> str:
    days, rest = divmod(minutes, 1440)
    hours, mins = divmod(rest, 60)
    parts = []
    if days:
        parts.append(f"{days} ngày")
    if hours:
        parts.append(f"{hours} giờ")
    if mins:
        parts.append(f"{mins} phút")
    return " ".join(parts) or "0 phút"


_CLOCK = r"(\d{1,2})\s*(?::|giờ|gio|h|g)\s*(\d{1,2})?\s*(?:phút|phut|p)?"
_DAILY_RE = re.compile(r"^(?:(?:lúc|luc|at|hằng ngày|hang ngay|mỗi ngày|moi ngay|daily)\s+)?" + _CLOCK + "$")
_PERIOD_END_RE = re.compile(
    r"^(?:(?:vào|vao|mỗi|moi)\s+)?(cuối tuần|cuoi tuan|cuối tháng|cuoi thang)"
    r"(?:\s+(?:(?:lúc|luc|at)\s+)?" + _CLOCK + ")?$"
)
DEFAULT_END_MINUTES = 20 * 60  # "cuối tuần/cuối tháng" không ghi giờ -> 20:00
_EVERY_RE = re.compile(
    r"^(?:mỗi|moi|every|cứ mỗi|cu moi)\s+(\d{1,4})\s*(phút|phut|min|m|p|giờ|gio|tiếng|tieng|h|g|ngày|ngay|d)$"
)
_UNIT_MINUTES = {
    "phút": 1, "phut": 1, "min": 1, "m": 1, "p": 1,
    "giờ": 60, "gio": 60, "tiếng": 60, "tieng": 60, "h": 60, "g": 60,
    "ngày": 1440, "ngay": 1440, "d": 1440,
}

TIME_HELP = ("Ví dụ: `06:30` (mỗi ngày lúc 6 giờ 30, giờ Việt Nam), `18h`, `mỗi 30 phút`, `mỗi 2 giờ`, "
             "`cuối tuần`, `cuối tháng 21:00`.")


def _clock_minutes(hour_text: str, minute_text: Optional[str]) -> int:
    hour, minute = int(hour_text), int(minute_text or 0)
    if hour > 23 or minute > 59:
        raise AutoError(f"Giờ không hợp lệ (giờ 0-23, phút 0-59). {TIME_HELP}")
    return hour * 60 + minute


def parse_schedule(text: str) -> Schedule:
    text = re.sub(r"\s+", " ", unicodedata.normalize("NFC", text).strip().lower())
    if not text:
        raise AutoError(f"Thiếu thời gian. {TIME_HELP}")

    match = _DAILY_RE.match(text)
    if match:
        return Schedule("daily", _clock_minutes(match.group(1), match.group(2)))

    match = _PERIOD_END_RE.match(text)
    if match:
        kind = "week_end" if match.group(1).startswith(("cuối tuần", "cuoi tuan")) else "month_end"
        minutes = _clock_minutes(match.group(2), match.group(3)) if match.group(2) else DEFAULT_END_MINUTES
        return Schedule(kind, minutes)

    match = _EVERY_RE.match(text)
    if match:
        minutes = int(match.group(1)) * _UNIT_MINUTES[match.group(2)]
        if minutes < MIN_INTERVAL_MINUTES:
            raise AutoError(f"Khoảng lặp tối thiểu là **{MIN_INTERVAL_MINUTES} phút** để tránh làm phiền kênh.")
        if minutes > MAX_INTERVAL_MINUTES:
            raise AutoError("Khoảng lặp tối đa là **7 ngày**. Muốn chạy mỗi ngày thì dùng giờ cố định, ví dụ `06:30`.")
        return Schedule("every", minutes)

    raise AutoError(f"Mình không hiểu thời gian `{_plain(text)[:40]}`. {TIME_HELP}")


def next_daily(after: datetime, minutes: int) -> datetime:
    """Lần chạy kế tiếp (UTC) lúc `minutes` phút kể từ 00:00 giờ Việt Nam, sau thời điểm `after`."""
    local = after.astimezone(VN_TZ)
    candidate = local.replace(hour=minutes // 60, minute=minutes % 60, second=0, microsecond=0)
    if candidate <= local:
        candidate += timedelta(days=1)
    return candidate.astimezone(UTC)


def next_week_end(after: datetime, minutes: int) -> datetime:
    """Chủ nhật kế tiếp (giờ Việt Nam) lúc `minutes` phút kể từ 00:00, sau thời điểm `after`."""
    local = after.astimezone(VN_TZ)
    day = local + timedelta(days=(6 - local.weekday()) % 7)  # weekday(): thứ Hai = 0 ... Chủ nhật = 6
    candidate = day.replace(hour=minutes // 60, minute=minutes % 60, second=0, microsecond=0)
    if candidate <= local:
        candidate += timedelta(days=7)
    return candidate.astimezone(UTC)


def next_month_end(after: datetime, minutes: int) -> datetime:
    """Ngày cuối cùng của tháng (28/29/30/31) lúc `minutes` phút kể từ 00:00 giờ Việt Nam, sau `after`."""
    local = after.astimezone(VN_TZ)
    year, month = local.year, local.month
    while True:
        last_day = calendar.monthrange(year, month)[1]
        candidate = datetime(year, month, last_day, minutes // 60, minutes % 60, tzinfo=VN_TZ)
        if candidate > local:
            return candidate.astimezone(UTC)
        year, month = (year + 1, 1) if month == 12 else (year, month + 1)


def _next_fixed(schedule: Schedule, after: datetime) -> datetime:
    if schedule.kind == "daily":
        return next_daily(after, schedule.value)
    if schedule.kind == "week_end":
        return next_week_end(after, schedule.value)
    return next_month_end(after, schedule.value)


def first_run(schedule: Schedule, now: datetime) -> datetime:
    if schedule.kind == "every":
        return now + timedelta(minutes=schedule.value)
    return _next_fixed(schedule, now)


def following_run(schedule: Schedule, scheduled: datetime, now: datetime) -> datetime:
    """Lần chạy sau lần `scheduled` (luôn lớn hơn `now`, nên bot tắt lâu cũng không chạy bù dồn dập)."""
    if schedule.kind != "every":
        return _next_fixed(schedule, now)
    step = timedelta(minutes=schedule.value)
    candidate = scheduled + step
    if candidate <= now:
        candidate = scheduled + step * ((now - scheduled) // step + 1)
    return candidate


def _now() -> datetime:
    return datetime.now(UTC)


def _ts(moment: datetime) -> str:
    return moment.astimezone(UTC).strftime(TS_FORMAT)


def _from_ts(value: str) -> datetime:
    return datetime.strptime(value, TS_FORMAT).replace(tzinfo=UTC)


def _plain(text: str) -> str:
    """Hiển thị an toàn trong dấu ` ` (bỏ dấu ` và ký tự xuống dòng)."""
    return text.replace("`", "'").replace("\n", " ")


# ---------------------------------------------------------------------------
# Tách tham số: "<lệnh> #kênh <thời gian>"
# ---------------------------------------------------------------------------
_CHANNEL_MENTION_RE = re.compile(r"<#(\d{15,22})>")
_CHANNEL_NAME_RE = re.compile(r"(?<!\S)#([^\s#<>]+)")


def split_args(text: str, guild: discord.Guild) -> tuple[str, discord.TextChannel, str]:
    text = text.strip()
    match = _CHANNEL_MENTION_RE.search(text)
    channel = None
    if match:
        channel = guild.get_channel(int(match.group(1)))
        if channel is None:
            raise AutoError("Không tìm thấy kênh đó trong máy chủ này.")
    else:
        match = _CHANNEL_NAME_RE.search(text)
        if match:
            wanted = match.group(1).casefold()
            channel = next((c for c in guild.text_channels if c.name.casefold() == wanted), None)
            if channel is None:
                raise AutoError(f"Không có kênh nào tên `#{_plain(match.group(1))[:50]}`. "
                                "Hãy gõ `#` rồi chọn kênh trong danh sách gợi ý của Discord.")
    if match is None:
        raise AutoError("Thiếu kênh nhận kết quả. Hãy gõ `#` rồi chọn kênh, ví dụ `#thời-tiết`.")
    if not isinstance(channel, discord.TextChannel):
        raise AutoError("Chỉ chọn được kênh chat văn bản.")

    command_text = text[:match.start()].strip()
    schedule_text = text[match.end():].strip()
    if not command_text:
        raise AutoError("Thiếu lệnh cần chạy, ví dụ `.thoitiet Quảng Ngãi`.")
    if not schedule_text:
        raise AutoError(f"Thiếu thời gian. {TIME_HELP}")
    return command_text, channel, schedule_text


def clean_command(raw: str, prefixes: tuple[str, ...]) -> str:
    """Bỏ dấu lệnh ở đầu (".thoitiet" -> "thoitiet") và gọn khoảng trắng."""
    text = re.sub(r"\s+", " ", raw).strip()
    for prefix in prefixes:
        if prefix and text.startswith(prefix):
            text = text[len(prefix):].strip()
            break
    return text


# ---------------------------------------------------------------------------
# Tin nhắn giả dùng để chạy lệnh theo lịch
# ---------------------------------------------------------------------------
class AutoMessage:
    """Thay cho tin nhắn lệnh khi chạy theo lịch.

    Không có tin nhắn thật nào được gửi, nên các thao tác lên "tin lệnh" (xóa, trả lời, thả reaction...)
    được bỏ qua êm. Ví dụ `.clear` gọi ctx.message.delete() sẽ không xóa nhầm tin của người khác.
    """

    def __init__(self, *, content: str, author: discord.Member, channel: discord.TextChannel) -> None:
        now = discord.utils.utcnow()
        self.content = content
        self.author = author
        self.channel = channel
        self.guild = channel.guild
        self._state = getattr(channel, "_state", None) or getattr(channel.guild, "_state", None)
        self.id = discord.utils.time_snowflake(now)
        self.created_at = now
        self.edited_at = None
        self.type = discord.MessageType.default
        self.mentions: list = []
        self.role_mentions: list = []
        self.channel_mentions: list = []
        self.attachments: list = []
        self.embeds: list = []
        self.stickers: list = []
        self.reactions: list = []
        self.components: list = []
        self.reference = None
        self.webhook_id = None
        self.application_id = None
        self.interaction = None
        self.pinned = False
        self.tts = False
        self.mention_everyone = False

    @property
    def jump_url(self) -> str:
        return f"https://discord.com/channels/{self.guild.id}/{self.channel.id}/{self.id}"

    async def delete(self, *, delay: Optional[float] = None) -> None:
        return None

    async def edit(self, **kwargs) -> None:
        return None

    async def add_reaction(self, emoji) -> None:
        return None

    async def pin(self, *, reason: Optional[str] = None) -> None:
        return None

    async def unpin(self, *, reason: Optional[str] = None) -> None:
        return None

    async def reply(self, content=None, **kwargs):
        kwargs.pop("reference", None)
        kwargs.pop("mention_author", None)
        return await self.channel.send(content, **kwargs)


# ---------------------------------------------------------------------------
# Cog
# ---------------------------------------------------------------------------
class Auto(commands.Cog):
    """Lên lịch cho bot tự chạy lệnh."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._running: set[asyncio.Task] = set()
        self._busy: set[int] = set()

    # -- vòng đời -------------------------------------------------------------
    async def cog_load(self) -> None:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS auto_tasks (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                num        INTEGER NOT NULL DEFAULT 0,
                guild_id   INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                creator_id INTEGER NOT NULL,
                command    TEXT    NOT NULL,
                kind       TEXT    NOT NULL,
                value      INTEGER NOT NULL,
                next_run   TEXT    NOT NULL,
                last_run   TEXT,
                enabled    INTEGER NOT NULL DEFAULT 1,
                failures   INTEGER NOT NULL DEFAULT 0,
                created_at TEXT    NOT NULL
            )
            """
        )
        await db.execute("CREATE INDEX IF NOT EXISTS idx_auto_due ON auto_tasks (enabled, next_run)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_auto_guild ON auto_tasks (guild_id)")
        columns = [r["name"] for r in await db.fetchall("PRAGMA table_info(auto_tasks)")]
        if "num" not in columns:  # bảng của bản cũ chưa có số thứ tự riêng: thêm cột rồi đánh số lại
            await db.execute("ALTER TABLE auto_tasks ADD COLUMN num INTEGER NOT NULL DEFAULT 0")
            await db.transaction(self._renumber_all)
        await db.execute("CREATE INDEX IF NOT EXISTS idx_auto_num ON auto_tasks (guild_id, num)")
        self.scheduler.start()

    @staticmethod
    def _renumber(conn, guild_id: int) -> None:
        """Đánh số lại các lịch của một máy chủ thành 1, 2, 3... theo thứ tự cũ (không có lỗ trống)."""
        rows = conn.execute("SELECT id FROM auto_tasks WHERE guild_id = ? ORDER BY num, id", (guild_id,)).fetchall()
        for number, row in enumerate(rows, start=1):
            conn.execute("UPDATE auto_tasks SET num = ? WHERE id = ?", (number, row["id"]))

    @classmethod
    def _renumber_all(cls, conn) -> None:
        for row in conn.execute("SELECT DISTINCT guild_id FROM auto_tasks").fetchall():
            cls._renumber(conn, row["guild_id"])

    def cog_unload(self) -> None:
        self.scheduler.cancel()
        for task in list(self._running):
            task.cancel()

    # -- bộ lập lịch ----------------------------------------------------------
    @tasks.loop(seconds=TICK_SECONDS)
    async def scheduler(self) -> None:
        try:
            await self._tick()
        except Exception:  # noqa: BLE001 - một lỗi không được làm dừng cả vòng lặp
            log.exception("Lỗi trong vòng lặp lịch tự động")

    @scheduler.before_loop
    async def _before_scheduler(self) -> None:
        await self.bot.wait_until_ready()

    async def _tick(self) -> None:
        now = _now()
        rows = await db.fetchall(
            "SELECT * FROM auto_tasks WHERE enabled = 1 AND next_run <= ? ORDER BY next_run LIMIT 50",
            (_ts(now),),
        )
        for row in rows:
            schedule = Schedule(row["kind"], row["value"])
            scheduled = _from_ts(row["next_run"])
            following = following_run(schedule, scheduled, now)
            if now - scheduled > LATE_GRACE:
                log.info("Bỏ qua lần chạy trễ của lịch #%s (đáng ra lúc %s UTC)", row["id"], row["next_run"])
                await db.execute("UPDATE auto_tasks SET next_run = ? WHERE id = ? AND enabled = 1",
                                 (_ts(following), row["id"]))
                continue
            # Cập nhật mốc kế tiếp TRƯỚC khi chạy: dù lệnh chạy lâu hay lỗi cũng không bị chạy lặp.
            await db.execute("UPDATE auto_tasks SET next_run = ?, last_run = ? WHERE id = ? AND enabled = 1",
                             (_ts(following), _ts(now), row["id"]))
            task = asyncio.create_task(self._execute(row))
            self._running.add(task)
            task.add_done_callback(self._running.discard)

    # -- chạy một lịch --------------------------------------------------------
    async def _execute(self, row, *, manual: bool = False) -> Optional[str]:
        """Chạy lệnh của một lịch. Trả về None nếu ổn, hoặc mô tả vấn đề."""
        task_id = row["id"]
        if task_id in self._busy:
            return "Lịch này đang chạy, bạn thử lại sau vài giây."
        self._busy.add(task_id)
        try:
            problem, fatal = await self._run(row)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            log.exception("Lỗi không mong muốn khi chạy lịch #%s", task_id)
            problem, fatal = "Lỗi không mong muốn (xem chi tiết trong bot.log).", False
        finally:
            self._busy.discard(task_id)
        if not manual:
            await self._record_result(row, problem, fatal)
        return problem

    async def _run(self, row) -> tuple[Optional[str], bool]:
        """(vấn đề hoặc None, có phải lỗi vĩnh viễn không)."""
        guild = self.bot.get_guild(row["guild_id"])
        if guild is None:
            return "Bot không còn ở trong máy chủ này.", True
        channel = guild.get_channel(row["channel_id"])
        if not isinstance(channel, discord.TextChannel):
            return "Kênh đã bị xóa hoặc không còn là kênh chat.", True
        perms = channel.permissions_for(guild.me)
        if not (perms.view_channel and perms.send_messages):
            return "Bot không có quyền xem hoặc gửi tin trong kênh này.", False

        member = guild.get_member(row["creator_id"])
        if member is None:
            try:
                member = await guild.fetch_member(row["creator_id"])
            except discord.NotFound:
                return "Người tạo lịch đã rời máy chủ.", True
            except discord.HTTPException:
                return "Không lấy được thông tin người tạo lịch.", False

        message = AutoMessage(content=f"{config.PREFIX}{row['command']}", author=member, channel=channel)
        ctx = await self.bot.get_context(message)
        if not ctx.valid or ctx.command is None:
            return "Lệnh này không còn tồn tại.", True
        root = ctx.command.root_parent or ctx.command
        if root.name in BLOCKED_COMMANDS:
            return "Lệnh này không được phép lên lịch.", True

        # Lịch tự động không bị cooldown của người tạo chặn (ví dụ hai lịch .thoitiet cùng giờ).
        ctx.command.reset_cooldown(ctx)
        await self.bot.invoke(ctx)
        if ctx.command_failed:
            return "Lệnh chạy bị lỗi hoặc bị từ chối (xem tin báo lỗi trong kênh, hoặc bot.log).", False
        return None, False

    async def _record_result(self, row, problem: Optional[str], fatal: bool) -> None:
        task_id = row["id"]
        if problem is None:
            await db.execute("UPDATE auto_tasks SET failures = 0 WHERE id = ?", (task_id,))
            return
        await db.execute("UPDATE auto_tasks SET failures = failures + 1 WHERE id = ?", (task_id,))
        current = await db.fetchone("SELECT failures, num FROM auto_tasks WHERE id = ?", (task_id,))
        if current is None:  # lịch vừa bị xóa
            return
        failures, number = current["failures"], current["num"]
        disabled = fatal or failures >= MAX_FAILURES
        if disabled:
            await db.execute("UPDATE auto_tasks SET enabled = 0 WHERE id = ?", (task_id,))
        guild = self.bot.get_guild(row["guild_id"])
        if guild is not None:
            tail = ("\n⏸️ Lịch đã **tự tắt**. Sửa lỗi rồi dùng `.auto resume "
                    f"{number}` để bật lại.") if disabled else f"\nLỗi liên tiếp: {failures}/{MAX_FAILURES}."
            await send_log(guild, title="⚠️ Lịch tự động gặp lỗi",
                           description=f"Lịch **#{number}** (`{config.PREFIX}{_plain(row['command'])}`): {problem}{tail}",
                           color=ui.Color.WARNING)

    # -- hiển thị -------------------------------------------------------------
    @staticmethod
    def _status(row) -> str:
        if row["enabled"]:
            return "✅ Đang bật" + (f" · lỗi {row['failures']}/{MAX_FAILURES}" if row["failures"] else "")
        return "⏸️ Tạm dừng"

    def _task_line(self, row) -> str:
        schedule = Schedule(row["kind"], row["value"])
        text = f"→ <#{row['channel_id']}> · {schedule.describe()}\n{self._status(row)}"
        if row["enabled"]:
            nxt = _from_ts(row["next_run"])
            text += f" · lần tới {discord.utils.format_dt(nxt, 'f')} ({discord.utils.format_dt(nxt, 'R')})"
        if row["last_run"]:
            text += f"\nChạy gần nhất: {discord.utils.format_dt(_from_ts(row['last_run']), 'R')}"
        return text

    async def _get_task(self, ctx: commands.Context, task_id: int):
        row = await db.fetchone("SELECT * FROM auto_tasks WHERE num = ? AND guild_id = ?", (task_id, ctx.guild.id))
        if row is None:
            await ctx.send(embed=ui.error(f"Không có lịch **#{task_id}** trong máy chủ này. "
                                          f"Dùng `{ctx.prefix}auto list` để xem danh sách.", ctx=ctx),
                           allowed_mentions=discord.AllowedMentions.none())
        return row

    # -- lệnh -----------------------------------------------------------------
    @commands.group(
        name="auto", aliases=["tudong"], invoke_without_command=True,
        help="Tự chạy một lệnh vào giờ hẹn. Dùng: .auto <lệnh> #kênh <giờ | cuối tuần | cuối tháng> | list | remove | pause | resume | run",
        usage="<lệnh> #kênh <giờ | cuối tuần | cuối tháng> (ví dụ: .thoitiet Quảng Ngãi #thời-tiết 06:30)",
    )
    @commands.guild_only()
    @_admin_only
    async def auto(self, ctx: commands.Context, *, text: Optional[str] = None) -> None:
        no_ping = discord.AllowedMentions.none()
        p = ctx.prefix
        if not text or not text.strip():
            await ctx.send(embed=ui.info(
                f"**Tạo lịch:** `{p}auto <lệnh> #kênh <giờ>`\n"
                f"`{p}auto {p}thoitiet Quảng Ngãi #thời-tiết 06:30` · mỗi ngày 6:30\n"
                f"`{p}auto {p}leaderboardWeek #bảng-xếp-hạng 20:00` · mỗi ngày 20:00\n"
                f"`{p}auto {p}thoitiet Hà Nội #thời-tiết mỗi 2 giờ` · cứ 2 giờ một lần\n"
                f"`{p}auto {p}leaderboardWeek #bảng-xếp-hạng cuối tuần` · Chủ nhật hằng tuần (20:00)\n"
                f"`{p}auto {p}leaderboardMonth #bảng-xếp-hạng cuối tháng 21:00` · ngày cuối tháng lúc 21:00\n\n"
                f"**Quản lý:** `{p}auto list` · `{p}auto remove <id>` · `{p}auto pause <id>` · "
                f"`{p}auto resume <id>` · `{p}auto run <id>` (chạy thử ngay)\n\n"
                f"Chỉ **quản trị viên** dùng được. Giờ tính theo **giờ Việt Nam (UTC+7)**. Lệnh chạy với quyền của người tạo lịch.",
                title="⏰ Cách dùng .auto", ctx=ctx), allowed_mentions=no_ping)
            return
        try:
            await self._create(ctx, text)
        except AutoError as exc:
            await ctx.send(embed=ui.error(str(exc), ctx=ctx), allowed_mentions=no_ping)

    async def _create(self, ctx: commands.Context, text: str) -> None:
        no_ping = discord.AllowedMentions.none()
        command_text, channel, schedule_text = split_args(text, ctx.guild)
        schedule = parse_schedule(schedule_text)
        prefixes = tuple(dict.fromkeys(p for p in (ctx.prefix, config.PREFIX) if p))
        command_text = clean_command(command_text, prefixes)
        if not command_text:
            raise AutoError("Thiếu lệnh cần chạy, ví dụ `.thoitiet Quảng Ngãi`.")
        if len(command_text) > MAX_COMMAND_LENGTH:
            raise AutoError(f"Lệnh quá dài (tối đa {MAX_COMMAND_LENGTH} ký tự).")

        perms = channel.permissions_for(ctx.guild.me)
        if not (perms.view_channel and perms.send_messages and perms.embed_links):
            raise AutoError(f"Bot thiếu quyền **Xem kênh / Gửi tin nhắn / Nhúng liên kết** ở {channel.mention}.")

        # Kiểm tra lệnh có tồn tại và chính người tạo được phép dùng.
        probe = AutoMessage(content=f"{config.PREFIX}{command_text}", author=ctx.author, channel=channel)
        probe_ctx = await self.bot.get_context(probe)
        if not probe_ctx.valid or probe_ctx.command is None:
            raise AutoError(f"Không có lệnh `{_plain(command_text.split()[0])[:40]}`. "
                            f"Gõ `{ctx.prefix}help` để xem danh sách lệnh.")
        root = probe_ctx.command.root_parent or probe_ctx.command
        if root.name in BLOCKED_COMMANDS:
            raise AutoError(f"Lệnh `{config.PREFIX}{root.name}` không được phép lên lịch.")
        try:
            allowed = await probe_ctx.command.can_run(probe_ctx)
        except commands.CommandError:
            allowed = False
        if not allowed:
            raise AutoError("Bạn không có quyền dùng lệnh này nên không thể lên lịch cho nó.")

        now = _now()
        run_at = first_run(schedule, now)
        guild_id, author_id = ctx.guild.id, ctx.author.id

        def insert(conn):
            count, biggest = conn.execute(
                "SELECT COUNT(*), COALESCE(MAX(num), 0) FROM auto_tasks WHERE guild_id = ?", (guild_id,)).fetchone()
            if count >= MAX_TASKS_PER_GUILD:
                return None
            number = biggest + 1  # số thứ tự trong máy chủ (không phải ID toàn bảng)
            conn.execute(
                "INSERT INTO auto_tasks (num, guild_id, channel_id, creator_id, command, kind, value, next_run, "
                "created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (number, guild_id, channel.id, author_id, command_text, schedule.kind, schedule.value,
                 _ts(run_at), _ts(now)),
            )
            return number

        task_id = await db.transaction(insert)
        if task_id is None:
            raise AutoError(f"Máy chủ đã có **{MAX_TASKS_PER_GUILD}** lịch (tối đa). "
                            f"Hãy xóa bớt bằng `{ctx.prefix}auto remove <id>`.")

        embed = ui.success(
            f"Lịch **#{task_id}** đã được tạo.\n\n"
            f"**Lệnh:** `{config.PREFIX}{_plain(command_text)}`\n"
            f"**Kênh:** {channel.mention}\n"
            f"**Lặp:** {schedule.describe()} (giờ Việt Nam)\n"
            f"**Lần chạy đầu:** {discord.utils.format_dt(run_at, 'F')} ({discord.utils.format_dt(run_at, 'R')})\n\n"
            f"Thử ngay: `{ctx.prefix}auto run {task_id}` · Xóa: `{ctx.prefix}auto remove {task_id}`",
            title="⏰ Đã tạo lịch tự động", ctx=ctx)
        await ctx.send(embed=embed, allowed_mentions=no_ping)
        await send_log(ctx.guild, title="⏰ Tạo lịch tự động",
                       description=f"{ctx.author.mention} tạo lịch **#{task_id}**: "
                                   f"`{config.PREFIX}{_plain(command_text)}` → {channel.mention}, "
                                   f"{schedule.describe()}.", color=ui.Color.INFO)

    @auto.command(name="list", aliases=["ds", "danhsach"], help="Xem các lịch tự động của máy chủ.")
    @commands.guild_only()
    @_admin_only
    async def auto_list(self, ctx: commands.Context) -> None:
        rows = await db.fetchall("SELECT * FROM auto_tasks WHERE guild_id = ? ORDER BY num", (ctx.guild.id,))
        no_ping = discord.AllowedMentions.none()
        if not rows:
            await ctx.send(embed=ui.info(f"Chưa có lịch nào. Tạo lịch bằng `{ctx.prefix}auto <lệnh> #kênh <giờ>`.",
                                         title="⏰ Lịch tự động", ctx=ctx), allowed_mentions=no_ping)
            return
        embed = ui.make("⏰ Lịch tự động", f"**{len(rows)}/{MAX_TASKS_PER_GUILD}** lịch · giờ Việt Nam (UTC+7)",
                        color=ui.Color.INFO, ctx=ctx)
        for row in rows:
            name = f"#{row['num']} · {config.PREFIX}{_plain(row['command'])}"
            embed.add_field(name=name[:256], value=self._task_line(row)[:1024], inline=False)
        await ctx.send(embed=embed, allowed_mentions=no_ping)

    @auto.command(name="remove", aliases=["xoa", "del", "delete"], help="Xóa một lịch. Dùng: .auto remove <id>")
    @commands.guild_only()
    @_admin_only
    async def auto_remove(self, ctx: commands.Context, task_id: int) -> None:
        row = await self._get_task(ctx, task_id)
        if row is None:
            return

        def remove(conn) -> int:
            conn.execute("DELETE FROM auto_tasks WHERE id = ?", (row["id"],))
            self._renumber(conn, ctx.guild.id)  # lịch phía sau được dồn lên, không để trống số
            return conn.execute("SELECT COUNT(*) FROM auto_tasks WHERE guild_id = ?", (ctx.guild.id,)).fetchone()[0]

        remaining = await db.transaction(remove)
        note = (f"\nCác lịch phía sau đã được đánh số lại, xem bằng `{ctx.prefix}auto list`."
                if task_id <= remaining else "")
        await ctx.send(embed=ui.success(
            f"Đã xóa lịch **#{task_id}** (`{config.PREFIX}{_plain(row['command'])}`).{note}", ctx=ctx),
            allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="🗑️ Xóa lịch tự động",
                       description=f"{ctx.author.mention} xóa lịch **#{task_id}** "
                                   f"(`{config.PREFIX}{_plain(row['command'])}`).", color=ui.Color.WARNING)

    @auto.command(name="pause", aliases=["tamdung"], help="Tạm dừng một lịch. Dùng: .auto pause <id>")
    @commands.guild_only()
    @_admin_only
    async def auto_pause(self, ctx: commands.Context, task_id: int) -> None:
        row = await self._get_task(ctx, task_id)
        if row is None:
            return
        await db.execute("UPDATE auto_tasks SET enabled = 0 WHERE id = ?", (row["id"],))
        await ctx.send(embed=ui.success(f"Đã tạm dừng lịch **#{task_id}**. Bật lại bằng `{ctx.prefix}auto resume "
                                        f"{task_id}`.", ctx=ctx), allowed_mentions=discord.AllowedMentions.none())

    @auto.command(name="resume", aliases=["tiep", "bat"], help="Bật lại một lịch đã dừng. Dùng: .auto resume <id>")
    @commands.guild_only()
    @_admin_only
    async def auto_resume(self, ctx: commands.Context, task_id: int) -> None:
        row = await self._get_task(ctx, task_id)
        if row is None:
            return
        schedule = Schedule(row["kind"], row["value"])
        run_at = first_run(schedule, _now())
        await db.execute("UPDATE auto_tasks SET enabled = 1, failures = 0, next_run = ? WHERE id = ?",
                         (_ts(run_at), row["id"]))
        await ctx.send(embed=ui.success(
            f"Đã bật lại lịch **#{task_id}**. Lần chạy tới: {discord.utils.format_dt(run_at, 'F')} "
            f"({discord.utils.format_dt(run_at, 'R')}).", ctx=ctx), allowed_mentions=discord.AllowedMentions.none())

    @auto.command(name="run", aliases=["test", "chay"], help="Chạy thử một lịch ngay bây giờ. Dùng: .auto run <id>")
    @commands.guild_only()
    @_admin_only
    async def auto_run(self, ctx: commands.Context, task_id: int) -> None:
        row = await self._get_task(ctx, task_id)
        if row is None:
            return
        problem = await self._execute(row, manual=True)
        no_ping = discord.AllowedMentions.none()
        if problem is None:
            await ctx.send(embed=ui.success(f"Đã chạy thử lịch **#{task_id}** ở <#{row['channel_id']}>. "
                                            "Lịch hằng ngày vẫn giữ nguyên giờ cũ.", ctx=ctx), allowed_mentions=no_ping)
        else:
            await ctx.send(embed=ui.error(problem, title=f"❌ Lịch #{task_id} chạy không được", ctx=ctx),
                           allowed_mentions=no_ping)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Auto(bot))
