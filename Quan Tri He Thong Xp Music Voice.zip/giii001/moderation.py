"""Quản trị: chống spam, nhật ký quản trị và lệnh .config."""
from __future__ import annotations

import logging
import time
from collections import deque
from datetime import timedelta
from typing import Optional

import discord
from discord.ext import commands

import config
import ui
from database import db
from utils import SETTINGS, get_setting_id, guild_allowed, send_log

log = logging.getLogger("bot.moderation")

OFF_WORDS = {"off", "0", "none", "tat", "tắt", "xoa", "xóa"}
FLAG_SECONDS = 60  # sau khi bị phát hiện spam, thành viên không được nhận XP trong khoảng này


class Moderation(commands.Cog):
    """Chống spam và quản lý cấu hình máy chủ."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._history: dict[tuple[int, int], deque] = {}
        self._violations: dict[tuple[int, int], deque] = {}
        self._flagged: dict[tuple[int, int], float] = {}
        self._last_cleanup = time.monotonic()

    # ------------------------------------------------------------------
    # Chống spam
    # ------------------------------------------------------------------
    def is_flagged(self, guild_id: int, user_id: int) -> bool:
        """True nếu thành viên vừa bị phát hiện spam (module leveling dùng để không cộng XP)."""
        until = self._flagged.get((guild_id, user_id))
        return until is not None and time.monotonic() < until

    def _is_exempt(self, member: discord.Member) -> bool:
        if member.guild_permissions.administrator:
            return True
        exempt = set(config.SPAM_EXEMPT_ROLE_IDS)
        if exempt and any(role.id in exempt for role in member.roles):
            return True
        return False

    def _in_scope(self, channel: discord.abc.GuildChannel) -> bool:
        """Kiểm tra kênh có nằm trong phạm vi chống spam (rỗng = mọi kênh)."""
        scope = config.SPAM_CHANNEL_IDS
        if not scope:
            return True
        parent_id = getattr(channel, "parent_id", None)
        return channel.id in scope or (parent_id is not None and parent_id in scope)

    def _cleanup(self, now: float) -> None:
        if now - self._last_cleanup < 300:
            return
        self._last_cleanup = now
        for key in [k for k, dq in self._history.items() if not dq or now - dq[-1][0] > config.SPAM_WINDOW_SECONDS]:
            del self._history[key]
        for key in [k for k, dq in self._violations.items()
                    if not dq or now - dq[-1] > config.SPAM_VIOLATION_WINDOW_SECONDS]:
            del self._violations[key]
        for key in [k for k, until in self._flagged.items() if now >= until]:
            del self._flagged[key]

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if not config.SPAM_ENABLED:
            return
        guild = message.guild
        if guild is None or message.author.bot or message.webhook_id is not None:
            return
        if not guild_allowed(guild) or not self._in_scope(message.channel):
            return
        member = message.author
        if self._is_exempt(member):
            return

        key = (guild.id, member.id)
        now = time.monotonic()
        self._cleanup(now)

        history = self._history.get(key)
        if history is None:
            history = self._history[key] = deque(maxlen=config.SPAM_MESSAGE_LIMIT + 5)
        history.append((now, message))
        while history and now - history[0][0] > config.SPAM_WINDOW_SECONDS:
            history.popleft()

        # "Trên N tin nhắn" => chỉ vi phạm khi số tin nhắn trong cửa sổ LỚN HƠN ngưỡng.
        if len(history) <= config.SPAM_MESSAGE_LIMIT:
            return

        # Lấy và xóa lịch sử NGAY (không có await ở giữa) để một đợt spam chỉ bị xử lý một lần.
        batch = [m for _, m in history]
        history.clear()
        await self._handle_spam(message, member, batch)

    async def _handle_spam(self, trigger: discord.Message, member: discord.Member,
                           batch: list[discord.Message]) -> None:
        guild = member.guild
        key = (guild.id, member.id)
        now = time.monotonic()
        self._flagged[key] = now + FLAG_SECONDS

        deleted = 0
        delete_note = "Không bật"
        if config.SPAM_DELETE_MESSAGES:
            deleted, delete_error = await self._delete_messages(batch)
            delete_note = f"Đã xóa {deleted}/{len(batch)} tin nhắn"
            if delete_error:
                delete_note += f" ({delete_error})"

        violations = self._violations.setdefault(key, deque())
        violations.append(now)
        while violations and now - violations[0] > config.SPAM_VIOLATION_WINDOW_SECONDS:
            violations.popleft()
        count = len(violations)
        threshold = config.SPAM_TIMEOUT_AFTER

        timed_out = False
        timeout_note = "Chưa đạt ngưỡng timeout"
        if threshold > 0 and count >= threshold:
            timed_out, error = await self._timeout(member)
            if timed_out:
                violations.clear()
                timeout_note = f"Đã timeout {config.SPAM_TIMEOUT_MINUTES} phút"
            else:
                timeout_note = f"Timeout thất bại: {error}"
        elif threshold == 0:
            timeout_note = "Không bật"

        # Cảnh báo cho thành viên (ngay tại kênh, tự xóa sau 20 giây).
        if timed_out:
            text = (f"🔇 {member.mention} đã bị timeout {config.SPAM_TIMEOUT_MINUTES} phút "
                    f"vì gửi tin nhắn quá nhanh liên tục.")
        else:
            progress = f" (cảnh báo {count}/{threshold})" if threshold > 0 else ""
            text = f"⚠️ {member.mention}, bạn đang gửi tin nhắn quá nhanh. Vui lòng chậm lại{progress}."
        try:
            await trigger.channel.send(text, delete_after=20, allowed_mentions=discord.AllowedMentions(users=[member]))
        except (discord.Forbidden, discord.HTTPException) as exc:
            log.warning("Không gửi được cảnh báo spam: %s", exc)

        await send_log(
            guild,
            title="🚨 Phát hiện spam",
            description=(f"{member.mention} gửi **{len(batch)}** tin nhắn trong tối đa "
                         f"{config.SPAM_WINDOW_SECONDS} giây (ngưỡng: trên {config.SPAM_MESSAGE_LIMIT})."),
            color=0xE74C3C if timed_out else 0xF39C12,
            fields=[
                ("Thành viên", f"{member} (`{member.id}`)", False),
                ("Kênh", getattr(trigger.channel, "mention", str(trigger.channel)), True),
                ("Số lần vi phạm", f"{count}" if threshold == 0 else f"{count}/{threshold}", True),
                ("Xóa tin nhắn", delete_note, False),
                ("Timeout", timeout_note, False),
            ],
        )

    async def _delete_messages(self, batch: list[discord.Message]) -> tuple[int, Optional[str]]:
        by_channel: dict[int, tuple[object, list[discord.Message]]] = {}
        for msg in batch:
            by_channel.setdefault(msg.channel.id, (msg.channel, []))[1].append(msg)

        deleted = 0
        error: Optional[str] = None
        for channel, messages in by_channel.values():
            try:
                if len(messages) >= 2 and hasattr(channel, "delete_messages"):
                    for start in range(0, len(messages), 100):
                        chunk = messages[start:start + 100]
                        await channel.delete_messages(chunk)
                        deleted += len(chunk)
                else:
                    for msg in messages:
                        await msg.delete()
                        deleted += 1
            except discord.Forbidden:
                error = "bot thiếu quyền Manage Messages"
            except discord.HTTPException as exc:
                # Xóa hàng loạt thất bại (ví dụ có tin đã bị xóa): thử xóa từng tin.
                log.info("Xóa hàng loạt lỗi (%s), chuyển sang xóa từng tin.", exc)
                for msg in messages:
                    try:
                        await msg.delete()
                        deleted += 1
                    except discord.HTTPException:
                        pass
        return deleted, error

    async def _timeout(self, member: discord.Member) -> tuple[bool, Optional[str]]:
        try:
            await member.timeout(
                timedelta(minutes=config.SPAM_TIMEOUT_MINUTES),
                reason="Chống spam tự động",
            )
            return True, None
        except discord.Forbidden:
            return False, "bot thiếu quyền Moderate Members hoặc role của thành viên cao hơn bot"
        except discord.HTTPException as exc:
            return False, str(exc)

    # ------------------------------------------------------------------
    # Lệnh .config
    # ------------------------------------------------------------------
    _SETTING_ICONS = {
        "welcome_channel": "👋",
        "log_channel": "📜",
        "levelup_channel": "🎉",
        "member_role": "🏷️",
    }

    async def _settings_embed(self, ctx: commands.Context) -> discord.Embed:
        guild = ctx.guild
        prefix = ctx.prefix
        embed = ui.make(
            "⚙️ Thiết lập của bot",
            f"Cấu hình hiện tại của **{discord.utils.escape_markdown(guild.name)}**.",
            color=ui.Color.INFO,
            ctx=ctx,
            thumbnail=guild.icon.url if guild.icon else None,
        )
        for key, (label, kind) in SETTINGS.items():
            value = await get_setting_id(guild.id, key)
            stored = await db.get_setting(guild.id, key)
            if not value:
                if key == "levelup_channel":
                    shown = "💬 Ngay tại kênh đang chat"
                elif stored == "0":
                    shown = "🚫 Đã tắt"
                else:
                    shown = "⚪ Chưa đặt"
                source = ""
            else:
                target = guild.get_channel(value) if kind == "channel" else guild.get_role(value)
                shown = f"✅ {target.mention}" if target is not None else f"❌ Không tìm thấy (ID `{value}`)"
                source = " · đặt bằng `.config`" if stored is not None else " · từ file `.env`"
            icon = self._SETTING_ICONS.get(key, "🔧")
            embed.add_field(name=f"{icon} {label}", value=f"{shown}\n`{key}`{source}", inline=False)
        embed.add_field(
            name="✏️ Cách đổi",
            value=(f"`{prefix}config welcome_channel #chao-mung`\n"
                   f"`{prefix}config member_role @Member`\n"
                   f"`off` để tắt · `reset` để về giá trị trong `.env`"),
            inline=False,
        )
        return embed

    @commands.command(
        name="config",
        aliases=["setup"],
        help="Xem hoặc đổi thiết lập. Dùng: .config | .config <khóa> <#kênh/@role|off|reset>",
    )
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def config_cmd(self, ctx: commands.Context, key: Optional[str] = None, *,
                         value: Optional[str] = None) -> None:
        if key is None:
            await ctx.send(embed=await self._settings_embed(ctx))
            return

        key = key.lower()
        if key not in SETTINGS:
            names = ", ".join(f"`{k}`" for k in SETTINGS)
            safe_key = discord.utils.escape_markdown(key.replace("`", ""))[:50]
            await ctx.send(embed=ui.error(f"Không có thiết lập `{safe_key}`.\nCác thiết lập hợp lệ: {names}",
                                          title="❌ Thiết lập không tồn tại", ctx=ctx))
            return
        label, kind = SETTINGS[key]
        if value is None:
            example = "#kênh" if kind == "channel" else "@role"
            await ctx.send(embed=ui.info(f"`{ctx.prefix}config {key} <{example} | off | reset>`",
                                         title=f"⚙️ Cách đổi {label}", ctx=ctx))
            return

        text = value.strip()
        if text.lower() == "reset":
            await db.delete_setting(ctx.guild.id, key)
            await ctx.send(embed=ui.success(f"Đã đặt lại **{label}** về giá trị trong file `.env`.",
                                            title="♻️ Đã đặt lại", ctx=ctx))
            return
        if text.lower() in OFF_WORDS:
            await db.set_setting(ctx.guild.id, key, "0")
            await ctx.send(embed=ui.success(f"Đã tắt **{label}**.", title="🚫 Đã tắt", ctx=ctx))
            return

        try:
            if kind == "channel":
                target = await commands.TextChannelConverter().convert(ctx, text)
            else:
                target = await commands.RoleConverter().convert(ctx, text)
        except commands.BadArgument:
            what = "kênh" if kind == "channel" else "role"
            safe_text = discord.utils.escape_markdown(text.replace("`", ""))[:80]
            await ctx.send(embed=ui.error(f"Không tìm thấy {what} `{safe_text}`.", ctx=ctx))
            return

        warning = ""
        if kind == "channel":
            if not target.permissions_for(ctx.guild.me).send_messages:
                warning = f"Bot chưa có quyền gửi tin nhắn trong {target.mention}."
        else:
            me = ctx.guild.me
            if target.is_default() or target.managed:
                await ctx.send(embed=ui.error("Không thể dùng role hệ thống làm role Member.", ctx=ctx))
                return
            if target >= me.top_role:
                warning = ("Role này đang cao hơn hoặc ngang role của bot nên bot sẽ không gán được. "
                           "Hãy kéo role của bot lên trên.")

        await db.set_setting(ctx.guild.id, key, str(target.id))
        embed = ui.make(
            "✅ Đã cập nhật thiết lập",
            f"**{label}** đã đặt thành {target.mention}.",
            color=ui.Color.WARNING if warning else ui.Color.SUCCESS,
            ctx=ctx,
        )
        embed.add_field(name="🔑 Khóa", value=f"`{key}`", inline=True)
        embed.add_field(name="📍 Giá trị", value=target.mention, inline=True)
        if warning:
            embed.add_field(name="⚠️ Cảnh báo", value=warning, inline=False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Moderation(bot))
