"""Điểm khởi chạy của bot: nạp cấu hình, kết nối cơ sở dữ liệu và nạp các module.

Chạy:  python main.py
"""
from __future__ import annotations

import logging
import logging.handlers
import sys

import discord
from discord.ext import commands

import config
from database import db
from utils import guild_allowed

log = logging.getLogger("bot")

EXTENSIONS = ("music", "welcome", "moderation", "leveling", "realm_roles", "help_cog", "moderation_actions", "info", "channel_tools", "weather", "auto", "voice_rooms")


def setup_logging() -> None:
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    root.addHandler(console)
    file_handler = logging.handlers.RotatingFileHandler(
        "bot.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)
    logging.getLogger("discord").setLevel(logging.INFO)


class DiscordBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.message_content = True  # cần cho lệnh dấu "." và đếm XP/chống spam
        intents.members = True  # cần cho chào mừng và gán role
        intents.voice_states = True  # cần cho phát nhạc và phòng thoại riêng
        super().__init__(
            command_prefix=config.PREFIX,
            intents=intents,
            case_insensitive=True,
            help_command=None,  # dùng .help tiếng Việt trong help_cog.py
            description="Bot đa chức năng: nhạc, quản trị, cấp độ XP",
        )
        self.add_check(self._guild_check)

    async def _guild_check(self, ctx: commands.Context) -> bool:
        # Chỉ chạy lệnh trong máy chủ (và đúng GUILD_ID nếu có cấu hình).
        return ctx.guild is not None and guild_allowed(ctx.guild)

    async def setup_hook(self) -> None:
        await db.connect(config.DATABASE_PATH)
        for extension in EXTENSIONS:
            try:
                await self.load_extension(extension)
                log.info("Đã nạp module: %s", extension)
            except Exception:
                log.exception("Không nạp được module %s", extension)

    async def close(self) -> None:
        await super().close()
        await db.close()

    async def on_ready(self) -> None:
        log.info("Đã đăng nhập: %s (ID %s) | %d máy chủ", self.user, self.user.id, len(self.guilds))
        await self.change_presence(activity=discord.Activity(type=discord.ActivityType.listening,
                                                             name=f"{config.PREFIX}help"))

    async def on_command_error(self, ctx: commands.Context, error: commands.CommandError) -> None:
        if isinstance(error, commands.CommandNotFound):
            return
        if ctx.command is not None and ctx.command.has_error_handler():
            return

        usage = ""
        if ctx.command is not None:
            usage = f"\nCách dùng: `{ctx.prefix}{ctx.command.qualified_name} {ctx.command.signature}`".rstrip()

        if isinstance(error, commands.MissingPermissions):
            message = "⛔ Bạn không có quyền dùng lệnh này."
        elif isinstance(error, commands.BotMissingPermissions):
            missing = ", ".join(error.missing_permissions)
            message = f"⚠️ Bot đang thiếu quyền: {missing}. Hãy cấp quyền cho bot rồi thử lại."
        elif isinstance(error, commands.NoPrivateMessage):
            message = "Lệnh này chỉ dùng được trong máy chủ."
        elif isinstance(error, commands.MissingRequiredArgument):
            message = f"⚠️ Thiếu tham số `{error.param.name}`.{usage}"
        elif isinstance(error, (commands.BadArgument, commands.BadUnionArgument)):
            message = f"⚠️ Tham số không hợp lệ.{usage}"
        elif isinstance(error, commands.TooManyArguments):
            message = f"⚠️ Bạn nhập thừa tham số.{usage}"
        elif isinstance(error, commands.CommandOnCooldown):
            message = f"⏳ Vui lòng chờ {error.retry_after:.0f} giây rồi thử lại."
        elif isinstance(error, commands.CheckFailure):
            return  # ví dụ lệnh gọi ngoài máy chủ được phép: bỏ qua im lặng
        else:
            original = getattr(error, "original", error)
            log.error("Lỗi khi chạy lệnh %s", ctx.command, exc_info=original)
            message = "❌ Có lỗi không mong muốn xảy ra. Quản trị viên có thể xem chi tiết trong file `bot.log`."

        try:
            await ctx.send(message, allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass


def main() -> None:
    setup_logging()
    if not config.TOKEN:
        raise SystemExit("Thiếu DISCORD_TOKEN. Hãy tạo file .env từ .env.example và dán token bot vào.")
    bot = DiscordBot()
    try:
        bot.run(config.TOKEN, log_handler=None)
    except discord.LoginFailure:
        raise SystemExit("Token không hợp lệ. Hãy tạo lại token trong Discord Developer Portal và cập nhật file .env.")
    except discord.PrivilegedIntentsRequired:
        raise SystemExit(
            "Chưa bật Privileged Intents. Vào Discord Developer Portal > Bot và bật "
            "'Server Members Intent' và 'Message Content Intent', rồi chạy lại."
        )


if __name__ == "__main__":
    main()
