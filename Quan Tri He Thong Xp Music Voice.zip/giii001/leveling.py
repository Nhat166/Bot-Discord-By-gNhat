"""Hệ thống cấp bậc: nhận XP khi chat, .rank, .leaderboard (+Week/Month), .level, .xp-admin."""
from __future__ import annotations

import logging
import random
import re
import time
from collections import deque
from datetime import timedelta, timezone
from typing import Optional

import discord
from discord.ext import commands

import config
import xp_bank
import realm_roles
import ui
from utils import fmt_int, fmt_percent, get_setting_id, guild_allowed, send_log

log = logging.getLogger("bot.leveling")

EMBED_COLOR = 0x6D3FE8
BAR_LENGTH = 20
_MENTION_RE = re.compile(r"<[^>\s]+>")  # mention, kênh, emoji tùy chỉnh
_admin_only = commands.has_guild_permissions(administrator=True)


def progress_bar(percent: float, length: int = BAR_LENGTH) -> str:
    filled = max(0, min(length, round(length * percent / 100)))
    return "▰" * filled + "▱" * (length - filled)


class Leveling(commands.Cog):
    """XP, cấp bậc và bảng xếp hạng."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._cooldowns: dict[tuple[int, int], float] = {}
        self._recent: dict[tuple[int, int], deque] = {}
        self._last_cleanup = time.monotonic()

    # ------------------------------------------------------------------
    # Nhận XP từ tin nhắn
    # ------------------------------------------------------------------
    def _cleanup(self, now: float) -> None:
        if now - self._last_cleanup < 600:
            return
        self._last_cleanup = now
        for key in [k for k, t in self._cooldowns.items() if now - t > max(config.XP_COOLDOWN_SECONDS, 1)]:
            del self._cooldowns[key]
        for key in [k for k, dq in self._recent.items()
                    if not dq or now - dq[-1][0] > config.XP_REPEAT_WINDOW_SECONDS]:
            del self._recent[key]

    def _is_repeated(self, key: tuple[int, int], now: float, text: str) -> bool:
        """True nếu cùng một nội dung đã lặp lại XP_REPEAT_LIMIT lần trong XP_REPEAT_WINDOW_SECONDS giây."""
        normalized = re.sub(r"\s+", " ", text.lower())
        window = self._recent.get(key)
        if window is None:
            window = self._recent[key] = deque(maxlen=max(config.XP_REPEAT_LIMIT * 2, 10))
        window.append((now, normalized))
        while window and now - window[0][0] > config.XP_REPEAT_WINDOW_SECONDS:
            window.popleft()
        return sum(1 for _, content in window if content == normalized) >= config.XP_REPEAT_LIMIT

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        guild = message.guild
        if guild is None or message.author.bot or message.webhook_id is not None:
            return
        if message.type not in (discord.MessageType.default, discord.MessageType.reply):
            return
        if not guild_allowed(guild):
            return

        # Lệnh của bot không tính XP.
        ctx = await self.bot.get_context(message)
        if ctx.command is not None:
            return

        # Chỉ tính tin nhắn văn bản đủ dài (bỏ mention/emoji khi đếm).
        clean = _MENTION_RE.sub("", message.content).strip()
        if len(clean) < config.XP_MIN_LENGTH:
            return

        key = (guild.id, message.author.id)
        now = time.monotonic()
        self._cleanup(now)

        if self._is_repeated(key, now, clean):
            return
        moderation = self.bot.get_cog("Moderation")
        if moderation is not None and moderation.is_flagged(*key):
            return
        last = self._cooldowns.get(key)
        if last is not None and now - last < config.XP_COOLDOWN_SECONDS:
            return
        self._cooldowns[key] = now  # đặt trước khi await để tin nhắn đến cùng lúc không nhận XP đôi

        amount = random.randint(config.XP_MIN, config.XP_MAX)
        try:
            change = await xp_bank.add_xp(
                message.author.id,
                guild.id,
                amount,
                "Tin nhắn hợp lệ",
                source="chat",
                ref=str(message.id),
            )
        except Exception:
            log.exception("Không cộng được XP cho %s trong máy chủ %s", message.author.id, guild.id)
            return

        # Đồng bộ role cảnh giới: khi lên cấp, hoặc lần đầu có XP (nhận role "Phàm Nhân").
        if change.applied > 0 and (change.leveled_up or change.old_xp == 0):
            await realm_roles.sync_member(message.author, change.new_level.index)
        if change.leveled_up:
            await self._announce_level_up(guild, message.author, message.channel, change)

    async def _announce_level_up(self, guild: discord.Guild, member: discord.Member,
                                 fallback_channel: discord.abc.Messageable,
                                 change: xp_bank.XPChange) -> None:
        channel = None
        channel_id = await get_setting_id(guild.id, "levelup_channel")
        if channel_id:
            channel = guild.get_channel(channel_id)
        if channel is None or not hasattr(channel, "send"):
            channel = fallback_channel
        level = change.new_level
        embed = discord.Embed(
            title="🎉 Đột phá cấp bậc!",
            description=(f"{member.mention} đã đạt **{level.name}** (Cấp độ {level.index}) "
                         f"với **{fmt_int(change.new_xp)} XP**."),
            color=EMBED_COLOR,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        try:
            await channel.send(embed=embed, allowed_mentions=discord.AllowedMentions(users=[member]))
        except (discord.Forbidden, discord.HTTPException) as exc:
            log.warning("Không gửi được thông báo lên cấp: %s", exc)

    # ------------------------------------------------------------------
    # Giao diện thẻ cấp bậc
    # ------------------------------------------------------------------
    async def build_rank_embed(self, member: discord.Member) -> discord.Embed:
        progress = await xp_bank.get_xp_progress(member.id, member.guild.id)
        rank = await xp_bank.get_rank(member.id, member.guild.id)
        level = progress.level
        rank_text = f"Rank #{rank}" if rank else "Chưa có hạng"

        lines = [f"Cấp độ {level.index} · {level.name} · {rank_text}"]
        if progress.remaining is None:
            lines.append(f"**{fmt_int(progress.xp)} XP** · đã đạt cấp bậc cao nhất")
            footer = "100% tiến độ"
        else:
            lines.append(f"**{fmt_int(progress.xp)} / {fmt_int(level.next_xp)} XP**")
            footer = (f"{fmt_percent(progress.percent)}% tiến độ · "
                      f"Còn {fmt_int(progress.remaining)} XP để lên {level.next_name}")
        lines.append(progress_bar(progress.percent))
        lines.append(footer)

        embed = discord.Embed(
            title=discord.utils.escape_markdown(member.display_name),
            description="\n".join(lines),
            color=EMBED_COLOR,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        return embed

    # ------------------------------------------------------------------
    # Lệnh cho thành viên
    # ------------------------------------------------------------------
    @commands.command(name="rank", help="Xem XP, cấp độ và tiến độ lên cấp. Dùng: .rank [@thành_viên]")
    @commands.guild_only()
    async def rank(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        if member.bot:
            await ctx.send("Bot không có XP.")
            return
        await ctx.send(embed=await self.build_rank_embed(member))

    @commands.command(name="leaderboard", aliases=["lb", "top"], help="Xem bảng xếp hạng XP của máy chủ.")
    @commands.guild_only()
    async def leaderboard(self, ctx: commands.Context) -> None:
        rows = await xp_bank.get_leaderboard(ctx.guild.id, 10)
        if not rows:
            await ctx.send(embed=ui.info("Chưa có ai có XP. Hãy bắt đầu trò chuyện nhé!",
                                         title="🏆 Bảng xếp hạng XP", ctx=ctx))
            return

        medals = {1: "🥇", 2: "🥈", 3: "🥉"}
        podium: list[str] = []
        others: list[str] = []
        top_member: Optional[discord.Member] = None
        for position, (user_id, xp) in enumerate(rows, start=1):
            member = ctx.guild.get_member(user_id)
            if position == 1:
                top_member = member
            name = discord.utils.escape_markdown(member.display_name) if member else f"<@{user_id}>"
            level = xp_bank.level_for_xp(xp)
            if position <= 3:
                podium.append(f"{medals[position]} **{name}**\n"
                              f"↳ {ui.realm_label(level)} · **{fmt_int(xp)} XP**")
            else:
                others.append(f"`#{position:<2}` **{name}** · {ui.realm_label(level)} · {fmt_int(xp)} XP")

        guild_icon = ctx.guild.icon.url if ctx.guild.icon else None
        thumbnail = top_member.display_avatar.url if top_member else guild_icon
        embed = ui.make("🏆 Bảng xếp hạng XP", "\n\n".join(podium), color=ui.Color.GOLD, thumbnail=thumbnail)
        embed.set_author(name=ctx.guild.name, icon_url=guild_icon)
        if others:
            embed.add_field(name="Top 4 – 10", value="\n".join(others)[:1024], inline=False)

        my_xp = await xp_bank.get_xp(ctx.author.id, ctx.guild.id)
        my_rank = await xp_bank.get_rank(ctx.author.id, ctx.guild.id)
        if my_rank:
            footer = f"Hạng của bạn: #{my_rank} · {fmt_int(my_xp)} XP · {xp_bank.level_for_xp(my_xp).name}"
        else:
            footer = "Bạn chưa có hạng. Hãy trò chuyện để nhận XP!"
        embed.set_footer(text=footer, icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)

    # ------------------------------------------------------------------
    # Bảng xếp hạng theo tuần / tháng
    # ------------------------------------------------------------------
    async def _period_leaderboard(self, ctx: commands.Context, kind: str) -> None:
        """Bảng xếp hạng XP kiếm được trong tuần (thứ Hai → Chủ nhật) hoặc tháng hiện tại."""
        start, end = xp_bank.period_bounds(kind)
        tz = timezone(timedelta(hours=config.LEADERBOARD_UTC_OFFSET))
        first_day, last_day = start.astimezone(tz), (end - timedelta(seconds=1)).astimezone(tz)
        if kind == "week":
            title, label = "📅 Bảng xếp hạng tuần", "tuần này"
            span = f"Tuần này: {first_day:%d/%m} – {last_day:%d/%m/%Y}"
        else:
            title, label = "🗓️ Bảng xếp hạng tháng", "tháng này"
            span = f"Tháng {first_day:%m/%Y}: {first_day:%d/%m} – {last_day:%d/%m}"
        header = (f"**{span}**\n🔄 Làm mới {discord.utils.format_dt(end, 'R')} "
                  f"({discord.utils.format_dt(end, 'f')})")

        rows = await xp_bank.get_period_leaderboard(ctx.guild.id, start, end, 10)
        if not rows:
            await ctx.send(embed=ui.info(
                f"{header}\n\nChưa có ai kiếm được XP {label}. Hãy trò chuyện để dẫn đầu nhé!",
                title=title, ctx=ctx))
            return

        medals = {1: "🥇", 2: "🥈", 3: "🥉"}
        podium: list[str] = []
        others: list[str] = []
        top_member: Optional[discord.Member] = None
        for position, (user_id, gained) in enumerate(rows, start=1):
            member = ctx.guild.get_member(user_id)
            if position == 1:
                top_member = member
            name = discord.utils.escape_markdown(member.display_name) if member else f"<@{user_id}>"
            if position <= 3:
                podium.append(f"{medals[position]} **{name}**\n↳ **+{fmt_int(gained)} XP** {label}")
            else:
                others.append(f"`#{position:<2}` **{name}** · +{fmt_int(gained)} XP")

        guild_icon = ctx.guild.icon.url if ctx.guild.icon else None
        thumbnail = top_member.display_avatar.url if top_member else guild_icon
        embed = ui.make(title, f"{header}\n\n" + "\n\n".join(podium), color=ui.Color.GOLD, thumbnail=thumbnail)
        embed.set_author(name=ctx.guild.name, icon_url=guild_icon)
        if others:
            embed.add_field(name="Top 4 – 10", value="\n".join(others)[:1024], inline=False)

        my_gained, my_rank = await xp_bank.get_period_standing(ctx.author.id, ctx.guild.id, start, end)
        if my_rank:
            footer = f"Hạng của bạn: #{my_rank} · +{fmt_int(my_gained)} XP {label}"
        else:
            footer = f"Bạn chưa kiếm được XP {label}. Hãy trò chuyện để lên hạng!"
        embed.set_footer(text=footer, icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name="leaderboardWeek", aliases=["lbweek", "lbw", "topweek"],
                      help="Xem bảng xếp hạng XP của tuần này (thứ Hai đến Chủ nhật).")
    @commands.guild_only()
    async def leaderboard_week(self, ctx: commands.Context) -> None:
        await self._period_leaderboard(ctx, "week")

    @commands.command(name="leaderboardMonth", aliases=["lbmonth", "lbm", "topmonth"],
                      help="Xem bảng xếp hạng XP của tháng này (từ ngày 1 đến cuối tháng).")
    @commands.guild_only()
    async def leaderboard_month(self, ctx: commands.Context) -> None:
        await self._period_leaderboard(ctx, "month")

    @commands.command(name="level", aliases=["levels"], help="Xem thông tin về hệ thống cấp độ.")
    @commands.guild_only()
    async def level(self, ctx: commands.Context) -> None:
        my_index = (await xp_bank.get_level(ctx.author.id, ctx.guild.id)).index
        tiers = []
        for index, (name, required) in enumerate(config.LEVELS):
            marker = "  ◀ **bạn**" if index == my_index else ""
            tiers.append(f"{ui.realm_prefix(index)}**Cấp {index} · {name}** — từ {fmt_int(required)} XP{marker}")
        embed = ui.make("📜 Hệ thống cấp độ", "\n".join(tiers), color=EMBED_COLOR, ctx=ctx)
        embed.add_field(
            name="Cách nhận XP",
            value=(f"• Mỗi tin nhắn hợp lệ nhận ngẫu nhiên **{config.XP_MIN}–{config.XP_MAX} XP**.\n"
                   f"• Cách nhau tối thiểu **{config.XP_COOLDOWN_SECONDS} giây** giữa hai lần nhận.\n"
                   f"• Tin quá ngắn (dưới {config.XP_MIN_LENGTH} ký tự), tin lặp lại {config.XP_REPEAT_LIMIT} lần "
                   f"trong {config.XP_REPEAT_WINDOW_SECONDS} giây, tin spam và tin của bot không có XP."),
            inline=False,
        )
        embed.add_field(
            name="Công thức tiến độ",
            value="`(XP hiện có − XP đầu cấp) / (XP cấp tiếp theo − XP đầu cấp) × 100%`",
            inline=False,
        )
        embed.add_field(
            name="Lệnh",
            value=(f"`{ctx.prefix}rank [@thành_viên]` · `{ctx.prefix}leaderboard` · "
                   f"`{ctx.prefix}leaderboardWeek` · `{ctx.prefix}leaderboardMonth` · `{ctx.prefix}level`"),
            inline=False,
        )
        await ctx.send(embed=embed)

    # ------------------------------------------------------------------
    # Lệnh quản trị XP
    # LƯU Ý: với group đặt invoke_without_command=True, kiểm tra quyền của group KHÔNG áp dụng
    # cho lệnh con, nên mỗi lệnh con đều phải có @_admin_only riêng.
    # ------------------------------------------------------------------
    @commands.group(name="xp-admin", invoke_without_command=True,
                    help="Quản lý XP (chỉ quản trị viên). Dùng: .xp-admin add|remove <@thành_viên> <số_xp>")
    @commands.guild_only()
    @_admin_only
    async def xp_admin(self, ctx: commands.Context) -> None:
        prefix = ctx.prefix
        embed = ui.make("🛠️ Quản lý XP", "Công cụ dành cho quản trị viên để chỉnh XP của thành viên.",
                        color=EMBED_COLOR, ctx=ctx)
        embed.add_field(name="➕ Cộng XP", value=f"`{prefix}xp-admin add <@thành_viên> <số_xp>`", inline=False)
        embed.add_field(name="➖ Trừ XP", value=f"`{prefix}xp-admin remove <@thành_viên> <số_xp>`", inline=False)
        embed.add_field(
            name="💡 Lưu ý",
            value=("Role cảnh giới tự đổi theo XP mới. Lên cấp sẽ có thông báo ở kênh lên cấp; "
                   "XP không bao giờ xuống dưới 0."),
            inline=False,
        )
        await ctx.send(embed=embed)

    def _xp_change_embed(self, ctx: commands.Context, member: discord.Member, change: xp_bank.XPChange,
                         *, adding: bool, role_changed: bool) -> discord.Embed:
        old, new = change.old_level, change.new_level
        sign = "+" if adding else "−"
        description = f"{member.mention} **{sign}{fmt_int(change.applied)} XP**"
        if change.requested != change.applied:
            description += (f"\n*Yêu cầu {fmt_int(change.requested)} XP, thực tế áp dụng "
                            f"{fmt_int(change.applied)} XP.*")
        embed = ui.make(
            "➕ Đã cộng XP" if adding else "➖ Đã trừ XP",
            description,
            color=ui.Color.XP_UP if adding else ui.Color.XP_DOWN,
            ctx=ctx,
            thumbnail=member.display_avatar.url,
        )
        embed.add_field(name="📊 Tổng XP",
                        value=f"{fmt_int(change.old_xp)} → **{fmt_int(change.new_xp)}**", inline=True)
        if old.index != new.index:
            arrow = "🎉" if new.index > old.index else "📉"
            realm = f"{ui.realm_label(old)} → **{ui.realm_label(new)}** {arrow}"
        else:
            realm = ui.realm_label(new)
        embed.add_field(name="🎖️ Cảnh giới", value=realm, inline=True)
        embed.add_field(name="📈 Tiến độ", value=ui.progress_text(xp_bank.progress_for_xp(change.new_xp)),
                        inline=False)
        if role_changed:
            embed.add_field(name="🏷️ Role", value=f"Đã đổi sang **{new.name}**", inline=False)
        return embed

    @xp_admin.command(name="add", help="Cộng XP cho thành viên.")
    @commands.guild_only()
    @_admin_only
    async def xp_admin_add(self, ctx: commands.Context, member: discord.Member, amount: int) -> None:
        if member.bot:
            await ctx.send(embed=ui.error("Không thể cộng XP cho bot.", ctx=ctx))
            return
        try:
            change = await xp_bank.add_xp(
                member.id, ctx.guild.id, amount,
                f"Quản trị viên {ctx.author} cộng XP",
                source="admin", actor_id=ctx.author.id,
            )
        except xp_bank.XPError as exc:
            await ctx.send(embed=ui.error(str(exc), ctx=ctx))
            return

        # Cập nhật role cảnh giới theo cấp mới (không ném lỗi).
        role_changed = await realm_roles.sync_member(member, change.new_level.index)

        await ctx.send(
            embed=self._xp_change_embed(ctx, member, change, adding=True, role_changed=role_changed),
            allowed_mentions=discord.AllowedMentions.none(),
        )
        await send_log(
            ctx.guild,
            title="➕ Quản trị viên cộng XP",
            description=f"{ctx.author.mention} cộng **{fmt_int(change.applied)} XP** cho {member.mention}.",
            color=0x2ECC71,
        )
        if change.leveled_up:
            await self._announce_level_up(ctx.guild, member, ctx.channel, change)

    @xp_admin.command(name="remove", help="Trừ XP của thành viên.")
    @commands.guild_only()
    @_admin_only
    async def xp_admin_remove(self, ctx: commands.Context, member: discord.Member, amount: int) -> None:
        if member.bot:
            await ctx.send(embed=ui.error("Không thể trừ XP của bot.", ctx=ctx))
            return
        try:
            change = await xp_bank.remove_xp(
                member.id, ctx.guild.id, amount,
                f"Quản trị viên {ctx.author} trừ XP",
                source="admin", actor_id=ctx.author.id,
            )
        except xp_bank.XPError as exc:
            await ctx.send(embed=ui.error(str(exc), ctx=ctx))
            return
        if change.applied == 0:
            await ctx.send(embed=ui.info(f"{member.mention} hiện không có XP để trừ.", ctx=ctx),
                           allowed_mentions=discord.AllowedMentions.none())
            return

        # Bị trừ XP có thể tụt cảnh giới: đổi lại role cho khớp.
        role_changed = await realm_roles.sync_member(member, change.new_level.index)

        await ctx.send(
            embed=self._xp_change_embed(ctx, member, change, adding=False, role_changed=role_changed),
            allowed_mentions=discord.AllowedMentions.none(),
        )
        await send_log(
            ctx.guild,
            title="➖ Quản trị viên trừ XP",
            description=f"{ctx.author.mention} trừ **{fmt_int(change.applied)} XP** của {member.mention}.",
            color=0xE67E22,
        )

async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Leveling(bot))
