"""Chào mừng thành viên mới, tự động gán role Member và lệnh .addrole."""
from __future__ import annotations

import logging
import re

import discord
from discord.ext import commands

import config
import ui
from utils import get_setting_id, guild_allowed, render_template, send_log

log = logging.getLogger("bot.welcome")


def find_roles(guild: discord.Guild, text: str) -> list[discord.Role]:
    """Tìm role theo mention, ID hoặc tên (không phân biệt hoa thường). Trả về danh sách khớp."""
    text = text.strip()
    mention = re.fullmatch(r"<@&(\d+)>", text)
    if mention:
        role = guild.get_role(int(mention.group(1)))
        return [role] if role else []
    if text.isdigit():
        role = guild.get_role(int(text))
        return [role] if role else []
    wanted = text.lstrip("@").casefold()
    return [r for r in guild.roles if not r.is_default() and r.name.casefold() == wanted]


class Welcome(commands.Cog):
    """Chào mừng, gán role tự động, .addrole."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # -- sự kiện ------------------------------------------------------------
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        if member.bot or not guild_allowed(member.guild):
            return
        await self._assign_member_role(member)
        await self._send_welcome(member)

    async def _assign_member_role(self, member: discord.Member) -> None:
        guild = member.guild
        role_id = await get_setting_id(guild.id, "member_role")
        if not role_id:
            return
        role = guild.get_role(role_id)
        if role is None:
            await send_log(
                guild,
                title="⚠️ Không gán được role Member",
                description=f"Không tìm thấy role có ID `{role_id}`. Hãy kiểm tra lại bằng lệnh `.config`.",
                color=0xF1C40F,
                fields=[("Thành viên", member.mention, True)],
            )
            return
        me = guild.me
        problem = None
        if not me.guild_permissions.manage_roles:
            problem = "Bot không có quyền **Manage Roles**."
        elif role.managed or role.is_default():
            problem = f"Role {role.mention} là role hệ thống, không thể gán thủ công."
        elif role >= me.top_role:
            problem = f"Role {role.mention} nằm cao hơn hoặc ngang role cao nhất của bot. Hãy kéo role của bot lên trên."
        if problem:
            await send_log(
                guild,
                title="⚠️ Không gán được role Member",
                description=problem,
                color=0xF1C40F,
                fields=[("Thành viên", member.mention, True), ("Role", role.mention, True)],
            )
            return
        try:
            await member.add_roles(role, reason="Tự động gán role cho thành viên mới")
        except (discord.Forbidden, discord.HTTPException) as exc:
            await send_log(
                guild,
                title="⚠️ Gán role Member thất bại",
                description=f"Discord báo lỗi: {exc}",
                color=0xE74C3C,
                fields=[("Thành viên", member.mention, True), ("Role", role.mention, True)],
            )

    def build_welcome_embed(self, member: discord.Member) -> discord.Embed:
        values = {
            "user": member.mention,
            "name": discord.utils.escape_markdown(member.display_name),
            "server": member.guild.name,
            "count": member.guild.member_count,
        }
        embed = discord.Embed(
            title=render_template(config.WELCOME_TITLE, **values)[:256],
            description=render_template(config.WELCOME_MESSAGE, **values)[:4000],
            color=config.WELCOME_COLOR,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        return embed

    async def _send_welcome(self, member: discord.Member) -> bool:
        guild = member.guild
        channel_id = await get_setting_id(guild.id, "welcome_channel")
        if not channel_id:
            return False
        channel = guild.get_channel(channel_id)
        if channel is None or not hasattr(channel, "send"):
            await send_log(
                guild,
                title="⚠️ Không gửi được lời chào",
                description=f"Không tìm thấy kênh chào mừng có ID `{channel_id}`.",
                color=0xF1C40F,
            )
            return False
        try:
            await channel.send(
                content=member.mention,
                embed=self.build_welcome_embed(member),
                allowed_mentions=discord.AllowedMentions(users=[member]),
            )
            return True
        except (discord.Forbidden, discord.HTTPException) as exc:
            await send_log(
                guild,
                title="⚠️ Gửi lời chào thất bại",
                description=f"Kênh {channel.mention}: {exc}",
                color=0xE74C3C,
            )
            return False

    # -- lệnh ---------------------------------------------------------------
    @commands.command(
        name="addrole",
        help="Gán role cho thành viên. Dùng: .addrole <tên role hoặc ID> <@thành_viên hoặc ID>",
    )
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def addrole(self, ctx: commands.Context, *, arguments: str) -> None:
        no_ping = discord.AllowedMentions.none()
        usage = f"Cách dùng: `{ctx.prefix}addrole <tên role hoặc ID> <@thành_viên hoặc ID>`"

        async def fail(text: str) -> None:
            await ctx.send(embed=ui.error(text, title="❌ Không gán được role", ctx=ctx), allowed_mentions=no_ping)

        def clip(text: str) -> str:
            return discord.utils.escape_markdown(text.replace("`", ""))[:80]

        parts = arguments.strip().rsplit(maxsplit=1)
        if len(parts) != 2:
            await ctx.send(embed=ui.info(
                f"{usage}\n\nVí dụ: `{ctx.prefix}addrole VIP @thành_viên`", title="🏷️ Cách dùng .addrole", ctx=ctx))
            return
        role_text, member_text = parts

        roles = find_roles(ctx.guild, role_text)
        if not roles:
            await fail(f"Không tìm thấy role `{clip(role_text)}`.\n{usage}")
            return
        if len(roles) > 1:
            ids = ", ".join(f"`{r.id}`" for r in roles)
            await fail(f"Có nhiều role trùng tên `{clip(role_text)}`. Hãy dùng ID role: {ids}")
            return
        role = roles[0]

        try:
            member = await commands.MemberConverter().convert(ctx, member_text)
        except commands.BadArgument:
            await fail(f"Không tìm thấy thành viên `{clip(member_text)}`.\n{usage}")
            return

        me = ctx.guild.me
        if role.is_default() or role.managed:
            await fail("Đây là role hệ thống (@everyone hoặc role của bot/tích hợp), không thể gán thủ công.")
            return
        if role >= me.top_role:
            await fail(f"Role {role.mention} cao hơn hoặc ngang role cao nhất của bot, bot không thể gán.")
            return
        if ctx.author.id != ctx.guild.owner_id and role >= ctx.author.top_role:
            await fail("Bạn không thể gán role cao hơn hoặc ngang role cao nhất của chính bạn.")
            return
        if role in member.roles:
            await ctx.send(embed=ui.info(f"{member.mention} đã có role {role.mention} rồi.",
                                         title="ℹ️ Không cần gán", ctx=ctx), allowed_mentions=no_ping)
            return

        try:
            await member.add_roles(role, reason=f"Lệnh .addrole bởi {ctx.author} ({ctx.author.id})")
        except discord.Forbidden:
            await fail("Discord từ chối: bot không đủ quyền (role của thành viên này có thể cao hơn bot).")
            return
        except discord.HTTPException as exc:
            await fail(f"Discord báo lỗi: {exc}")
            return

        embed = ui.make(
            "🏷️ Đã gán role",
            f"{member.mention} vừa nhận role {role.mention}.",
            color=role.color.value or ui.Color.SUCCESS,
            ctx=ctx,
            thumbnail=member.display_avatar.url,
        )
        embed.add_field(name="👤 Thành viên", value=f"{member.mention}\n`{member.id}`", inline=True)
        embed.add_field(name="🎭 Role", value=f"{role.mention}\n`{role.id}`", inline=True)
        embed.add_field(name="🛡️ Thực hiện bởi", value=ctx.author.mention, inline=True)
        await ctx.send(embed=embed, allowed_mentions=no_ping)
        await send_log(
            ctx.guild,
            title="🏷️ Gán role thủ công",
            description=f"{ctx.author.mention} đã gán {role.mention} cho {member.mention}.",
            color=0x2ECC71,
        )

    @commands.command(name="testwelcome", help="Gửi thử lời chào mừng (dành cho quản trị viên).")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def testwelcome(self, ctx: commands.Context) -> None:
        sent = await self._send_welcome(ctx.author)
        if sent:
            await ctx.send("✅ Đã gửi lời chào thử vào kênh chào mừng.")
        else:
            await ctx.send("⚠️ Chưa gửi được. Hãy đặt kênh chào mừng bằng `.config welcome_channel #kênh` (xem kênh log để biết lỗi).")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Welcome(bot))
