"""Lớp truy cập SQLite dùng chung cho toàn bot.

Dùng thư viện `sqlite3` có sẵn của Python. Mọi truy vấn chạy trong luồng nền
(`asyncio.to_thread`) và được tuần tự hóa bằng một khóa, nên không chặn event loop và
không bao giờ có hai giao dịch chạy chồng lên nhau.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sqlite3
from typing import Any, Callable, Sequence, TypeVar

log = logging.getLogger("bot.database")

T = TypeVar("T")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    guild_id   INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    xp         INTEGER NOT NULL DEFAULT 0 CHECK (xp >= 0),
    updated_at TEXT    NOT NULL,
    PRIMARY KEY (guild_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_users_rank ON users (guild_id, xp DESC);

CREATE TABLE IF NOT EXISTS xp_transactions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id      INTEGER NOT NULL,
    user_id       INTEGER NOT NULL,
    delta         INTEGER NOT NULL,
    balance_after INTEGER NOT NULL,
    reason        TEXT    NOT NULL,
    source        TEXT    NOT NULL,
    actor_id      INTEGER,
    ref           TEXT,
    created_at    TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_xp_tx_user ON xp_transactions (guild_id, user_id, created_at);
-- Phục vụ bảng xếp hạng tuần/tháng (lọc theo máy chủ + khoảng thời gian).
CREATE INDEX IF NOT EXISTS idx_xp_tx_time ON xp_transactions (guild_id, created_at);
-- Mỗi (máy chủ, thành viên, nguồn, ref) chỉ được ghi một lần => không cộng XP trùng.
CREATE UNIQUE INDEX IF NOT EXISTS idx_xp_tx_ref
    ON xp_transactions (guild_id, user_id, source, ref) WHERE ref IS NOT NULL;

-- Lịch sử cảnh cáo (.warn).
CREATE TABLE IF NOT EXISTS warnings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     INTEGER NOT NULL,
    user_id      INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason       TEXT    NOT NULL,
    created_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_warnings_user ON warnings (guild_id, user_id);

CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id INTEGER NOT NULL,
    key      TEXT    NOT NULL,
    value    TEXT    NOT NULL,
    PRIMARY KEY (guild_id, key)
);
"""


class Database:
    def __init__(self) -> None:
        self._conn: sqlite3.Connection | None = None
        self._lock: asyncio.Lock | None = None

    # -- vòng đời -----------------------------------------------------------
    async def connect(self, path: str) -> None:
        folder = os.path.dirname(os.path.abspath(path))
        os.makedirs(folder, exist_ok=True)
        self._lock = asyncio.Lock()
        self._conn = await asyncio.to_thread(self._open, path)
        log.info("Đã mở cơ sở dữ liệu: %s", path)

    @staticmethod
    def _open(path: str) -> sqlite3.Connection:
        conn = sqlite3.connect(path, isolation_level=None, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.executescript(SCHEMA)
        return conn

    async def close(self) -> None:
        if self._conn is None or self._lock is None:
            return
        async with self._lock:
            await asyncio.to_thread(self._conn.close)
            self._conn = None

    def _require(self) -> tuple[sqlite3.Connection, asyncio.Lock]:
        if self._conn is None or self._lock is None:
            raise RuntimeError("Cơ sở dữ liệu chưa được kết nối (gọi db.connect trước).")
        return self._conn, self._lock

    # -- truy vấn đơn lẻ ----------------------------------------------------
    async def execute(self, sql: str, params: Sequence[Any] = ()) -> None:
        conn, lock = self._require()
        async with lock:
            await asyncio.to_thread(conn.execute, sql, tuple(params))

    async def fetchone(self, sql: str, params: Sequence[Any] = ()) -> sqlite3.Row | None:
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(lambda: conn.execute(sql, tuple(params)).fetchone())

    async def fetchall(self, sql: str, params: Sequence[Any] = ()) -> list[sqlite3.Row]:
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(lambda: conn.execute(sql, tuple(params)).fetchall())

    # -- giao dịch ----------------------------------------------------------
    async def transaction(self, func: Callable[[sqlite3.Connection], T]) -> T:
        """Chạy `func(conn)` (hàm đồng bộ) trong một giao dịch duy nhất.

        Thành công thì COMMIT, có lỗi thì ROLLBACK rồi ném lại lỗi.
        """
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(self._run_transaction, conn, func)

    @staticmethod
    def _run_transaction(conn: sqlite3.Connection, func: Callable[[sqlite3.Connection], T]) -> T:
        conn.execute("BEGIN IMMEDIATE")
        try:
            result = func(conn)
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        conn.execute("COMMIT")
        return result

    # -- cấu hình theo máy chủ ----------------------------------------------
    async def get_setting(self, guild_id: int, key: str) -> str | None:
        row = await self.fetchone(
            "SELECT value FROM guild_settings WHERE guild_id = ? AND key = ?", (guild_id, key)
        )
        return None if row is None else row["value"]

    async def set_setting(self, guild_id: int, key: str, value: str) -> None:
        await self.execute(
            "INSERT INTO guild_settings (guild_id, key, value) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value",
            (guild_id, key, value),
        )

    async def delete_setting(self, guild_id: int, key: str) -> None:
        await self.execute("DELETE FROM guild_settings WHERE guild_id = ? AND key = ?", (guild_id, key))


db = Database()
