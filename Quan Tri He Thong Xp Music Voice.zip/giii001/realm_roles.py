"""Role tự động theo cảnh giới: lên cấp thì nhận role mới và mất role cảnh giới cũ. Lệnh .syncroles."""
from __future__ import annotations

import asyncio
import logging
import time

import discord
from discord.ext import commands

import config
import ui
import xp_bank
from utils import fmt_int, guild_allowed, send_log

log = logging.getLogger("bot.realm_roles")

# Màu cho từng cảnh giới (theo thứ tự trong config.LEVELS, thiếu thì dùng màu mặc định)
REALM_COLORS = [0x95A5A6, 0x2ECC71, 0x1ABC9C, 0x3498DB, 0x9B59B6,
                0xE91E63, 0xE67E22, 0xF1C40F, 0xE74C3C]

_create_lock = asyncio.Lock()  # tránh tạo trùng role khi nhiều người lên cấp cùng lúc

WARN_INTERVAL = 600  # giây: cùng một cảnh báo chỉ gửi vào kênh log một lần trong khoảng này
_last_warn: dict[tuple[int, str], float] = {}

# Kết quả của một lần đồng bộ
CHANGED = "changed"      # đã đổi role
UNCHANGED = "unchanged"  # role đã đúng sẵn
FAILED = "failed"        # không đổi được (thiếu quyền, role cao hơn bot, lỗi Discord...)


async def _warn(guild: discord.Guild, text: str) -> None:
    """Gửi cảnh báo vào kênh log nhưng không lặp lại cùng nội dung quá thường xuyên (chống tràn log)."""
    key, now = (guild.id, text), time.monotonic()
    if now - _last_warn.get(key, -1e9) < WARN_INTERVAL:
        return
    _last_warn[key] = now
    await send_log(guild, title="⚠️ Không gán được role cảnh giới", description=text, color=0xF1C40F)


def realm_names() -> list[str]:
    return [name for name, _ in config.LEVELS]


async def sync_member_status(member: discord.Member, level_index: int) -> str:
    """Gán role cảnh giới đúng với level_index, gỡ các role cảnh giới khác.

    Trả về CHANGED / UNCHANGED / FAILED. Không bao giờ ném lỗi.
    """
    guild = member.guild
    me = guild.me
    names = realm_names()
    if not 0 <= level_index < len(names):
        return FAILED
    target_name = names[level_index]

    # Kiểm tra nhanh (không gọi API): đã đúng role và không dư role cảnh giới nào thì thôi.
    realm_roles_now = [r for r in member.roles if r.name in names]
    if len(realm_roles_now) == 1 and realm_roles_now[0].name == target_name:
        return UNCHANGED

    if not me.guild_permissions.manage_roles:
        await _warn(guild, "Bot thiếu quyền **Manage Roles** nên không đổi được role cảnh giới.")
        return FAILED

    try:
        target = discord.utils.get(guild.roles, name=target_name)
        if target is None:
            async with _create_lock:
                target = discord.utils.get(guild.roles, name=target_name)  # kiểm tra lại
                if target is None:
                    color = REALM_COLORS[level_index] if level_index < len(REALM_COLORS) else 0x5865F2
                    target = await guild.create_role(
                        name=target_name, colour=discord.Colour(color), hoist=True,
                        reason="Tạo role cảnh giới tự động",
                    )
        if target.managed or target >= me.top_role:
            await _warn(guild, f"Role {target.mention} cao hơn hoặc ngang role bot. Hãy kéo role bot lên trên.")
            return FAILED

        to_remove = [r for r in realm_roles_now if r != target and not r.managed and r < me.top_role]
        if target not in member.roles:
            await member.add_roles(target, reason="Role cảnh giới tự động")
        if to_remove:
            await member.remove_roles(*to_remove, reason="Gỡ role cảnh giới cũ")
        return CHANGED
    except (discord.Forbidden, discord.HTTPException) as exc:
        log.warning("Không đồng bộ được role cho %s: %s", member.id, exc)
        return FAILED


async def sync_member(member: discord.Member, level_index: int) -> bool:
    """Như sync_member_status nhưng chỉ trả về True nếu có thay đổi. Không bao giờ ném lỗi."""
    return await sync_member_status(member, level_index) == CHANGED


def _fmt_elapsed(seconds: float) -> str:
    minutes, secs = divmod(int(seconds), 60)
    return f"{minutes} phút {secs} giây" if minutes else f"{secs} giây"


class RealmRoles(commands.Cog):
    """Đồng bộ role cảnh giới."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._running: set[int] = set()  # máy chủ đang chạy .syncroles

    # -- giao diện .syncroles ----------------------------------------------
    @staticmethod
    def _add_stats(embed: discord.Embed, counts: dict[str, int]) -> None:
        embed.add_field(name="🔁 Đã cập nhật", value=f"**{fmt_int(counts[CHANGED])}**", inline=True)
        embed.add_field(name="✔️ Đã đúng sẵn", value=f"**{fmt_int(counts[UNCHANGED])}**", inline=True)
        embed.add_field(name="⚠️ Không đổi được", value=f"**{fmt_int(counts[FAILED])}**", inline=True)

    @staticmethod
    def _bar_line(done: int, total: int) -> str:
        percent = (done / total * 100) if total else 100.0
        return f"{ui.progress_bar(percent)} **{percent:.0f}%**\n`{fmt_int(done)} / {fmt_int(total)}` thành viên"

    def _progress_embed(self, ctx: commands.Context, done: int, total: int,
                        counts: dict[str, int]) -> discord.Embed:
        embed = ui.make("🔄 Đang đồng bộ role cảnh giới", self._bar_line(done, total),
                        color=ui.Color.INFO, ctx=ctx)
        self._add_stats(embed, counts)
        return embed

    def _done_embed(self, ctx: commands.Context, total: int, counts: dict[str, int],
                    dist: dict[int, int], elapsed: float) -> discord.Embed:
        failed = counts[FAILED]
        if failed:
            title, color = "⚠️ Đồng bộ xong, một số thành viên chưa đổi được", ui.Color.WARNING
        else:
            title, color = "✅ Đồng bộ role cảnh giới hoàn tất", ui.Color.SUCCESS
        embed = ui.make(title, self._bar_line(total, total), color=color, ctx=ctx)
        self._add_stats(embed, counts)
        if dist:
            names = realm_names()
            lines = [f"{ui.realm_prefix(i)}{names[i]}: **{fmt_int(dist[i])}**" for i in sorted(dist, reverse=True)]
            embed.add_field(name="🎖️ Phân bố cảnh giới", value="\n".join(lines)[:1024], inline=False)
        if failed:
            embed.add_field(
                name="🔧 Cách khắc phục",
                value=("Cấp cho bot quyền **Manage Roles** và kéo role của bot **lên trên** các role cảnh giới "
                       "(Cài đặt máy chủ → Vai trò), rồi chạy lại `.syncroles`. Chi tiết xem ở kênh log."),
                inline=False,
            )
        embed.add_field(name="⏱️ Thời gian", value=_fmt_elapsed(elapsed), inline=True)
        return embed

    async def _show(self, ctx: commands.Context, message: discord.Message | None,
                    embed: discord.Embed) -> discord.Message | None:
        """Sửa tin tiến độ; nếu tin đã bị xóa thì gửi tin mới. Trả về tin đang dùng."""
        if message is not None:
            try:
                await message.edit(embed=embed)
                return message
            except discord.NotFound:
                pass
            except discord.HTTPException as exc:  # lỗi tạm (ví dụ giới hạn tốc độ): giữ tin cũ, thử lại lần sau
                log.debug("Không sửa được tin tiến độ: %s", exc)
                return message
        try:
            return await ctx.send(embed=embed)
        except discord.HTTPException:
            return None

    # -- lệnh ---------------------------------------------------------------
    @commands.command(name="syncroles", help="Gán lại role cảnh giới cho toàn bộ thành viên (quản trị viên).")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def syncroles(self, ctx: commands.Context) -> None:
        if not guild_allowed(ctx.guild):
            return
        if ctx.guild.id in self._running:
            await ctx.send(embed=ui.warning("Đang có một lượt đồng bộ chạy rồi, vui lòng đợi nó xong.",
                                            title="⏳ Đang bận", ctx=ctx))
            return
        self._running.add(ctx.guild.id)
        try:
            await self._run_sync(ctx)
        finally:
            self._running.discard(ctx.guild.id)

    async def _run_sync(self, ctx: commands.Context) -> None:
        members = [m for m in ctx.guild.members if not m.bot]
        total = len(members)
        counts = {CHANGED: 0, UNCHANGED: 0, FAILED: 0}
        dist: dict[int, int] = {}
        started = last_edit = time.monotonic()

        message = await self._show(ctx, None, self._progress_embed(ctx, 0, total, counts))
        for done, member in enumerate(members, start=1):
            xp = await xp_bank.get_xp(member.id, ctx.guild.id)
            index = xp_bank.level_for_xp(xp).index
            dist[index] = dist.get(index, 0) + 1
            result = await sync_member_status(member, index)
            counts[result] += 1
            if result == CHANGED:
                await asyncio.sleep(0.5)  # tránh bị Discord giới hạn tốc độ
            now = time.monotonic()
            if done < total and now - last_edit >= 4:  # làm mới thanh tiến độ mỗi vài giây
                last_edit = now
                message = await self._show(ctx, message, self._progress_embed(ctx, done, total, counts))

        await self._show(ctx, message, self._done_embed(ctx, total, counts, dist, time.monotonic() - started))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(RealmRoles(bot))
