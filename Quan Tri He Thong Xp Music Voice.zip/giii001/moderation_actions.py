"""Lệnh quản trị thành viên: kick, ban, unban, mute (timeout), unmute, warn.

    .kick <@thành_viên> [lý do]
    .ban  <@thành_viên> [lý do]
    .unban <ID hoặc tên#tag> [lý do]
    .mute <@thành_viên> [thời gian] [lý do]     # ví dụ: .mute @ai 10m spam
    .unmute <@thành_viên> [lý do]
    .warn <@thành_viên> [lý do]                 # cảnh cáo, lưu vào cơ sở dữ liệu
    .warnings [@thành_viên]                     # xem lịch sử cảnh cáo
    .clearwarns <@thành_viên>                   # xóa toàn bộ cảnh cáo

Thời gian mute hiểu theo: s = giây, m = phút, h = giờ, d = ngày.
- .mute @ai 10m  -> timeout 10 phút
- .mute @ai 10   -> mặc định là phút (giống Discord UI)
- .mute @ai      -> timeout dài nhất Discord cho phép (~28 ngày), dùng .unmute để mở sớm
- gõ sai thời gian (vd 10min) sẽ báo lỗi chứ không mute nhầm

Discord giới hạn timeout tối đa 28 ngày (40320 phút), nên nếu bạn muốn "khoá vĩnh viễn"
hãy dùng .ban thay vì .mute.
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta
from typing import Optional

import discord
from discord.ext import commands

import ui
from database import db
from utils import send_log

log = logging.getLogger("bot.moderation_actions")

# Discord chặn timeout dài hơn 28 ngày.
MAX_TIMEOUT_MINUTES = 40320

# Giới hạn dùng thật: trừ 1 phút để không bị Discord từ chối khi đồng hồ máy chạy bot lệch nhẹ.
SAFE_MAX_TIMEOUT = timedelta(minutes=MAX_TIMEOUT_MINUTES) - timedelta(minutes=1)

# Đơn vị thời gian: ký tự -> số phút
_UNIT_MINUTES = {
    "s": 1 / 60,
    "m": 1,
    "h": 60,
    "d": 60 * 24,
}

# ".mute @ai 10m", ".mute @ai 1h30m", ".mute @ai 30" (mặc định phút), ".mute @ai" (tối đa)
_DURATION_RE = re.compile(r"^(\d+)\s*([smhdSMHD]?)$")


def parse_duration(text: str) -> Optional[timedelta]:
    """Đọc chuỗi thời gian như '10', '10m', '1h30m', '2d'.

    Trả về timedelta, hoặc None nếu không hiểu. Chuỗi rỗng cũng trả None (để caller tự xử lý).
    """
    text = text.strip().lower()
    if not text:
        return None

    # Hỗ trợ dạng ghép: 1h30m, 2d12h, 45s
    total_seconds = 0.0
    matched_any = False
    for amount, unit in re.findall(r"(\d+)\s*([smhd])", text):
        matched_any = True
        total_seconds += int(amount) * _UNIT_MINUTES[unit] * 60
    if matched_any:
        # Nếu còn ký tự lạ thì coi như sai
        leftover = re.sub(r"(\d+)\s*([smhd])", "", text).strip()
        if leftover:
            return None
        return timedelta(seconds=total_seconds)

    # Dạng số trơn: ".mute @ai 10" -> 10 phút
    if text.isdigit():
        return timedelta(minutes=int(text))
    return None


def format_duration(delta: timedelta) -> str:
    """timedelta -> '1 giờ 30 phút' (tiếng Việt, bỏ các phần bằng 0)."""
    total = int(delta.total_seconds())
    days, rest = divmod(total, 86400)
    hours, rest = divmod(rest, 3600)
    minutes, seconds = divmod(rest, 60)
    parts = [f"{value} {unit}" for value, unit in
             ((days, "ngày"), (hours, "giờ"), (minutes, "phút"), (seconds, "giây")) if value]
    return " ".join(parts) or "0 giây"


class ModerationActions(commands.Cog):
    """Các lệnh xử lý thành viên: kick, ban, unban, mute, unmute."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # Tiện ích
    # ------------------------------------------------------------------
    def _can_act_on(self, ctx: commands.Context, target: discord.Member) -> Optional[str]:
        """Trả về thông báo lỗi nếu không thể xử lý `target`, hoặc None nếu OK."""
        me = ctx.guild.me
        author = ctx.author
        if target.id == ctx.guild.owner_id:
            return "Không thể xử lý chủ máy chủ."
        if target.id == me.id:
            return "Bot không thể tự xử lý chính mình."
        if target.id == author.id:
            return "Bạn không thể tự xử lý chính mình."
        if target.top_role >= me.top_role:
            return f"Role của {target.mention} cao hơn hoặc ngang role cao nhất của bot."
        if author.id != ctx.guild.owner_id and target.top_role >= author.top_role:
            return f"Role của {target.mention} cao hơn hoặc ngang role cao nhất của bạn."
        return None

    @staticmethod
    def _reason(ctx: commands.Context, reason: Optional[str]) -> str:
        text = (reason or "").strip()
        return text or f"Không có lý do (bởi {ctx.author})"

    async def _notify_dm(self, target: discord.Member, action: str, guild: discord.Guild,
                         duration_text: str, reason: str) -> Optional[discord.Message]:
        """Gửi DM cho thành viên bị xử lý (không bắt buộc thành công). Trả về tin nhắn đã gửi."""
        try:
            embed = discord.Embed(
                title=f"🔨 Bạn đã bị {action}",
                description=f"Tại máy chủ **{discord.utils.escape_markdown(guild.name)}**.",
                color=0xE74C3C,
            )
            if duration_text:
                embed.add_field(name="⏱️ Thời hạn", value=duration_text, inline=True)
            embed.add_field(name="📝 Lý do", value=reason[:1024], inline=False)
            return await target.send(embed=embed)
        except (discord.Forbidden, discord.HTTPException):
            return None  # DM đóng: bỏ qua

    @staticmethod
    async def _retract_dm(message: Optional[discord.Message]) -> None:
        """Xóa DM đã gửi khi hành động (kick/ban/mute) cuối cùng thất bại, tránh báo sai cho thành viên."""
        if message is None:
            return
        try:
            await message.delete()
        except (discord.Forbidden, discord.HTTPException):
            pass

    @staticmethod
    def _done_embed(title: str, member: discord.Member, action: str, reason: str,
                    ctx: commands.Context, duration_text: str = "") -> discord.Embed:
        embed = ui.make(title, f"{member.mention} đã bị **{action}**.", color=ui.Color.WARNING, ctx=ctx,
                        thumbnail=member.display_avatar.url)
        embed.add_field(name="👤 Thành viên", value=f"{member.mention}\n`{member.id}`", inline=True)
        embed.add_field(name="🛡️ Thực hiện bởi", value=ctx.author.mention, inline=True)
        if duration_text:
            embed.add_field(name="⏱️ Thời hạn", value=duration_text, inline=True)
        embed.add_field(name="📝 Lý do", value=reason[:1024], inline=False)
        return embed

    # ------------------------------------------------------------------
    # .kick
    # ------------------------------------------------------------------
    @commands.command(name="kick", help="Kick thành viên khỏi máy chủ. Dùng: .kick <@thành_viên> [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(kick_members=True)
    @commands.bot_has_guild_permissions(kick_members=True)
    async def kick(self, ctx: commands.Context, member: discord.Member, *, reason: Optional[str] = None) -> None:
        problem = self._can_act_on(ctx, member)
        if problem:
            await ctx.send(embed=ui.error(problem, ctx=ctx))
            return

        full_reason = self._reason(ctx, reason)
        dm: Optional[discord.Message] = None
        try:
            dm = await self._notify_dm(member, "kick", ctx.guild, "", full_reason)
            await member.kick(reason=full_reason)
        except discord.Forbidden:
            await self._retract_dm(dm)
            await ctx.send(embed=ui.error("Bot không đủ quyền để kick thành viên này.", ctx=ctx))
            return
        except discord.HTTPException as exc:
            await self._retract_dm(dm)
            await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
            return

        await ctx.send(embed=self._done_embed("👢 Đã kick thành viên", member, "kick", full_reason, ctx),
                       allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="👢 Kick thành viên",
                       description=f"{ctx.author.mention} đã kick {member.mention}.",
                       color=0xE67E22,
                       fields=[("Lý do", full_reason, False)])

    # ------------------------------------------------------------------
    # .ban
    # ------------------------------------------------------------------
    @commands.command(name="ban", help="Ban thành viên khỏi máy chủ. Dùng: .ban <@thành_viên> [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(ban_members=True)
    @commands.bot_has_guild_permissions(ban_members=True)
    async def ban(self, ctx: commands.Context, member: discord.Member, *, reason: Optional[str] = None) -> None:
        problem = self._can_act_on(ctx, member)
        if problem:
            await ctx.send(embed=ui.error(problem, ctx=ctx))
            return

        full_reason = self._reason(ctx, reason)
        dm: Optional[discord.Message] = None
        try:
            dm = await self._notify_dm(member, "ban", ctx.guild, "Vĩnh viễn", full_reason)
            await member.ban(reason=full_reason, delete_message_seconds=86400)  # xóa tin nhắn 24 giờ gần nhất
        except discord.Forbidden:
            await self._retract_dm(dm)
            await ctx.send(embed=ui.error("Bot không đủ quyền để ban thành viên này.", ctx=ctx))
            return
        except discord.HTTPException as exc:
            await self._retract_dm(dm)
            await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
            return

        await ctx.send(embed=self._done_embed("🔨 Đã ban thành viên", member, "ban", full_reason, ctx,
                                              duration_text="Vĩnh viễn"),
                       allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="🔨 Ban thành viên",
                       description=f"{ctx.author.mention} đã ban {member.mention}.",
                       color=0xE74C3C,
                       fields=[("Lý do", full_reason, False)])

    # ------------------------------------------------------------------
    # .unban
    # ------------------------------------------------------------------
    @commands.command(name="unban", help="Gỡ ban theo ID hoặc tên. Dùng: .unban <ID> [lý do] hoặc .unban <tên> | [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(ban_members=True)
    @commands.bot_has_guild_permissions(ban_members=True)
    async def unban(self, ctx: commands.Context, *, query: str) -> None:
        query = query.strip()
        # Tách lý do nếu người dùng dùng dấu "|"
        reason = None
        if "|" in query:
            query, reason = [p.strip() for p in query.split("|", 1)]
        else:
            first, _, rest = query.partition(" ")
            if first.isdigit() and rest.strip():  # .unban 123456789 lý do ở đây
                query, reason = first, rest.strip()

        target: Optional[discord.User] = None
        if query.isdigit():
            try:
                target = await self.bot.fetch_user(int(query))
            except discord.NotFound:
                target = None
            except discord.HTTPException as exc:
                await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
                return
        else:
            # Tìm theo tên (name hoặc name#discriminator)
            try:
                bans = [entry async for entry in ctx.guild.bans(limit=1000)]
            except discord.Forbidden:
                await ctx.send(embed=ui.error("Bot không đủ quyền để xem danh sách ban.", ctx=ctx))
                return
            needle = query.casefold()
            for entry in bans:
                user = entry.user
                if (user.name.casefold() == needle
                        or user.display_name.casefold() == needle
                        or f"{user.name}#{user.discriminator}".casefold() == needle):
                    target = user
                    break

        if target is None:
            await ctx.send(embed=ui.error(f"Không tìm thấy người dùng bị ban khớp `{query}`.", ctx=ctx))
            return

        full_reason = self._reason(ctx, reason)
        try:
            await ctx.guild.unban(target, reason=full_reason)
        except discord.NotFound:
            await ctx.send(embed=ui.error(f"{target} không có trong danh sách ban.", ctx=ctx))
            return
        except discord.Forbidden:
            await ctx.send(embed=ui.error("Bot không đủ quyền để gỡ ban.", ctx=ctx))
            return
        except discord.HTTPException as exc:
            await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
            return

        embed = ui.make("♻️ Đã gỡ ban", f"{target.mention} đã được gỡ ban.",
                        color=ui.Color.SUCCESS, ctx=ctx, thumbnail=target.display_avatar.url)
        embed.add_field(name="👤 Người dùng", value=f"{target}\n`{target.id}`", inline=True)
        embed.add_field(name="📝 Lý do", value=full_reason[:1024], inline=False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="♻️ Gỡ ban",
                       description=f"{ctx.author.mention} đã gỡ ban **{target}** (`{target.id}`).",
                       color=0x2ECC71,
                       fields=[("Lý do", full_reason, False)])

    # ------------------------------------------------------------------
    # .mute (timeout)
    # ------------------------------------------------------------------
    @commands.command(name="mute",
                      help="Timeout thành viên. Dùng: .mute <@thành_viên> [thời gian: 10m/1h30m/45s] [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(moderate_members=True)
    @commands.bot_has_guild_permissions(moderate_members=True)
    async def mute(self, ctx: commands.Context, member: discord.Member, *,
                   args: Optional[str] = None) -> None:
        problem = self._can_act_on(ctx, member)
        if problem:
            await ctx.send(embed=ui.error(problem, ctx=ctx))
            return

        # Đã bị mute sẵn?
        if member.is_timed_out():
            until = member.timed_out_until
            await ctx.send(embed=ui.info(
                f"{member.mention} đang bị timeout đến <t:{(int(until.timestamp()))}:f>.\n"
                f"Muốn đặt lại thời gian, hãy dùng `{ctx.prefix}unmute` trước rồi mute lại.",
                title="ℹ️ Đã bị mute", ctx=ctx))
            return

        duration: Optional[timedelta] = None
        reason_text: Optional[str] = None
        raw = (args or "").strip()
        if raw:
            parts = raw.split(maxsplit=1)
            duration = parse_duration(parts[0])
            if duration is not None:
                reason_text = parts[1] if len(parts) > 1 else None
            elif parts[0][:1].isdigit():
                # Trông như thời gian nhưng gõ sai (10min, 5p, 1giờ...) -> báo lỗi, KHÔNG mute 28 ngày nhầm.
                safe = discord.utils.escape_markdown(parts[0].replace("`", ""))[:30]
                await ctx.send(embed=ui.error(
                    f"Không hiểu thời gian `{safe}`. Dùng: `30s`, `10m`, `2h`, `1d` hoặc ghép như `1h30m`.",
                    ctx=ctx))
                return
            else:
                # Không phải thời gian -> coi toàn bộ là lý do, dùng timeout dài nhất
                reason_text = raw

        if duration is None:
            # Không nhập thời gian -> timeout tối đa Discord cho phép (28 ngày)
            duration = SAFE_MAX_TIMEOUT
        elif duration.total_seconds() < 1:
            await ctx.send(embed=ui.error("Thời gian mute phải ít nhất 1 giây.", ctx=ctx))
            return
        elif duration > timedelta(minutes=MAX_TIMEOUT_MINUTES):
            await ctx.send(embed=ui.error(
                f"Discord chỉ cho timeout tối đa **28 ngày**. Nếu muốn khoá lâu hơn, hãy dùng `.ban`.",
                ctx=ctx))
            return
        duration = min(duration, SAFE_MAX_TIMEOUT)

        full_reason = self._reason(ctx, reason_text)
        until = discord.utils.utcnow() + duration
        until_text = (f"{format_duration(duration)} · đến <t:{int(until.timestamp())}:f> "
                      f"(<t:{int(until.timestamp())}:R>)")

        dm: Optional[discord.Message] = None
        try:
            dm = await self._notify_dm(member, "mute", ctx.guild,
                                       f"{format_duration(duration)} (đến <t:{int(until.timestamp())}:f>)",
                                       full_reason)
            await member.timeout(duration, reason=full_reason)
        except discord.Forbidden:
            await self._retract_dm(dm)
            await ctx.send(embed=ui.error(
                "Bot không đủ quyền timeout thành viên này (cần **Moderate Members** và role bot phải cao hơn).",
                ctx=ctx))
            return
        except discord.HTTPException as exc:
            await self._retract_dm(dm)
            await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
            return

        await ctx.send(
            embed=self._done_embed("🔇 Đã mute thành viên", member, "mute", full_reason, ctx,
                                   duration_text=until_text),
            allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="🔇 Mute thành viên",
                       description=f"{ctx.author.mention} đã mute {member.mention} {until_text}.",
                       color=0xF39C12,
                       fields=[("Lý do", full_reason, False),
                               ("Kết thúc", f"<t:{int(until.timestamp())}:f>", True)])

    # ------------------------------------------------------------------
    # .unmute
    # ------------------------------------------------------------------
    @commands.command(name="unmute", help="Gỡ timeout cho thành viên. Dùng: .unmute <@thành_viên> [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(moderate_members=True)
    @commands.bot_has_guild_permissions(moderate_members=True)
    async def unmute(self, ctx: commands.Context, member: discord.Member, *,
                     reason: Optional[str] = None) -> None:
        if not member.is_timed_out():
            await ctx.send(embed=ui.info(f"{member.mention} hiện không bị mute.", ctx=ctx),
                           allowed_mentions=discord.AllowedMentions.none())
            return

        problem = self._can_act_on(ctx, member)
        if problem:
            await ctx.send(embed=ui.error(problem, ctx=ctx))
            return

        full_reason = self._reason(ctx, reason)
        try:
            await member.timeout(None, reason=full_reason)
        except discord.Forbidden:
            await ctx.send(embed=ui.error("Bot không đủ quyền để gỡ mute cho thành viên này.", ctx=ctx))
            return
        except discord.HTTPException as exc:
            await ctx.send(embed=ui.error(f"Discord báo lỗi: {exc}", ctx=ctx))
            return

        embed = ui.make("🔊 Đã gỡ mute", f"{member.mention} đã được gỡ timeout.",
                        color=ui.Color.SUCCESS, ctx=ctx, thumbnail=member.display_avatar.url)
        embed.add_field(name="👤 Thành viên", value=f"{member.mention}\n`{member.id}`", inline=True)
        embed.add_field(name="🛡️ Thực hiện bởi", value=ctx.author.mention, inline=True)
        embed.add_field(name="📝 Lý do", value=full_reason[:1024], inline=False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="🔊 Gỡ mute",
                       description=f"{ctx.author.mention} đã gỡ mute cho {member.mention}.",
                       color=0x2ECC71,
                       fields=[("Lý do", full_reason, False)])

    # ------------------------------------------------------------------
    # .warn / .warnings / .clearwarns
    # ------------------------------------------------------------------
    @commands.command(name="warn", help="Cảnh cáo thành viên và lưu lịch sử. Dùng: .warn <@thành_viên> [lý do]")
    @commands.guild_only()
    @commands.has_guild_permissions(moderate_members=True)
    async def warn(self, ctx: commands.Context, member: discord.Member, *,
                   reason: Optional[str] = None) -> None:
        if member.bot:
            await ctx.send(embed=ui.error("Không thể cảnh cáo bot.", ctx=ctx))
            return
        problem = self._can_act_on(ctx, member)
        if problem:
            await ctx.send(embed=ui.error(problem, ctx=ctx))
            return

        text = (reason or "").strip()[:500] or "Không nêu lý do"
        created = discord.utils.utcnow().isoformat(timespec="seconds")

        def run(conn) -> tuple[int, int]:
            cursor = conn.execute(
                "INSERT INTO warnings (guild_id, user_id, moderator_id, reason, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (ctx.guild.id, member.id, ctx.author.id, text, created),
            )
            total = conn.execute(
                "SELECT COUNT(*) AS n FROM warnings WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, member.id),
            ).fetchone()["n"]
            return int(cursor.lastrowid), int(total)

        warn_id, total = await db.transaction(run)
        await self._notify_dm(member, "cảnh cáo", ctx.guild, "", f"{text}\n\nĐây là lần cảnh cáo thứ {total}.")

        embed = self._done_embed("⚠️ Đã cảnh cáo thành viên", member, "cảnh cáo", text, ctx)
        embed.add_field(name="🔢 Tổng số lần cảnh cáo", value=f"**{total}** (mã `#{warn_id}`)", inline=True)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="⚠️ Cảnh cáo thành viên",
                       description=f"{ctx.author.mention} đã cảnh cáo {member.mention}.",
                       color=0xF39C12,
                       fields=[("Lý do", text, False), ("Tổng số lần", str(total), True),
                               ("Mã", f"#{warn_id}", True)])

    @commands.command(name="warnings", aliases=["warns"],
                      help="Xem lịch sử cảnh cáo. Dùng: .warnings [@thành_viên]")
    @commands.guild_only()
    async def warnings(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        if member.id != ctx.author.id and not ctx.author.guild_permissions.moderate_members:
            await ctx.send(embed=ui.error(
                "Bạn chỉ xem được cảnh cáo của chính mình (xem người khác cần quyền **Moderate Members**).",
                ctx=ctx))
            return

        total_row = await db.fetchone(
            "SELECT COUNT(*) AS n FROM warnings WHERE guild_id = ? AND user_id = ?", (ctx.guild.id, member.id))
        total = int(total_row["n"])
        if total == 0:
            await ctx.send(embed=ui.info(f"{member.mention} chưa có cảnh cáo nào.", title="✅ Sạch sẽ", ctx=ctx),
                           allowed_mentions=discord.AllowedMentions.none())
            return

        rows = await db.fetchall(
            "SELECT id, moderator_id, reason, created_at FROM warnings "
            "WHERE guild_id = ? AND user_id = ? ORDER BY id DESC LIMIT 10",
            (ctx.guild.id, member.id),
        )
        lines = []
        for row in rows:
            when = discord.utils.format_dt(datetime.fromisoformat(row["created_at"]), "d")
            reason = discord.utils.escape_markdown(row["reason"])[:150]
            lines.append(f"`#{row['id']}` {when} · bởi <@{row['moderator_id']}>\n↳ {reason}")
        embed = ui.make(f"⚠️ Cảnh cáo của {discord.utils.escape_markdown(member.display_name)}",
                        "\n".join(lines), color=ui.Color.WARNING, ctx=ctx,
                        thumbnail=member.display_avatar.url)
        shown = f"{len(rows)} lần gần nhất" if total > len(rows) else "tất cả"
        embed.add_field(name="🔢 Tổng số", value=f"**{total}** (hiển thị {shown})", inline=False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

    @commands.command(name="clearwarns", aliases=["resetwarns"],
                      help="Xóa toàn bộ cảnh cáo của thành viên. Dùng: .clearwarns <@thành_viên>")
    @commands.guild_only()
    @commands.has_guild_permissions(moderate_members=True)
    async def clearwarns(self, ctx: commands.Context, member: discord.Member) -> None:
        def run(conn) -> int:
            count = conn.execute("SELECT COUNT(*) AS n FROM warnings WHERE guild_id = ? AND user_id = ?",
                                 (ctx.guild.id, member.id)).fetchone()["n"]
            conn.execute("DELETE FROM warnings WHERE guild_id = ? AND user_id = ?", (ctx.guild.id, member.id))
            return int(count)

        removed = await db.transaction(run)
        if removed == 0:
            await ctx.send(embed=ui.info(f"{member.mention} không có cảnh cáo nào để xóa.", ctx=ctx),
                           allowed_mentions=discord.AllowedMentions.none())
            return
        await ctx.send(embed=ui.success(f"Đã xóa **{removed}** cảnh cáo của {member.mention}.",
                                        title="🧹 Đã xóa cảnh cáo", ctx=ctx),
                       allowed_mentions=discord.AllowedMentions.none())
        await send_log(ctx.guild, title="🧹 Xóa cảnh cáo",
                       description=f"{ctx.author.mention} đã xóa {removed} cảnh cáo của {member.mention}.",
                       color=0x2ECC71)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ModerationActions(bot))