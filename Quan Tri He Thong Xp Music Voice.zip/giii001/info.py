"""Lệnh xem thông tin: .infouser và .infoserver.

    .infouser [@thành_viên]   -> thông tin thành viên (mặc định là chính bạn)
    .infoserver               -> thông tin máy chủ
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

import discord
from discord.ext import commands

import ui
import xp_bank
from database import db
from utils import fmt_int

log = logging.getLogger("bot.info")

MAX_ROLES_SHOWN = 15
VERIFICATION_TEXT = {"none": "Không", "low": "Thấp", "medium": "Trung bình", "high": "Cao", "highest": "Rất cao"}


def _when(moment: Optional[datetime]) -> str:
    """'<ngày đầy đủ> (<cách đây bao lâu>)' theo giờ địa phương của người xem; '?' nếu không có dữ liệu."""
    if moment is None:
        return "Không rõ"
    return f"{discord.utils.format_dt(moment, 'D')}\n{discord.utils.format_dt(moment, 'R')}"


class Info(commands.Cog):
    """Thông tin thành viên và máy chủ."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # .infouser
    # ------------------------------------------------------------------
    @commands.command(name="infouser", aliases=["userinfo", "whois"],
                      help="Xem thông tin thành viên. Dùng: .infouser [@thành_viên]")
    @commands.guild_only()
    async def infouser(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        guild = ctx.guild
        name = discord.utils.escape_markdown(member.display_name)

        embed = ui.make(
            name,
            f"{member.mention} · `{discord.utils.escape_markdown(member.name)}`",
            color=member.color.value or ui.Color.INFO,
            ctx=ctx,
            thumbnail=member.display_avatar.url,
        )
        kind = "🤖 Bot" if member.bot else "👤 Thành viên"
        if member.id == guild.owner_id:
            kind += " · 👑 Chủ máy chủ"
        embed.add_field(name="🆔 ID", value=f"`{member.id}`", inline=True)
        embed.add_field(name="🧾 Loại", value=kind, inline=True)
        embed.add_field(name="\u200b", value="\u200b", inline=True)  # đệm cho đủ 3 cột
        embed.add_field(name="📅 Tạo tài khoản", value=_when(member.created_at), inline=True)
        embed.add_field(name="📥 Vào máy chủ", value=_when(member.joined_at), inline=True)
        if member.premium_since:
            embed.add_field(name="💎 Booster từ", value=_when(member.premium_since), inline=True)

        if not member.bot:
            progress = await xp_bank.get_xp_progress(member.id, guild.id)
            rank = await xp_bank.get_rank(member.id, guild.id)
            rank_text = f"Hạng #{rank}" if rank else "Chưa có hạng"
            embed.add_field(
                name="⚔️ Cảnh giới",
                value=f"{ui.realm_label(progress.level)}\n**{fmt_int(progress.xp)} XP** · {rank_text}",
                inline=False,
            )

        roles = [role for role in reversed(member.roles) if not role.is_default()]
        if roles:
            text = " ".join(role.mention for role in roles[:MAX_ROLES_SHOWN])
            if len(roles) > MAX_ROLES_SHOWN:
                text += f" … và {len(roles) - MAX_ROLES_SHOWN} role nữa"
            embed.add_field(name=f"🎭 Role ({len(roles)})", value=text[:1024], inline=False)
            embed.add_field(name="🏷️ Role cao nhất", value=member.top_role.mention, inline=True)

        if member.guild_permissions.administrator:
            embed.add_field(name="🛡️ Quyền", value="Quản trị viên", inline=True)
        if member.is_timed_out():
            embed.add_field(name="🔇 Đang bị mute đến",
                            value=discord.utils.format_dt(member.timed_out_until, "f"), inline=True)

        # Số lần cảnh cáo chỉ hiện cho người có quyền kiểm duyệt, tránh công khai lịch sử của thành viên.
        if ctx.author.guild_permissions.moderate_members:
            row = await db.fetchone("SELECT COUNT(*) AS n FROM warnings WHERE guild_id = ? AND user_id = ?",
                                    (guild.id, member.id))
            embed.add_field(name="⚠️ Cảnh cáo", value=f"**{int(row['n'])}** lần", inline=True)

        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

    # ------------------------------------------------------------------
    # .infoserver
    # ------------------------------------------------------------------
    @commands.command(name="infoserver", aliases=["infosever", "serverinfo"],
                      help="Xem thông tin máy chủ. Dùng: .infoserver")
    @commands.guild_only()
    async def infoserver(self, ctx: commands.Context) -> None:
        guild = ctx.guild
        embed = ui.make(
            discord.utils.escape_markdown(guild.name),
            guild.description or "",
            color=ui.Color.BRAND,
            ctx=ctx,
            thumbnail=guild.icon.url if guild.icon else None,
        )
        if guild.banner:
            embed.set_image(url=guild.banner.url)

        embed.add_field(name="🆔 ID", value=f"`{guild.id}`", inline=True)
        embed.add_field(name="👑 Chủ máy chủ", value=f"<@{guild.owner_id}>", inline=True)
        embed.add_field(name="📅 Ngày tạo", value=_when(guild.created_at), inline=True)

        total = guild.member_count or len(guild.members)
        members_text = f"**{fmt_int(total)}** thành viên"
        if len(guild.members) == total:  # bộ nhớ đệm đủ thì mới chia được người/bot cho chính xác
            bots = sum(1 for member in guild.members if member.bot)
            members_text += f"\n👤 {fmt_int(total - bots)} người · 🤖 {fmt_int(bots)} bot"
        embed.add_field(name="👥 Thành viên", value=members_text, inline=True)

        voice = len(guild.voice_channels) + len(guild.stage_channels)
        embed.add_field(
            name="💬 Kênh",
            value=f"📝 {len(guild.text_channels)} văn bản\n🔊 {voice} thoại\n📁 {len(guild.categories)} danh mục",
            inline=True,
        )
        embed.add_field(name="🎭 Role", value=f"**{max(len(guild.roles) - 1, 0)}**", inline=True)
        embed.add_field(
            name="😀 Emoji & sticker",
            value=f"{len(guild.emojis)}/{guild.emoji_limit} emoji\n{len(guild.stickers)}/{guild.sticker_limit} sticker",
            inline=True,
        )
        embed.add_field(
            name="🚀 Boost",
            value=f"Cấp **{guild.premium_tier}** · {guild.premium_subscription_count} lượt",
            inline=True,
        )
        embed.add_field(
            name="🔒 Xác minh",
            value=VERIFICATION_TEXT.get(guild.verification_level.name, guild.verification_level.name),
            inline=True,
        )
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Info(bot))
