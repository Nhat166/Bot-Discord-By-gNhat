"""Lệnh .help tiếng Việt, chia nhóm bằng embed.

    .help            -> tổng quan các nhóm lệnh (chỉ hiện lệnh bạn dùng được)
    .help <lệnh>     -> chi tiết một lệnh: mô tả, cách dùng, tên gọi tắt
    .help <nhóm>     -> ví dụ: .help nhạc, .help quản trị

Muốn thêm lệnh mới vào nhóm: sửa CATEGORIES. Lệnh chưa có trong nhóm nào tự rơi vào "Khác".
"""
from __future__ import annotations

import logging
from typing import Optional

import discord
from discord.ext import commands

import config

log = logging.getLogger("bot.help")

# (tên hiển thị, từ khóa tìm nhóm, danh sách tên lệnh)
CATEGORIES: list[tuple[str, str, list[str]]] = [
    ("🎵 Âm nhạc", "nhạc", ["play", "dung", "again", "skip", "stop", "danhsach", "nowplay", "volume"]),
    ("⚔️ Tu tiên", "tu tiên", ["rank", "leaderboard", "level"]),
    ("🏷️ Role & chào mừng", "role", ["addrole", "testwelcome"]),
    ("🛡️ Quản trị", "quản trị", ["config", "xp-admin", "syncroles"]),
]
OTHER_NAME = "📦 Khác"
HELP_COLOR = 0x5865F2


def _signature(prefix: str, command: commands.Command) -> str:
    return f"{prefix}{command.qualified_name} {command.signature}".strip()


def _short(command: commands.Command) -> str:
    text = (command.help or "Chưa có mô tả.").strip().splitlines()[0]
    # Bỏ phần "Dùng: ..." khỏi dòng mô tả ngắn để gọn.
    text = text.split(" Dùng:")[0].strip()
    return text[:120]


async def _can_run(ctx: commands.Context, command: commands.Command) -> bool:
    if command.hidden:
        return False
    try:
        return await command.can_run(ctx)
    except commands.CommandError:
        return False
    except Exception:  # check lỗi bất ngờ: coi như không chạy được
        log.exception("Kiểm tra quyền lệnh %s lỗi", command.qualified_name)
        return False


class VietHelp(commands.Cog):
    """Lệnh .help chia nhóm."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # -- dữ liệu --------------------------------------------------------------
    async def _grouped(self, ctx: commands.Context) -> list[tuple[str, list[commands.Command]]]:
        """Các nhóm (đã bỏ nhóm rỗng) chứa lệnh mà người gọi dùng được."""
        runnable = {c.qualified_name: c for c in self.bot.commands if await _can_run(ctx, c)}
        used: set[str] = set()
        result: list[tuple[str, list[commands.Command]]] = []
        for title, _, names in CATEGORIES:
            cmds = [runnable[n] for n in names if n in runnable]
            used.update(n for n in names if n in runnable)
            if cmds:
                result.append((title, cmds))
        # Lệnh chưa được xếp nhóm (trừ chính .help) vào "Khác".
        rest = [c for n, c in sorted(runnable.items()) if n not in used and n != "help"]
        if rest:
            result.append((OTHER_NAME, rest))
        return result

    # -- embed ----------------------------------------------------------------
    def _overview(self, prefix: str, groups: list[tuple[str, list[commands.Command]]]) -> discord.Embed:
        embed = discord.Embed(
            title="📖 Hướng dẫn sử dụng bot",
            description=(f"Tiền tố lệnh: `{prefix}`\n"
                         f"Xem chi tiết: `{prefix}help <lệnh>` hoặc `{prefix}help <tên nhóm>`"),
            color=HELP_COLOR,
        )
        for title, cmds in groups:
            lines = [f"`{prefix}{c.qualified_name}` · {_short(c)}" for c in cmds]
            value = "\n".join(lines)
            if len(value) > 1024:
                value = value[:1020] + "…"
            embed.add_field(name=title, value=value, inline=False)
        embed.set_footer(text="Chỉ hiện các lệnh bạn có quyền dùng.")
        return embed

    def _group_embed(self, prefix: str, title: str, cmds: list[commands.Command]) -> discord.Embed:
        embed = discord.Embed(title=title, color=HELP_COLOR)
        for c in cmds:
            aliases = f"\nTên gọi tắt: {', '.join(f'`{prefix}{a}`' for a in c.aliases)}" if c.aliases else ""
            embed.add_field(
                name=f"`{_signature(prefix, c)}`",
                value=(_short(c) + aliases)[:1024],
                inline=False,
            )
        embed.set_footer(text=f"Gõ {prefix}help để quay lại tổng quan.")
        return embed

    def _command_embed(self, prefix: str, command: commands.Command) -> discord.Embed:
        embed = discord.Embed(
            title=f"📌 {prefix}{command.qualified_name}",
            description=(command.help or "Chưa có mô tả.")[:2000],
            color=HELP_COLOR,
        )
        embed.add_field(name="Cách dùng", value=f"`{_signature(prefix, command)}`", inline=False)
        if command.aliases:
            embed.add_field(name="Tên gọi tắt", value=", ".join(f"`{prefix}{a}`" for a in command.aliases),
                            inline=False)
        subs = getattr(command, "commands", None)
        if subs:
            embed.add_field(
                name="Lệnh con",
                value="\n".join(f"`{_signature(prefix, s)}` · {_short(s)}" for s in sorted(subs, key=lambda s: s.name))[:1024],
                inline=False,
            )
        return embed

    # -- lệnh -----------------------------------------------------------------
    @commands.command(name="help", aliases=["h", "trogiup"], help="Xem danh sách lệnh. Dùng: .help [lệnh hoặc nhóm]")
    async def help_cmd(self, ctx: commands.Context, *, query: Optional[str] = None) -> None:
        prefix = ctx.prefix or config.PREFIX
        groups = await self._grouped(ctx)
        no_mentions = discord.AllowedMentions.none()

        if not query:
            await ctx.send(embed=self._overview(prefix, groups), allowed_mentions=no_mentions)
            return

        wanted = query.strip().lstrip(prefix).casefold()

        # 1) tên nhóm (khớp từ khóa, hoặc nằm trong tên hiển thị)
        keywords = {title: kw for title, kw, _ in CATEGORIES}
        for title, cmds in groups:
            kw = keywords.get(title, "khác")
            if wanted == kw or wanted == title.casefold() or wanted in title.casefold().split():
                await ctx.send(embed=self._group_embed(prefix, title, cmds), allowed_mentions=no_mentions)
                return

        # 2) tên lệnh (hoặc lệnh con: "xp-admin add")
        command = self.bot.get_command(wanted)
        if command is not None and await _can_run(ctx, command):
            await ctx.send(embed=self._command_embed(prefix, command), allowed_mentions=no_mentions)
            return

        await ctx.send(
            f"❌ Không tìm thấy lệnh hoặc nhóm `{discord.utils.escape_markdown(wanted)[:50]}`. "
            f"Gõ `{prefix}help` để xem danh sách.",
            allowed_mentions=no_mentions,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(VietHelp(bot))
