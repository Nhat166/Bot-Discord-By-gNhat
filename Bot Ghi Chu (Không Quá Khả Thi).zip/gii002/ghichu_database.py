"""Lớp truy cập SQLite: mọi truy vấn chạy trong luồng nền và được tuần tự hóa bằng một khóa."""
from __future__ import annotations

import asyncio
import logging
import os
import sqlite3
from typing import Any, Callable, Sequence, TypeVar

log = logging.getLogger("ghichu.database")

T = TypeVar("T")

SCHEMA = """
CREATE TABLE IF NOT EXISTS folders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    scope      TEXT    NOT NULL CHECK (scope IN ('u', 'g')),   -- u = riêng của một người, g = của cả máy chủ
    scope_id   INTEGER NOT NULL,                                -- ID người dùng (u) hoặc ID máy chủ (g)
    name       TEXT    NOT NULL,
    name_key   TEXT    NOT NULL,                                -- tên đã chuẩn hóa để chống trùng
    creator_id INTEGER NOT NULL,
    created_at TEXT    NOT NULL,
    updated_at TEXT    NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_folders_name ON folders (scope, scope_id, name_key);

CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    scope      TEXT    NOT NULL CHECK (scope IN ('u', 'g')),
    scope_id   INTEGER NOT NULL,
    folder_id  INTEGER REFERENCES folders (id) ON DELETE CASCADE,   -- NULL = văn bản không nằm trong thư mục
    title      TEXT    NOT NULL,
    title_key  TEXT    NOT NULL,
    content    TEXT    NOT NULL DEFAULT '',
    creator_id INTEGER NOT NULL,
    created_at TEXT    NOT NULL,
    updated_at TEXT    NOT NULL
);
-- Tên văn bản không được trùng trong cùng một thư mục (hoặc trong cùng khu "không thư mục").
CREATE UNIQUE INDEX IF NOT EXISTS ux_notes_title ON notes (scope, scope_id, IFNULL(folder_id, 0), title_key);
CREATE INDEX IF NOT EXISTS ix_notes_folder ON notes (folder_id);
CREATE INDEX IF NOT EXISTS ix_notes_scope ON notes (scope, scope_id);

-- Lịch sử chỉnh sửa: mỗi dòng là trạng thái (tên + nội dung) của văn bản SAU một lần tạo/sửa.
CREATE TABLE IF NOT EXISTS note_versions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    note_id    INTEGER NOT NULL REFERENCES notes (id) ON DELETE CASCADE,
    title      TEXT    NOT NULL,
    content    TEXT    NOT NULL,
    editor_id  INTEGER NOT NULL,
    created_at TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_versions_note ON note_versions (note_id, id);

-- Thùng rác: bản chụp (JSON) của văn bản/thư mục đã xóa, giữ vài chục ngày rồi tự dọn.
CREATE TABLE IF NOT EXISTS trash (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    scope       TEXT    NOT NULL CHECK (scope IN ('u', 'g')),
    scope_id    INTEGER NOT NULL,
    kind        TEXT    NOT NULL CHECK (kind IN ('note', 'folder')),
    name        TEXT    NOT NULL,
    folder_name TEXT,                                   -- văn bản: tên thư mục lúc bị xóa
    item_count  INTEGER NOT NULL DEFAULT 0,             -- thư mục: số văn bản bên trong
    creator_id  INTEGER NOT NULL,
    deleted_by  INTEGER NOT NULL,
    deleted_at  TEXT    NOT NULL,
    payload     TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_trash_scope ON trash (scope, scope_id, deleted_at);
"""


class Database:
    def __init__(self) -> None:
        self._conn: sqlite3.Connection | None = None
        self._lock: asyncio.Lock | None = None

    async def connect(self, path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._lock = asyncio.Lock()
        self._conn = await asyncio.to_thread(self._open, path)
        log.info("Đã mở cơ sở dữ liệu: %s", path)

    @staticmethod
    def _open(path: str) -> sqlite3.Connection:
        conn = sqlite3.connect(path, isolation_level=None, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(SCHEMA)
        return conn

    async def close(self) -> None:
        if self._conn is None or self._lock is None:
            return
        async with self._lock:
            await asyncio.to_thread(self._conn.close)
            self._conn = None

    def _require(self) -> tuple[sqlite3.Connection, asyncio.Lock]:
        if self._conn is None or self._lock is None:
            raise RuntimeError("Cơ sở dữ liệu chưa được kết nối (gọi db.connect trước).")
        return self._conn, self._lock

    async def fetchone(self, sql: str, params: Sequence[Any] = ()) -> sqlite3.Row | None:
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(lambda: conn.execute(sql, tuple(params)).fetchone())

    async def fetchall(self, sql: str, params: Sequence[Any] = ()) -> list[sqlite3.Row]:
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(lambda: conn.execute(sql, tuple(params)).fetchall())

    async def transaction(self, func: Callable[[sqlite3.Connection], T]) -> T:
        """Chạy `func(conn)` (hàm đồng bộ) trong một giao dịch: thành công thì COMMIT, lỗi thì ROLLBACK."""
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(self._run_transaction, conn, func)

    @staticmethod
    def _run_transaction(conn: sqlite3.Connection, func: Callable[[sqlite3.Connection], T]) -> T:
        conn.execute("BEGIN IMMEDIATE")
        try:
            result = func(conn)
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        conn.execute("COMMIT")
        return result


db = Database()
