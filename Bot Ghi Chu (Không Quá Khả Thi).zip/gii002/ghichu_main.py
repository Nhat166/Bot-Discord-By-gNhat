"""Điểm khởi chạy của bot ghi chú.

Chạy:  python ghichu_main.py
"""
from __future__ import annotations

import logging
import logging.handlers
import sys

import discord
from discord.ext import commands

import ghichu_config as config
from ghichu_database import db

log = logging.getLogger("ghichu")


def setup_logging() -> None:
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    root.addHandler(console)
    file_handler = logging.handlers.RotatingFileHandler("ghichu.log", maxBytes=2_000_000, backupCount=3,
                                                        encoding="utf-8")
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)


class GhiChuBot(commands.Bot):
    def __init__(self) -> None:
        # Bot chỉ dùng lệnh /, nên KHÔNG cần intent đặc quyền (Message Content, Members...).
        super().__init__(command_prefix=commands.when_mentioned, intents=discord.Intents.default(),
                         help_command=None)

    async def setup_hook(self) -> None:
        await db.connect(config.DATABASE_PATH)
        await self.load_extension("ghichu_notes")
        await self.load_extension("ghichu_help")
        if config.GUILD_ID:
            guild = discord.Object(id=config.GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Đã đồng bộ %d lệnh / vào máy chủ %s (có hiệu lực ngay).", len(synced), config.GUILD_ID)
        else:
            synced = await self.tree.sync()
            log.info("Đã đồng bộ %d lệnh / toàn cầu (Discord có thể mất một lúc để hiện ra).", len(synced))

    async def close(self) -> None:
        await super().close()
        await db.close()

    async def on_ready(self) -> None:
        log.info("Đã đăng nhập: %s (ID %s) | %d máy chủ", self.user, self.user.id, len(self.guilds))


def main() -> None:
    setup_logging()
    if not config.TOKEN:
        raise SystemExit("Thiếu GHICHU_TOKEN. Hãy tạo file ghichu.env từ ghichu.env.example và dán token của bot ghi chú vào.")
    try:
        GhiChuBot().run(config.TOKEN, log_handler=None)
    except discord.LoginFailure:
        raise SystemExit("Token không hợp lệ. Hãy tạo lại token trong Discord Developer Portal và cập nhật file ghichu.env.")


if __name__ == "__main__":
    main()
