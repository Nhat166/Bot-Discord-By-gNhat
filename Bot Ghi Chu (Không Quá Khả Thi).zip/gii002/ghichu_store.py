"""Lưu trữ ghi chú: thư mục -> văn bản -> nội dung (hoặc văn bản đứng riêng, không thư mục).

Một "khu" (Scope) là một tập ghi chú độc lập:
    Scope("u", <ID người dùng>)  : ghi chú RIÊNG của một người
    Scope("g", <ID máy chủ>)     : ghi chú CHUNG của cả máy chủ
Mọi hàm ở đây chỉ làm việc với dữ liệu; việc kiểm tra quyền và hiển thị nằm ở notes.py.
"""
from __future__ import annotations

import json
import sqlite3
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from ghichu_database import Database

PRIVATE = "u"
SERVER = "g"
NAME_MAX = 50
CONTENT_MAX = 4000
# (số thư mục tối đa, số văn bản tối đa) cho mỗi khu
LIMITS = {PRIVATE: (50, 300), SERVER: (100, 1000)}
SNIPPET_RADIUS = 40
HISTORY_MAX = 20   # số bản lịch sử giữ cho mỗi văn bản
TRASH_DAYS = 30    # thùng rác giữ bao nhiêu ngày
TRASH_MAX = 100    # tối đa số mục trong thùng rác của mỗi khu
TS_FORMAT = "%Y-%m-%d %H:%M:%S.%f"


class NoteError(Exception):
    """Lỗi có nội dung thân thiện, hiện thẳng cho người dùng."""


class Ambiguous(NoteError):
    """Nhiều văn bản trùng tên ở các thư mục khác nhau."""

    def __init__(self, title: str, folders: list[str]) -> None:
        self.folders = folders
        listing = ", ".join(f"**{f}**" for f in folders[:10])
        super().__init__(f"Có {len(folders)} văn bản tên **{title}** trong các thư mục: {listing}. "
                         "Hãy điền thêm tên thư mục để chọn đúng văn bản.")


@dataclass(frozen=True)
class Scope:
    kind: str  # PRIVATE | SERVER
    id: int

    @property
    def is_server(self) -> bool:
        return self.kind == SERVER


@dataclass(frozen=True)
class Folder:
    id: int
    name: str
    creator_id: int
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class Note:
    id: int
    folder_id: Optional[int]
    folder_name: Optional[str]
    title: str
    content: str
    creator_id: int
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class Version:
    id: int
    note_id: int
    title: str
    content: str
    editor_id: int
    created_at: str


@dataclass(frozen=True)
class TrashItem:
    id: int
    kind: str  # "note" | "folder"
    name: str
    folder_name: Optional[str]
    item_count: int
    creator_id: int
    deleted_by: int
    deleted_at: str


@dataclass
class Restored:
    kind: str
    name: str                      # tên sau khi khôi phục (có thể đã đổi nếu bị trùng)
    original_name: str
    folder_name: Optional[str]     # văn bản: đang nằm trong thư mục nào
    count: int                     # thư mục: số văn bản được khôi phục
    folder_created: bool           # thư mục cũ đã mất nên bot tạo lại
    folder_lost: bool              # không tạo lại được thư mục -> văn bản để ngoài thư mục

    @property
    def renamed(self) -> bool:
        return self.name != self.original_name


@dataclass
class SearchResult:
    folders: list[Folder]
    by_title: list[Note]
    by_content: list[tuple[Note, str]]  # (văn bản, đoạn trích quanh chỗ khớp)

    @property
    def total(self) -> int:
        return len(self.folders) + len(self.by_title) + len(self.by_content)


# ---------------------------------------------------------------------------
# Chuẩn hóa văn bản
# ---------------------------------------------------------------------------
def clean_name(raw: str, what: str = "Tên") -> str:
    """Chuẩn hóa tên thư mục/văn bản: gộp khoảng trắng, bỏ ký tự điều khiển, kiểm tra độ dài."""
    text = unicodedata.normalize("NFC", raw or "")
    text = "".join(" " if unicodedata.category(c).startswith("C") else c for c in text)
    text = " ".join(text.split())
    if not text:
        raise NoteError(f"{what} không được để trống.")
    if len(text) > NAME_MAX:
        raise NoteError(f"{what} tối đa **{NAME_MAX}** ký tự (bạn nhập {len(text)}).")
    return text


def clean_content(raw: Optional[str]) -> str:
    text = unicodedata.normalize("NFC", raw or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if len(text) > CONTENT_MAX:
        raise NoteError(f"Nội dung tối đa **{CONTENT_MAX}** ký tự (bạn nhập {len(text)}).")
    return text


def key_of(name: str) -> str:
    """Khóa chống trùng tên: không phân biệt hoa/thường (nhưng vẫn phân biệt dấu)."""
    return unicodedata.normalize("NFC", name).casefold()


def _fold_char(char: str) -> str:
    if char in "đĐ":
        return "d"
    base = "".join(c for c in unicodedata.normalize("NFD", char) if not unicodedata.combining(c))
    return (base or char).lower()[:1] or char


def fold(text: str) -> str:
    """Bỏ dấu + hạ chữ thường, giữ nguyên độ dài (để tìm 'toan' ra 'Toán' và cắt đoạn trích đúng chỗ)."""
    return "".join(_fold_char(c) for c in unicodedata.normalize("NFC", text))


def _now() -> str:
    return datetime.now(timezone.utc).strftime(TS_FORMAT)


def _folder(row: sqlite3.Row) -> Folder:
    return Folder(row["id"], row["name"], row["creator_id"], row["created_at"], row["updated_at"])


def _note(row: sqlite3.Row) -> Note:
    return Note(row["id"], row["folder_id"], row["folder_name"], row["title"], row["content"],
                row["creator_id"], row["created_at"], row["updated_at"])


def _version(row: sqlite3.Row) -> Version:
    return Version(row["id"], row["note_id"], row["title"], row["content"], row["editor_id"], row["created_at"])


def _trash_item(row: sqlite3.Row) -> TrashItem:
    return TrashItem(row["id"], row["kind"], row["name"], row["folder_name"], row["item_count"],
                     row["creator_id"], row["deleted_by"], row["deleted_at"])


_NOTE_SELECT = ("SELECT n.*, f.name AS folder_name FROM notes n LEFT JOIN folders f ON f.id = n.folder_id ")


# ---------------------------------------------------------------------------
# Các hàm đồng bộ chạy trong giao dịch
# ---------------------------------------------------------------------------
def _find_folder(conn: sqlite3.Connection, scope: Scope, name: str) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM folders WHERE scope = ? AND scope_id = ? AND name_key = ?",
                        (scope.kind, scope.id, key_of(name))).fetchone()


def _require_folder(conn: sqlite3.Connection, scope: Scope, name: str) -> sqlite3.Row:
    row = _find_folder(conn, scope, name)
    if row is None:
        raise NoteError(f"Không có thư mục **{name}**. Tạo trước bằng lệnh add với tên thư mục đó.")
    return row


def _find_note(conn: sqlite3.Connection, scope: Scope, title: str, folder_name: Optional[str]) -> Optional[sqlite3.Row]:
    key = key_of(title)
    if folder_name:
        folder = _require_folder(conn, scope, folder_name)
        return conn.execute(_NOTE_SELECT + "WHERE n.scope = ? AND n.scope_id = ? AND n.folder_id = ? AND n.title_key = ?",
                            (scope.kind, scope.id, folder["id"], key)).fetchone()
    rows = conn.execute(_NOTE_SELECT + "WHERE n.scope = ? AND n.scope_id = ? AND n.title_key = ? "
                        "ORDER BY n.folder_id IS NOT NULL, n.id", (scope.kind, scope.id, key)).fetchall()
    if not rows:
        return None
    if rows[0]["folder_id"] is None or len(rows) == 1:  # ưu tiên văn bản không thư mục
        return rows[0]
    raise Ambiguous(title, [r["folder_name"] for r in rows])


def _title_taken(conn: sqlite3.Connection, scope: Scope, folder_id: Optional[int], title_key: str,
                 exclude_id: Optional[int] = None) -> bool:
    row = conn.execute("SELECT 1 FROM notes WHERE scope = ? AND scope_id = ? AND IFNULL(folder_id, 0) = ? "
                       "AND title_key = ? AND id != ?", (scope.kind, scope.id, folder_id or 0, title_key, exclude_id or 0)
                       ).fetchone()
    return row is not None


def _free_title(conn: sqlite3.Connection, scope: Scope, folder_id: Optional[int], title: str,
                tag: str) -> str:
    """Tên chưa bị trùng: giữ nguyên nếu được, không thì thêm hậu tố `tag` rồi số thứ tự."""
    candidate, number = title, 1
    while _title_taken(conn, scope, folder_id, key_of(candidate)):
        number += 1
        suffix = f" ({tag})" if number == 2 else f" ({tag} {number - 1})"
        candidate = title[:NAME_MAX - len(suffix)].rstrip() + suffix
    return candidate


def _add_version(conn: sqlite3.Connection, note_id: int, title: str, content: str, editor_id: int, stamp: str) -> None:
    conn.execute("INSERT INTO note_versions (note_id, title, content, editor_id, created_at) VALUES (?, ?, ?, ?, ?)",
                 (note_id, title, content, editor_id, stamp))
    conn.execute("DELETE FROM note_versions WHERE note_id = ? AND id NOT IN "
                 "(SELECT id FROM note_versions WHERE note_id = ? ORDER BY id DESC LIMIT ?)",
                 (note_id, note_id, HISTORY_MAX))


def _note_payload(conn: sqlite3.Connection, row: sqlite3.Row) -> dict:
    versions = conn.execute("SELECT title, content, editor_id, created_at FROM note_versions WHERE note_id = ? "
                            "ORDER BY id", (row["id"],)).fetchall()
    return {"title": row["title"], "content": row["content"], "creator_id": row["creator_id"],
            "created_at": row["created_at"], "updated_at": row["updated_at"],
            "versions": [dict(v) for v in versions]}


def _trash_put(conn: sqlite3.Connection, scope: Scope, kind: str, name: str, folder_name: Optional[str],
               item_count: int, creator_id: int, deleted_by: int, payload: dict) -> None:
    conn.execute("INSERT INTO trash (scope, scope_id, kind, name, folder_name, item_count, creator_id, deleted_by, "
                 "deleted_at, payload) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                 (scope.kind, scope.id, kind, name, folder_name, item_count, creator_id, deleted_by, _now(),
                  json.dumps(payload, ensure_ascii=False)))
    _trash_cleanup(conn, scope)


def _trash_cleanup(conn: sqlite3.Connection, scope: Scope) -> None:
    cutoff = (datetime.now(timezone.utc) - timedelta(days=TRASH_DAYS)).strftime(TS_FORMAT)
    conn.execute("DELETE FROM trash WHERE scope = ? AND scope_id = ? AND deleted_at < ?", (scope.kind, scope.id, cutoff))
    conn.execute("DELETE FROM trash WHERE scope = ? AND scope_id = ? AND id NOT IN "
                 "(SELECT id FROM trash WHERE scope = ? AND scope_id = ? ORDER BY id DESC LIMIT ?)",
                 (scope.kind, scope.id, scope.kind, scope.id, TRASH_MAX))


def _insert_note(conn: sqlite3.Connection, scope: Scope, folder_id: Optional[int], data: dict, title: str) -> None:
    """Chèn lại một văn bản từ bản chụp trong thùng rác (giữ nguyên ngày tạo/sửa và lịch sử)."""
    cursor = conn.execute(
        "INSERT INTO notes (scope, scope_id, folder_id, title, title_key, content, creator_id, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (scope.kind, scope.id, folder_id, title, key_of(title), data["content"], data["creator_id"],
         data["created_at"], data["updated_at"]))
    versions = data.get("versions") or [{"title": title, "content": data["content"], "editor_id": data["creator_id"],
                                         "created_at": data["updated_at"]}]
    for v in versions:
        conn.execute("INSERT INTO note_versions (note_id, title, content, editor_id, created_at) VALUES (?, ?, ?, ?, ?)",
                     (cursor.lastrowid, v["title"], v["content"], v["editor_id"], v["created_at"]))


def _counts(conn: sqlite3.Connection, scope: Scope) -> tuple[int, int]:
    folders = conn.execute("SELECT COUNT(*) FROM folders WHERE scope = ? AND scope_id = ?",
                           (scope.kind, scope.id)).fetchone()[0]
    notes = conn.execute("SELECT COUNT(*) FROM notes WHERE scope = ? AND scope_id = ?",
                         (scope.kind, scope.id)).fetchone()[0]
    return folders, notes


class NoteStore:
    def __init__(self, database: Database) -> None:
        self.db = database

    # -- tạo -------------------------------------------------------------------
    async def create_folder(self, scope: Scope, name: str, creator_id: int) -> Folder:
        name = clean_name(name, "Tên thư mục")

        def work(conn: sqlite3.Connection) -> Folder:
            if _counts(conn, scope)[0] >= LIMITS[scope.kind][0]:
                raise NoteError(f"Đã đạt giới hạn **{LIMITS[scope.kind][0]}** thư mục. Hãy xóa bớt trước.")
            if _find_folder(conn, scope, name):
                raise NoteError(f"Đã có thư mục tên **{name}**.")
            now = _now()
            cursor = conn.execute(
                "INSERT INTO folders (scope, scope_id, name, name_key, creator_id, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)", (scope.kind, scope.id, name, key_of(name), creator_id, now, now))
            return _folder(conn.execute("SELECT * FROM folders WHERE id = ?", (cursor.lastrowid,)).fetchone())

        return await self.db.transaction(work)

    async def ensure_folder(self, scope: Scope, name: str, creator_id: int) -> tuple[Folder, bool]:
        """Lấy thư mục theo tên; chưa có thì tạo. Trả về (thư mục, có phải vừa tạo không)."""
        existing = await self.find_folder(scope, name)
        if existing:
            return existing, False
        try:
            return await self.create_folder(scope, name, creator_id), True
        except NoteError:  # có thể vừa bị người khác tạo cùng lúc
            existing = await self.find_folder(scope, name)
            if existing:
                return existing, False
            raise

    async def create_note(self, scope: Scope, title: str, content: Optional[str], creator_id: int,
                          folder_name: Optional[str] = None, auto_rename: bool = False) -> Note:
        title = clean_name(title, "Tên văn bản")
        content = clean_content(content)

        def work(conn: sqlite3.Connection) -> Note:
            folder = _require_folder(conn, scope, folder_name) if folder_name else None
            if _counts(conn, scope)[1] >= LIMITS[scope.kind][1]:
                raise NoteError(f"Đã đạt giới hạn **{LIMITS[scope.kind][1]}** văn bản. Hãy xóa bớt trước.")
            folder_id = folder["id"] if folder else None
            final = title
            if _title_taken(conn, scope, folder_id, key_of(title)):
                if not auto_rename:
                    where = f"trong thư mục **{folder['name']}**" if folder else "ở ngoài thư mục"
                    raise NoteError(f"Đã có văn bản tên **{title}** {where}.")
                final = _free_title(conn, scope, folder_id, title, "trùng")
            now = _now()
            cursor = conn.execute(
                "INSERT INTO notes (scope, scope_id, folder_id, title, title_key, content, creator_id, created_at, "
                "updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (scope.kind, scope.id, folder_id, final, key_of(final), content, creator_id, now, now))
            _add_version(conn, cursor.lastrowid, final, content, creator_id, now)
            return _note(conn.execute(_NOTE_SELECT + "WHERE n.id = ?", (cursor.lastrowid,)).fetchone())

        return await self.db.transaction(work)

    # -- đọc -------------------------------------------------------------------
    async def find_folder(self, scope: Scope, name: str) -> Optional[Folder]:
        row = await self.db.fetchone("SELECT * FROM folders WHERE scope = ? AND scope_id = ? AND name_key = ?",
                                     (scope.kind, scope.id, key_of(clean_name(name, "Tên thư mục"))))
        return _folder(row) if row else None

    async def find_note(self, scope: Scope, title: str, folder_name: Optional[str] = None) -> Optional[Note]:
        title = clean_name(title, "Tên văn bản")
        folder_name = clean_name(folder_name, "Tên thư mục") if folder_name else None
        row = await self.db.transaction(lambda conn: _find_note(conn, scope, title, folder_name))
        return _note(row) if row else None

    async def get_note(self, note_id: int) -> Optional[Note]:
        row = await self.db.fetchone(_NOTE_SELECT + "WHERE n.id = ?", (note_id,))
        return _note(row) if row else None

    async def get_folder(self, folder_id: int) -> Optional[Folder]:
        row = await self.db.fetchone("SELECT * FROM folders WHERE id = ?", (folder_id,))
        return _folder(row) if row else None

    async def tree(self, scope: Scope) -> tuple[list[tuple[Folder, list[Note]]], list[Note]]:
        folders = await self.db.fetchall("SELECT * FROM folders WHERE scope = ? AND scope_id = ? ORDER BY name_key",
                                         (scope.kind, scope.id))
        notes = await self.db.fetchall(_NOTE_SELECT + "WHERE n.scope = ? AND n.scope_id = ? ORDER BY n.title_key",
                                       (scope.kind, scope.id))
        by_folder: dict[int, list[Note]] = {}
        loose: list[Note] = []
        for row in notes:
            note = _note(row)
            if note.folder_id is None:
                loose.append(note)
            else:
                by_folder.setdefault(note.folder_id, []).append(note)
        return [(_folder(f), by_folder.get(f["id"], [])) for f in folders], loose

    async def folder_notes(self, folder_id: int) -> list[Note]:
        rows = await self.db.fetchall(_NOTE_SELECT + "WHERE n.folder_id = ? ORDER BY n.title_key", (folder_id,))
        return [_note(r) for r in rows]

    async def count_notes_by_others(self, folder_id: int, user_id: int) -> int:
        row = await self.db.fetchone("SELECT COUNT(*) AS c FROM notes WHERE folder_id = ? AND creator_id != ?",
                                     (folder_id, user_id))
        return row["c"]

    async def search(self, scope: Scope, keyword: str) -> SearchResult:
        query = fold(unicodedata.normalize("NFC", keyword).strip())
        if not query:
            raise NoteError("Từ khóa không được để trống.")
        folders, loose = await self.tree(scope)
        found_folders = [f for f, _ in folders if query in fold(f.name)]
        every_note = loose + [n for _, notes in folders for n in notes]
        by_title = [n for n in every_note if query in fold(n.title)]
        title_ids = {n.id for n in by_title}
        by_content: list[tuple[Note, str]] = []
        for note in every_note:
            if note.id in title_ids:
                continue
            index = fold(note.content).find(query)
            if index >= 0:
                start = max(0, index - SNIPPET_RADIUS)
                end = min(len(note.content), index + len(query) + SNIPPET_RADIUS)
                snippet = " ".join(note.content[start:end].split())
                by_content.append((note, ("…" if start else "") + snippet + ("…" if end < len(note.content) else "")))
        return SearchResult(found_folders, by_title, by_content)

    async def suggest_folders(self, scope: Scope, current: str, limit: int = 25) -> list[str]:
        rows = await self.db.fetchall("SELECT name FROM folders WHERE scope = ? AND scope_id = ? ORDER BY name_key",
                                      (scope.kind, scope.id))
        query = fold(current.strip())
        return [r["name"] for r in rows if query in fold(r["name"])][:limit]

    async def suggest_notes(self, scope: Scope, current: str, folder_name: Optional[str] = None,
                            limit: int = 25) -> list[tuple[str, Optional[str]]]:
        """[(tên văn bản, tên thư mục hoặc None)] khớp với phần đang gõ."""
        params: list = [scope.kind, scope.id]
        sql = _NOTE_SELECT + "WHERE n.scope = ? AND n.scope_id = ? "
        if folder_name:
            sql += "AND f.name_key = ? "
            params.append(key_of(" ".join(folder_name.split())))
        rows = await self.db.fetchall(sql + "ORDER BY n.title_key", params)
        query = fold(current.strip())
        return [(r["title"], r["folder_name"]) for r in rows if query in fold(r["title"])][:limit]

    # -- sửa / xóa / chuyển ----------------------------------------------------
    async def rename_folder(self, folder_id: int, new_name: str) -> Folder:
        new_name = clean_name(new_name, "Tên thư mục")

        def work(conn: sqlite3.Connection) -> Folder:
            row = conn.execute("SELECT * FROM folders WHERE id = ?", (folder_id,)).fetchone()
            if row is None:
                raise NoteError("Thư mục này không còn tồn tại.")
            clash = conn.execute("SELECT id FROM folders WHERE scope = ? AND scope_id = ? AND name_key = ? AND id != ?",
                                 (row["scope"], row["scope_id"], key_of(new_name), folder_id)).fetchone()
            if clash:
                raise NoteError(f"Đã có thư mục tên **{new_name}**.")
            conn.execute("UPDATE folders SET name = ?, name_key = ?, updated_at = ? WHERE id = ?",
                         (new_name, key_of(new_name), _now(), folder_id))
            return _folder(conn.execute("SELECT * FROM folders WHERE id = ?", (folder_id,)).fetchone())

        return await self.db.transaction(work)

    async def update_note(self, note_id: int, *, expected_updated_at: str, title: str, content: Optional[str],
                          editor_id: int) -> Note:
        """Sửa tên + nội dung. Báo lỗi nếu văn bản đã bị người khác sửa kể từ lúc bạn mở khung chỉnh sửa."""
        title = clean_name(title, "Tên văn bản")
        content = clean_content(content)

        def work(conn: sqlite3.Connection) -> Note:
            row = conn.execute("SELECT * FROM notes WHERE id = ?", (note_id,)).fetchone()
            if row is None:
                raise NoteError("Văn bản này không còn tồn tại.")
            if row["updated_at"] != expected_updated_at:
                raise NoteError("Văn bản vừa được người khác sửa. Hãy mở lại `edit` để lấy bản mới nhất, "
                                "tránh ghi đè mất nội dung.")
            if row["title"] == title and row["content"] == content:  # không có gì thay đổi
                return _note(conn.execute(_NOTE_SELECT + "WHERE n.id = ?", (note_id,)).fetchone())
            if _title_taken(conn, Scope(row["scope"], row["scope_id"]), row["folder_id"], key_of(title), note_id):
                raise NoteError(f"Đã có văn bản tên **{title}** ở cùng chỗ này.")
            now = _now()
            has_history = conn.execute("SELECT 1 FROM note_versions WHERE note_id = ?", (note_id,)).fetchone()
            if not has_history:  # văn bản có từ trước khi có lịch sử: lưu bản cũ làm mốc
                _add_version(conn, note_id, row["title"], row["content"], row["creator_id"], row["updated_at"])
            conn.execute("UPDATE notes SET title = ?, title_key = ?, content = ?, updated_at = ? WHERE id = ?",
                         (title, key_of(title), content, now, note_id))
            _add_version(conn, note_id, title, content, editor_id, now)
            return _note(conn.execute(_NOTE_SELECT + "WHERE n.id = ?", (note_id,)).fetchone())

        return await self.db.transaction(work)

    async def delete_note(self, note_id: int, deleted_by: int) -> bool:
        """Chuyển văn bản vào thùng rác. False nếu văn bản không còn."""
        def work(conn: sqlite3.Connection) -> bool:
            row = conn.execute(_NOTE_SELECT + "WHERE n.id = ?", (note_id,)).fetchone()
            if row is None:
                return False
            payload = _note_payload(conn, row)
            payload["folder"] = row["folder_name"]
            _trash_put(conn, Scope(row["scope"], row["scope_id"]), "note", row["title"], row["folder_name"], 0,
                       row["creator_id"], deleted_by, payload)
            conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
            return True
        return await self.db.transaction(work)

    async def delete_folder(self, folder_id: int, deleted_by: int) -> int:
        """Chuyển thư mục cùng mọi văn bản bên trong vào thùng rác. Trả về số văn bản (-1 nếu thư mục không còn)."""
        def work(conn: sqlite3.Connection) -> int:
            folder = conn.execute("SELECT * FROM folders WHERE id = ?", (folder_id,)).fetchone()
            if folder is None:
                return -1
            rows = conn.execute(_NOTE_SELECT + "WHERE n.folder_id = ? ORDER BY n.title_key", (folder_id,)).fetchall()
            payload = {"name": folder["name"], "creator_id": folder["creator_id"], "created_at": folder["created_at"],
                       "updated_at": folder["updated_at"], "notes": [_note_payload(conn, r) for r in rows]}
            _trash_put(conn, Scope(folder["scope"], folder["scope_id"]), "folder", folder["name"], None, len(rows),
                       folder["creator_id"], deleted_by, payload)
            conn.execute("DELETE FROM notes WHERE folder_id = ?", (folder_id,))
            conn.execute("DELETE FROM folders WHERE id = ?", (folder_id,))
            return len(rows)
        return await self.db.transaction(work)

    # -- lịch sử chỉnh sửa -----------------------------------------------------
    async def versions(self, note_id: int) -> list[Version]:
        """Các bản của văn bản, MỚI NHẤT trước."""
        rows = await self.db.fetchall("SELECT * FROM note_versions WHERE note_id = ? ORDER BY id DESC", (note_id,))
        return [_version(r) for r in rows]

    # -- thùng rác ---------------------------------------------------------------
    async def trash_items(self, scope: Scope, *, purge: bool = True) -> list[TrashItem]:
        """Các mục trong thùng rác, mới xóa trước. `purge` = dọn luôn mục quá hạn."""
        if purge:
            await self.db.transaction(lambda conn: _trash_cleanup(conn, scope))
        rows = await self.db.fetchall("SELECT * FROM trash WHERE scope = ? AND scope_id = ? ORDER BY id DESC",
                                      (scope.kind, scope.id))
        return [_trash_item(r) for r in rows]

    async def get_trash(self, scope: Scope, trash_id: int) -> Optional[TrashItem]:
        row = await self.db.fetchone("SELECT * FROM trash WHERE id = ? AND scope = ? AND scope_id = ?",
                                     (trash_id, scope.kind, scope.id))
        return _trash_item(row) if row else None

    async def find_trash_by_name(self, scope: Scope, name: str) -> Optional[TrashItem]:
        """Mục xóa gần nhất có tên khớp (không phân biệt hoa/thường)."""
        wanted = key_of(" ".join(name.split()))
        for item in await self.trash_items(scope, purge=False):
            if key_of(item.name) == wanted:
                return item
        return None

    async def restore(self, scope: Scope, trash_id: int, restorer_id: int) -> Restored:
        def work(conn: sqlite3.Connection) -> Restored:
            row = conn.execute("SELECT * FROM trash WHERE id = ? AND scope = ? AND scope_id = ?",
                               (trash_id, scope.kind, scope.id)).fetchone()
            if row is None:
                raise NoteError("Mục này không còn trong thùng rác (có thể đã được khôi phục hoặc quá "
                                f"{TRASH_DAYS} ngày).")
            data = json.loads(row["payload"])
            max_folders, max_notes = LIMITS[scope.kind]
            folders, notes = _counts(conn, scope)

            if row["kind"] == "note":
                if notes >= max_notes:
                    raise NoteError(f"Đã đạt giới hạn **{max_notes}** văn bản, hãy xóa bớt trước khi khôi phục.")
                folder_id, created, lost = None, False, False
                wanted = data.get("folder")
                if wanted:
                    found = _find_folder(conn, scope, wanted)
                    if found:
                        folder_id = found["id"]
                    elif folders < max_folders:
                        now = _now()
                        folder_id = conn.execute(
                            "INSERT INTO folders (scope, scope_id, name, name_key, creator_id, created_at, updated_at) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?)",
                            (scope.kind, scope.id, wanted, key_of(wanted), restorer_id, now, now)).lastrowid
                        created = True
                    else:
                        lost = True
                title = _free_title(conn, scope, folder_id, data["title"], "khôi phục")
                _insert_note(conn, scope, folder_id, data, title)
                conn.execute("DELETE FROM trash WHERE id = ?", (trash_id,))
                placed = wanted if folder_id else None
                return Restored("note", title, data["title"], placed, 0, created, lost)

            # thư mục
            inside = data.get("notes", [])
            if folders >= max_folders:
                raise NoteError(f"Đã đạt giới hạn **{max_folders}** thư mục, hãy xóa bớt trước khi khôi phục.")
            if notes + len(inside) > max_notes:
                raise NoteError(f"Khôi phục sẽ vượt giới hạn **{max_notes}** văn bản, hãy xóa bớt trước.")
            name, number = data["name"], 1
            while _find_folder(conn, scope, name):
                number += 1
                suffix = " (khôi phục)" if number == 2 else f" (khôi phục {number - 1})"
                name = data["name"][:NAME_MAX - len(suffix)].rstrip() + suffix
            now = _now()
            folder_id = conn.execute(
                "INSERT INTO folders (scope, scope_id, name, name_key, creator_id, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (scope.kind, scope.id, name, key_of(name), data["creator_id"], data["created_at"], now)).lastrowid
            for note_data in inside:
                _insert_note(conn, scope, folder_id, note_data, note_data["title"])
            conn.execute("DELETE FROM trash WHERE id = ?", (trash_id,))
            return Restored("folder", name, data["name"], None, len(inside), False, False)

        return await self.db.transaction(work)

    async def move_note(self, note_id: int, dest_folder_name: Optional[str]) -> Note:
        """Chuyển văn bản vào thư mục `dest_folder_name`; None = đưa ra ngoài (không thư mục)."""
        dest = clean_name(dest_folder_name, "Tên thư mục") if dest_folder_name else None

        def work(conn: sqlite3.Connection) -> Note:
            row = conn.execute(_NOTE_SELECT + "WHERE n.id = ?", (note_id,)).fetchone()
            if row is None:
                raise NoteError("Văn bản này không còn tồn tại.")
            scope = Scope(row["scope"], row["scope_id"])
            target = _require_folder(conn, scope, dest) if dest else None
            target_id = target["id"] if target else None
            if target_id == row["folder_id"]:
                raise NoteError("Văn bản đã ở sẵn chỗ này rồi." if target else "Văn bản đang ở ngoài thư mục rồi.")
            clash = conn.execute("SELECT 1 FROM notes WHERE scope = ? AND scope_id = ? AND IFNULL(folder_id, 0) = ? "
                                 "AND title_key = ?", (scope.kind, scope.id, target_id or 0, row["title_key"])).fetchone()
            if clash:
                where = f"trong thư mục **{target['name']}**" if target else "ở ngoài thư mục"
                raise NoteError(f"Đã có văn bản tên **{row['title']}** {where}. Hãy đổi tên một trong hai trước.")
            conn.execute("UPDATE notes SET folder_id = ?, updated_at = ? WHERE id = ?", (target_id, _now(), note_id))
            return _note(conn.execute(_NOTE_SELECT + "WHERE n.id = ?", (note_id,)).fetchone())

        return await self.db.transaction(work)
