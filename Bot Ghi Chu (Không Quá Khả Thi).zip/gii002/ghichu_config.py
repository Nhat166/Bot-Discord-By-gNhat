"""Cấu hình của bot ghi chú, đọc từ file ghichu.env (xem ghichu.env.example).

Dùng file và tên biến RIÊNG (ghichu.env, GHICHU_*) để không lẫn với file .env / DISCORD_TOKEN của bot cũ.
"""
from __future__ import annotations

import os

from dotenv import load_dotenv

load_dotenv("ghichu.env")


def _get_str(name: str, default: str = "") -> str:
    return (os.getenv(name) or default).strip()


def _get_int(name: str, default: int = 0) -> int:
    raw = _get_str(name)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        raise SystemExit(f"Biến môi trường {name} phải là số nguyên (hiện là {raw!r}).") from None


TOKEN = _get_str("GHICHU_TOKEN")
# Nếu đặt GHICHU_GUILD_ID: lệnh / được đồng bộ NGAY vào máy chủ đó (tiện khi thử nghiệm).
# Để trống: đồng bộ lệnh toàn cầu (dùng được ở mọi máy chủ và trong tin nhắn riêng với bot).
GUILD_ID = _get_int("GHICHU_GUILD_ID")
DATABASE_PATH = _get_str("GHICHU_DATABASE_PATH", "data/ghichu.db")
