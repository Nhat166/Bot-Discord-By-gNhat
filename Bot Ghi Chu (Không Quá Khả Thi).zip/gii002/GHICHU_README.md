# Bot ghi chú (Discord) – bản đặt tên riêng, không trùng với bot cũ – thư mục → văn bản → nội dung

Bot lưu ghi chú có tổ chức, dùng **lệnh gạch chéo `/note`**:

```
thư mục
   └─ văn bản
         └─ nội dung
hoặc
văn bản (không thư mục)
   └─ nội dung
```

Dùng chung một bộ lệnh cho **ghi chú riêng** (chỉ bạn thấy) và **ghi chú chung của máy chủ** (thêm đuôi `sv`).
Gõ **`/help`** để xem hướng dẫn ngay trong Discord (có menu chọn chủ đề).

## Cài đặt

1. Vào <https://discord.com/developers/applications> → **New Application** → tab **Bot** → **Reset Token** và copy token.
   Đây là bot **mới**, hãy tạo ứng dụng và token riêng, đừng dùng lại token của bot khác.
   Bot này **không cần bật Privileged Intent nào**.
2. Mời bot: tab **OAuth2 → URL Generator**, chọn scope **`bot`** và **`applications.commands`**, mở link vừa tạo để thêm bot vào máy chủ.
3. Cài thư viện và cấu hình:
   ```
   pip install -r ghichu_requirements.txt
   copy ghichu.env.example ghichu.env      (Linux/macOS: cp ghichu.env.example ghichu.env)
   ```
   Mở `ghichu.env`, dán token vào `GHICHU_TOKEN=`. Khi thử nghiệm nên điền thêm `GHICHU_GUILD_ID=<ID máy chủ>` để lệnh `/` hiện **ngay**;
   để trống thì lệnh là lệnh toàn cầu (Discord có thể mất một lúc để hiện ra).
4. Chạy: `python ghichu_main.py`. Dữ liệu nằm trong `data/ghichu.db` (nhớ sao lưu file này), nhật ký trong `ghichu.log`.

## Không trùng với bot cũ
Có thể để chung thư mục với bot cũ (nhạc/quản trị/XP) vì mọi tên đều có tiền tố `ghichu`:

| Bot cũ | Bot ghi chú |
|---|---|
| `main.py`, `config.py`, `database.py` | `ghichu_main.py`, `ghichu_config.py`, `ghichu_database.py` |
| `.env` (`DISCORD_TOKEN`) | `ghichu.env` (`GHICHU_TOKEN`), **token riêng của bot mới** |
| `data/bot.db`, `bot.log` | `data/ghichu.db`, `ghichu.log` |
| `requirements.txt`, `README.md` | `ghichu_requirements.txt`, `GHICHU_README.md` |

Bot gồm các file: `ghichu_main.py`, `ghichu_config.py`, `ghichu_database.py`, `ghichu_store.py` (dữ liệu), `ghichu_notes.py` (lệnh `/note` và menu chuột phải), `ghichu_help.py` (lệnh `/help`).

Hai bot là hai ứng dụng Discord khác nhau, chạy bằng hai lệnh `python` riêng (mỗi bot một cửa sổ terminal).

## Lệnh

Tên ô nhập (tham số) viết không dấu: `danh_muc` (thư mục), `van_ban` (văn bản), `noi_dung`, `tu_khoa`, `thu_muc`.
Các ô tên thư mục/văn bản đều **gợi ý khi gõ**.

| Riêng | Chung máy chủ | Chức năng |
|---|---|---|
| `/note add` | `/note addsv` | Tạo thư mục / văn bản |
| `/note list` | `/note listsv` | Xem cây thư mục, xem trong một thư mục, đọc một văn bản |
| `/note edit` | `/note editsv` | Sửa văn bản (khung nhập nhiều dòng) hoặc đổi tên thư mục |
| `/note delete` | `/note deletesv` | Xóa văn bản hoặc thư mục (có hộp xác nhận) |
| `/note search` | `/note searchsv` | Tìm theo tên hoặc nội dung (không cần gõ dấu) |
| `/note move` | `/note movesv` | Chuyển văn bản sang thư mục khác / đưa ra ngoài thư mục |
| `/note trash` | `/note trashsv` | Xem thùng rác (giữ 30 ngày) |
| `/note restore` | `/note restoresv` | Khôi phục văn bản/thư mục đã xóa |
| `/note history` | `/note historysv` | Xem lịch sử sửa, quay về bản cũ |

Ngoài ra: **chuột phải vào một tin nhắn → Apps → Lưu vào ghi chú**, và lệnh **`/help`**.

### Cách điền `/note add`
Bot hiểu theo ô bạn điền:

| Điền | Kết quả |
|---|---|
| chỉ `danh_muc` | tạo **thư mục** |
| `danh_muc` + `van_ban` | tạo **văn bản trong thư mục** (thư mục phải có sẵn) |
| `danh_muc` + `van_ban` + `noi_dung` | tạo văn bản **kèm nội dung** trong thư mục |
| chỉ `van_ban` (+ `noi_dung`) | tạo **văn bản riêng lẻ**, không thuộc thư mục nào |

### Các lệnh còn lại
- `/note list`: không điền gì = cả cây; điền `danh_muc` = xem trong thư mục (kèm đoạn xem trước); điền `van_ban` = đọc nội dung. Danh sách dài được chia **trang**, bấm ◀ ▶ để lật.
- `/note edit`: điền `van_ban` = mở khung sửa tên + nội dung; chỉ điền `danh_muc` = mở khung đổi tên thư mục.
- `/note delete`: điền `van_ban` = xóa văn bản; chỉ điền `danh_muc` = xóa thư mục **và mọi văn bản bên trong**.
- `/note move van_ban:… thu_muc:…`: chuyển vào thư mục; **bỏ trống `thu_muc`** = đưa ra ngoài thư mục.
- `/note delete`: không xóa hẳn mà chuyển vào **thùng rác 30 ngày** (tối đa 100 mục mỗi khu).
- `/note trash`: liệt kê mục đã xóa kèm số `#`. `/note restore da_xoa:…` chọn từ gợi ý (hoặc nhập số `#`, hoặc tên). Khôi phục thư mục mang theo mọi văn bản bên trong; tên bị trùng thì thêm "(khôi phục)"; thư mục cũ của văn bản không còn thì bot tạo lại.
- `/note history van_ban:…`: danh sách các bản (giữ 20 bản gần nhất), chọn một bản để đọc rồi bấm **↩️ Khôi phục bản này**. Việc khôi phục cũng được ghi vào lịch sử nên hoàn tác được. Văn bản chưa sửa lần nào thì chưa có bản cũ.
- **Lưu từ tin nhắn**: chuột phải (điện thoại: nhấn giữ) vào tin nhắn → **Apps → Lưu vào ghi chú** → chọn Lưu riêng / Lưu chung → đặt tên, thư mục (chưa có thì tự tạo), sửa nội dung rồi gửi. Ghi chú kèm nội dung tin nhắn, link tệp đính kèm, người gửi, giờ gửi và liên kết tin gốc. Tên trùng thì tự thêm "(trùng)".
- Nếu có nhiều văn bản trùng tên ở các thư mục khác nhau, điền thêm `danh_muc` (với `move` là `tu_thu_muc`) để chọn đúng cái.

## Phân quyền ghi chú chung (`...sv`)

| Thao tác | Người tạo | Thành viên khác | Quản trị viên |
|---|---|---|---|
| Xem, tìm | ✅ | ✅ | ✅ |
| Thêm thư mục / văn bản (kể cả vào thư mục của người khác) | ✅ | ✅ | ✅ |
| Sửa, xóa, chuyển, quay về bản cũ **của mình** | ✅ | – | ✅ |
| Sửa, xóa, chuyển, quay về bản cũ **của người khác** | – | ❌ | ✅ |
| Khôi phục từ thùng rác chung | ✅ (nếu là người tạo/xóa) | ❌ | ✅ |
| Xóa thư mục có văn bản của người khác | ❌ | ❌ | ✅ |

"Quản trị viên" = người có quyền **Administrator** hoặc **Manage Server**.
Ghi chú riêng: chỉ chủ sở hữu thấy và thao tác; phản hồi là tin nhắn ẩn (chỉ mình bạn thấy).
Ghi chú riêng đi theo tài khoản của bạn, dùng được ở mọi máy chủ có bot và cả trong tin nhắn riêng với bot.
Lệnh `...sv` chỉ dùng được trong máy chủ.

## Giới hạn
- Tên thư mục/văn bản tối đa 50 ký tự, không trùng nhau trong cùng một thư mục (không phân biệt hoa/thường). Nội dung tối đa 4000 ký tự.
- Riêng mỗi người: 50 thư mục, 300 văn bản. Mỗi máy chủ: 100 thư mục, 1000 văn bản. Đổi trong `store.py` (`LIMITS`).
- Khi hai người cùng sửa một văn bản, người lưu sau sẽ nhận cảnh báo thay vì ghi đè mất nội dung.
