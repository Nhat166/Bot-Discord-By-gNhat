"""Lệnh /note: ghi chú có tổ chức, riêng cho từng người hoặc chung cho cả máy chủ.

Cấu trúc:   thư mục -> văn bản -> nội dung      hoặc      văn bản -> nội dung (không thư mục)

Ghi chú RIÊNG (chỉ bạn thấy)            Ghi chú CHUNG của máy chủ (thêm "sv")
    /note add                               /note addsv
    /note list                              /note listsv
    /note edit                              /note editsv
    /note delete                            /note deletesv
    /note search                            /note searchsv
    /note move                              /note movesv
    /note trash   (thùng rác, 30 ngày)      /note trashsv
    /note restore (khôi phục từ thùng rác)  /note restoresv
    /note history (lịch sử sửa + hoàn tác)  /note historysv
    Chuột phải vào tin nhắn -> Apps -> "Lưu vào ghi chú"

Cách điền /note add (điền ô nào thì bot hiểu theo ô đó):
    chỉ danh_muc                    -> tạo thư mục
    danh_muc + van_ban              -> tạo văn bản trong thư mục (thư mục phải có sẵn)
    danh_muc + van_ban + noi_dung   -> tạo văn bản kèm nội dung trong thư mục
    chỉ van_ban (+ noi_dung)        -> tạo văn bản riêng lẻ, không thuộc thư mục nào

Quyền với ghi chú CHUNG:
    - Ai cũng xem, tìm và thêm được.
    - Sửa / xóa / chuyển văn bản hoặc thư mục: chỉ NGƯỜI TẠO ra nó hoặc quản trị viên
      (quyền Administrator hoặc Manage Server).
    - Xóa thư mục chứa văn bản của người khác: chỉ quản trị viên.
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

import ghichu_store as notestore
from ghichu_database import db
from ghichu_store import (CONTENT_MAX, HISTORY_MAX, NAME_MAX, PRIVATE, SERVER, TRASH_DAYS, Folder, Note, NoteError,
                          NoteStore, Scope, TrashItem, Version, fold)

log = logging.getLogger("ghichu.notes")

NO_PING = discord.AllowedMentions.none()
COLOR = 0x5865F2
COLOR_OK = 0x2ECC71
COLOR_ERR = 0xE74C3C
COLOR_WARN = 0xF39C12
MAX_LIST_LINES = 3800  # độ dài mô tả embed tối đa (Discord cho 4096)
MAX_RESULTS = 10
PAGE_LINES = 18        # số dòng tối đa mỗi trang khi xem danh sách
PAGE_NOTES = 8         # số văn bản mỗi trang khi xem trong một thư mục
PAGE_TRASH = 8


# ---------------------------------------------------------------------------
# Hàm phụ hiển thị
# ---------------------------------------------------------------------------
def _embed(title: str, description: str = "", color: int = COLOR) -> discord.Embed:
    return discord.Embed(title=title[:256], description=description[:4000], color=color)


def _ok(description: str, title: str = "✅ Thành công") -> discord.Embed:
    return _embed(title, description, COLOR_OK)


def _err(description: str, title: str = "❌ Không thực hiện được") -> discord.Embed:
    return _embed(title, description, COLOR_ERR)


def _esc(text: str) -> str:
    return discord.utils.escape_markdown(text)


def _when(stamp: str) -> str:
    moment = datetime.strptime(stamp, "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc)
    return discord.utils.format_dt(moment, "R")


def _ago(stamp: str) -> str:
    moment = datetime.strptime(stamp, "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc)
    seconds = int((datetime.now(timezone.utc) - moment).total_seconds())
    if seconds < 60:
        return "vừa xong"
    if seconds < 3600:
        return f"{seconds // 60} phút trước"
    if seconds < 86400:
        return f"{seconds // 3600} giờ trước"
    return f"{seconds // 86400} ngày trước"


def _preview(content: str, length: int = 80) -> str:
    flat = " ".join(content.split())
    return (flat[:length] + "…") if len(flat) > length else flat


def tree_pages(folders: list[tuple[Folder, list[Note]]], loose: list[Note]) -> list[str]:
    """Chia cây thư mục/văn bản thành các trang văn bản. Trang tiếp theo luôn có dòng thư mục cha ở đầu."""
    items: list[tuple[str, Optional[str]]] = []  # (dòng, tên thư mục cha nếu là văn bản con)
    for folder, notes in folders:
        count = f" · {len(notes)} văn bản" if notes else " · trống"
        items.append((f"📁 **{_esc(folder.name)}**{count}", None))
        for index, note in enumerate(notes):
            branch = "┗" if index == len(notes) - 1 else "┣"
            items.append((f"　{branch} 📄 {_esc(note.title)}", folder.name))
    for note in loose:
        items.append((f"📄 **{_esc(note.title)}**", None))
    return _chunk(items)


def _chunk(items: list[tuple[str, Optional[str]]]) -> list[str]:
    pages: list[list[str]] = []
    current: list[str] = []
    size = 0
    for line, parent in items:
        if current and (len(current) >= PAGE_LINES or size + len(line) + 1 > MAX_LIST_LINES):
            pages.append(current)
            current, size = [], 0
        if not current and parent is not None:
            head = f"📁 **{_esc(parent)}** *(tiếp)*"
            current.append(head)
            size += len(head) + 1
        current.append(line)
        size += len(line) + 1
    if current:
        pages.append(current)
    return ["\n".join(page) for page in pages]


def paged_embeds(title: str, pages: list[str], footer: str = "", color: int = COLOR) -> list[discord.Embed]:
    total = len(pages)
    embeds = []
    for number, text in enumerate(pages, 1):
        embed = _embed(title, text, color)
        label = f"Trang {number}/{total}" if total > 1 else ""
        embed.set_footer(text=" · ".join(p for p in (label, footer) if p)[:2048] or None)
        embeds.append(embed)
    return embeds


def _is_admin(user: discord.abc.User) -> bool:
    perms = getattr(user, "guild_permissions", None)
    return bool(perms and (perms.administrator or perms.manage_guild))


def _can_modify(scope: Scope, creator_id: int, user: discord.abc.User) -> bool:
    """Ghi chú riêng: chủ sở hữu. Ghi chú chung: người tạo hoặc quản trị viên."""
    if not scope.is_server:
        return True
    return creator_id == user.id or _is_admin(user)


async def _send(interaction: discord.Interaction, *, embed: Optional[discord.Embed] = None,
                ephemeral: bool = False, view: Optional[discord.ui.View] = None) -> None:
    kwargs: dict = {"embed": embed, "ephemeral": ephemeral, "allowed_mentions": NO_PING}
    if view is not None:
        kwargs["view"] = view
    if interaction.response.is_done():
        await interaction.followup.send(**kwargs)
    else:
        await interaction.response.send_message(**kwargs)


class Pager(discord.ui.View):
    """Nút ◀ ▶ lật trang; chỉ người gõ lệnh bấm được."""

    def __init__(self, user_id: int, pages: list[discord.Embed], interaction: discord.Interaction) -> None:
        super().__init__(timeout=180)
        self.user_id, self.pages, self.interaction, self.index = user_id, pages, interaction, 0
        self.prev_button = discord.ui.Button(emoji="◀️", style=discord.ButtonStyle.secondary)
        self.counter = discord.ui.Button(label="", style=discord.ButtonStyle.secondary, disabled=True)
        self.next_button = discord.ui.Button(emoji="▶️", style=discord.ButtonStyle.secondary)
        self.prev_button.callback = self._prev
        self.next_button.callback = self._next
        for item in (self.prev_button, self.counter, self.next_button):
            self.add_item(item)
        self._refresh()

    def _refresh(self) -> None:
        self.counter.label = f"{self.index + 1}/{len(self.pages)}"
        self.prev_button.disabled = self.index == 0
        self.next_button.disabled = self.index >= len(self.pages) - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Chỉ người gõ lệnh mới lật trang được.", ephemeral=True)
            return False
        return True

    async def _go(self, interaction: discord.Interaction, step: int) -> None:
        self.index = max(0, min(len(self.pages) - 1, self.index + step))
        self._refresh()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    async def _prev(self, interaction: discord.Interaction) -> None:
        await self._go(interaction, -1)

    async def _next(self, interaction: discord.Interaction) -> None:
        await self._go(interaction, 1)

    async def on_timeout(self) -> None:
        try:
            await self.interaction.edit_original_response(view=None)
        except discord.HTTPException:
            pass


async def _send_pages(interaction: discord.Interaction, pages: list[discord.Embed], ephemeral: bool) -> None:
    """Một trang: gửi thẳng. Nhiều trang: kèm nút lật trang."""
    if len(pages) == 1:
        await _send(interaction, embed=pages[0], ephemeral=ephemeral)
    else:
        await _send(interaction, embed=pages[0], ephemeral=ephemeral, view=Pager(interaction.user.id, pages, interaction))


# ---------------------------------------------------------------------------
# Khung chỉnh sửa (Modal) và hộp xác nhận
# ---------------------------------------------------------------------------
class EditNoteModal(discord.ui.Modal):
    """Sửa tên + nội dung (nhiều dòng) của một văn bản."""

    def __init__(self, cog: "Notes", scope: Scope, note: Note) -> None:
        super().__init__(title="Sửa văn bản", timeout=900)
        self.cog, self.scope, self.note = cog, scope, note
        self.title_input = discord.ui.TextInput(label="Tên văn bản", default=note.title, max_length=NAME_MAX,
                                                required=True)
        self.content_input = discord.ui.TextInput(label="Nội dung", style=discord.TextStyle.paragraph,
                                                  default=note.content or None, max_length=CONTENT_MAX,
                                                  required=False, placeholder="Nhập nội dung văn bản...")
        self.add_item(self.title_input)
        self.add_item(self.content_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            if not _can_modify(self.scope, self.note.creator_id, interaction.user):
                raise NoteError("Bạn không còn quyền sửa văn bản này.")
            updated = await self.cog.store.update_note(
                self.note.id, expected_updated_at=self.note.updated_at,
                title=self.title_input.value, content=self.content_input.value, editor_id=interaction.user.id)
        except NoteError as exc:
            await _send(interaction, embed=_err(str(exc)), ephemeral=True)
            return
        embed = _ok(f"Đã lưu văn bản **{_esc(updated.title)}**"
                    + (f" trong thư mục **{_esc(updated.folder_name)}**." if updated.folder_name else "."),
                    "✏️ Đã sửa văn bản")
        await _send(interaction, embed=embed, ephemeral=not self.scope.is_server)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi khi lưu văn bản", exc_info=error)
        await _send(interaction, embed=_err("Có lỗi không mong muốn khi lưu. Bạn thử lại nhé."), ephemeral=True)


class RenameFolderModal(discord.ui.Modal):
    def __init__(self, cog: "Notes", scope: Scope, folder: Folder) -> None:
        super().__init__(title="Đổi tên thư mục", timeout=900)
        self.cog, self.scope, self.folder = cog, scope, folder
        self.name_input = discord.ui.TextInput(label="Tên thư mục", default=folder.name, max_length=NAME_MAX,
                                               required=True)
        self.add_item(self.name_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            if not _can_modify(self.scope, self.folder.creator_id, interaction.user):
                raise NoteError("Bạn không còn quyền sửa thư mục này.")
            updated = await self.cog.store.rename_folder(self.folder.id, self.name_input.value)
        except NoteError as exc:
            await _send(interaction, embed=_err(str(exc)), ephemeral=True)
            return
        await _send(interaction, embed=_ok(f"Thư mục **{_esc(self.folder.name)}** giờ tên là "
                                           f"**{_esc(updated.name)}**.", "✏️ Đã đổi tên thư mục"),
                    ephemeral=not self.scope.is_server)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi khi đổi tên thư mục", exc_info=error)
        await _send(interaction, embed=_err("Có lỗi không mong muốn. Bạn thử lại nhé."), ephemeral=True)


class ConfirmView(discord.ui.View):
    """Hộp xác nhận Xóa/Hủy; chỉ người gõ lệnh bấm được."""

    def __init__(self, user_id: int) -> None:
        super().__init__(timeout=60)
        self.user_id = user_id
        self.value: Optional[bool] = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Chỉ người gõ lệnh mới bấm được nút này.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Xóa", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.value = True
        self.stop()
        await interaction.response.defer()

    @discord.ui.button(label="Hủy", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.value = False
        self.stop()
        await interaction.response.defer()


class HistoryView(discord.ui.View):
    """Lịch sử chỉnh sửa của một văn bản: chọn bản cũ để xem và khôi phục."""

    def __init__(self, cog: "Notes", scope: Scope, note: Note, versions: list[Version], user_id: int,
                 interaction: discord.Interaction) -> None:
        super().__init__(timeout=300)
        self.cog, self.scope, self.note, self.versions = cog, scope, note, versions  # versions: mới nhất trước
        self.user_id, self.interaction = user_id, interaction
        self.selected: Optional[Version] = None
        self.can_edit = _can_modify(scope, note.creator_id, interaction.user)
        self._rebuild()

    def number(self, version: Version) -> int:
        return len(self.versions) - self.versions.index(version)

    def _rebuild(self) -> None:
        self.clear_items()
        options = [discord.SelectOption(
            label=f"v{self.number(v)} · {_ago(v.created_at)}"[:100], value=str(v.id),
            description=(_preview(v.content, 90) or "(trống)")[:100], default=v is self.selected)
            for v in self.versions[:25]]
        select = discord.ui.Select(placeholder="Chọn một bản để xem…", options=options, row=0)
        select.callback = self._on_select
        self.add_item(select)
        if self.selected is not None:
            restore = discord.ui.Button(label="Khôi phục bản này", emoji="↩️", style=discord.ButtonStyle.success, row=1,
                                        disabled=(not self.can_edit) or self.selected is self.versions[0])
            restore.callback = self._on_restore
            back = discord.ui.Button(label="Danh sách", emoji="📜", style=discord.ButtonStyle.secondary, row=1)
            back.callback = self._on_back
            self.add_item(restore)
            self.add_item(back)

    def list_embed(self, extra: str = "") -> discord.Embed:
        lines = []
        for v in self.versions[:25]:
            tag = " **(hiện tại)**" if v is self.versions[0] else ""
            lines.append(f"`v{self.number(v)}` · {_when(v.created_at)} · <@{v.editor_id}>{tag}\n"
                         f"　{_esc(_preview(v.content, 60)) or '*(trống)*'}")
        embed = _embed(f"📜 Lịch sử: {self.note.title}", (extra + "\n\n" if extra else "") + "\n".join(lines))
        embed.set_footer(text=f"Giữ {HISTORY_MAX} bản gần nhất · Chọn một bản bên dưới để xem")
        return embed

    def version_embed(self, version: Version) -> discord.Embed:
        embed = _embed(f"📜 v{self.number(version)} · {version.title}", version.content or "*(trống)*")
        embed.add_field(name="Người sửa", value=f"<@{version.editor_id}>", inline=True)
        embed.add_field(name="Lúc", value=_when(version.created_at), inline=True)
        if version is self.versions[0]:
            embed.add_field(name="Ghi chú", value="Đây là bản hiện tại.", inline=True)
        elif not self.can_edit:
            embed.add_field(name="Ghi chú", value="Bạn không có quyền khôi phục văn bản này.", inline=True)
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Chỉ người gõ lệnh mới dùng được bảng này.", ephemeral=True)
            return False
        return True

    async def _on_select(self, interaction: discord.Interaction) -> None:
        wanted = int(interaction.data["values"][0])
        self.selected = next((v for v in self.versions if v.id == wanted), None)
        self._rebuild()
        embed = self.version_embed(self.selected) if self.selected else self.list_embed()
        await interaction.response.edit_message(embed=embed, view=self)

    async def _on_back(self, interaction: discord.Interaction) -> None:
        self.selected = None
        self._rebuild()
        await interaction.response.edit_message(embed=self.list_embed(), view=self)

    async def _on_restore(self, interaction: discord.Interaction) -> None:
        version = self.selected
        try:
            if version is None:
                raise NoteError("Hãy chọn một bản trước.")
            if not _can_modify(self.scope, self.note.creator_id, interaction.user):
                raise NoteError("Bạn không còn quyền sửa văn bản này.")
            fresh = await self.cog.store.get_note(self.note.id)
            if fresh is None:
                raise NoteError("Văn bản này không còn tồn tại.")
            updated = await self.cog.store.update_note(fresh.id, expected_updated_at=fresh.updated_at,
                                                       title=version.title, content=version.content,
                                                       editor_id=interaction.user.id)
        except NoteError as exc:
            await interaction.response.send_message(embed=_err(str(exc)), ephemeral=True)
            return
        number = self.number(version)
        self.note = updated
        self.versions = await self.cog.store.versions(updated.id)
        self.selected = None
        self._rebuild()
        await interaction.response.edit_message(
            embed=self.list_embed(f"✅ Đã khôi phục nội dung bản **v{number}**. Bản trước đó vẫn nằm trong lịch sử."),
            view=self)
        if self.scope.is_server:
            await interaction.followup.send(embed=_embed("↩️ Ghi chú chung đã được khôi phục bản cũ",
                                                         f"{interaction.user.mention} khôi phục văn bản "
                                                         f"**{_esc(updated.title)}** về bản v{number}."),
                                            ephemeral=False, allowed_mentions=NO_PING)

    async def on_timeout(self) -> None:
        try:
            await self.interaction.edit_original_response(view=None)
        except discord.HTTPException:
            pass


URL_RE = re.compile(r"https?://\S+")


def message_text(message: discord.Message) -> str:
    """Nội dung ghi chú tạo từ một tin nhắn: chữ + link tệp đính kèm + dòng nguồn (tác giả, giờ, liên kết)."""
    parts: list[str] = []
    text = (message.content or "").strip()
    if text:
        parts.append(text)
    else:  # tin nhắn của bot thường chỉ có embed
        for embed in message.embeds:
            bits = [b for b in (embed.title, embed.description) if b]
            if bits:
                parts.append("\n".join(bits))
    for attachment in message.attachments:
        parts.append(attachment.url)
    body = "\n\n".join(parts)
    footer = (f"— {message.author.display_name} · <t:{int(message.created_at.timestamp())}:f>\n{message.jump_url}")
    room = CONTENT_MAX - len(footer) - 2
    if len(body) > room:
        body = body[:max(room - 1, 0)].rstrip() + "…"
    return f"{body}\n\n{footer}" if body else footer


def default_title(message: discord.Message) -> str:
    first = next((ln for ln in URL_RE.sub("", message.content or "").splitlines() if ln.strip()), "")
    flat = " ".join(first.split())[:40].strip()
    try:
        return notestore.clean_name(flat or f"Tin nhắn của {message.author.display_name}")
    except NoteError:
        return "Tin nhắn đã lưu"


class SaveMessageModal(discord.ui.Modal):
    """Hỏi tên, thư mục và cho sửa nội dung trước khi lưu một tin nhắn thành ghi chú."""

    def __init__(self, cog: "Notes", server: bool, content: str, title: str) -> None:
        super().__init__(title="Lưu vào ghi chú chung" if server else "Lưu vào ghi chú riêng", timeout=900)
        self.cog, self.server = cog, server
        self.title_input = discord.ui.TextInput(label="Tên văn bản", default=title, max_length=NAME_MAX, required=True)
        self.folder_input = discord.ui.TextInput(label="Thư mục (để trống = không thư mục)", max_length=NAME_MAX,
                                                 required=False, placeholder="Chưa có thì bot tự tạo")
        self.content_input = discord.ui.TextInput(label="Nội dung", style=discord.TextStyle.paragraph,
                                                  default=content[:CONTENT_MAX], max_length=CONTENT_MAX, required=False)
        for item in (self.title_input, self.folder_input, self.content_input):
            self.add_item(item)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            scope = self.cog._scope(interaction, self.server)
            wanted = notestore.clean_name(self.title_input.value, "Tên văn bản")
            folder_name = self.folder_input.value.strip() or None
            folder_created = False
            if folder_name:
                folder, folder_created = await self.cog.store.ensure_folder(scope, folder_name, interaction.user.id)
                folder_name = folder.name
            note = await self.cog.store.create_note(scope, wanted, self.content_input.value, interaction.user.id,
                                                    folder_name, auto_rename=True)
        except NoteError as exc:
            await _send(interaction, embed=_err(str(exc)), ephemeral=True)
            return
        lines = [f"Đã lưu văn bản **{_esc(note.title)}** vào ghi chú {'chung của máy chủ' if self.server else 'riêng của bạn'}."]
        if note.folder_name:
            lines.append(f"Thư mục: 📁 **{_esc(note.folder_name)}**" + (" (vừa tạo mới)" if folder_created else ""))
        if note.title != wanted:
            lines.append(f"Tên **{_esc(wanted)}** đã có sẵn nên bot đặt là **{_esc(note.title)}**.")
        lines.append(f"Đọc lại: `{self.cog._cmd('list', self.server)}` điền van_ban.")
        await _send(interaction, embed=_ok("\n".join(lines), "📌 Đã lưu từ tin nhắn"), ephemeral=not self.server)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi khi lưu tin nhắn thành ghi chú", exc_info=error)
        await _send(interaction, embed=_err("Có lỗi không mong muốn khi lưu. Bạn thử lại nhé."), ephemeral=True)


class SaveChoiceView(discord.ui.View):
    """Hai nút chọn nơi lưu: riêng hoặc chung máy chủ."""

    def __init__(self, cog: "Notes", user_id: int, content: str, title: str, in_guild: bool) -> None:
        super().__init__(timeout=300)
        self.cog, self.user_id, self.content, self.title = cog, user_id, content, title
        self.shared_button.disabled = not in_guild

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Chỉ người bấm menu mới dùng được nút này.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Lưu riêng", emoji="🔒", style=discord.ButtonStyle.primary)
    async def private_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_modal(SaveMessageModal(self.cog, False, self.content, self.title))

    @discord.ui.button(label="Lưu chung máy chủ", emoji="🌐", style=discord.ButtonStyle.secondary)
    async def shared_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_modal(SaveMessageModal(self.cog, True, self.content, self.title))


# ---------------------------------------------------------------------------
# Cog
# ---------------------------------------------------------------------------
class Notes(commands.GroupCog, group_name="note", group_description="Ghi chú có tổ chức: riêng hoặc chung cả máy chủ"):
    def __init__(self, bot: commands.Bot) -> None:
        super().__init__()
        self.bot = bot
        self.store = NoteStore(db)
        self.save_menu = app_commands.ContextMenu(name="Lưu vào ghi chú", callback=self._save_from_message)

    async def cog_load(self) -> None:
        self.bot.tree.add_command(self.save_menu)

    async def cog_unload(self) -> None:
        self.bot.tree.remove_command(self.save_menu.name, type=self.save_menu.type)

    async def _save_from_message(self, interaction: discord.Interaction, message: discord.Message) -> None:
        """Chuột phải vào tin nhắn -> Apps -> Lưu vào ghi chú."""
        try:
            content = message_text(message)
            view = SaveChoiceView(self, interaction.user.id, content, default_title(message),
                                  in_guild=interaction.guild is not None)
            embed = _embed("📌 Lưu tin nhắn vào ghi chú", _preview(content, 300) or "*(không có chữ)*")
            embed.add_field(name="Chọn nơi lưu", inline=False, value=(
                "🔒 **Lưu riêng**: chỉ bạn thấy, dùng được ở mọi máy chủ.\n"
                "🌐 **Lưu chung máy chủ**: ai trong máy chủ cũng đọc được."))
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True,
                                                    allowed_mentions=NO_PING)
        except Exception:  # noqa: BLE001
            log.exception("Lỗi menu 'Lưu vào ghi chú'")
            await _send(interaction, embed=_err("Có lỗi không mong muốn xảy ra. Bạn thử lại sau nhé."), ephemeral=True)

    # -- tiện ích dùng chung ---------------------------------------------------
    @staticmethod
    def _scope(interaction: discord.Interaction, server: bool) -> Scope:
        if not server:
            return Scope(PRIVATE, interaction.user.id)
        if interaction.guild is None:
            raise NoteError("Lệnh có đuôi `sv` (ghi chú chung của máy chủ) chỉ dùng được trong máy chủ. "
                            "Ở đây bạn dùng các lệnh không có `sv` cho ghi chú riêng.")
        return Scope(SERVER, interaction.guild.id)

    @staticmethod
    def _cmd(name: str, server: bool) -> str:
        return f"/note {name}{'sv' if server else ''}"

    async def _guarded(self, interaction: discord.Interaction, work) -> None:
        try:
            await work
        except NoteError as exc:
            await _send(interaction, embed=_err(str(exc)), ephemeral=True)

    async def _need_note(self, scope: Scope, title: str, folder: Optional[str], server: bool) -> Note:
        note = await self.store.find_note(scope, title, folder)
        if note is None:
            where = f" trong thư mục **{_esc(folder)}**" if folder else ""
            raise NoteError(f"Không tìm thấy văn bản **{_esc(title)}**{where}. "
                            f"Dùng `{self._cmd('list', server)}` để xem danh sách.")
        return note

    async def _need_folder(self, scope: Scope, name: str, server: bool) -> Folder:
        folder = await self.store.find_folder(scope, name)
        if folder is None:
            raise NoteError(f"Không tìm thấy thư mục **{_esc(name)}**. "
                            f"Dùng `{self._cmd('list', server)}` để xem danh sách.")
        return folder

    @staticmethod
    def _deny(server: bool, what: str) -> NoteError:
        return NoteError(f"Chỉ **người tạo ra {what}** hoặc **quản trị viên** mới được làm việc này với ghi chú chung.")

    # -- add -------------------------------------------------------------------
    async def _add(self, interaction: discord.Interaction, server: bool, danh_muc: Optional[str],
                   van_ban: Optional[str], noi_dung: Optional[str]) -> None:
        scope = self._scope(interaction, server)
        if not danh_muc and not van_ban:
            raise NoteError("Hãy điền `danh_muc` để tạo thư mục, hoặc `van_ban` để tạo văn bản "
                            "(điền cả hai để tạo văn bản trong thư mục).")
        if noi_dung and not van_ban:
            raise NoteError("`noi_dung` phải đi kèm `van_ban`.")
        ephemeral = not server
        if van_ban:
            note = await self.store.create_note(scope, van_ban, noi_dung, interaction.user.id, danh_muc or None)
            place = f"trong thư mục **{_esc(note.folder_name)}**" if note.folder_name else "(không thuộc thư mục nào)"
            embed = _ok(f"Đã tạo văn bản **{_esc(note.title)}** {place}.\n"
                        + (f"Nội dung: {_esc(_preview(note.content))}\n" if note.content else
                           f"Văn bản đang trống, dùng `{self._cmd('edit', server)}` để viết nội dung.\n")
                        + f"Người tạo: {interaction.user.mention}", "📄 Đã tạo văn bản")
        else:
            folder = await self.store.create_folder(scope, danh_muc, interaction.user.id)
            embed = _ok(f"Đã tạo thư mục **{_esc(folder.name)}**.\n"
                        f"Thêm văn bản vào: `{self._cmd('add', server)}` điền `danh_muc` = {_esc(folder.name)} "
                        "và `van_ban`.\nNgười tạo: " + interaction.user.mention, "📁 Đã tạo thư mục")
        await _send(interaction, embed=embed, ephemeral=ephemeral)

    # -- list ------------------------------------------------------------------
    async def _list(self, interaction: discord.Interaction, server: bool, danh_muc: Optional[str],
                    van_ban: Optional[str]) -> None:
        scope = self._scope(interaction, server)
        ephemeral = not server
        label = "của máy chủ" if server else "riêng của bạn"

        if van_ban:  # đọc một văn bản
            note = await self._need_note(scope, van_ban, danh_muc, server)
            embed = _embed(f"📄 {note.title}", note.content or "*(văn bản đang trống)*")
            embed.add_field(name="Thư mục", value=f"📁 {_esc(note.folder_name)}" if note.folder_name else "Không có",
                            inline=True)
            if server:
                embed.add_field(name="Người tạo", value=f"<@{note.creator_id}>", inline=True)
            embed.add_field(name="Cập nhật", value=_when(note.updated_at), inline=True)
            await _send(interaction, embed=embed, ephemeral=ephemeral)
            return

        if danh_muc:  # xem trong một thư mục
            folder = await self._need_folder(scope, danh_muc, server)
            notes = await self.store.folder_notes(folder.id)
            if not notes:
                pages = ["*Thư mục đang trống.*"]
            else:
                blocks = [f"📄 **{_esc(n.title)}**" + (f"\n　{_esc(_preview(n.content))}" if n.content else "")
                          for n in notes]
                pages = ["\n".join(blocks[k:k + PAGE_NOTES]) for k in range(0, len(blocks), PAGE_NOTES)]
            footer = f"{len(notes)} văn bản · Đọc nội dung: {self._cmd('list', server)} điền van_ban"
            await _send_pages(interaction, paged_embeds(f"📁 {folder.name}", pages, footer), ephemeral)
            return

        folders, loose = await self.store.tree(scope)
        if not folders and not loose:
            await _send(interaction, embed=_embed(
                f"🗂️ Ghi chú {label}", f"Chưa có gì cả. Bắt đầu bằng `{self._cmd('add', server)}`."), ephemeral=ephemeral)
            return
        total = len(loose) + sum(len(n) for _, n in folders)
        footer = f"{len(folders)} thư mục · {total} văn bản"
        await _send_pages(interaction, paged_embeds(f"🗂️ Ghi chú {label}", tree_pages(folders, loose), footer),
                          ephemeral)

    # -- edit ------------------------------------------------------------------
    async def _edit(self, interaction: discord.Interaction, server: bool, danh_muc: Optional[str],
                    van_ban: Optional[str]) -> None:
        scope = self._scope(interaction, server)
        if van_ban:
            note = await self._need_note(scope, van_ban, danh_muc, server)
            if not _can_modify(scope, note.creator_id, interaction.user):
                raise self._deny(server, "văn bản này")
            await interaction.response.send_modal(EditNoteModal(self, scope, note))
        elif danh_muc:
            folder = await self._need_folder(scope, danh_muc, server)
            if not _can_modify(scope, folder.creator_id, interaction.user):
                raise self._deny(server, "thư mục này")
            await interaction.response.send_modal(RenameFolderModal(self, scope, folder))
        else:
            raise NoteError("Hãy điền `van_ban` để sửa nội dung văn bản, hoặc chỉ `danh_muc` để đổi tên thư mục.")

    # -- delete ----------------------------------------------------------------
    async def _delete(self, interaction: discord.Interaction, server: bool, danh_muc: Optional[str],
                      van_ban: Optional[str]) -> None:
        scope = self._scope(interaction, server)
        folder: Optional[Folder] = None
        note: Optional[Note] = None
        if van_ban:
            note = await self._need_note(scope, van_ban, danh_muc, server)
            if not _can_modify(scope, note.creator_id, interaction.user):
                raise self._deny(server, "văn bản này")
            question = f"Xóa văn bản **{_esc(note.title)}**?"
        elif danh_muc:
            folder = await self._need_folder(scope, danh_muc, server)
            if not _can_modify(scope, folder.creator_id, interaction.user):
                raise self._deny(server, "thư mục này")
            inside = await self.store.folder_notes(folder.id)
            others = await self.store.count_notes_by_others(folder.id, interaction.user.id)
            if server and others and not _is_admin(interaction.user):
                raise NoteError(f"Thư mục **{_esc(folder.name)}** có **{others}** văn bản của người khác nên chỉ "
                                "quản trị viên mới xóa được. Bạn có thể chuyển văn bản của mình ra ngoài bằng "
                                f"`{self._cmd('move', server)}`.")
            question = (f"Xóa thư mục **{_esc(folder.name)}** cùng **{len(inside)}** văn bản bên trong?"
                        if inside else f"Xóa thư mục trống **{_esc(folder.name)}**?")
        else:
            raise NoteError("Hãy điền `van_ban` để xóa văn bản, hoặc chỉ `danh_muc` để xóa cả thư mục.")

        view = ConfirmView(interaction.user.id)
        await _send(interaction, embed=_embed("🗑️ Xác nhận xóa", f"{question}\nBản xóa được giữ trong thùng rác "
                                                              f"**{TRASH_DAYS} ngày**, khôi phục bằng "
                                                              f"`{self._cmd('restore', server)}`.", COLOR_WARN),
                    ephemeral=True, view=view)
        await view.wait()
        if view.value is None:
            await interaction.edit_original_response(embed=_embed("⌛ Hết thời gian", "Đã hủy xóa.", COLOR_WARN), view=None)
            return
        if view.value is False:
            await interaction.edit_original_response(embed=_embed("Đã hủy", "Không có gì bị xóa."), view=None)
            return
        if note is not None:
            deleted = await self.store.delete_note(note.id, interaction.user.id)
            text = (f"Đã chuyển văn bản **{_esc(note.title)}** vào thùng rác." if deleted
                    else "Văn bản này đã bị xóa từ trước.")
        else:
            count = await self.store.delete_folder(folder.id, interaction.user.id)
            text = (f"Đã chuyển thư mục **{_esc(folder.name)}** và {count} văn bản bên trong vào thùng rác."
                    if count >= 0 else "Thư mục này đã bị xóa từ trước.")
        await interaction.edit_original_response(embed=_ok(text, "🗑️ Đã xóa"), view=None)
        if server:  # ghi chú chung: thông báo công khai để mọi người biết ai đã xóa
            await interaction.followup.send(embed=_embed("🗑️ Ghi chú chung đã bị xóa",
                                                         f"{interaction.user.mention}: {text}"),
                                            ephemeral=False, allowed_mentions=NO_PING)

    # -- search ----------------------------------------------------------------
    async def _search(self, interaction: discord.Interaction, server: bool, tu_khoa: str) -> None:
        scope = self._scope(interaction, server)
        result = await self.store.search(scope, tu_khoa)
        label = "ghi chú chung" if server else "ghi chú riêng"
        if result.total == 0:
            await _send(interaction, embed=_embed(f"🔎 Tìm trong {label}", f"Không có kết quả cho **{_esc(tu_khoa)}**."),
                        ephemeral=not server)
            return
        embed = _embed(f"🔎 Tìm trong {label}", f"Từ khóa: **{_esc(tu_khoa)}** · {result.total} kết quả")

        def clip(lines: list[str]) -> str:
            shown = lines[:MAX_RESULTS]
            more = f"\n…và {len(lines) - len(shown)} kết quả nữa" if len(lines) > len(shown) else ""
            return ("\n".join(shown) + more)[:1024]

        if result.folders:
            embed.add_field(name="📁 Thư mục", value=clip([f"📁 **{_esc(f.name)}**" for f in result.folders]), inline=False)
        if result.by_title:
            embed.add_field(name="📄 Văn bản (theo tên)", value=clip(
                [f"📄 **{_esc(n.title)}**" + (f" · 📁 {_esc(n.folder_name)}" if n.folder_name else "")
                 for n in result.by_title]), inline=False)
        if result.by_content:
            embed.add_field(name="📝 Khớp trong nội dung", value=clip(
                [f"📄 **{_esc(n.title)}**" + (f" · 📁 {_esc(n.folder_name)}" if n.folder_name else "")
                 + f"\n　*{_esc(snippet)}*" for n, snippet in result.by_content]), inline=False)
        await _send(interaction, embed=embed, ephemeral=not server)

    # -- move ------------------------------------------------------------------
    async def _move(self, interaction: discord.Interaction, server: bool, van_ban: str,
                    thu_muc: Optional[str], tu_thu_muc: Optional[str]) -> None:
        scope = self._scope(interaction, server)
        note = await self._need_note(scope, van_ban, tu_thu_muc, server)
        if not _can_modify(scope, note.creator_id, interaction.user):
            raise self._deny(server, "văn bản này")
        moved = await self.store.move_note(note.id, thu_muc or None)
        where = f"vào thư mục **{_esc(moved.folder_name)}**" if moved.folder_name else "ra ngoài thư mục"
        await _send(interaction, embed=_ok(f"Đã chuyển văn bản **{_esc(moved.title)}** {where}.", "📦 Đã chuyển văn bản"),
                    ephemeral=not server)

    # -- trash -----------------------------------------------------------------
    async def _trash(self, interaction: discord.Interaction, server: bool) -> None:
        scope = self._scope(interaction, server)
        items = await self.store.trash_items(scope)
        label = "chung của máy chủ" if server else "riêng của bạn"
        if not items:
            await _send(interaction, embed=_embed(f"🗑️ Thùng rác ghi chú {label}", "Thùng rác đang trống."), ephemeral=True)
            return
        lines = []
        for item in items:
            if item.kind == "folder":
                detail = f"{item.item_count} văn bản"
            else:
                detail = f"từ 📁 {_esc(item.folder_name)}" if item.folder_name else ""
            who = f" · bởi <@{item.deleted_by}>" if server else ""
            lines.append(f"`#{item.id}` {'📁' if item.kind == 'folder' else '📄'} **{_esc(item.name)}**"
                         + (f" · {detail}" if detail else "") + f" · {_ago(item.deleted_at)}{who}")
        pages = ["\n".join(lines[k:k + PAGE_TRASH]) for k in range(0, len(lines), PAGE_TRASH)]
        footer = f"{len(items)} mục · giữ {TRASH_DAYS} ngày · Khôi phục: {self._cmd('restore', server)}"
        await _send_pages(interaction, paged_embeds(f"🗑️ Thùng rác ghi chú {label}", pages, footer, COLOR_WARN), True)

    async def _restore(self, interaction: discord.Interaction, server: bool, da_xoa: str) -> None:
        scope = self._scope(interaction, server)
        raw = (da_xoa or "").strip().lstrip("#").strip()
        if not raw:
            raise NoteError(f"Hãy chọn mục cần khôi phục. Xem danh sách bằng `{self._cmd('trash', server)}`.")
        item = await self.store.get_trash(scope, int(raw)) if raw.isdigit() else None
        if item is None:
            item = await self.store.find_trash_by_name(scope, raw)
        if item is None:
            raise NoteError(f"Không thấy **{_esc(raw)}** trong thùng rác. Xem danh sách bằng `{self._cmd('trash', server)}`.")
        user_id = interaction.user.id
        if server and user_id not in (item.deleted_by, item.creator_id) and not _is_admin(interaction.user):
            raise NoteError("Chỉ **người xóa**, **người tạo** hoặc **quản trị viên** mới khôi phục được mục này.")
        result = await self.store.restore(scope, item.id, user_id)
        if result.kind == "folder":
            lines = [f"Đã khôi phục thư mục 📁 **{_esc(result.name)}** cùng {result.count} văn bản bên trong."]
        else:
            where = f" vào thư mục 📁 **{_esc(result.folder_name)}**" if result.folder_name else ""
            lines = [f"Đã khôi phục văn bản 📄 **{_esc(result.name)}**{where}."]
            if result.folder_created:
                lines.append("Thư mục cũ không còn nên bot đã tạo lại thư mục này.")
            if result.folder_lost:
                lines.append("Không tạo lại được thư mục cũ (đã đạt giới hạn) nên văn bản nằm ngoài thư mục.")
        if result.renamed:
            lines.append(f"Tên **{_esc(result.original_name)}** đã bị dùng nên đổi thành **{_esc(result.name)}**.")
        await _send(interaction, embed=_ok("\n".join(lines), "♻️ Đã khôi phục"), ephemeral=not server)

    # -- history -----------------------------------------------------------------
    async def _history(self, interaction: discord.Interaction, server: bool, van_ban: str,
                       danh_muc: Optional[str]) -> None:
        scope = self._scope(interaction, server)
        note = await self._need_note(scope, van_ban, danh_muc, server)
        versions = await self.store.versions(note.id)
        if len(versions) <= 1:
            await _send(interaction, embed=_embed(
                f"📜 Lịch sử: {note.title}",
                f"Văn bản chưa được sửa lần nào nên chưa có bản cũ.\nSửa bằng `{self._cmd('edit', server)}`."),
                ephemeral=True)
            return
        view = HistoryView(self, scope, note, versions, interaction.user.id, interaction)
        await _send(interaction, embed=view.list_embed(), ephemeral=True, view=view)

    # =======================================================================
    # Lệnh slash: ghi chú RIÊNG
    # =======================================================================
    @app_commands.command(name="add", description="Tạo thư mục hoặc văn bản riêng của bạn")
    @app_commands.describe(danh_muc="Tên thư mục (một mình = tạo thư mục; kèm van_ban = văn bản nằm trong thư mục)",
                           van_ban="Tên văn bản (không điền danh_muc = văn bản đứng riêng)",
                           noi_dung="Nội dung văn bản (tối đa 4000 ký tự; nhiều dòng thì dùng /note edit)")
    async def note_add(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                       van_ban: Optional[str] = None, noi_dung: Optional[app_commands.Range[str, 1, 4000]] = None) -> None:
        await self._guarded(interaction, self._add(interaction, False, danh_muc, van_ban, noi_dung))

    @app_commands.command(name="list", description="Xem thư mục và văn bản riêng của bạn")
    @app_commands.describe(danh_muc="Chỉ xem bên trong thư mục này", van_ban="Đọc nội dung của văn bản này")
    async def note_list(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                        van_ban: Optional[str] = None) -> None:
        await self._guarded(interaction, self._list(interaction, False, danh_muc, van_ban))

    @app_commands.command(name="edit", description="Sửa nội dung văn bản hoặc đổi tên thư mục riêng")
    @app_commands.describe(danh_muc="Thư mục cần đổi tên (hoặc thư mục chứa văn bản)", van_ban="Văn bản cần sửa")
    async def note_edit(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                        van_ban: Optional[str] = None) -> None:
        await self._guarded(interaction, self._edit(interaction, False, danh_muc, van_ban))

    @app_commands.command(name="delete", description="Xóa văn bản hoặc thư mục riêng")
    @app_commands.describe(danh_muc="Thư mục cần xóa (xóa luôn văn bản bên trong) hoặc thư mục chứa văn bản",
                           van_ban="Văn bản cần xóa")
    async def note_delete(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                          van_ban: Optional[str] = None) -> None:
        await self._guarded(interaction, self._delete(interaction, False, danh_muc, van_ban))

    @app_commands.command(name="search", description="Tìm thư mục hoặc văn bản riêng theo tên hoặc nội dung")
    @app_commands.describe(tu_khoa="Từ cần tìm (không cần gõ dấu)")
    async def note_search(self, interaction: discord.Interaction, tu_khoa: str) -> None:
        await self._guarded(interaction, self._search(interaction, False, tu_khoa))

    @app_commands.command(name="move", description="Chuyển văn bản riêng sang thư mục khác (bỏ trống thư mục = đưa ra ngoài)")
    @app_commands.describe(van_ban="Văn bản cần chuyển", thu_muc="Thư mục đích (bỏ trống = đưa ra ngoài thư mục)",
                           tu_thu_muc="Thư mục hiện tại của văn bản (chỉ cần khi có nhiều văn bản trùng tên)")
    async def note_move(self, interaction: discord.Interaction, van_ban: str, thu_muc: Optional[str] = None,
                        tu_thu_muc: Optional[str] = None) -> None:
        await self._guarded(interaction, self._move(interaction, False, van_ban, thu_muc, tu_thu_muc))

    # =======================================================================
    # Lệnh slash: ghi chú CHUNG của máy chủ (đuôi "sv")
    # =======================================================================
    @app_commands.command(name="addsv", description="Tạo thư mục hoặc văn bản chung của máy chủ")
    @app_commands.describe(danh_muc="Tên thư mục (một mình = tạo thư mục; kèm van_ban = văn bản nằm trong thư mục)",
                           van_ban="Tên văn bản (không điền danh_muc = văn bản đứng riêng)",
                           noi_dung="Nội dung văn bản (tối đa 4000 ký tự; nhiều dòng thì dùng /note editsv)")
    async def note_addsv(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                         van_ban: Optional[str] = None, noi_dung: Optional[app_commands.Range[str, 1, 4000]] = None) -> None:
        await self._guarded(interaction, self._add(interaction, True, danh_muc, van_ban, noi_dung))

    @app_commands.command(name="listsv", description="Xem thư mục và văn bản chung của máy chủ")
    @app_commands.describe(danh_muc="Chỉ xem bên trong thư mục này", van_ban="Đọc nội dung của văn bản này")
    async def note_listsv(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                          van_ban: Optional[str] = None) -> None:
        await self._guarded(interaction, self._list(interaction, True, danh_muc, van_ban))

    @app_commands.command(name="editsv", description="Sửa văn bản hoặc đổi tên thư mục chung (người tạo hoặc admin)")
    @app_commands.describe(danh_muc="Thư mục cần đổi tên (hoặc thư mục chứa văn bản)", van_ban="Văn bản cần sửa")
    async def note_editsv(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                          van_ban: Optional[str] = None) -> None:
        await self._guarded(interaction, self._edit(interaction, True, danh_muc, van_ban))

    @app_commands.command(name="deletesv", description="Xóa văn bản hoặc thư mục chung (người tạo hoặc admin)")
    @app_commands.describe(danh_muc="Thư mục cần xóa (xóa luôn văn bản bên trong) hoặc thư mục chứa văn bản",
                           van_ban="Văn bản cần xóa")
    async def note_deletesv(self, interaction: discord.Interaction, danh_muc: Optional[str] = None,
                            van_ban: Optional[str] = None) -> None:
        await self._guarded(interaction, self._delete(interaction, True, danh_muc, van_ban))

    @app_commands.command(name="searchsv", description="Tìm thư mục hoặc văn bản chung theo tên hoặc nội dung")
    @app_commands.describe(tu_khoa="Từ cần tìm (không cần gõ dấu)")
    async def note_searchsv(self, interaction: discord.Interaction, tu_khoa: str) -> None:
        await self._guarded(interaction, self._search(interaction, True, tu_khoa))

    @app_commands.command(name="movesv", description="Chuyển văn bản chung sang thư mục khác (người tạo hoặc admin)")
    @app_commands.describe(van_ban="Văn bản cần chuyển", thu_muc="Thư mục đích (bỏ trống = đưa ra ngoài thư mục)",
                           tu_thu_muc="Thư mục hiện tại của văn bản (chỉ cần khi có nhiều văn bản trùng tên)")
    async def note_movesv(self, interaction: discord.Interaction, van_ban: str, thu_muc: Optional[str] = None,
                          tu_thu_muc: Optional[str] = None) -> None:
        await self._guarded(interaction, self._move(interaction, True, van_ban, thu_muc, tu_thu_muc))

    # =======================================================================
    # Thùng rác, khôi phục, lịch sử (riêng + chung)
    # =======================================================================
    @app_commands.command(name="trash", description="Xem thùng rác ghi chú riêng của bạn (giữ 30 ngày)")
    async def note_trash(self, interaction: discord.Interaction) -> None:
        await self._guarded(interaction, self._trash(interaction, False))

    @app_commands.command(name="trashsv", description="Xem thùng rác ghi chú chung của máy chủ (giữ 30 ngày)")
    async def note_trashsv(self, interaction: discord.Interaction) -> None:
        await self._guarded(interaction, self._trash(interaction, True))

    @app_commands.command(name="restore", description="Khôi phục văn bản hoặc thư mục riêng từ thùng rác")
    @app_commands.describe(da_xoa="Chọn mục đã xóa (gõ để lọc, hoặc nhập số # trong /note trash)")
    async def note_restore(self, interaction: discord.Interaction, da_xoa: str) -> None:
        await self._guarded(interaction, self._restore(interaction, False, da_xoa))

    @app_commands.command(name="restoresv", description="Khôi phục ghi chú chung từ thùng rác (người xóa, người tạo hoặc admin)")
    @app_commands.describe(da_xoa="Chọn mục đã xóa (gõ để lọc, hoặc nhập số # trong /note trashsv)")
    async def note_restoresv(self, interaction: discord.Interaction, da_xoa: str) -> None:
        await self._guarded(interaction, self._restore(interaction, True, da_xoa))

    @app_commands.command(name="history", description="Xem lịch sử sửa văn bản riêng và quay về bản cũ")
    @app_commands.describe(van_ban="Văn bản cần xem lịch sử", danh_muc="Thư mục chứa văn bản (chỉ cần khi trùng tên)")
    async def note_history(self, interaction: discord.Interaction, van_ban: str, danh_muc: Optional[str] = None) -> None:
        await self._guarded(interaction, self._history(interaction, False, van_ban, danh_muc))

    @app_commands.command(name="historysv", description="Xem lịch sử sửa văn bản chung và quay về bản cũ")
    @app_commands.describe(van_ban="Văn bản cần xem lịch sử", danh_muc="Thư mục chứa văn bản (chỉ cần khi trùng tên)")
    async def note_historysv(self, interaction: discord.Interaction, van_ban: str, danh_muc: Optional[str] = None) -> None:
        await self._guarded(interaction, self._history(interaction, True, van_ban, danh_muc))

    # =======================================================================
    # Gợi ý khi gõ (autocomplete)
    # =======================================================================
    async def _folder_choices(self, interaction: discord.Interaction, current: str, server: bool) -> list[app_commands.Choice[str]]:
        try:
            scope = self._scope(interaction, server)
            names = await self.store.suggest_folders(scope, current)
            return [app_commands.Choice(name=name[:100], value=name) for name in names]
        except Exception:  # noqa: BLE001 - gợi ý lỗi thì thôi, không làm hỏng lệnh
            return []

    async def _note_choices(self, interaction: discord.Interaction, current: str, server: bool) -> list[app_commands.Choice[str]]:
        try:
            scope = self._scope(interaction, server)
            ns = interaction.namespace
            folder = getattr(ns, "danh_muc", None) or getattr(ns, "tu_thu_muc", None)
            try:
                folder = notestore.clean_name(folder) if folder else None
            except NoteError:
                folder = None  # thư mục đang gõ dở/không hợp lệ: gợi ý trong mọi thư mục
            rows = await self.store.suggest_notes(scope, current, folder)
            return [app_commands.Choice(name=(title if not where else f"{title}  ·  📁 {where}")[:100], value=title)
                    for title, where in rows]
        except Exception:  # noqa: BLE001
            return []

    async def _ac_folder_private(self, interaction: discord.Interaction, current: str):
        return await self._folder_choices(interaction, current, False)

    async def _ac_folder_server(self, interaction: discord.Interaction, current: str):
        return await self._folder_choices(interaction, current, True)

    async def _ac_note_private(self, interaction: discord.Interaction, current: str):
        return await self._note_choices(interaction, current, False)

    async def _ac_note_server(self, interaction: discord.Interaction, current: str):
        return await self._note_choices(interaction, current, True)

    async def _trash_choices(self, interaction: discord.Interaction, current: str, server: bool) -> list[app_commands.Choice[str]]:
        try:
            scope = self._scope(interaction, server)
            query = fold(current.strip().lstrip("#"))
            items = await self.store.trash_items(scope, purge=False)
            return [app_commands.Choice(
                name=f"{'📁' if i.kind == 'folder' else '📄'} {i.name} · {_ago(i.deleted_at)} (#{i.id})"[:100], value=str(i.id))
                for i in items if query in fold(i.name) or query == str(i.id)][:25]
        except Exception:  # noqa: BLE001
            return []

    async def _ac_trash_private(self, interaction: discord.Interaction, current: str):
        return await self._trash_choices(interaction, current, False)

    async def _ac_trash_server(self, interaction: discord.Interaction, current: str):
        return await self._trash_choices(interaction, current, True)

    # Gắn gợi ý cho từng tham số: (lệnh, là ghi chú chung?, các tham số thư mục, có tham số văn bản?)
    # (các hàm gợi ý ở trên cần `self` vì nằm trong lớp; /note add không gợi ý tên văn bản vì đó là tên MỚI)
    for _sc, _sv, _fp, _hn in (
        (note_add, False, ("danh_muc",), False),
        (note_list, False, ("danh_muc",), True),
        (note_edit, False, ("danh_muc",), True),
        (note_delete, False, ("danh_muc",), True),
        (note_move, False, ("thu_muc", "tu_thu_muc"), True),
        (note_addsv, True, ("danh_muc",), False),
        (note_listsv, True, ("danh_muc",), True),
        (note_editsv, True, ("danh_muc",), True),
        (note_deletesv, True, ("danh_muc",), True),
        (note_movesv, True, ("thu_muc", "tu_thu_muc"), True),
        (note_history, False, ("danh_muc",), True),
        (note_historysv, True, ("danh_muc",), True),
    ):
        for _pn in _fp:
            _sc.autocomplete(_pn)(_ac_folder_server if _sv else _ac_folder_private)
        if _hn:
            _sc.autocomplete("van_ban")(_ac_note_server if _sv else _ac_note_private)
    del _sc, _sv, _fp, _hn, _pn
    note_restore.autocomplete("da_xoa")(_ac_trash_private)
    note_restoresv.autocomplete("da_xoa")(_ac_trash_server)

    # -- lỗi không lường trước -------------------------------------------------
    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
        log.error("Lỗi khi chạy lệnh %s", getattr(interaction.command, "qualified_name", "?"),
                  exc_info=getattr(error, "original", error))
        try:
            await _send(interaction, embed=_err("Có lỗi không mong muốn xảy ra. Bạn thử lại sau nhé."), ephemeral=True)
        except discord.HTTPException:
            pass


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Notes(bot))
