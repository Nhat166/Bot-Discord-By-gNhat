"""Lệnh /help: hướng dẫn dùng bot ghi chú, có menu chọn chủ đề.

    /help               -> tổng quan
    /help chu_de:...    -> mở thẳng một chủ đề (hoặc đổi chủ đề bằng menu bên dưới)
"""
from __future__ import annotations

import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from ghichu_store import CONTENT_MAX, HISTORY_MAX, LIMITS, NAME_MAX, PRIVATE, SERVER, TRASH_DAYS

log = logging.getLogger("ghichu.help")
COLOR = 0x5865F2

# (mã, nhãn hiển thị, mô tả ngắn cho menu)
TOPICS: list[tuple[str, str, str]] = [
    ("tong_quan", "📖 Tổng quan", "Bot làm được gì, các nhóm lệnh"),
    ("tao", "➕ Tạo thư mục / văn bản", "/note add"),
    ("xem", "🗂️ Xem và đọc", "/note list, lật trang"),
    ("sua_xoa", "✏️ Sửa, xóa, chuyển", "/note edit, delete, move"),
    ("tim", "🔎 Tìm kiếm", "/note search"),
    ("thung_rac", "🗑️ Thùng rác & khôi phục", "/note trash, restore"),
    ("lich_su", "📜 Lịch sử chỉnh sửa", "/note history"),
    ("luu_tin_nhan", "📌 Lưu từ tin nhắn", "Chuột phải tin nhắn -> Apps"),
    ("quyen", "🔐 Quyền & giới hạn", "Ai được làm gì, giới hạn số lượng"),
]


def build_topic(topic: str) -> discord.Embed:
    pf, sf = LIMITS[PRIVATE], LIMITS[SERVER]
    if topic == "tao":
        embed = discord.Embed(title="➕ Tạo thư mục / văn bản", color=COLOR, description=(
            "`/note add` hiểu theo ô bạn điền:\n"
            "• chỉ `danh_muc` → tạo **thư mục**\n"
            "• `danh_muc` + `van_ban` → tạo **văn bản trong thư mục** (thư mục phải có sẵn)\n"
            "• thêm `noi_dung` → văn bản có sẵn nội dung\n"
            "• chỉ `van_ban` (+ `noi_dung`) → văn bản **đứng riêng**, không thư mục\n\n"
            "Nội dung nhiều dòng: tạo văn bản rồi dùng `/note edit` để mở khung soạn thảo.\n"
            "Ghi chú chung của máy chủ: dùng `/note addsv`."))
    elif topic == "xem":
        embed = discord.Embed(title="🗂️ Xem và đọc", color=COLOR, description=(
            "`/note list`\n"
            "• không điền gì → cả cây thư mục và văn bản\n"
            "• `danh_muc` → xem bên trong một thư mục (kèm đoạn xem trước)\n"
            "• `van_ban` → đọc nội dung (thêm `danh_muc` nếu nhiều văn bản trùng tên)\n\n"
            "Danh sách dài được chia **trang**, bấm ◀ ▶ để lật. Ghi chú chung: `/note listsv`."))
    elif topic == "sua_xoa":
        embed = discord.Embed(title="✏️ Sửa, xóa, chuyển", color=COLOR, description=(
            "• `/note edit` — điền `van_ban` để sửa tên + nội dung (khung nhiều dòng); chỉ `danh_muc` để đổi tên thư mục.\n"
            f"• `/note delete` — xóa văn bản hoặc cả thư mục (có hộp xác nhận). Bản xóa vào **thùng rác {TRASH_DAYS} ngày**.\n"
            "• `/note move` — chuyển văn bản sang thư mục khác; **bỏ trống `thu_muc`** để đưa ra ngoài thư mục.\n\n"
            "Khi hai người cùng sửa một văn bản, người lưu sau sẽ được báo thay vì ghi đè mất nội dung.\n"
            "Ghi chú chung: thêm đuôi `sv` (`editsv`, `deletesv`, `movesv`)."))
    elif topic == "tim":
        embed = discord.Embed(title="🔎 Tìm kiếm", color=COLOR, description=(
            "`/note search tu_khoa:...` tìm theo **tên thư mục, tên văn bản và nội dung**.\n"
            "Không cần gõ dấu: `toan` tìm ra `Toán`. Kết quả chia theo nhóm, nội dung khớp có kèm đoạn trích.\n"
            "Ghi chú chung: `/note searchsv`."))
    elif topic == "thung_rac":
        embed = discord.Embed(title="🗑️ Thùng rác & khôi phục", color=COLOR, description=(
            f"Mọi thứ bạn xóa được giữ **{TRASH_DAYS} ngày** (tối đa 100 mục) rồi tự dọn.\n\n"
            "• `/note trash` — xem các mục đã xóa (số `#` ở đầu mỗi dòng).\n"
            "• `/note restore da_xoa:...` — chọn từ gợi ý khi gõ, hoặc nhập số `#` / tên.\n\n"
            "Khôi phục thư mục sẽ mang theo mọi văn bản bên trong. Nếu tên đã bị dùng, bot thêm "
            "\"(khôi phục)\"; nếu thư mục cũ của văn bản không còn, bot tạo lại.\n"
            "Ghi chú chung: `/note trashsv`, `/note restoresv` (người xóa, người tạo hoặc quản trị viên khôi phục được)."))
    elif topic == "lich_su":
        embed = discord.Embed(title="📜 Lịch sử chỉnh sửa", color=COLOR, description=(
            f"Mỗi lần sửa, bot giữ lại **{HISTORY_MAX} bản gần nhất** của văn bản.\n\n"
            "`/note history van_ban:...` → danh sách bản kèm người sửa và thời điểm. Chọn một bản trong menu để "
            "đọc, rồi bấm **↩️ Khôi phục bản này** để quay về.\n"
            "Khôi phục cũng được ghi vào lịch sử nên có thể hoàn tác lại.\n"
            "Ghi chú chung: `/note historysv` (chỉ người tạo hoặc quản trị viên khôi phục được)."))
    elif topic == "luu_tin_nhan":
        embed = discord.Embed(title="📌 Lưu từ tin nhắn", color=COLOR, description=(
            "1. **Chuột phải** (điện thoại: nhấn giữ) vào một tin nhắn bất kỳ.\n"
            "2. Chọn **Apps → Lưu vào ghi chú**.\n"
            "3. Chọn **🔒 Lưu riêng** hoặc **🌐 Lưu chung máy chủ**.\n"
            "4. Đặt tên, chọn thư mục (chưa có thì bot tự tạo), sửa nội dung nếu muốn rồi gửi.\n\n"
            "Ghi chú có sẵn nội dung tin nhắn, link tệp đính kèm, tên người gửi, giờ gửi và liên kết về tin nhắn gốc. "
            "Nếu tên đã có, bot tự đặt thêm \"(trùng)\"."))
    elif topic == "quyen":
        embed = discord.Embed(title="🔐 Quyền & giới hạn", color=COLOR, description=(
            "**Ghi chú riêng** (lệnh không có `sv`): chỉ bạn thấy và dùng được; đi theo tài khoản, dùng được ở mọi "
            "máy chủ và cả trong tin nhắn riêng với bot.\n\n"
            "**Ghi chú chung** (lệnh có đuôi `sv`, chỉ trong máy chủ):\n"
            "• Ai cũng xem, tìm và thêm được.\n"
            "• Sửa, xóa, chuyển, xem lại lịch sử để khôi phục: **người tạo** hoặc **quản trị viên** "
            "(quyền Administrator hoặc Manage Server).\n"
            "• Xóa thư mục có văn bản của người khác: chỉ quản trị viên.\n\n"
            f"**Giới hạn:** tên tối đa {NAME_MAX} ký tự, nội dung tối đa {CONTENT_MAX}. "
            f"Riêng mỗi người: {pf[0]} thư mục, {pf[1]} văn bản. Mỗi máy chủ: {sf[0]} thư mục, {sf[1]} văn bản."))
    else:  # tổng quan
        embed = discord.Embed(title="📖 Bot ghi chú", color=COLOR, description=(
            "Lưu ghi chú có tổ chức: **thư mục → văn bản → nội dung** (hoặc văn bản đứng riêng).\n"
            "Mỗi lệnh có hai dạng: **riêng** (chỉ bạn thấy) và **chung máy chủ** (thêm đuôi `sv`)."))
        embed.add_field(name="Lệnh chính", inline=False, value=(
            "`/note add` tạo · `/note list` xem · `/note edit` sửa\n"
            "`/note delete` xóa · `/note move` chuyển · `/note search` tìm"))
        embed.add_field(name="Mới", inline=False, value=(
            "`/note trash` · `/note restore` thùng rác và khôi phục\n"
            "`/note history` lịch sử sửa, quay về bản cũ\n"
            "📌 Chuột phải tin nhắn → Apps → **Lưu vào ghi chú**"))
        embed.add_field(name="Ghi chú chung của máy chủ", inline=False,
                        value="Thêm đuôi `sv`: `/note addsv`, `listsv`, `editsv`, `deletesv`, `searchsv`, `movesv`, "
                              "`trashsv`, `restoresv`, `historysv`.")
        embed.set_footer(text="Chọn chủ đề trong menu bên dưới để xem chi tiết.")
        return embed
    embed.set_footer(text="Chọn chủ đề khác trong menu bên dưới · /help để về tổng quan")
    return embed


class HelpView(discord.ui.View):
    def __init__(self, user_id: int, interaction: discord.Interaction, current: str) -> None:
        super().__init__(timeout=300)
        self.user_id, self.interaction = user_id, interaction
        select = discord.ui.Select(placeholder="Chọn chủ đề…", options=[
            discord.SelectOption(label=label[:100], value=code, description=desc[:100], default=code == current)
            for code, label, desc in TOPICS])
        select.callback = self._on_select
        self.select = select
        self.add_item(select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Gõ `/help` để mở bảng hướng dẫn của riêng bạn.", ephemeral=True)
            return False
        return True

    async def _on_select(self, interaction: discord.Interaction) -> None:
        topic = interaction.data["values"][0]
        for option in self.select.options:
            option.default = option.value == topic
        await interaction.response.edit_message(embed=build_topic(topic), view=self)

    async def on_timeout(self) -> None:
        try:
            await self.interaction.edit_original_response(view=None)
        except discord.HTTPException:
            pass


class Help(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name="help", description="Hướng dẫn dùng bot ghi chú")
    @app_commands.describe(chu_de="Chủ đề muốn xem (bỏ trống = tổng quan)")
    @app_commands.choices(chu_de=[app_commands.Choice(name=label[:100], value=code) for code, label, _ in TOPICS])
    async def help_command(self, interaction: discord.Interaction, chu_de: Optional[str] = None) -> None:
        topic = chu_de if chu_de in {code for code, _, _ in TOPICS} else "tong_quan"
        await interaction.response.send_message(embed=build_topic(topic), view=HelpView(interaction.user.id, interaction, topic),
                                                ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Help(bot))
