"""Lệnh quản lý chung cho các game bàn: /reset [game] (đặt lại số ván hiển thị về #1)."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

import ibank_ui as ui
from ibank_bank import BankError
from game_base import GameBase

GAMES = {"taixiu": "TaiXiu", "baucua": "BauCua"}     # giá trị lựa chọn -> tên Cog


class GameAdmin(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name="reset", description="(Nhà Cái / Admin) Đặt lại số ván về #1 (chỉ đổi số hiển thị, không ảnh hưởng ván đang chơi).")
    @app_commands.describe(game="Game cần đặt lại số ván")
    @app_commands.choices(game=[app_commands.Choice(name="Tài Xỉu", value="taixiu"),
                                app_commands.Choice(name="Bầu Cua", value="baucua"),
                                app_commands.Choice(name="Tất cả", value="all")])
    @app_commands.guild_only()
    async def cmd_reset(self, interaction: discord.Interaction, game: str) -> None:
        cogs = {k: self.bot.get_cog(v) for k, v in GAMES.items()}
        probe = next((c for c in cogs.values() if isinstance(c, GameBase)), None)
        if probe is None:
            await interaction.response.send_message("Chưa có game nào được nạp.", ephemeral=True)
            return

        async def work() -> None:
            if not (probe.is_admin(interaction) or await probe.is_house(interaction)):
                raise BankError("Chỉ Nhà Cái, quản trị viên hoặc admin mới dùng được lệnh này.")
            keys = list(GAMES) if game == "all" else [game if game in GAMES else "taixiu"]
            lines = [f"**{cogs[k].GAME_NAME}**: {await cogs[k].reset_numbering(interaction.guild_id)}" for k in keys if isinstance(cogs[k], GameBase)]
            await probe.reply(interaction, ui.success("\n".join(lines), title="🔄 Đã đặt lại số ván"))
            await probe.log_to(interaction.guild_id, ui.make("🔄 Đặt lại số ván", f"{interaction.user.mention}\n" + "\n".join(lines), color=ui.RED))
        await probe.guard(interaction, work)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(GameAdmin(bot))
