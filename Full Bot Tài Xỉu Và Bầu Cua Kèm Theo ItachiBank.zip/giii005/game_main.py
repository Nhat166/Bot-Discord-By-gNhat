"""Điểm khởi chạy của bot game (Tài Xỉu + Bầu Cua; bot riêng, token riêng, dùng chung ví với ItachiBank).

Chạy:  python game_main.py      (đặt cùng thư mục với các file ibank_*.py)
"""
from __future__ import annotations

import logging
import logging.handlers
import sys

import discord
from discord.ext import commands

import taixiu_config as config
from ibank_database import db

log = logging.getLogger("taixiu")


def setup_logging() -> None:
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    root.addHandler(console)
    file_handler = logging.handlers.RotatingFileHandler(config.BASE_DIR / "taixiu.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)


class TaiXiuBot(commands.Bot):
    def __init__(self) -> None:
        # Chỉ dùng lệnh / và nút bấm nên không cần intent đặc quyền.
        super().__init__(command_prefix=commands.when_mentioned, intents=discord.Intents.default(), help_command=None)

    async def setup_hook(self) -> None:
        await db.connect(config.DATABASE_PATH)
        await self.load_extension("taixiu_cog")
        await self.load_extension("baucua_cog")
        await self.load_extension("game_admin_cog")
        if config.GUILD_ID:
            guild = discord.Object(id=config.GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Đã đồng bộ %d lệnh vào máy chủ %s", len(synced), config.GUILD_ID)
        else:
            synced = await self.tree.sync()
            log.info("Đã đồng bộ %d lệnh toàn cầu (có thể mất tới 1 giờ)", len(synced))

    async def close(self) -> None:
        await super().close()
        await db.close()

    async def on_ready(self) -> None:
        log.info("Đã đăng nhập: %s (ID %s) | %d máy chủ", self.user, self.user.id, len(self.guilds))
        await self.change_presence(activity=discord.Game(name="Tài Xỉu · Bầu Cua 🎲"))


def main() -> None:
    setup_logging()
    if not config.TOKEN:
        raise SystemExit("Thiếu TAIXIU_TOKEN. Hãy copy taixiu.env.example thành taixiu.env và dán token bot Tài Xỉu vào.")
    bot = TaiXiuBot()
    try:
        bot.run(config.TOKEN, log_handler=None)
    except discord.LoginFailure:
        raise SystemExit("Token không hợp lệ. Hãy tạo lại token trong Discord Developer Portal và cập nhật taixiu.env.")


if __name__ == "__main__":
    main()
