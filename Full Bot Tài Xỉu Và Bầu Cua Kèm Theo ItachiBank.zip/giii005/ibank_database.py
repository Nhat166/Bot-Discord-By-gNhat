"""Lớp truy cập SQLite: mọi truy vấn chạy trong luồng nền và được tuần tự hóa bằng một khóa."""
from __future__ import annotations

import asyncio
import logging
import os
import sqlite3
from typing import Any, Callable, Sequence, TypeVar

log = logging.getLogger("ibank.database")

T = TypeVar("T")

SCHEMA = """
CREATE TABLE IF NOT EXISTS wallets (
    user_id    INTEGER PRIMARY KEY,
    cash       INTEGER NOT NULL DEFAULT 0 CHECK (cash >= 0),   -- tiền mặt (VNĐ)
    debt       INTEGER NOT NULL DEFAULT 0 CHECK (debt >= 0),   -- tiền nợ (dùng cho hệ thống vay sau này)
    last_daily TEXT,                                           -- ngày (giờ Việt Nam, YYYY-MM-DD) nhận /daily gần nhất
    created_at TEXT    NOT NULL
);

-- Sổ cái: mọi lần tiền vào/ra đều được ghi lại để admin tra cứu và đối chiếu.
CREATE TABLE IF NOT EXISTS ledger (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL,
    delta         INTEGER NOT NULL,
    balance_after INTEGER NOT NULL,
    kind          TEXT    NOT NULL,       -- start, daily, ...
    note          TEXT    NOT NULL DEFAULT '',
    created_at    TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_ledger_user ON ledger (user_id, id);

-- Tài khoản ngân hàng: không phí, không lãi. Số tài khoản duy nhất toàn bot.
CREATE TABLE IF NOT EXISTS accounts (
    number     TEXT PRIMARY KEY,
    owner_id   INTEGER NOT NULL,
    holder     TEXT    NOT NULL,
    balance    INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
    created_at TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_accounts_owner ON accounts (owner_id);

-- Mọi lần chuyển / nộp / rút ở ngân hàng.
CREATE TABLE IF NOT EXISTS transfers (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kind         TEXT    NOT NULL,        -- deposit, withdraw, transfer
    from_account TEXT,
    to_account   TEXT,
    from_user    INTEGER,
    to_user      INTEGER,
    amount       INTEGER NOT NULL,
    note         TEXT    NOT NULL DEFAULT '',
    created_at   TEXT    NOT NULL
);

-- Vay tiền giữa thành viên (không lãi). status: pending, active, repaid, declined, expired
CREATE TABLE IF NOT EXISTS loans (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    lender_id        INTEGER NOT NULL,
    borrower_id      INTEGER NOT NULL,
    amount           INTEGER NOT NULL CHECK (amount > 0),
    repaid           INTEGER NOT NULL DEFAULT 0,
    days             INTEGER NOT NULL,
    status           TEXT    NOT NULL,
    created_at       TEXT    NOT NULL,
    decided_at       TEXT,
    due_at           TEXT,
    notified_overdue INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_loans_lender ON loans (lender_id, status);
CREATE INDEX IF NOT EXISTS ix_loans_borrower ON loans (borrower_id, status);

CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER NOT NULL,
    key      TEXT    NOT NULL,
    value    TEXT    NOT NULL,
    PRIMARY KEY (guild_id, key)
);
"""


class Database:
    def __init__(self) -> None:
        self._conn: sqlite3.Connection | None = None
        self._lock: asyncio.Lock | None = None

    async def connect(self, path: str) -> None:
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._lock = asyncio.Lock()
        self._conn = await asyncio.to_thread(self._open, path)
        log.info("Đã mở cơ sở dữ liệu: %s", path)

    @staticmethod
    def _open(path: str) -> sqlite3.Connection:
        conn = sqlite3.connect(path, isolation_level=None, check_same_thread=False, timeout=30)  # timeout: chờ khi bot game cùng dùng db
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(SCHEMA)
        return conn

    async def close(self) -> None:
        if self._conn is None or self._lock is None:
            return
        async with self._lock:
            await asyncio.to_thread(self._conn.close)
            self._conn = None

    def _require(self) -> tuple[sqlite3.Connection, asyncio.Lock]:
        if self._conn is None or self._lock is None:
            raise RuntimeError("Cơ sở dữ liệu chưa được kết nối (gọi db.connect trước).")
        return self._conn, self._lock

    async def fetchone(self, sql: str, params: Sequence[Any] = ()) -> sqlite3.Row | None:
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(lambda: conn.execute(sql, tuple(params)).fetchone())

    async def fetchall(self, sql: str, params: Sequence[Any] = ()) -> list[sqlite3.Row]:
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(lambda: conn.execute(sql, tuple(params)).fetchall())

    async def transaction(self, func: Callable[[sqlite3.Connection], T]) -> T:
        """Chạy `func(conn)` (hàm đồng bộ) trong một giao dịch: thành công thì COMMIT, lỗi thì ROLLBACK."""
        conn, lock = self._require()
        async with lock:
            return await asyncio.to_thread(self._run_transaction, conn, func)

    @staticmethod
    def _run_transaction(conn: sqlite3.Connection, func: Callable[[sqlite3.Connection], T]) -> T:
        conn.execute("BEGIN IMMEDIATE")
        try:
            result = func(conn)
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        conn.execute("COMMIT")
        return result


db = Database()
