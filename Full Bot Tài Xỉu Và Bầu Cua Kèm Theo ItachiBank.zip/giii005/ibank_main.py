"""Điểm khởi chạy của ItachiBank.

Chạy:  python ibank_main.py
(Bot dùng token và file cấu hình RIÊNG: ibank.env / IBANK_TOKEN; không dính tới bot cũ hay bot ghi chú.)
"""
from __future__ import annotations

import logging
import logging.handlers
import sys

import discord
from discord.ext import commands

import ibank_config as config
from ibank_database import db

log = logging.getLogger("ibank")


def setup_logging() -> None:
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    root.addHandler(console)
    file_handler = logging.handlers.RotatingFileHandler(
        config.BASE_DIR / "ibank.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)


class ItachiBankBot(commands.Bot):
    def __init__(self) -> None:
        # Chỉ dùng lệnh /, nên không cần intent đặc quyền nào (không message_content, không members).
        super().__init__(command_prefix=commands.when_mentioned, intents=discord.Intents.default(), help_command=None)

    async def setup_hook(self) -> None:
        await db.connect(config.DATABASE_PATH)
        await self.load_extension("ibank_cog")
        if config.GUILD_ID:
            guild = discord.Object(id=config.GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Đã đồng bộ %d lệnh vào máy chủ %s", len(synced), config.GUILD_ID)
        else:
            synced = await self.tree.sync()
            log.info("Đã đồng bộ %d lệnh toàn cầu (có thể mất tới 1 giờ mới hiện ở mọi nơi)", len(synced))

    async def close(self) -> None:
        await super().close()
        await db.close()

    async def on_ready(self) -> None:
        log.info("Đã đăng nhập: %s (ID %s) | %d máy chủ", self.user, self.user.id, len(self.guilds))
        await self.change_presence(activity=discord.Game(name="ItachiBank · /vi"))


def main() -> None:
    setup_logging()
    if not config.TOKEN:
        raise SystemExit("Thiếu IBANK_TOKEN. Hãy copy ibank.env.example thành ibank.env và dán token bot vào.")
    bot = ItachiBankBot()
    try:
        bot.run(config.TOKEN, log_handler=None)
    except discord.LoginFailure:
        raise SystemExit("Token không hợp lệ. Hãy tạo lại token trong Discord Developer Portal và cập nhật ibank.env.")


if __name__ == "__main__":
    main()
