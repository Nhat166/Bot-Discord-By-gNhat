"""Cấu hình của ItachiBank, đọc từ file ibank.env (xem ibank.env.example).

Dùng file và tên biến RIÊNG (ibank.env, IBANK_*) để không lẫn với bot cũ (.env / DISCORD_TOKEN) và bot ghi chú (ghichu.env).
Các số tiền viết được dạng 200000, 200k, 1.5tr...
"""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

from ibank_money import AmountError, parse_amount

# Thư mục chứa file này: mọi đường dẫn mặc định tính từ đây, nên chạy bot từ thư mục nào cũng được.
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / "ibank.env")


def _get_str(name: str, default: str = "") -> str:
    return (os.getenv(name) or default).strip()


def _get_int(name: str, default: int = 0) -> int:
    raw = _get_str(name)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        raise SystemExit(f"Biến môi trường {name} phải là số nguyên (hiện là {raw!r}).") from None


def _get_money(name: str, default: int, *, minimum: int = 1) -> int:
    raw = _get_str(name)
    if not raw:
        return default
    try:
        return parse_amount(raw, minimum=minimum)
    except AmountError as exc:
        raise SystemExit(f"Biến môi trường {name} không hợp lệ ({raw!r}): {exc}") from None


TOKEN = _get_str("IBANK_TOKEN")
# Nếu đặt IBANK_GUILD_ID: lệnh / được đồng bộ NGAY vào máy chủ đó. Để trống: đồng bộ toàn cầu (chậm hơn).
GUILD_ID = _get_int("IBANK_GUILD_ID")
DATABASE_PATH = _get_str("IBANK_DATABASE_PATH", str(BASE_DIR / "data" / "ibank.db"))

# --- Kinh tế (đổi ở ibank.env, không cần sửa code) ---
STARTING_BALANCE = _get_money("IBANK_STARTING_BALANCE", 200_000, minimum=0)  # tiền mặt khi mở ví lần đầu
DAILY_MIN = _get_money("IBANK_DAILY_MIN", 50_000)
DAILY_MAX = _get_money("IBANK_DAILY_MAX", 500_000)
DAILY_STEP = _get_money("IBANK_DAILY_STEP", 1_000)   # /daily chỉ ra số tròn theo bước này
if DAILY_MIN > DAILY_MAX:
    raise SystemExit("IBANK_DAILY_MIN không được lớn hơn IBANK_DAILY_MAX.")
DAILY_PUBLIC = _get_str("IBANK_DAILY_PUBLIC", "1") not in ("0", "false", "no")  # /daily hiện công khai trong kênh


# --- Ngân hàng ---
MAX_ACCOUNTS = _get_int("IBANK_MAX_ACCOUNTS", 3)                 # số tài khoản tối đa mỗi người
ACCOUNT_NUMBER_MIN = _get_int("IBANK_ACCOUNT_NUMBER_MIN", 8)     # số tài khoản: từ ... đến ... chữ số
ACCOUNT_NUMBER_MAX = _get_int("IBANK_ACCOUNT_NUMBER_MAX", 12)
HOLDER_MIN, HOLDER_MAX = 2, 40                                   # độ dài họ tên chủ tài khoản
MIN_TRANSFER = _get_money("IBANK_MIN_TRANSFER", 1_000)
MIN_MEMBER_AGE_DAYS = _get_int("IBANK_MIN_MEMBER_AGE_DAYS", 3)   # ở máy chủ tối thiểu ... ngày mới được chuyển tiền / vay (0 = tắt)

# --- Vay tiền (không lãi) ---
LOAN_MIN = _get_money("IBANK_LOAN_MIN", 10_000)
LOAN_DEFAULT_DAYS = _get_int("IBANK_LOAN_DEFAULT_DAYS", 7)
LOAN_MAX_DAYS = _get_int("IBANK_LOAN_MAX_DAYS", 30)
LOAN_PENDING_HOURS = _get_int("IBANK_LOAN_PENDING_HOURS", 24)    # đơn vay quá hạn duyệt này thì tự hủy
MAX_PENDING_LOANS = _get_int("IBANK_MAX_PENDING_LOANS", 3)       # số đơn xin vay đang chờ tối đa của một người
MAX_ACTIVE_LOANS = _get_int("IBANK_MAX_ACTIVE_LOANS", 3)         # số khoản đang nợ tối đa của một người

# --- Giao diện ---
FOOTER_TEXT = _get_str("IBANK_FOOTER_TEXT", "by: giii•")
# Số ký tự trống chèn trước dòng chân bảng để đẩy chữ sang góc phải. Điện thoại màn hình hẹp thì giảm xuống (ví dụ 20).
FOOTER_PAD = _get_int("IBANK_FOOTER_PAD", 36)
