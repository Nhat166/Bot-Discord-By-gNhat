# Bot game: Tài Xỉu + Bầu Cua (dùng chung ví ItachiBank)

Bot **riêng, token riêng**, nhưng dùng chung cơ sở dữ liệu và ví VNĐ với ItachiBank: tiền thắng thua cộng/trừ thẳng vào ví, và hiện trong `/lichsu`.

## Cài đặt
1. Chép các file `taixiu_*.py`, `baucua_*.py`, `game_base.py`, thư mục `taixiu_fonts/`, `taixiu_assets/`, `taixiu.env.example` vào **cùng thư mục** với các file `ibank_*.py` (bot cần chúng để dùng chung ví).
2. Tạo ứng dụng bot **mới** ở Discord Developer Portal, lấy token riêng. Mời bot với quyền: Xem kênh, Gửi tin nhắn, Nhúng liên kết, Đính kèm tệp (scope `bot` + `applications.commands`). Không cần bật intent đặc quyền.
3. `pip install -r taixiu_requirements.txt` (cần thêm Pillow để vẽ ảnh).
4. Copy `taixiu.env.example` thành `taixiu.env`, điền `TAIXIU_TOKEN` (và `TAIXIU_GUILD_ID` để lệnh hiện ngay).
5. Chạy: `python game_main.py` (chạy song song với `python ibank_main.py`, **cùng một máy**).
6. Admin gõ `/taixiu_batdau` (Tài Xỉu) và/hoặc `/baucua_batdau` (Bầu Cua) ở kênh muốn đặt bàn; mỗi game một kênh riêng.

## Cách chơi
Mỗi ván: **40 giây cược** → **khóa + lắc 3 giây** → **hiện kết quả 6 giây** → ván mới (cùng một tin nhắn được sửa, tin nhắn "cầu" riêng cho 10 ván gần nhất).
- Bấm **Tài** (xanh lá, tổng 11–18) hoặc **Xỉu** (xanh dương, tổng 3–10), nhập số tiền (`50k`, `1.5tr`, `all` = tất cả).
- Tiền cược bị trừ khỏi ví ngay; thắng nhận lại **gấp đôi** tiền cược. Mỗi ván chỉ cược một bên (cược thêm cùng bên được).
- Bot dừng giữa ván: lần khởi động sau **hoàn lại** toàn bộ cược của ván dang dở.

## Lệnh
| Lệnh | Ai dùng | Mô tả |
|---|---|---|
| `/taixiu_batdau [kenh]` | admin / quản trị viên | Mở bàn chạy liên tục ở kênh (tự chạy lại sau khi bot khởi động lại) |
| `/taixiu_dung` | admin / quản trị viên | Dừng bàn sau ván hiện tại |
| `/nhacai` | **chỉ người có role Nhà Cái** | Bảng riêng (chỉ mình bạn thấy) có 2 nút đỏ **Bẻ Tài** / **Bẻ Xỉu**, thêm **Bỏ bẻ** và **Làm mới** |

## Nhà cái bẻ cầu
- Discord **không thể** ẩn nút của một tin nhắn công khai với từng người, nên 2 nút bẻ nằm trong bảng riêng `/nhacai`, không nằm dưới tin nhắn ván. Người không có role không mở được bảng.
- Role Nhà Cái lấy từ cài đặt của ItachiBank: `/bankconfig rolenhacai:@role`. Chỉ người **đang có role** mới dùng được (admin không có role cũng không dùng được). Mỗi lần bấm nút, bot kiểm tra lại role; nếu vừa bị gỡ role thì bảng mất nút và không bẻ được.
- Bẻ áp dụng cho ván hiện tại, có thể đổi ý (lần bấm cuối thắng) tới hết lúc lắc; sang ván mới thì tự bỏ bẻ.
- Mỗi lần bẻ được ghi vào cơ sở dữ liệu (`taixiu_rounds.forced_by`) và gửi vào kênh log của `/bankconfig kenhlog` nếu có, để admin kiểm tra.

## Bầu Cua (cùng bot)
Mỗi ván cũng 40 giây cược → khóa + lắc 3 giây → kết quả 6 giây. Tin nhắn ván dùng ảnh bàn Bầu Cua (`taixiu_assets/baucua_board.jpg`), 6 nút con vật xếp 3+3 như bàn thật (Hươu, Bầu, Gà / Cá, Cua, Tôm) và nút **Cược của tôi**.
- Cược **nhiều con cùng lúc** được; cược thêm cùng con thì cộng dồn.
- Trả thưởng: con trúng nhận lại cược + 1 phần cho **mỗi xúc xắc** ra con đó (ra 1 lần: ×2, 2 lần: ×3, 3 lần: ×4 tổng cược vào con). Không ra thì mất cược. Nhà cái có lợi thế khoảng 7,9%, nên đây cũng là nơi thu tiền về.
- Ảnh kết quả: 3 ô con vật cắt tròn từ chính ảnh bàn. Bầu Cua không có tin nhắn cầu.
- Discord không có emoji trái bầu, nên ô Bầu dùng 🍐 (đổi bằng `BAUCUA_BAU_EMOJI` trong `taixiu.env`); ảnh thì là hình trái bầu thật.

| Lệnh | Ai dùng | Mô tả |
|---|---|---|
| `/baucua_batdau [kenh]` | admin / quản trị viên | Mở bàn Bầu Cua |
| `/baucua_dung` | admin / quản trị viên | Dừng bàn sau ván hiện tại |
| `/baucuapanel` | **chỉ người có role Nhà Cái** | Bảng riêng: chọn 3 mặt xúc xắc rồi **Bẻ theo 3 mặt đã chọn**, hoặc **Nhà cái ăn nhiều nhất** (bot tự chọn kết quả trả ít nhất); có Bỏ bẻ và Làm mới. Bảng cho biết nếu bẻ thế nào thì nhà cái lời/lỗ bao nhiêu |
| `/reset game:` | **role Nhà Cái, quản trị viên hoặc admin** | Đặt lại số ván hiển thị về **#1** cho Tài Xỉu, Bầu Cua hoặc tất cả. Chỉ đổi con số và sửa tin nhắn, không ảnh hưởng ván đang chạy, cược hay tiền |

Quy tắc role Nhà Cái, kiểm tra lại mỗi lần bấm, ghi lại và gửi log: giống phần Tài Xỉu ở trên.

## Cấu hình (taixiu.env)
`TAIXIU_BET_SECONDS` (40), `TAIXIU_SHAKE_SECONDS` (3), `TAIXIU_RESULT_SECONDS` (6), `TAIXIU_MIN_BET` (1k), `TAIXIU_MAX_BET` (0 = không giới hạn), `TAIXIU_TRIPLE_HOUSE` (1 = bộ ba nhà cái ăn hết), `BAUCUA_BAU_EMOJI` (🍐). Thời gian và mức cược dùng chung cho cả hai game.

## Đặt tên (không đụng bot khác)
| | ItachiBank | Tài Xỉu |
|---|---|---|
| File | `ibank_*.py` | `taixiu_*.py` |
| Cấu hình | `ibank.env` (`IBANK_*`) | `taixiu.env` (`TAIXIU_*`) |
| Cơ sở dữ liệu | `data/ibank.db` | **cùng file** (thêm bảng `taixiu_rounds`, `taixiu_bets`) |
| Log | `ibank.log` | `taixiu.log` |
