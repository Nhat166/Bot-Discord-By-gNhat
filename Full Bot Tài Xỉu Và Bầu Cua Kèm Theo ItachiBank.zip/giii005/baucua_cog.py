"""Bàn Bầu Cua liên tục trong một kênh (cùng bot với Tài Xỉu): 40 giây cược → khóa + lắc 3 giây → kết quả 6 giây → ván mới.

Lệnh:
  /baucua_batdau [kenh]   (admin / quản trị viên) mở bàn ở kênh
  /baucua_dung            (admin / quản trị viên) dừng bàn sau ván hiện tại
  /baucuapanel            (chỉ người có role Nhà Cái) bảng riêng để chỉnh kết quả

Cược nhiều con cùng lúc được. Không có tin nhắn cầu. Con trúng: nhận lại cược + (số xúc xắc ra con đó) × cược. Dùng chung ví ItachiBank.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

import baucua_image as images
import ibank_ui as ui
import taixiu_config as config
from baucua_logic import ANIMALS, NAMES, best_for_house, parse_faces, payout_total, roll
from baucua_store import BauCuaStore, Settlement
from game_base import NO_PING, GameBase, Table, fmt_vn, money
from ibank_bank import BankError, BankStore
from ibank_database import db
from ibank_money import is_all, parse_amount
from ibank_store import WalletStore

log = logging.getLogger("baucua.cog")

POLL_SECONDS = 1.0
EDIT_EVERY = 4.0
EMOJI = {"huou": "🦌", "bau": config.BAUCUA_BAU_EMOJI, "ga": "🐓", "ca": "🐟", "cua": "🦀", "tom": "🦐"}


def label(animal: str) -> str:
    return f"{EMOJI[animal]} {NAMES[animal]}"


def faces_text(dice) -> str:
    return " · ".join(label(d) for d in dice)


# ---------------------------------------------------------------------------
# Khung nhập và các nút
# ---------------------------------------------------------------------------
class BetModal(discord.ui.Modal):
    def __init__(self, cog: "BauCua", animal: str, round_id: int) -> None:
        super().__init__(title=f"Cược {NAMES[animal]}", timeout=300)
        self.cog, self.animal, self.round_id = cog, animal, round_id
        self.amount = discord.ui.TextInput(label="Số tiền hoặc all = tất cả", placeholder="Ví dụ: 50000, 50k, 1.5tr, all",
                                           max_length=20, required=True)
        self.add_item(self.amount)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await self.cog.guard(interaction, lambda: self.cog.place_bet(interaction, self.round_id, self.animal, self.amount.value))

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi bảng cược", exc_info=error)
        await self.cog.reply(interaction, ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))


class BetView(discord.ui.View):
    """6 nút con vật (2 hàng × 3, giống bàn thật) + nút "Cược của tôi". Cố định nên vẫn bấm được sau khi bot khởi động lại."""

    def __init__(self, cog: "BauCua") -> None:
        super().__init__(timeout=None)
        self.cog = cog
        for i, animal in enumerate(ANIMALS):
            button = discord.ui.Button(label=NAMES[animal], emoji=EMOJI[animal], style=discord.ButtonStyle.secondary,
                                       custom_id=f"baucua:{animal}", row=i // 3)
            button.callback = self._bet_callback(animal)
            self.add_item(button)
        mine = discord.ui.Button(label="Cược của tôi", emoji="📋", style=discord.ButtonStyle.primary, custom_id="baucua:mine", row=2)
        mine.callback = self._mine_callback
        self.add_item(mine)

    def _bet_callback(self, animal: str):
        async def callback(interaction: discord.Interaction) -> None:
            await self.cog.guard(interaction, lambda: self.cog.open_bet(interaction, animal))
        return callback

    async def _mine_callback(self, interaction: discord.Interaction) -> None:
        await self.cog.guard(interaction, lambda: self.cog.show_mine(interaction))


class HouseView(discord.ui.View):
    """Bảng riêng của Nhà Cái: chọn 3 mặt xúc xắc rồi bẻ, hoặc để bot chọn kết quả nhà cái ăn nhiều nhất."""

    def __init__(self, cog: "BauCua", user_id: int) -> None:
        super().__init__(timeout=300)
        self.cog, self.user_id = cog, user_id
        self.faces: list[Optional[str]] = [None, None, None]
        for i in range(3):
            select = discord.ui.Select(placeholder=f"Xúc xắc {i + 1}: chọn con", row=i, options=[
                discord.SelectOption(label=NAMES[a], value=a, emoji=EMOJI[a]) for a in ANIMALS])
            select.callback = self._pick_callback(i)
            self.add_item(select)

    def _pick_callback(self, index: int):
        async def callback(interaction: discord.Interaction) -> None:
            await self.cog.guard(interaction, lambda: self.cog.house_pick(interaction, self, index, interaction.data["values"][0]))
        return callback

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Bảng này không phải của bạn.", ephemeral=True)
            return False
        if not await self.cog.is_house(interaction):       # đã bị gỡ role: ẩn nút, không cho dùng
            await interaction.response.edit_message(embed=ui.error("Bạn không còn role Nhà Cái nên không dùng được bảng này."), view=None)
            return False
        return True

    @discord.ui.button(label="Bẻ theo 3 mặt đã chọn", emoji="🔴", style=discord.ButtonStyle.danger, row=3)
    async def force_faces(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_force(interaction, self, "faces"))

    @discord.ui.button(label="Nhà cái ăn nhiều nhất", emoji="🔴", style=discord.ButtonStyle.danger, row=3)
    async def force_auto(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_force(interaction, self, "auto"))

    @discord.ui.button(label="Bỏ bẻ", style=discord.ButtonStyle.secondary, row=4)
    async def clear(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_force(interaction, self, None))

    @discord.ui.button(label="Làm mới", emoji="🔄", style=discord.ButtonStyle.secondary, row=4)
    async def refresh(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_refresh(interaction, self))


# ---------------------------------------------------------------------------
# Cog
# ---------------------------------------------------------------------------
class BauCua(GameBase, commands.Cog):
    """Bầu Cua bằng VNĐ dùng chung ví ItachiBank."""

    KEY_CHANNEL, KEY_MSG, KEY_CAU = "bc_channel", "bc_msg", "bc_cau"
    KEY_OFFSET, GAME_NAME = "bc_offset", "Bầu Cua"
    REST_TITLE = "🎲 BẦU CUA — BÀN TẠM NGHỈ"

    def rest_image(self):
        return ("board.jpg", self._board_img)

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.wallets = WalletStore(db, config.STARTING_BALANCE)
        self.bank = BankStore(db, self.wallets)          # chỉ để đọc/ghi cài đặt chung (role nhà cái, kênh log)
        self.store = BauCuaStore(db, self.wallets)
        self.tables: dict[int, Table] = {}
        self.bet_view = BetView(self)
        self._resumed = False
        self._board_img: Optional[bytes] = None
        self._shaking_img: Optional[bytes] = None

    async def cog_load(self) -> None:
        await self.store.setup()
        rounds, refunded = await self.store.refund_unfinished()
        if rounds:
            log.warning("Đã hoàn %s VNĐ cược của %d ván bầu cua dang dở.", f"{refunded:,}", rounds)
        self._board_img, self._shaking_img = await asyncio.gather(asyncio.to_thread(images.board_image),
                                                                  asyncio.to_thread(images.shaking_image))
        self.bot.add_view(self.bet_view)

    async def cog_unload(self) -> None:
        for table in self.tables.values():
            if table.task:
                table.task.cancel()

    @commands.Cog.listener()
    async def on_ready(self) -> None:
        if self._resumed:
            return
        self._resumed = True
        await self.resume_tables()

    # -- bảng hiển thị ---------------------------------------------------------------------------------
    @staticmethod
    def _totals_fields(totals: dict[str, tuple[int, int]]) -> list[tuple[str, str, bool]]:
        return [(label(a), f"{totals[a][0]} người\n**{money(totals[a][1])}**", True) for a in ANIMALS]

    def betting_embed(self, table: Table, totals, lock_unix: int) -> discord.Embed:
        return ui.make(f"🎲 BẦU CUA — VÁN #{table.no}",
                       "Bấm con bạn muốn cược rồi nhập số tiền (gõ `all` = tất cả). Cược được **nhiều con** cùng lúc.\n"
                       f"⏳ Khóa cược <t:{lock_unix}:R>\n💰 Trúng nhận lại cược + **1 phần cho mỗi xúc xắc** ra con đó."
                       f"\n\n⏰ Ván bắt đầu: **{fmt_vn(table.started)}**", color=ui.GOLD, fields=self._totals_fields(totals))

    def locked_embed(self, table: Table, totals) -> discord.Embed:
        return ui.make("BẦU CUA — ĐÃ KHÓA CƯỢC", "🔒 **Đã hết thời gian cược!**\n🎲 Đang lắc xúc xắc...\n\n"
                       f"⏰ {fmt_vn(table.started)}", color=ui.RED, fields=self._totals_fields(totals))

    def result_embed(self, table: Table, st: Settlement) -> discord.Embed:
        lines = [f"🎲 **{faces_text(st.dice)}**"]
        if len(set(st.dice)) == 1:
            lines.append("🎰 **Ba con giống nhau!**")
        lines.append(f"\n⏰ {fmt_vn(table.started)}")
        fields: list[tuple[str, str, bool]] = []
        winners, losers = st.winners, st.losers
        if winners:
            top = "\n".join(f"<@{u.user_id}> **+{money(u.net)}**" for u in winners[:5])
            more = f"\n… và {len(winners) - 5} người nữa" if len(winners) > 5 else ""
            fields.append((f"🏆 Thắng ({len(winners)} người)", f"{top}{more}\nTổng trả thưởng: **{money(st.total_payout)}**", False))
        if losers:
            fields.append((f"💸 Thua ({len(losers)} người)", f"Tổng: **{money(sum(-u.net for u in losers))}**", False))
        if not st.users:
            fields.append(("Ván này", "Không có ai đặt cược.", False))
        return ui.make(f"🎲 BẦU CUA — KẾT QUẢ VÁN #{table.no}", "\n".join(lines), color=0xC92A2A, fields=fields)

    # -- vòng chơi --------------------------------------------------------------------------------------------
    async def _play_round(self, table: Table) -> None:
        if table.cau is not None:                       # Bầu Cua không còn tin nhắn cầu: xóa tin cũ còn sót
            try:
                await table.cau.delete()
            except discord.HTTPException:
                pass
            table.cau = None
            await self.bank.set_setting(table.guild_id, self.KEY_CAU, None)
        # 1. mở ván, nhận cược
        table.round_id, table.started = await self.store.create_round(table.guild_id, table.channel_id)
        table.phase, table.dirty = "open", False
        rid = table.round_id
        lock_unix = table.lock_unix = int(time.time()) + config.BET_SECONDS
        deadline = time.monotonic() + config.BET_SECONDS
        await self._publish(table, "message", self.betting_embed(table, await self.store.totals(rid), lock_unix),
                            image=("board.jpg", self._board_img), view=self.bet_view)
        last_edit = time.monotonic()
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            await asyncio.sleep(min(POLL_SECONDS, remaining))
            if table.dirty and time.monotonic() - last_edit >= EDIT_EVERY and deadline - time.monotonic() > 1:
                table.dirty, last_edit = False, time.monotonic()
                await self._publish(table, "message", self.betting_embed(table, await self.store.totals(rid), lock_unix),
                                    image=("board.jpg", None))
        # 2. khóa cược, lắc
        await self.store.lock_round(rid)
        table.phase = "locked"
        await self._publish(table, "message", self.locked_embed(table, await self.store.totals(rid)),
                            image=("shaking.png", self._shaking_img), view=None)
        await asyncio.sleep(config.SHAKE_SECONDS)
        # 3. chốt kết quả (nhà cái được bẻ cho tới lúc này), trả thưởng
        mode, _ = await self.store.get_force(rid)
        if mode == "auto":
            bets = {a: s for a, (_, s) in (await self.store.totals(rid)).items()}
            dice = best_for_house(bets)
        elif mode:
            dice = parse_faces(mode)
        else:
            dice = roll()
        settlement = await self.store.settle(rid, dice)
        table.phase = "result"
        png = await asyncio.to_thread(images.result_image, dice)
        await self._publish(table, "message", self.result_embed(table, settlement), image=(f"result_{rid}.png", png), view=None)
        await asyncio.sleep(config.RESULT_SECONDS)

    async def refresh_open(self, table: Table) -> None:
        await self._publish(table, "message", self.betting_embed(table, await self.store.totals(table.round_id), table.lock_unix),
                            image=("board.jpg", None))

    # -- cược ---------------------------------------------------------------------------------------------------
    async def open_bet(self, interaction: discord.Interaction, animal: str) -> None:
        table = self.tables.get(interaction.guild_id or 0)
        if table is None or table.phase != "open":
            raise BankError("Ván này đã khóa cược, hãy chờ ván sau.")
        await interaction.response.send_modal(BetModal(self, animal, table.round_id))

    @staticmethod
    def _mine_lines(bets: dict[str, int]) -> str:
        return "\n".join(f"{label(a)}: **{money(bets[a])}**" for a in ANIMALS if a in bets) or "Bạn chưa cược gì ở ván này."

    async def place_bet(self, interaction: discord.Interaction, round_id: int, animal: str, raw: str) -> None:
        amount = None if is_all(raw) else parse_amount(raw)
        res = await self.store.place_bet(round_id, interaction.user.id, animal, amount, min_bet=config.MIN_BET, max_bet=config.MAX_BET)
        table = self.tables.get(interaction.guild_id or 0)
        if table is not None:
            table.dirty = True
        mine = await self.store.my_bets(round_id, interaction.user.id)
        embed = ui.success(f"Đã cược **{money(res.added)}** vào {label(animal)} (ván #{self.shown(interaction.guild_id or 0, round_id)}).", title="🎲 Đặt cược thành công", fields=[
            ("Cược của bạn ở ván này", self._mine_lines(mine), False),
            ("Tổng cược", f"**{money(res.user_total)}**", True), ("💵 Tiền mặt còn lại", f"**{money(res.cash)}**", True)])
        await self.reply(interaction, ui.author(embed, interaction.user))

    async def show_mine(self, interaction: discord.Interaction) -> None:
        table = self.tables.get(interaction.guild_id or 0)
        if table is None or not table.round_id:
            raise BankError("Bàn Bầu Cua chưa chạy.")
        mine = await self.store.my_bets(table.round_id, interaction.user.id)
        embed = ui.info(self._mine_lines(mine), title=f"📋 Cược của bạn — ván #{table.no}",
                        fields=[("Tổng cược", f"**{money(sum(mine.values()))}**", True)] if mine else ())
        await self.reply(interaction, ui.author(embed, interaction.user))

    # -- nhà cái ------------------------------------------------------------------------------------------------
    async def house_embed(self, interaction: discord.Interaction, view: Optional[HouseView] = None, note: str = "") -> discord.Embed:
        table = self.tables.get(interaction.guild_id or 0)
        if table is None or not table.round_id:
            return ui.warning("Bàn Bầu Cua chưa chạy ở máy chủ này. Admin dùng `/baucua_batdau`.", title="🎛️ Bảng nhà cái Bầu Cua")
        totals = await self.store.totals(table.round_id)
        bets = {a: s for a, (_, s) in totals.items()}
        mode, _ = await self.store.get_force(table.round_id)
        phase = {"open": "đang nhận cược", "locked": "đã khóa, đang lắc", "result": "đã có kết quả, chờ ván mới", "idle": "—"}[table.phase]
        if mode == "auto":
            state = "🔴 Đang bẻ: **nhà cái ăn nhiều nhất** (bot chọn lúc chốt)"
        elif mode:
            state = f"🔴 Đang bẻ: **{faces_text(parse_faces(mode))}**"
        else:
            state = "Chưa bẻ (kết quả ngẫu nhiên)"
        lines = [note] if note else []
        lines += [f"Ván **#{table.no}** · {phase}", state]
        pot = sum(bets.values())
        if view is not None and all(view.faces):
            pay = payout_total(tuple(view.faces), bets)
            lines.append(f"Đã chọn: **{faces_text(view.faces)}** → trả **{money(pay)}** (nhà cái {'lời' if pot >= pay else 'lỗ'} **{money(abs(pot - pay))}**)")
        elif view is not None and any(view.faces):
            lines.append("Đã chọn: " + " · ".join(label(f) if f else "…" for f in view.faces))
        if pot:
            best = best_for_house(bets)
            lines.append(f"Ăn nhiều nhất: **{faces_text(best)}** → trả {money(payout_total(best, bets))}")
        embed = ui.make("🎛️ Bảng nhà cái Bầu Cua", "\n".join(lines), color=ui.RED, fields=self._totals_fields(totals))
        embed.add_field(name="Lưu ý", value="Bẻ được tới hết lúc lắc. Chỉ bạn thấy bảng này; mỗi lần bấm đều kiểm tra lại role Nhà Cái.", inline=False)
        return embed

    async def house_pick(self, interaction: discord.Interaction, view: HouseView, index: int, animal: str) -> None:
        if animal not in ANIMALS:
            raise BankError("Con không hợp lệ.")
        view.faces[index] = animal
        await self.reply(interaction, await self.house_embed(interaction, view), view=view, edit=True)

    async def house_force(self, interaction: discord.Interaction, view: HouseView, mode: Optional[str]) -> None:
        table = self.tables.get(interaction.guild_id or 0)
        if table is None or not table.round_id:
            raise BankError("Bàn Bầu Cua chưa chạy.")
        if mode == "faces":
            if not all(view.faces):
                raise BankError("Hãy chọn đủ 3 con ở 3 ô phía trên trước khi bẻ.")
            mode = ",".join(view.faces)  # type: ignore[arg-type]
        await self.store.set_force(table.round_id, mode, interaction.user.id)
        if mode == "auto":
            text, log_text = f"✅ Đã bẻ ván #{table.no}: nhà cái ăn nhiều nhất.", "nhà cái ăn nhiều nhất"
        elif mode:
            text, log_text = f"✅ Đã bẻ ván #{table.no} ra **{faces_text(parse_faces(mode))}**.", faces_text(parse_faces(mode))
        else:
            text, log_text = f"✅ Đã bỏ bẻ ván #{table.no}.", ""
        await self.reply(interaction, await self.house_embed(interaction, view, text), view=view, edit=True)
        await self.log_to(interaction.guild_id, ui.make(
            "🎛️ Nhà cái bẻ Bầu Cua" if mode else "🎛️ Nhà cái bỏ bẻ Bầu Cua",
            f"{interaction.user.mention} · ván #{table.no}" + (f" → **{log_text}**" if mode else ""), color=ui.RED))

    async def house_refresh(self, interaction: discord.Interaction, view: HouseView) -> None:
        await self.reply(interaction, await self.house_embed(interaction, view), view=view, edit=True)

    @app_commands.command(name="baucuapanel", description="(Chỉ role Nhà Cái) Bảng riêng để chỉnh kết quả Bầu Cua.")
    @app_commands.guild_only()
    async def cmd_panel(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            if not await self.is_house(interaction):
                raise BankError("Chỉ người có role Nhà Cái mới dùng được lệnh này.")
            view = HouseView(self, interaction.user.id)
            await self.reply(interaction, await self.house_embed(interaction, view), view=view)
        await self.guard(interaction, work)

    # -- mở / dừng bàn ----------------------------------------------------------------------------------------------
    @app_commands.command(name="baucua_batdau", description="(Admin) Mở bàn Bầu Cua chạy liên tục ở một kênh.")
    @app_commands.describe(kenh="Kênh đặt bàn (mặc định: kênh hiện tại)")
    @app_commands.guild_only()
    async def cmd_batdau(self, interaction: discord.Interaction, kenh: Optional[discord.TextChannel] = None) -> None:
        async def work() -> None:
            if not self.is_admin(interaction):
                raise BankError("Chỉ admin hoặc quản trị viên mới dùng được lệnh này.")
            channel = kenh or interaction.channel
            running = self.tables.get(interaction.guild_id)
            if running is not None:
                raise BankError(f"Bàn Bầu Cua đang chạy ở <#{running.channel_id}>. Dùng `/baucua_dung` trước nếu muốn đổi kênh.")
            perms = channel.permissions_for(interaction.guild.me)
            if not (perms.send_messages and perms.embed_links and perms.attach_files):
                raise BankError(f"Bot cần quyền **Gửi tin nhắn, Nhúng liên kết, Đính kèm tệp** ở <#{channel.id}>.")
            gid = interaction.guild_id
            await self.bank.set_setting(gid, self.KEY_CHANNEL, str(channel.id))
            await self.bank.set_setting(gid, self.KEY_MSG, None)
            await self.bank.set_setting(gid, self.KEY_CAU, None)
            self.start_table(Table(gid, channel.id))
            await self.reply(interaction, ui.success(f"Đã mở bàn Bầu Cua ở <#{channel.id}>. Dùng `/baucua_dung` để dừng."))
        await self.guard(interaction, work)

    @app_commands.command(name="baucua_dung", description="(Admin) Dừng bàn Bầu Cua sau khi ván hiện tại kết thúc.")
    @app_commands.guild_only()
    async def cmd_dung(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            if not self.is_admin(interaction):
                raise BankError("Chỉ admin hoặc quản trị viên mới dùng được lệnh này.")
            table = self.tables.get(interaction.guild_id)
            if table is None:
                raise BankError("Bàn Bầu Cua đang không chạy.")
            table.stop = True
            await self.bank.set_setting(interaction.guild_id, self.KEY_CHANNEL, None)
            await self.reply(interaction, ui.success("Bàn sẽ dừng sau khi ván hiện tại có kết quả (cược đã đặt vẫn được trả thưởng bình thường)."))
        await self.guard(interaction, work)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(BauCua(bot))
