"""Luật Bầu Cua thuần túy (không phụ thuộc discord/db).

6 con: Hươu, Bầu, Gà, Cá, Cua, Tôm. Mỗi ván tung 3 xúc xắc (mỗi xúc xắc rơi vào một con).
Cược một con: không ra thì mất cược; ra k lần (k = 1..3) thì nhận lại cược + k lần cược, tức tổng cược × (1 + k).
"""
from __future__ import annotations

import itertools
import random
from typing import Mapping, Optional, Sequence

ANIMALS = ("huou", "bau", "ga", "ca", "cua", "tom")
NAMES = {"huou": "Hươu", "bau": "Bầu", "ga": "Gà", "ca": "Cá", "cua": "Cua", "tom": "Tôm"}


def roll(rng: Optional[random.Random] = None) -> tuple[str, str, str]:
    r = rng or random
    return r.choice(ANIMALS), r.choice(ANIMALS), r.choice(ANIMALS)


def multiplier(dice: Sequence[str], animal: str) -> int:
    """Hệ số nhân trên tiền cược: 0 nếu không ra, ngược lại 1 + số xúc xắc ra con đó."""
    k = sum(1 for d in dice if d == animal)
    return 1 + k if k else 0


def payout_total(dice: Sequence[str], bets: Mapping[str, int]) -> int:
    """Tổng tiền nhà cái phải trả (gồm cả tiền cược trả lại) nếu ra `dice`, với tổng cược theo từng con."""
    return sum(amount * multiplier(dice, animal) for animal, amount in bets.items())


def best_for_house(bets: Mapping[str, int], rng: Optional[random.Random] = None) -> tuple[str, str, str]:
    """Kết quả khiến nhà cái trả ít nhất (nhiều combo bằng nhau thì chọn ngẫu nhiên trong số đó)."""
    best, pool = None, []
    for dice in itertools.product(ANIMALS, repeat=3):
        cost = payout_total(dice, bets)
        if best is None or cost < best:
            best, pool = cost, [dice]
        elif cost == best:
            pool.append(dice)
    return (rng or random).choice(pool)


def parse_faces(text: str) -> tuple[str, str, str]:
    """'ga,ca,cua' → ('ga','ca','cua'); ném ValueError nếu sai."""
    faces = tuple(text.split(","))
    if len(faces) != 3 or any(f not in ANIMALS for f in faces):
        raise ValueError(f"Kết quả không hợp lệ: {text!r}")
    return faces  # type: ignore[return-value]
