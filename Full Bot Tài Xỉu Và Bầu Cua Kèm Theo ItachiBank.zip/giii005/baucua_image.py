"""Ảnh cho bàn Bầu Cua. Dùng ảnh bàn Bầu Cua do chủ bot cung cấp (taixiu_assets/baucua_board.jpg):
  * ảnh cược   = nguyên tấm bàn 6 ô;
  * ảnh lắc    = bàn làm tối + bát úp đang lắc;
  * ảnh kết quả = 3 ô con vật được cắt tròn từ chính tấm ảnh đó.
Thiếu file ảnh thì bot vẫn chạy: ảnh cược/lắc dùng nền màu, ảnh kết quả hiện tên các con.
"""
from __future__ import annotations

import io
from pathlib import Path
from typing import Optional, Sequence

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter

from baucua_logic import ANIMALS, NAMES
from taixiu_image import GOLD, GOLD_DARK, SS, _bowl, _lerp, _text_center

ASSET = Path(__file__).resolve().parent / "taixiu_assets" / "baucua_board.jpg"
W, H = 960, 420
# Ô của từng con trong ảnh bàn (trái, trên, phải, dưới), theo thứ tự ANIMALS: Hươu Bầu Gà / Cá Cua Tôm
TILE_BOXES = {
    "huou": (51, 56, 269, 270), "bau": (275, 56, 487, 270), "ga": (490, 56, 700, 270),
    "ca": (51, 277, 269, 489), "cua": (275, 277, 487, 489), "tom": (490, 277, 700, 489),
}
RED_TOP, RED_BOTTOM = (150, 18, 28), (70, 6, 14)
_board_cache: Optional[Image.Image] = None


def _board() -> Optional[Image.Image]:
    global _board_cache
    if _board_cache is None and ASSET.exists():
        _board_cache = Image.open(ASSET).convert("RGB")
    return _board_cache


def _png(img: Image.Image, fmt: str = "PNG") -> bytes:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, fmt, **({"quality": 90} if fmt == "JPEG" else {"optimize": True}))
    return buf.getvalue()


def _background(w: int, h: int) -> Image.Image:
    img = Image.new("RGB", (w, h))
    px = ImageDraw.Draw(img)
    for y in range(h):
        px.line([(0, y), (w, y)], fill=_lerp(RED_TOP, RED_BOTTOM, y / h))
    d = ImageDraw.Draw(img)
    for inset, width, color in ((14, 5, GOLD), (26, 2, GOLD_DARK)):
        d.rounded_rectangle((inset * SS, inset * SS, w - inset * SS, h - inset * SS), radius=34 * SS, outline=color, width=width * SS)
    return img


def board_image() -> bytes:
    """Ảnh phần cược: nguyên tấm bàn Bầu Cua."""
    board = _board()
    if board is None:
        img = _background(W * SS, H * SS).resize((W, H), Image.LANCZOS)
        _text_center_small(img, "BẦU CUA")
        return _png(img)
    return _png(board, "JPEG")


def _text_center_small(img: Image.Image, text: str) -> None:
    big = img.resize((img.width * SS, img.height * SS))
    _text_center(big, (img.width / 2, img.height / 2), text, 60, GOLD, stroke=3, stroke_fill=(70, 40, 0))
    img.paste(big.resize(img.size, Image.LANCZOS))


def shaking_image() -> bytes:
    """Bàn tối đi + bát úp đang lắc ở giữa."""
    board = _board()
    if board is None:
        base = _background(W * SS, H * SS)
    else:
        base = ImageEnhance.Brightness(board).enhance(0.42).resize((board.width * SS, board.height * SS), Image.LANCZOS)
    w, h = base.size[0] // SS, base.size[1] // SS
    for cx_off, tilt in ((0, -9),):
        _bowl(base, (w / 2 + cx_off, h * 0.56), int(w * 0.34), tilt=tilt)
    _text_center(base, (w / 2, h * 0.14), "ĐANG LẮC...", int(h * 0.1), GOLD, stroke=3, stroke_fill=(70, 40, 0))
    return _png(base.resize((w, h), Image.LANCZOS))


def _medallion(animal: str, diameter: int) -> Image.Image:
    """Cắt tròn ô của `animal` từ ảnh bàn (bỏ phần góc/xúc xắc nhỏ trong ảnh gốc)."""
    board = _board()
    d = diameter * SS
    if board is None:
        tile = Image.new("RGB", (d, d), (245, 238, 222))
        _text_center(tile, (diameter / 2, diameter / 2), NAMES[animal], int(diameter * 0.22), (150, 18, 28))
    else:
        l, t, r, b = TILE_BOXES[animal]
        cx, cy, rad = (l + r) / 2, (t + b) / 2, min(r - l, b - t) / 2 - 7
        tile = board.crop((int(cx - rad), int(cy - rad), int(cx + rad), int(cy + rad))).resize((d, d), Image.LANCZOS)
    mask = Image.new("L", (d * 2, d * 2), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, d * 2 - 1, d * 2 - 1), fill=255)
    out = Image.new("RGBA", (d, d), (0, 0, 0, 0))
    out.paste(tile, (0, 0), mask.resize((d, d), Image.LANCZOS))
    return out


def result_image(dice: Sequence[str]) -> bytes:
    """Ba ô con vật rơi ra + tên."""
    img = _background(W * SS, H * SS)
    _text_center(img, (W / 2, 70), "BẦU CUA", 56, GOLD, stroke=3, stroke_fill=(70, 40, 0))
    _text_center(img, (W / 2, 118), "KẾT QUẢ", 21, (255, 235, 225))
    size = 190
    for cx, animal in zip((220, 480, 740), dice):
        shadow = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(shadow).ellipse(((cx - size * 0.5) * SS, (232 + size * 0.40) * SS, (cx + size * 0.5) * SS, (232 + size * 0.62) * SS),
                                       fill=(0, 0, 0, 140))
        shadow = shadow.filter(ImageFilter.GaussianBlur(12 * SS))
        img.paste(shadow, (0, 0), shadow)
        ring = (size + 12) * SS
        ImageDraw.Draw(img).ellipse(((cx - ring / SS / 2) * SS, (232 - ring / SS / 2) * SS, (cx + ring / SS / 2) * SS, (232 + ring / SS / 2) * SS),
                                    fill=GOLD)
        med = _medallion(animal, size)
        img.paste(med, (int(cx * SS - med.width / 2), int(232 * SS - med.height / 2)), med)
        _text_center(img, (cx, 232 + size / 2 + 26), NAMES[animal], 24, (255, 245, 230), stroke=2, stroke_fill=(60, 0, 8))
    return _png(img.resize((W, H), Image.LANCZOS))


if __name__ == "__main__":      # xem thử: python baucua_image.py
    for name, data in (("bc_board.jpg", board_image()), ("bc_shaking.png", shaking_image()),
                       ("bc_result.png", result_image(("cua", "ca", "ga")))):
        Path(name).write_bytes(data)
        print("đã ghi", name, len(data), "byte")
