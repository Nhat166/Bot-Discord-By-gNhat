"""Luật Tài Xỉu thuần túy (không phụ thuộc discord/db): phân loại tổng điểm và tung xúc xắc."""
from __future__ import annotations

import random
from typing import Optional, Sequence

TAI, XIU = "tai", "xiu"
SIDE_NAMES = {TAI: "TÀI", XIU: "XỈU"}
TAI_MIN = 11     # tổng 11–18 là Tài, 3–10 là Xỉu


def side_of(total: int) -> str:
    return TAI if total >= TAI_MIN else XIU


def is_triple(dice: Sequence[int]) -> bool:
    return len(set(dice)) == 1


def roll(rng: Optional[random.Random] = None) -> tuple[int, int, int]:
    r = rng or random
    return r.randint(1, 6), r.randint(1, 6), r.randint(1, 6)


def roll_for_side(side: str, *, avoid_triple: bool = False, rng: Optional[random.Random] = None) -> tuple[int, int, int]:
    """Tung xúc xắc cho tới khi ra đúng bên `side` (dùng khi nhà cái bẻ cầu)."""
    if side not in (TAI, XIU):
        raise ValueError(f"Bên không hợp lệ: {side!r}")
    while True:
        dice = roll(rng)
        if side_of(sum(dice)) == side and not (avoid_triple and is_triple(dice)):
            return dice
