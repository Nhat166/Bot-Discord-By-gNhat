"""Bàn Tài Xỉu liên tục trong một kênh: mỗi ván 40 giây cược → khóa + lắc 3 giây → hiện kết quả 6 giây → ván mới.

Lệnh:
  /taixiu_batdau [kenh]   (admin / quản trị viên) mở bàn ở kênh
  /taixiu_dung            (admin / quản trị viên) dừng bàn sau ván hiện tại
  /nhacai                 (chỉ người có role Nhà Cái) bảng riêng với nút Bẻ Tài / Bẻ Xỉu

Tiền dùng chung ví ItachiBank (cùng cơ sở dữ liệu). Role Nhà Cái lấy từ `/bankconfig rolenhacai` của ItachiBank.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

import ibank_ui as ui
import taixiu_config as config
import taixiu_image as images
from game_base import MISSING, NO_PING, GameBase, Table, fmt_vn, money
from ibank_bank import BankError, BankStore
from ibank_database import db
from ibank_money import is_all, parse_amount
from ibank_store import WalletStore
from taixiu_logic import SIDE_NAMES, TAI, XIU, roll, roll_for_side
from taixiu_store import Settlement, TaiXiuStore, Totals

log = logging.getLogger("taixiu.cog")

POLL_SECONDS = 1.0         # nhịp kiểm tra khi chờ hết giờ cược
EDIT_EVERY = 4.0           # tối thiểu giây giữa hai lần cập nhật tổng cược (tránh bị Discord giới hạn tốc độ)
SIDE_ICON = {TAI: "🟢", XIU: "🔵"}
CAU_ICON = {TAI: "🔴", XIU: "🔵"}          # tin nhắn cầu: 🔴 Tài, 🔵 Xỉu


# ---------------------------------------------------------------------------
# Khung nhập và các nút
# ---------------------------------------------------------------------------
class BetModal(discord.ui.Modal):
    def __init__(self, cog: "TaiXiu", side: str, round_id: int) -> None:
        super().__init__(title=f"Cược {SIDE_NAMES[side]}", timeout=300)
        self.cog, self.side, self.round_id = cog, side, round_id
        self.amount = discord.ui.TextInput(label="Số tiền hoặc all = tất cả", placeholder="Ví dụ: 50000, 50k, 1.5tr, all",
                                           max_length=20, required=True)
        self.add_item(self.amount)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await self.cog.guard(interaction, lambda: self.cog.place_bet(interaction, self.round_id, self.side, self.amount.value))

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi bảng cược", exc_info=error)
        await self.cog.reply(interaction, ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))


class BetView(discord.ui.View):
    """Hai nút Tài / Xỉu dưới tin nhắn ván. Cố định (persistent) nên vẫn bấm được sau khi bot khởi động lại."""

    def __init__(self, cog: "TaiXiu") -> None:
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label="Tài", emoji="🟢", style=discord.ButtonStyle.success, custom_id="taixiu:tai")
    async def tai(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.open_bet(interaction, TAI))

    @discord.ui.button(label="Xỉu", emoji="🔵", style=discord.ButtonStyle.primary, custom_id="taixiu:xiu")
    async def xiu(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.open_bet(interaction, XIU))


class HouseView(discord.ui.View):
    """Bảng riêng (chỉ người bấm /nhacai thấy) của Nhà Cái. Mỗi lần bấm đều kiểm tra lại role."""

    def __init__(self, cog: "TaiXiu", user_id: int) -> None:
        super().__init__(timeout=300)
        self.cog, self.user_id = cog, user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Bảng này không phải của bạn.", ephemeral=True)
            return False
        if not await self.cog.is_house(interaction):       # đã bị gỡ role: ẩn nút, không cho dùng
            await interaction.response.edit_message(embed=ui.error("Bạn không còn role Nhà Cái nên không dùng được bảng này."), view=None)
            return False
        return True

    @discord.ui.button(label="Bẻ Tài", emoji="🔴", style=discord.ButtonStyle.danger)
    async def force_tai(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_force(interaction, TAI))

    @discord.ui.button(label="Bẻ Xỉu", emoji="🔴", style=discord.ButtonStyle.danger)
    async def force_xiu(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_force(interaction, XIU))

    @discord.ui.button(label="Bỏ bẻ", style=discord.ButtonStyle.secondary)
    async def clear(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_force(interaction, None))

    @discord.ui.button(label="Làm mới", emoji="🔄", style=discord.ButtonStyle.secondary)
    async def refresh(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.house_refresh(interaction))


# ---------------------------------------------------------------------------
# Cog
# ---------------------------------------------------------------------------
class TaiXiu(GameBase, commands.Cog):
    """Tài Xỉu bằng VNĐ dùng chung ví ItachiBank."""

    KEY_CHANNEL, KEY_MSG, KEY_CAU = "tx_channel", "tx_msg", "tx_cau"
    KEY_OFFSET, GAME_NAME = "tx_offset", "Tài Xỉu"
    REST_TITLE = "🎲 TÀI XỈU — BÀN TẠM NGHỈ"

    def rest_image(self):
        return ("tx_betting.png", self._betting_png)

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.wallets = WalletStore(db, config.STARTING_BALANCE)
        self.bank = BankStore(db, self.wallets)          # chỉ dùng để đọc/ghi cài đặt chung (role nhà cái, kênh log)
        self.store = TaiXiuStore(db, self.wallets)
        self.tables: dict[int, Table] = {}
        self.bet_view = BetView(self)
        self._resumed = False
        self._betting_png: Optional[bytes] = None
        self._shaking_png: Optional[bytes] = None

    async def cog_load(self) -> None:
        await self.store.setup()
        rounds, refunded = await self.store.refund_unfinished()
        if rounds:
            log.warning("Đã hoàn %s VNĐ cược của %d ván dang dở (bot dừng giữa chừng).", f"{refunded:,}", rounds)
        self._betting_png, self._shaking_png = await asyncio.gather(asyncio.to_thread(images.betting_image),
                                                                    asyncio.to_thread(images.shaking_image))
        self.bot.add_view(self.bet_view)

    async def cog_unload(self) -> None:
        for table in self.tables.values():
            if table.task:
                table.task.cancel()

    @commands.Cog.listener()
    async def on_ready(self) -> None:
        if self._resumed:
            return
        self._resumed = True
        await self.resume_tables()

    # -- bảng hiển thị ---------------------------------------------------------------------------------
    @staticmethod
    def _totals_fields(totals: Totals) -> list[tuple[str, str, bool]]:
        return [(f"{SIDE_ICON[TAI]} TÀI (11–18)", f"{totals.tai_count} người\n**{money(totals.tai_sum)}**", True),
                (f"{SIDE_ICON[XIU]} XỈU (3–10)", f"{totals.xiu_count} người\n**{money(totals.xiu_sum)}**", True)]

    def betting_embed(self, table: Table, totals: Totals, lock_unix: int) -> discord.Embed:
        extra = "\n⚠️ Ra **bộ ba** thì nhà cái ăn hết." if config.TRIPLE_HOUSE else ""
        return ui.make(f"🎲 TÀI XỈU — VÁN #{table.no}",
                       "Bấm **Tài** hoặc **Xỉu** bên dưới rồi nhập số tiền cược (gõ `all` = tất cả).\n"
                       f"⏳ Khóa cược <t:{lock_unix}:R>\n💰 Thắng nhận lại **gấp đôi** tiền cược." + extra
                       + f"\n\n⏰ Ván bắt đầu: **{fmt_vn(table.started)}**",
                       color=ui.GOLD, fields=self._totals_fields(totals))

    def locked_embed(self, table: Table, totals: Totals) -> discord.Embed:
        return ui.make("TÀI XỈU — ĐÃ KHÓA CƯỢC",
                       "🔒 **Đã hết thời gian cược!**\n🎲 Đang lắc xúc xắc...\n\n"
                       f"⏰ {fmt_vn(table.started)}", color=ui.RED, fields=self._totals_fields(totals))

    def result_embed(self, table: Table, st: Settlement) -> discord.Embed:
        name = SIDE_NAMES[st.side]
        lines = [f"🎲 **{st.dice[0]} · {st.dice[1]} · {st.dice[2]}** = **{st.total}**", f"{SIDE_ICON[st.side]} Kết quả: **{name}**"]
        if st.triple:
            lines.append("🎰 **Bộ ba!**" + (" Nhà cái ăn hết." if st.house_took_all else ""))
        lines.append(f"\n⏰ {fmt_vn(table.started)}")
        fields: list[tuple[str, str, bool]] = []
        if st.winners:
            top = "\n".join(f"<@{w.user_id}> **+{money(w.profit)}**" for w in st.winners[:5])
            more = f"\n… và {len(st.winners) - 5} người nữa" if len(st.winners) > 5 else ""
            paid = sum(w.payout for w in st.winners)
            fields.append((f"🏆 Thắng ({len(st.winners)} người)", f"{top}{more}\nTổng trả thưởng: **{money(paid)}**", False))
        if st.losers:
            fields.append((f"💸 Thua ({st.losers} người)", f"Tổng: **{money(st.lost_sum)}**", False))
        if not st.winners and not st.losers:
            fields.append(("Ván này", "Không có ai đặt cược.", False))
        return ui.make(f"🎲 TÀI XỈU — KẾT QUẢ VÁN #{table.no}", "\n".join(lines),
                       color=0x2F9E44 if st.side == TAI else 0x2B6CB0, fields=fields)

    async def cau_embed(self, table: Table) -> discord.Embed:
        results = await self.store.recent(table.guild_id, config.HISTORY_SIZE)
        if not results:
            return ui.make("📊 CẦU TÀI XỈU", "Chưa có ván nào.", color=ui.GREY)
        row = " ".join(CAU_ICON[r.side] for r in reversed(results))          # cũ → mới, từ trái sang phải
        stats = await self.store.bet_stats([r.id for r in results])
        rounds = {TAI: sum(1 for r in results if r.side == TAI)}
        rounds[XIU] = len(results) - rounds[TAI]

        def line(side: str) -> str:
            people, total = stats[side]
            return f"{CAU_ICON[side]} **{SIDE_NAMES[side]}**: {rounds[side]} ván · {people} lượt cược · {money(total)}"
        return ui.make(f"📊 CẦU TÀI XỈU — {len(results)} ván gần nhất", color=ui.BRAND, fields=[
            ("Kết quả gần đây", row, False),
            ("Thống kê", f"{line(XIU)}\n{line(TAI)}", False),
            ("Chú thích", f"{CAU_ICON[TAI]} = **TÀI** (11–18)   ·   {CAU_ICON[XIU]} = **XỈU** (3–10)\n_Cũ → mới, trái → phải_", False),
            ("⏰", fmt_vn(datetime.now(timezone.utc)), False),
        ])

    # -- vòng chơi ------------------------------------------------------------------------------------------
    async def _play_round(self, table: Table) -> None:
        # 1. mở ván, nhận cược
        table.round_id, table.started = await self.store.create_round(table.guild_id, table.channel_id)
        table.phase, table.dirty = "open", False
        rid = table.round_id
        lock_unix = table.lock_unix = int(time.time()) + config.BET_SECONDS
        deadline = time.monotonic() + config.BET_SECONDS
        await self._publish(table, "message", self.betting_embed(table, await self.store.totals(rid), lock_unix),
                            image=("tx_betting.png", self._betting_png), view=self.bet_view)
        last_edit = time.monotonic()
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            await asyncio.sleep(min(POLL_SECONDS, remaining))
            if table.dirty and time.monotonic() - last_edit >= EDIT_EVERY and deadline - time.monotonic() > 1:
                table.dirty, last_edit = False, time.monotonic()
                await self._publish(table, "message", self.betting_embed(table, await self.store.totals(rid), lock_unix),
                                    image=("tx_betting.png", None))
        # 2. khóa cược, lắc
        await self.store.lock_round(rid)
        table.phase = "locked"
        totals = await self.store.totals(rid)
        await self._publish(table, "message", self.locked_embed(table, totals), image=("tx_shaking.png", self._shaking_png), view=None)
        await asyncio.sleep(config.SHAKE_SECONDS)
        # 3. chốt kết quả (nhà cái được bẻ cho tới lúc này), trả thưởng
        forced, _ = await self.store.get_force(rid)
        dice = roll_for_side(forced, avoid_triple=config.TRIPLE_HOUSE) if forced else roll()
        settlement = await self.store.settle(rid, dice, triple_house=config.TRIPLE_HOUSE)
        table.phase = "result"
        png = await asyncio.to_thread(images.result_image, dice, settlement.side)
        await self._publish(table, "message", self.result_embed(table, settlement), image=(f"tx_result_{rid}.png", png), view=None)
        await self._publish(table, "cau", await self.cau_embed(table))
        await asyncio.sleep(config.RESULT_SECONDS)

    async def refresh_open(self, table: Table) -> None:
        await self._publish(table, "message", self.betting_embed(table, await self.store.totals(table.round_id), table.lock_unix),
                            image=("tx_betting.png", None))

    # -- cược -------------------------------------------------------------------------------------------------
    async def open_bet(self, interaction: discord.Interaction, side: str) -> None:
        table = self.tables.get(interaction.guild_id or 0)
        if table is None or table.phase != "open":
            raise BankError("Ván này đã khóa cược, hãy chờ ván sau.")
        await interaction.response.send_modal(BetModal(self, side, table.round_id))

    async def place_bet(self, interaction: discord.Interaction, round_id: int, side: str, raw: str) -> None:
        amount = None if is_all(raw) else parse_amount(raw)
        res = await self.store.place_bet(round_id, interaction.user.id, side, amount, min_bet=config.MIN_BET, max_bet=config.MAX_BET)
        table = self.tables.get(interaction.guild_id or 0)
        if table is not None:
            table.dirty = True
        embed = ui.success(f"Đã cược **{money(res.added)}** vào {SIDE_ICON[side]} **{SIDE_NAMES[side]}** (ván #{self.shown(interaction.guild_id or 0, round_id)}).",
                           title="🎲 Đặt cược thành công", fields=[
                               ("Tổng cược của bạn ván này", f"**{money(res.total)}**", True),
                               ("💵 Tiền mặt còn lại", f"**{money(res.cash)}**", True)])
        await self.reply(interaction, ui.author(embed, interaction.user))

    # -- nhà cái ----------------------------------------------------------------------------------------------
    async def house_embed(self, interaction: discord.Interaction, note: str = "") -> discord.Embed:
        table = self.tables.get(interaction.guild_id or 0)
        if table is None or not table.round_id:
            return ui.warning("Bàn tài xỉu chưa chạy ở máy chủ này. Admin dùng `/taixiu_batdau`.", title="🎛️ Bảng nhà cái")
        totals = await self.store.totals(table.round_id)
        forced, _ = await self.store.get_force(table.round_id)
        phase = {"open": "đang nhận cược", "locked": "đã khóa, đang lắc", "result": "đã có kết quả, chờ ván mới", "idle": "—"}[table.phase]
        state = f"{SIDE_ICON[forced]} Đang bẻ **{SIDE_NAMES[forced]}**" if forced else "Chưa bẻ (kết quả ngẫu nhiên)"
        embed = ui.make("🎛️ Bảng nhà cái", (note + "\n\n" if note else "") + f"Ván **#{table.no}** · {phase}\n{state}",
                        color=ui.RED, fields=self._totals_fields(totals))
        embed.add_field(name="Lưu ý", value="Bẻ được tới hết lúc lắc. Chỉ bạn thấy bảng này; mỗi lần bấm đều kiểm tra lại role Nhà Cái.", inline=False)
        return embed

    async def house_force(self, interaction: discord.Interaction, side: Optional[str]) -> None:
        table = self.tables.get(interaction.guild_id or 0)
        if table is None or not table.round_id:
            raise BankError("Bàn tài xỉu chưa chạy.")
        await self.store.set_force(table.round_id, side, interaction.user.id)
        text = f"✅ Đã bẻ ván #{table.no} ra **{SIDE_NAMES[side]}**." if side else f"✅ Đã bỏ bẻ ván #{table.no}."
        await self.reply(interaction, await self.house_embed(interaction, text), view=HouseView(self, interaction.user.id), edit=True)
        who = interaction.user.mention
        await self.log_to(interaction.guild_id, ui.make(
            "🎛️ Nhà cái bẻ cầu" if side else "🎛️ Nhà cái bỏ bẻ", f"{who} · ván #{table.no}" + (f" → **{SIDE_NAMES[side]}**" if side else ""),
            color=ui.RED))

    async def house_refresh(self, interaction: discord.Interaction) -> None:
        await self.reply(interaction, await self.house_embed(interaction), view=HouseView(self, interaction.user.id), edit=True)

    @app_commands.command(name="nhacai", description="(Chỉ role Nhà Cái) Bảng riêng để bẻ kết quả Tài / Xỉu.")
    @app_commands.guild_only()
    async def cmd_nhacai(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            if not await self.is_house(interaction):
                raise BankError("Chỉ người có role Nhà Cái mới dùng được lệnh này.")
            await self.reply(interaction, await self.house_embed(interaction), view=HouseView(self, interaction.user.id))
        await self.guard(interaction, work)

    # -- mở / dừng bàn ------------------------------------------------------------------------------------------
    @app_commands.command(name="taixiu_batdau", description="(Admin) Mở bàn Tài Xỉu chạy liên tục ở một kênh.")
    @app_commands.describe(kenh="Kênh đặt bàn (mặc định: kênh hiện tại)")
    @app_commands.guild_only()
    async def cmd_batdau(self, interaction: discord.Interaction, kenh: Optional[discord.TextChannel] = None) -> None:
        async def work() -> None:
            if not self.is_admin(interaction):
                raise BankError("Chỉ admin hoặc quản trị viên mới dùng được lệnh này.")
            channel = kenh or interaction.channel
            running = self.tables.get(interaction.guild_id)
            if running is not None:
                raise BankError(f"Bàn đang chạy ở <#{running.channel_id}>. Dùng `/taixiu_dung` trước nếu muốn đổi kênh.")
            perms = channel.permissions_for(interaction.guild.me)
            if not (perms.send_messages and perms.embed_links and perms.attach_files):
                raise BankError(f"Bot cần quyền **Gửi tin nhắn, Nhúng liên kết, Đính kèm tệp** ở <#{channel.id}>.")
            gid = interaction.guild_id
            await self.bank.set_setting(gid, self.KEY_CHANNEL, str(channel.id))
            await self.bank.set_setting(gid, self.KEY_MSG, None)
            await self.bank.set_setting(gid, self.KEY_CAU, None)
            self.start_table(Table(gid, channel.id))
            await self.reply(interaction, ui.success(f"Đã mở bàn Tài Xỉu ở <#{channel.id}>. Dùng `/taixiu_dung` để dừng."))
        await self.guard(interaction, work)

    @app_commands.command(name="taixiu_dung", description="(Admin) Dừng bàn Tài Xỉu sau khi ván hiện tại kết thúc.")
    @app_commands.guild_only()
    async def cmd_dung(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            if not self.is_admin(interaction):
                raise BankError("Chỉ admin hoặc quản trị viên mới dùng được lệnh này.")
            table = self.tables.get(interaction.guild_id)
            if table is None:
                raise BankError("Bàn Tài Xỉu đang không chạy.")
            table.stop = True
            await self.bank.set_setting(interaction.guild_id, self.KEY_CHANNEL, None)
            await self.reply(interaction, ui.success("Bàn sẽ dừng sau khi ván hiện tại có kết quả (cược đã đặt vẫn được trả thưởng bình thường)."))
        await self.guard(interaction, work)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(TaiXiu(bot))
