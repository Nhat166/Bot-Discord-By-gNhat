"""Các lệnh / của ItachiBank: ví, ngân hàng, vay tiền, thu/thêm tiền.

  /vi  /daily  /lichsu  /top  /tao  /bank  /bankinfo  /vay  /checkvay  /tratien  /thutien  /addmoney  /bankconfig

Mọi bảng đều có dòng chân "by: giii•" (xem ibank_ui). Số tiền nhập được dạng 50000, 50k, 1.5tr, 2 tỷ (xem ibank_money).
"""
from __future__ import annotations

import logging
import random
from datetime import datetime, timedelta, timezone
from typing import Awaitable, Callable, Optional

import discord
from discord import app_commands
from discord.ext import commands, tasks

import ibank_config as config
import ibank_ui as ui
from ibank_bank import Account, BankError, BankStore, CollectEvent, HistoryEntry, Loan, TransferResult
from ibank_database import db
from ibank_money import AmountError, format_vnd, is_all, parse_amount
from ibank_store import DailyCooldown, InsufficientFunds, WalletError, WalletStore, today_vn

log = logging.getLogger("ibank.cog")

NO_PING = discord.AllowedMentions.none()
VIEW_TIMEOUT = 180
SETTING_LOG_CHANNEL = "log_channel"
SETTING_BANKER_ROLE = "banker_role"
MAX_CHECKVAY_SHOWN = 5
HISTORY_PAGE = 10
HISTORY_LABELS = {
    "start": "🆕 Mở ví", "daily": "🎁 Nhận /daily", "deposit": "📥 Nộp tiền", "withdraw": "📤 Rút tiền",
    "transfer_out": "💸 Chuyển tiền", "transfer_in": "💰 Nhận tiền", "loan_out": "🤝 Cho vay", "loan_in": "📨 Vay tiền",
    "loan_repay": "💳 Trả nợ", "loan_repaid_in": "💵 Được trả nợ", "loan_auto": "⏰ Tự trừ nợ quá hạn",
    "admin_add": "➕ Nhà cái thêm tiền", "admin_take": "➖ Nhà cái thu tiền",
    "taixiu_bet": "🎲 Cược tài xỉu", "taixiu_win": "🏆 Thắng tài xỉu", "taixiu_refund": "↩️ Hoàn cược tài xỉu",
    "baucua_bet": "🎲 Cược bầu cua", "baucua_win": "🏆 Thắng bầu cua", "baucua_refund": "↩️ Hoàn cược bầu cua",
}


def money(amount: int) -> str:
    return format_vnd(amount)


def amount_or_all(raw: str, *, minimum: int = 1) -> Optional[int]:
    """Số tiền người dùng nhập; `all` / `tất cả` trả None (nghĩa là toàn bộ số tiền có)."""
    return None if is_all(raw) else parse_amount(raw, minimum=minimum)


def _unix(dt: datetime) -> int:
    return int(dt.replace(tzinfo=dt.tzinfo or timezone.utc).timestamp())


# ---------------------------------------------------------------------------
# Khung nhập và hộp chọn
# ---------------------------------------------------------------------------
Field = tuple[str, str, int, bool]   # (nhãn, gợi ý, độ dài tối đa, bắt buộc)


class BankModal(discord.ui.Modal):
    """Bảng nhập chung: các ô nhập rồi gọi handler(interaction, [giá trị các ô])."""

    def __init__(self, cog: "ItachiBank", title: str, fields: list[Field],
                 handler: Callable[[discord.Interaction, list[str]], Awaitable[None]]) -> None:
        super().__init__(title=title[:45], timeout=300)
        self.cog, self.handler = cog, handler
        self.inputs: list[discord.ui.TextInput] = []
        for label, placeholder, max_len, required in fields:
            item = discord.ui.TextInput(label=label[:45], placeholder=placeholder[:100], max_length=max_len,
                                        required=required)
            self.add_item(item)
            self.inputs.append(item)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        values = [item.value for item in self.inputs]
        await self.cog.guard(interaction, lambda: self.handler(interaction, values))

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        log.exception("Lỗi bảng nhập", exc_info=error)
        await self.cog.reply(interaction, ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))


class _OwnedView(discord.ui.View):
    def __init__(self, cog: "ItachiBank", user_id: int) -> None:
        super().__init__(timeout=VIEW_TIMEOUT)
        self.cog, self.user_id = cog, user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Bảng này không phải của bạn.", ephemeral=True)
            return False
        return True


class AccountPickView(_OwnedView):
    """Chọn một trong các tài khoản của mình rồi gọi then(interaction, số tài khoản)."""

    def __init__(self, cog: "ItachiBank", user_id: int, accounts: list[Account],
                 then: Callable[[discord.Interaction, str], Awaitable[None]]) -> None:
        super().__init__(cog, user_id)
        self.then = then
        select = discord.ui.Select(placeholder="Chọn tài khoản…", options=[
            discord.SelectOption(label=a.number, value=a.number, description=f"{a.holder} · {money(a.balance)}"[:100])
            for a in accounts[:25]])
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction) -> None:
        number = interaction.data["values"][0]
        await self.cog.guard(interaction, lambda: self.then(interaction, number))


class WalletView(_OwnedView):
    @discord.ui.button(label="Nhận /daily", emoji="🎁", style=discord.ButtonStyle.success)
    async def daily(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.daily_from_wallet(interaction))

    @discord.ui.button(label="Nộp vào tài khoản", emoji="🏦", style=discord.ButtonStyle.primary)
    async def deposit(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.start_account_action(interaction, "deposit", "wallet"))


class BankView(_OwnedView):
    def __init__(self, cog: "ItachiBank", user_id: int, number: str) -> None:
        super().__init__(cog, user_id)
        self.number = number

    @discord.ui.button(label="Nộp tiền", emoji="📥", style=discord.ButtonStyle.success)
    async def deposit(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.open_modal(interaction, "deposit", "bank", self.number))

    @discord.ui.button(label="Rút ra ví", emoji="📤", style=discord.ButtonStyle.secondary)
    async def withdraw(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.open_modal(interaction, "withdraw", "bank", self.number))

    @discord.ui.button(label="Chuyển tiền", emoji="💸", style=discord.ButtonStyle.primary)
    async def transfer(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.open_modal(interaction, "transfer", "bank", self.number))


class HistoryView(_OwnedView):
    """Nút Trước / Sau để lật trang lịch sử."""

    def __init__(self, cog: "ItachiBank", user_id: int, target: discord.abc.User, page: int, pages: int) -> None:
        super().__init__(cog, user_id)
        self.target, self.page = target, page
        self.prev_page.disabled = page <= 0
        self.next_page.disabled = page >= pages - 1

    @discord.ui.button(label="Trước", emoji="◀️", style=discord.ButtonStyle.secondary)
    async def prev_page(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.show_history(interaction, self.target, self.page - 1, edit=True))

    @discord.ui.button(label="Sau", emoji="▶️", style=discord.ButtonStyle.secondary)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.show_history(interaction, self.target, self.page + 1, edit=True))


class LoanDecisionView(discord.ui.View):
    """Người cho vay bấm Chấp nhận / Từ chối một đơn vay."""

    def __init__(self, cog: "ItachiBank", loan_id: int, lender_id: int) -> None:
        super().__init__(timeout=VIEW_TIMEOUT)
        self.cog, self.loan_id, self.lender_id = cog, loan_id, lender_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.lender_id:
            await interaction.response.send_message("Đơn vay này không gửi cho bạn.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Chấp nhận", emoji="✅", style=discord.ButtonStyle.success)
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.decide_loan(interaction, self.loan_id, True))

    @discord.ui.button(label="Từ chối", emoji="❌", style=discord.ButtonStyle.danger)
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.guard(interaction, lambda: self.cog.decide_loan(interaction, self.loan_id, False))


class LoanPickView(_OwnedView):
    """Chọn khoản nợ muốn trả (/tratien)."""

    def __init__(self, cog: "ItachiBank", user_id: int, loans: list[Loan]) -> None:
        super().__init__(cog, user_id)
        select = discord.ui.Select(placeholder="Chọn khoản nợ muốn trả…", options=[
            discord.SelectOption(label=f"#{ln.id} · còn nợ {money(ln.remaining)}"[:100], value=str(ln.id),
                                 description=f"Cho vay bởi {ln.lender_id}"[:100]) for ln in loans[:25]])
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction) -> None:
        loan_id = int(interaction.data["values"][0])
        await self.cog.guard(interaction, lambda: self.cog.open_repay_modal(interaction, loan_id))


# ---------------------------------------------------------------------------
# Cog
# ---------------------------------------------------------------------------
class ItachiBank(commands.Cog):
    """Ví, ngân hàng, vay tiền."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.wallets = WalletStore(db, config.STARTING_BALANCE)
        self.bank = BankStore(db, self.wallets)

    async def cog_load(self) -> None:
        self.collector.start()

    async def cog_unload(self) -> None:
        self.collector.cancel()

    # -- tiện ích ----------------------------------------------------------------------------------
    async def reply(self, interaction: discord.Interaction, embed: discord.Embed, *, view=discord.utils.MISSING,
                    ephemeral: bool = True, edit: bool = False) -> None:
        """Trả lời; edit=True thì sửa chính tin nhắn chứa nút vừa bấm (nếu có)."""
        kwargs: dict = {"embed": embed, "allowed_mentions": NO_PING}
        if edit and interaction.message is not None and not interaction.response.is_done():
            if view is not discord.utils.MISSING:
                kwargs["view"] = view
            await interaction.response.edit_message(**kwargs)
            return
        if view is not discord.utils.MISSING and view is not None:
            kwargs["view"] = view
        if interaction.response.is_done():
            await interaction.followup.send(ephemeral=ephemeral, **kwargs)
        else:
            await interaction.response.send_message(ephemeral=ephemeral, **kwargs)

    async def guard(self, interaction: discord.Interaction, work: Callable[[], Awaitable[None]]) -> None:
        try:
            await work()
        except DailyCooldown as exc:
            when = datetime.now(timezone.utc) + timedelta(seconds=exc.remaining)
            await self.reply(interaction, ui.warning_daily(_unix(when)))
        except InsufficientFunds as exc:
            await self.reply(interaction, ui.error(f"Không đủ tiền mặt: bạn có **{money(exc.cash)}**, cần **{money(exc.needed)}**."))
        except (WalletError, AmountError) as exc:
            await self.reply(interaction, ui.error(str(exc)))
        except discord.HTTPException as exc:
            log.warning("Lỗi Discord khi xử lý lệnh: %s", exc)
            await self._safe_error(interaction, "Discord báo lỗi, bạn thử lại sau nhé.")
        except Exception:  # noqa: BLE001
            log.exception("Lỗi không mong muốn")
            await self._safe_error(interaction, "Có lỗi không mong muốn. Bạn thử lại nhé.")

    async def _safe_error(self, interaction: discord.Interaction, text: str) -> None:
        try:
            await self.reply(interaction, ui.error(text))
        except discord.HTTPException:
            pass

    @staticmethod
    def check_age(member: discord.abc.User, who: str = "Bạn") -> None:
        """Chặn tài khoản mới tham gia (chống tạo tài khoản phụ gom tiền)."""
        days = config.MIN_MEMBER_AGE_DAYS
        if days <= 0:
            return
        joined = getattr(member, "joined_at", None) or getattr(member, "created_at", None)
        if joined is None:
            return
        if datetime.now(timezone.utc) - joined < timedelta(days=days):
            raise BankError(f"{who} cần ở trong máy chủ ít nhất **{days} ngày** mới dùng được chức năng này.")

    async def is_banker(self, interaction: discord.Interaction) -> bool:
        perms = interaction.permissions
        if perms.administrator or perms.manage_guild:
            return True
        role_id = await self.bank.get_setting(interaction.guild_id, SETTING_BANKER_ROLE)
        return bool(role_id) and any(r.id == int(role_id) for r in getattr(interaction.user, "roles", []))

    async def require_banker(self, interaction: discord.Interaction) -> None:
        if not await self.is_banker(interaction):
            raise BankError("Chỉ admin, quản trị viên hoặc role nhà cái mới dùng được lệnh này.")

    async def log_to(self, guild: Optional[discord.Guild], embed: discord.Embed) -> None:
        """Gửi bảng vào kênh log đã cấu hình (/bankconfig). Lỗi gửi không làm hỏng giao dịch."""
        if guild is None:
            return
        raw = await self.bank.get_setting(guild.id, SETTING_LOG_CHANNEL)
        channel = guild.get_channel(int(raw)) if raw else None
        if channel is None:
            return
        try:
            await channel.send(embed=embed, allowed_mentions=NO_PING)
        except (discord.Forbidden, discord.HTTPException) as exc:
            log.warning("Không gửi được log vào kênh %s: %s", raw, exc)

    async def dm(self, user_id: int, embed: discord.Embed) -> bool:
        try:
            user = self.bot.get_user(user_id) or await self.bot.fetch_user(user_id)
            await user.send(embed=embed, allowed_mentions=NO_PING)
            return True
        except (discord.Forbidden, discord.HTTPException):
            return False

    # -- bảng hiển thị ---------------------------------------------------------------------------------
    async def wallet_embed(self, user: discord.abc.User, note: Optional[str] = None) -> discord.Embed:
        wallet = await self.wallets.get(user.id)
        accounts = await self.bank.accounts_of(user.id)
        bank_total = sum(a.balance for a in accounts)
        claimed = wallet.last_daily == today_vn(self.wallets.clock())
        embed = ui.make("👛 Ví của bạn", note or "", fields=[
            ("💵 Tiền mặt", f"**{money(wallet.cash)}**", True),
            ("🏦 Trong ngân hàng", f"**{money(bank_total)}**\n{len(accounts)}/{config.MAX_ACCOUNTS} tài khoản", True),
            ("💳 Tiền nợ", f"**{money(wallet.debt)}**", True),
            ("📊 Tổng tài sản", f"**{money(wallet.cash + bank_total - wallet.debt)}**", True),
            ("🎁 /daily", "Hôm nay bạn đã nhận ✅" if claimed else "Hôm nay chưa nhận, bấm nút bên dưới!", True),
        ])
        return ui.author(embed, user)

    def bank_embed(self, account: Account, note: Optional[str] = None) -> discord.Embed:
        return ui.make("🏦 ItachiBank", note or "", fields=[
            ("Số tài khoản", f"`{account.number}`", True),
            ("Chủ tài khoản", account.holder, True),
            ("Số dư", f"**{money(account.balance)}**", True),
        ])

    @staticmethod
    def loan_embed(loan: Loan, title: str, color: int = ui.BRAND, note: str = "") -> discord.Embed:
        fields = [
            ("Người vay", f"<@{loan.borrower_id}>", True),
            ("Người cho vay", f"<@{loan.lender_id}>", True),
            ("Số tiền", f"**{money(loan.amount)}**", True),
            ("Thời hạn", f"{loan.days} ngày", True),
        ]
        if loan.status == "active" and loan.due:
            fields.append(("Hạn trả", f"<t:{_unix(loan.due)}:R>", True))
            fields.append(("Còn nợ", f"**{money(loan.remaining)}**", True))
        return ui.make(f"{title} · #{loan.id}", note, color=color, fields=fields)

    # -- /vi, /daily ----------------------------------------------------------------------------------
    @app_commands.command(name="vi", description="Xem ví: tiền mặt, tiền nợ, tài khoản ngân hàng.")
    @app_commands.guild_only()
    async def cmd_vi(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            embed = await self.wallet_embed(interaction.user)
            await self.reply(interaction, embed, view=WalletView(self, interaction.user.id))
        await self.guard(interaction, work)

    async def _claim(self, user: discord.abc.User) -> int:
        amount = random.randrange(config.DAILY_MIN, config.DAILY_MAX + 1, config.DAILY_STEP)
        amount, _ = await self.wallets.claim_daily(user.id, amount)
        return amount

    @app_commands.command(name="daily", description="Nhận tiền ngẫu nhiên mỗi ngày (đặt lại lúc 0 giờ giờ Việt Nam).")
    @app_commands.guild_only()
    async def cmd_daily(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            amount = await self._claim(interaction.user)
            wallet = await self.wallets.get(interaction.user.id)
            embed = ui.make("🎁 Quà hằng ngày", f"Bạn nhận được **{money(amount)}**!", color=ui.GOLD, fields=[
                ("💵 Tiền mặt hiện có", f"**{money(wallet.cash)}**", True)])
            await self.reply(interaction, ui.author(embed, interaction.user), ephemeral=not config.DAILY_PUBLIC)
        await self.guard(interaction, work)

    async def daily_from_wallet(self, interaction: discord.Interaction) -> None:
        amount = await self._claim(interaction.user)
        embed = await self.wallet_embed(interaction.user, note=f"🎁 Bạn vừa nhận **{money(amount)}**!")
        await self.reply(interaction, embed, view=WalletView(self, interaction.user.id), edit=True)

    # -- /lichsu ----------------------------------------------------------------------------------------
    @staticmethod
    def history_line(e: HistoryEntry) -> str:
        label = HISTORY_LABELS.get(e.kind, e.kind)
        if e.kind in ("deposit", "withdraw"):
            amount = f"**{money(abs(e.amount))}**"      # chỉ chuyển giữa ví và ngân hàng, không tăng/giảm tài sản
        else:
            amount = f"**{'+' if e.amount >= 0 else '-'}{money(abs(e.amount))}**"
        detail = ""
        if e.detail and e.kind not in ("daily", "start"):
            detail = f"\n> {e.detail[:90]}"
        return f"<t:{_unix(e.when)}:f> · {label} · {amount}{detail}"

    async def show_history(self, interaction: discord.Interaction, target: discord.abc.User, page: int, *,
                           edit: bool = False) -> None:
        total_hint = await self.bank.history(target.id, 1, 0)
        pages = max(1, -(-total_hint[1] // HISTORY_PAGE))
        page = min(max(page, 0), pages - 1)
        entries, total = await self.bank.history(target.id, HISTORY_PAGE, page * HISTORY_PAGE)
        body = "\n".join(self.history_line(e) for e in entries) or "Chưa có giao dịch nào."
        title = "📜 Lịch sử giao dịch" if target.id == interaction.user.id else f"📜 Lịch sử giao dịch của {getattr(target, 'display_name', target)}"
        embed = ui.make(title, body)
        embed.add_field(name="Trang", value=f"{page + 1}/{pages} · tổng {total} giao dịch", inline=False)
        ui.author(embed, target)
        await self.reply(interaction, embed, view=HistoryView(self, interaction.user.id, target, page, pages), edit=edit)

    @app_commands.command(name="lichsu", description="Xem lịch sử giao dịch: nộp, rút, chuyển, nhận tiền, /daily...")
    @app_commands.describe(thanhvien="(Chỉ admin/nhà cái) xem lịch sử của thành viên khác")
    @app_commands.guild_only()
    async def cmd_lichsu(self, interaction: discord.Interaction, thanhvien: Optional[discord.Member] = None) -> None:
        async def work() -> None:
            target = thanhvien or interaction.user
            if target.id != interaction.user.id:
                await self.require_banker(interaction)
            await self.show_history(interaction, target, 0)
        await self.guard(interaction, work)

    # -- /top -------------------------------------------------------------------------------------------------
    TOP_SIZE = 10
    TOP_TITLES = {"giau": ("🏆 Bảng xếp hạng — Giàu nhất", "Tổng tài sản = tiền mặt + ngân hàng − tiền nợ."),
                  "lai": ("📈 Bảng xếp hạng — Lãi game nhiều nhất", "Lãi ròng từ Tài Xỉu và Bầu Cua (thắng trừ cược). Chỉ tính người đang có lãi.")}

    @app_commands.command(name="top", description="Bảng xếp hạng: giàu nhất hoặc lãi game nhiều nhất.")
    @app_commands.describe(loai="Chọn bảng xếp hạng (mặc định: giàu nhất)")
    @app_commands.choices(loai=[app_commands.Choice(name="Giàu nhất (tổng tài sản)", value="giau"),
                                app_commands.Choice(name="Lãi game nhiều nhất", value="lai")])
    @app_commands.guild_only()
    async def cmd_top(self, interaction: discord.Interaction, loai: Optional[str] = None) -> None:
        async def work() -> None:
            mode = loai if loai in self.TOP_TITLES else "giau"
            title, about = self.TOP_TITLES[mode]
            rows = await self.bank.leaderboard(mode, self.TOP_SIZE)
            medals = ["🥇", "🥈", "🥉"]
            lines = [f"{medals[i] if i < 3 else f'`{i + 1}.`'} <@{uid}> — **{money(score)}**" for i, (uid, score) in enumerate(rows)]
            embed = ui.make(title, about + "\n\n" + ("\n".join(lines) if lines else "Chưa có ai trong bảng."), color=ui.GOLD)
            mine = await self.bank.rank_of(mode, interaction.user.id)
            if mine is None:
                text = "Bạn chưa có lãi từ game." if mode == "lai" else "Bạn chưa có ví, dùng `/vi` hoặc `/daily` để bắt đầu."
            else:
                text = f"Hạng **#{mine[0]}** · {money(mine[1])}"
            embed.add_field(name="Hạng của bạn", value=text, inline=False)
            await self.reply(interaction, ui.author(embed, interaction.user), ephemeral=False)
        await self.guard(interaction, work)

    # -- /tao, /bank, /bankinfo ------------------------------------------------------------------------
    @app_commands.command(name="tao", description="Mở tài khoản ngân hàng ItachiBank (tối đa 3 tài khoản mỗi người).")
    @app_commands.describe(hoten="Họ và tên chủ tài khoản", sotaikhoan=f"Số tài khoản {config.ACCOUNT_NUMBER_MIN}–{config.ACCOUNT_NUMBER_MAX} chữ số, không trùng người khác")
    @app_commands.guild_only()
    async def cmd_tao(self, interaction: discord.Interaction, hoten: str, sotaikhoan: str) -> None:
        async def work() -> None:
            account = await self.bank.create_account(interaction.user.id, hoten, sotaikhoan)
            embed = self.bank_embed(account, note="🎉 Mở tài khoản thành công! Dùng `/bank` để nộp, rút và chuyển tiền.")
            await self.reply(interaction, ui.author(embed, interaction.user))
        await self.guard(interaction, work)

    @app_commands.command(name="bank", description="Xem tài khoản ngân hàng: nộp tiền, rút ra ví, chuyển tiền.")
    @app_commands.describe(taikhoan="Chọn tài khoản (để trống nếu bạn chỉ có một)")
    @app_commands.guild_only()
    async def cmd_bank(self, interaction: discord.Interaction, taikhoan: Optional[str] = None) -> None:
        async def work() -> None:
            accounts = await self.bank.accounts_of(interaction.user.id)
            if not accounts:
                raise BankError("Bạn chưa có tài khoản. Dùng `/tao` để mở tài khoản.")
            if taikhoan:
                account = next((a for a in accounts if a.number == taikhoan), None)
                if account is None:
                    raise BankError("Không tìm thấy tài khoản này trong danh sách của bạn.")
            elif len(accounts) == 1:
                account = accounts[0]
            else:
                raise BankError("Bạn có nhiều tài khoản, hãy chọn một tài khoản trong ô `taikhoan`.")
            await self.reply(interaction, ui.author(self.bank_embed(account), interaction.user),
                             view=BankView(self, interaction.user.id, account.number))
        await self.guard(interaction, work)

    @cmd_bank.autocomplete("taikhoan")
    async def bank_account_autocomplete(self, interaction: discord.Interaction, current: str) -> list[app_commands.Choice[str]]:
        accounts = await self.bank.accounts_of(interaction.user.id)
        needle = current.strip().lower()
        return [app_commands.Choice(name=f"{a.number} · {a.holder}"[:100], value=a.number)
                for a in accounts if needle in a.number or needle in a.holder.lower()][:25]

    @app_commands.command(name="bankinfo", description="Xem ví và tất cả tài khoản ngân hàng của bạn.")
    @app_commands.describe(thanhvien="(Chỉ admin/nhà cái) xem của thành viên khác")
    @app_commands.guild_only()
    async def cmd_bankinfo(self, interaction: discord.Interaction, thanhvien: Optional[discord.Member] = None) -> None:
        async def work() -> None:
            target = thanhvien or interaction.user
            if target.id != interaction.user.id:
                await self.require_banker(interaction)
            wallet = await self.wallets.get(target.id)
            accounts = await self.bank.accounts_of(target.id)
            lines = [f"`{a.number}` · {a.holder} · **{money(a.balance)}**" for a in accounts] or ["Chưa có tài khoản nào."]
            embed = ui.make("📋 Thông tin tài chính", fields=[
                ("💵 Ví (tiền mặt)", f"**{money(wallet.cash)}**", True),
                ("💳 Tiền nợ", f"**{money(wallet.debt)}**", True),
                ("🏦 Tài khoản ngân hàng", "\n".join(lines), False),
            ])
            await self.reply(interaction, ui.author(embed, target))
        await self.guard(interaction, work)

    # -- nộp / rút / chuyển (nút + bảng nhập) ------------------------------------------------------------
    async def start_account_action(self, interaction: discord.Interaction, action: str, source: str) -> None:
        """Từ nút ở /vi: chọn tài khoản (nếu có nhiều) rồi mở bảng nhập."""
        accounts = await self.bank.accounts_of(interaction.user.id)
        if not accounts:
            raise BankError("Bạn chưa có tài khoản. Dùng `/tao` để mở tài khoản.")
        if len(accounts) == 1:
            await self.open_modal(interaction, action, source, accounts[0].number)
            return

        async def then(inter: discord.Interaction, number: str) -> None:
            await self.open_modal(inter, action, source, number)
        await self.reply(interaction, ui.info("Chọn tài khoản:"), view=AccountPickView(self, interaction.user.id, accounts, then))

    async def open_modal(self, interaction: discord.Interaction, action: str, source: str, number: str) -> None:
        async def handler(inter: discord.Interaction, values: list[str]) -> None:
            await self.do_account_action(inter, action, source, number, values)
        if action == "transfer":
            self.check_age(interaction.user)
            modal = BankModal(self, "Chuyển tiền", [
                ("Số tiền hoặc all = tất cả", "Ví dụ: 50000, 50k, 1.5tr, all", 20, True),
                ("Số tài khoản nhận", f"{config.ACCOUNT_NUMBER_MIN}–{config.ACCOUNT_NUMBER_MAX} chữ số", 20, True),
                ("Lý do", "Không bắt buộc", 100, False)], handler)
        else:
            title = "Nộp tiền vào tài khoản" if action == "deposit" else "Rút tiền ra ví"
            modal = BankModal(self, title, [("Số tiền hoặc all = tất cả", "Ví dụ: 50000, 50k, 1.5tr, all", 20, True)], handler)
        await interaction.response.send_modal(modal)

    async def _show_after(self, interaction: discord.Interaction, source: str, number: str, note: str) -> None:
        if source == "wallet":
            await self.reply(interaction, await self.wallet_embed(interaction.user, note=note),
                             view=WalletView(self, interaction.user.id), edit=True)
        else:
            account = await self.bank.get_account(number)
            await self.reply(interaction, ui.author(self.bank_embed(account, note=note), interaction.user),
                             view=BankView(self, interaction.user.id, number), edit=True)

    async def do_account_action(self, interaction: discord.Interaction, action: str, source: str, number: str,
                                values: list[str]) -> None:
        uid = interaction.user.id
        if action == "deposit":
            _, _, moved = await self.bank.deposit(uid, number, amount_or_all(values[0]))
            await self._show_after(interaction, source, number, f"✅ Đã nộp **{money(moved)}** vào tài khoản `{number}`.")
        elif action == "withdraw":
            _, _, moved = await self.bank.withdraw(uid, number, amount_or_all(values[0]))
            await self._show_after(interaction, source, number, f"✅ Đã rút **{money(moved)}** về ví.")
        else:
            self.check_age(interaction.user)
            amount = amount_or_all(values[0], minimum=config.MIN_TRANSFER)
            result = await self.bank.transfer(uid, number, values[1], amount, values[2] if len(values) > 2 else "")
            await self._show_after(interaction, source, number,
                                   f"✅ Đã chuyển **{money(result.amount)}** đến tài khoản `{result.recipient.number}`.")
            await self._notify_transfer(interaction, result)

    async def _notify_transfer(self, interaction: discord.Interaction, result: TransferResult) -> None:
        """Báo cho người chuyển (biên lai riêng), người nhận (tin nhắn riêng) và kênh log của admin."""
        sender, recipient_id = interaction.user, result.recipient.owner_id
        fields = [
            ("Người chuyển", f"{sender.mention}\n`{result.sender.number}` · {result.sender.holder}", True),
            ("Người nhận", f"<@{recipient_id}>\n`{result.recipient.number}` · {result.recipient.holder}", True),
            ("Số tiền", f"**{money(result.amount)}**", True),
            ("Lý do", result.reason or "—", False),
        ]
        receipt = ui.make("🧾 Biên lai chuyển tiền", color=ui.GREEN, fields=fields)
        try:
            await interaction.followup.send(embed=receipt, ephemeral=True, allowed_mentions=NO_PING)
        except discord.HTTPException:
            pass
        if recipient_id != sender.id:
            await self.dm(recipient_id, ui.make("💰 Bạn vừa nhận tiền", color=ui.GREEN, fields=fields))
        await self.log_to(interaction.guild, ui.make("🧾 Chuyển tiền", color=ui.BRAND, fields=fields))

    # -- vay tiền --------------------------------------------------------------------------------------------
    @app_commands.command(name="vay", description="Gửi đơn xin vay tiền (không lãi) cho một thành viên.")
    @app_commands.describe(thanhvien="Người bạn muốn vay", sotien="Số tiền, ví dụ 100k, 1.5tr",
                           songay="Số ngày được vay (mặc định 7)")
    @app_commands.guild_only()
    async def cmd_vay(self, interaction: discord.Interaction, thanhvien: discord.Member, sotien: str,
                      songay: Optional[int] = None) -> None:
        async def work() -> None:
            if thanhvien.bot:
                raise BankError("Không thể vay tiền của bot.")
            self.check_age(interaction.user)
            self.check_age(thanhvien, who=thanhvien.display_name)
            amount = parse_amount(sotien, minimum=config.LOAN_MIN)
            loan = await self.bank.request_loan(interaction.user.id, thanhvien.id, amount, songay or config.LOAN_DEFAULT_DAYS)
            embed = self.loan_embed(loan, "📨 Đã gửi đơn vay", ui.GOLD,
                                    note=f"Chờ {thanhvien.mention} duyệt bằng `/checkvay` (tự hủy sau {config.LOAN_PENDING_HOURS} giờ).")
            sent = await self.dm(thanhvien.id, self.loan_embed(
                loan, "📨 Có người xin vay tiền", ui.GOLD,
                note=f"{interaction.user.mention} xin vay bạn. Dùng `/checkvay` ở máy chủ để chấp nhận hoặc từ chối."))
            if not sent:
                embed.description += "\n(Không nhắn riêng được cho họ, hãy báo họ dùng `/checkvay`.)"
            await self.reply(interaction, embed)
        await self.guard(interaction, work)

    @app_commands.command(name="checkvay", description="Xem đơn xin vay tiền người khác gửi cho bạn.")
    @app_commands.guild_only()
    async def cmd_checkvay(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            loans = await self.bank.pending_for_lender(interaction.user.id)
            if not loans:
                await self.reply(interaction, ui.info("Hiện không có đơn xin vay nào gửi cho bạn."))
                return
            for loan in loans[:MAX_CHECKVAY_SHOWN]:
                embed = self.loan_embed(loan, "📨 Đơn xin vay", ui.GOLD)
                await self.reply(interaction, embed, view=LoanDecisionView(self, loan.id, interaction.user.id))
            if len(loans) > MAX_CHECKVAY_SHOWN:
                await self.reply(interaction, ui.info(f"Còn {len(loans) - MAX_CHECKVAY_SHOWN} đơn nữa, xử lý xong rồi gõ lại `/checkvay`."))
        await self.guard(interaction, work)

    async def decide_loan(self, interaction: discord.Interaction, loan_id: int, accept: bool) -> None:
        if accept:
            self.check_age(interaction.user)
        loan = await self.bank.respond_loan(loan_id, interaction.user.id, accept)
        if accept:
            embed = self.loan_embed(loan, "✅ Đã cho vay", ui.GREEN, note=f"Đã chuyển **{money(loan.amount)}** sang ví người vay.")
            await self.dm(loan.borrower_id, self.loan_embed(
                loan, "✅ Đơn vay được chấp nhận", ui.GREEN,
                note=f"Bạn nhận **{money(loan.amount)}** vào ví. Trả bằng `/tratien`; quá hạn bot tự trừ tiền mặt trong ví."))
            await self.log_to(interaction.guild, self.loan_embed(loan, "🤝 Khoản vay mới", ui.BRAND))
        else:
            embed = self.loan_embed(loan, "❌ Đã từ chối", ui.RED)
            await self.dm(loan.borrower_id, self.loan_embed(loan, "❌ Đơn vay bị từ chối", ui.RED))
        await self.reply(interaction, embed, view=None, edit=True)

    @app_commands.command(name="tratien", description="Trả nợ các khoản đã vay.")
    @app_commands.guild_only()
    async def cmd_tratien(self, interaction: discord.Interaction) -> None:
        async def work() -> None:
            loans = await self.bank.active_loans(interaction.user.id)
            if not loans:
                await self.reply(interaction, ui.info("Bạn không có khoản nợ nào. 🎉"))
                return
            await self.reply(interaction, self._debts_embed(loans), view=LoanPickView(self, interaction.user.id, loans))
        await self.guard(interaction, work)

    @staticmethod
    def _debts_embed(loans: list[Loan], note: str = "") -> discord.Embed:
        lines = [f"**#{ln.id}** · còn nợ **{money(ln.remaining)}** · cho <@{ln.lender_id}> vay · hạn <t:{_unix(ln.due)}:R>"
                 for ln in loans]
        return ui.make("💳 Các khoản nợ của bạn", (note + "\n\n" if note else "") + "\n".join(lines), color=ui.GOLD)

    async def open_repay_modal(self, interaction: discord.Interaction, loan_id: int) -> None:
        async def handler(inter: discord.Interaction, values: list[str]) -> None:
            await self.do_repay(inter, loan_id, values[0])
        await interaction.response.send_modal(BankModal(
            self, f"Trả nợ #{loan_id}", [("Số tiền (để trống = trả hết)", "Ví dụ: 50k", 20, False)], handler))

    async def do_repay(self, interaction: discord.Interaction, loan_id: int, raw: str) -> None:
        amount = parse_amount(raw) if raw and raw.strip() else None
        paid, loan, _ = await self.bank.repay(loan_id, interaction.user.id, amount)
        note = f"✅ Đã trả **{money(paid)}**" + (" — khoản vay đã được trả hết!" if loan.status == "repaid" else f", còn nợ **{money(loan.remaining)}**.")
        loans = await self.bank.active_loans(interaction.user.id)
        if loans:
            await self.reply(interaction, self._debts_embed(loans, note), view=LoanPickView(self, interaction.user.id, loans), edit=True)
        else:
            await self.reply(interaction, ui.success(note), view=None, edit=True)
        await self.dm(loan.lender_id, ui.make("💰 Bạn được trả nợ", color=ui.GREEN, fields=[
            ("Người trả", f"<@{interaction.user.id}>", True), ("Số tiền", f"**{money(paid)}**", True),
            ("Còn lại", f"{money(loan.remaining)}", True)]))
        await self.log_to(interaction.guild, self.loan_embed(loan, "💳 Trả nợ", ui.BRAND, note=f"Đã trả **{money(paid)}**."))

    @tasks.loop(minutes=1)
    async def collector(self) -> None:
        """Dọn đơn vay hết hạn duyệt và tự thu nợ quá hạn."""
        try:
            await self.bank.expire_pending()
            for event in await self.bank.collect_overdue():
                await self._notify_collect(event)
        except Exception:  # noqa: BLE001
            log.exception("Lỗi vòng thu nợ")

    @collector.before_loop
    async def _before_collector(self) -> None:
        await self.bot.wait_until_ready()

    async def _notify_collect(self, event: CollectEvent) -> None:
        loan = event.loan
        text = (f"Bot đã tự trừ **{money(event.paid)}** từ tiền mặt trong ví." if event.paid
                else "Ví hiện không có tiền mặt để trừ.")
        remain = "Khoản vay đã được trả hết." if loan.status == "repaid" else f"Còn nợ **{money(loan.remaining)}**."
        embed = self.loan_embed(loan, "⏰ Khoản vay quá hạn", ui.RED, note=f"{text} {remain}")
        await self.dm(loan.borrower_id, embed)
        await self.dm(loan.lender_id, embed)
        for guild in self.bot.guilds:
            await self.log_to(guild, embed)

    # -- admin / nhà cái ------------------------------------------------------------------------------------------
    @app_commands.command(name="thutien", description="(Admin/nhà cái) Thu tiền mặt trong ví của một thành viên.")
    @app_commands.describe(thanhvien="Người bị thu", sotien="Số tiền, ví dụ 100k", lydo="Lý do (không bắt buộc)")
    @app_commands.guild_only()
    async def cmd_thutien(self, interaction: discord.Interaction, thanhvien: discord.Member, sotien: str,
                          lydo: Optional[str] = None) -> None:
        await self._money_admin(interaction, thanhvien, sotien, lydo, take=True)

    @app_commands.command(name="addmoney", description="(Admin/nhà cái) Thêm tiền mặt vào ví một thành viên.")
    @app_commands.describe(thanhvien="Người nhận", sotien="Số tiền, ví dụ 1tr", lydo="Lý do (không bắt buộc)")
    @app_commands.guild_only()
    async def cmd_addmoney(self, interaction: discord.Interaction, thanhvien: discord.Member, sotien: str,
                           lydo: Optional[str] = None) -> None:
        await self._money_admin(interaction, thanhvien, sotien, lydo, take=False)

    async def _money_admin(self, interaction: discord.Interaction, member: discord.Member, raw: str,
                           reason: Optional[str], *, take: bool) -> None:
        async def work() -> None:
            await self.require_banker(interaction)
            if member.bot:
                raise BankError("Không áp dụng cho bot.")
            amount = parse_amount(raw)
            reason_text = " ".join((reason or "").split())[:100]
            if take:
                done, wallet = await self.bank.admin_take(member.id, amount, interaction.user.id, reason_text)
                title, color, verb = "➖ Thu tiền", ui.RED, "thu"
            else:
                wallet = await self.bank.admin_add(member.id, amount, interaction.user.id, reason_text)
                done, title, color, verb = amount, "➕ Thêm tiền", ui.GREEN, "thêm"
            fields = [("Thành viên", member.mention, True), ("Số tiền", f"**{money(done)}**", True),
                      ("Tiền mặt sau đó", money(wallet.cash), True), ("Người thực hiện", interaction.user.mention, True),
                      ("Lý do", reason_text or "—", False)]
            note = "" if done == amount else f"Chỉ thu được **{money(done)}** (số tiền mặt đang có)."
            await self.reply(interaction, ui.make(f"{title} thành công", note, color=color, fields=fields))
            await self.dm(member.id, ui.make(f"{title} từ nhà cái", color=color, fields=fields[1:3] + fields[4:]))
            await self.log_to(interaction.guild, ui.make(title, color=color, fields=fields))
        await self.guard(interaction, work)

    @staticmethod
    def _collected_text(burned: int, game_bet: int, game_paid: int) -> str:
        """Tiền thu về = /thutien + (tiền cược game - tiền trả thưởng). Âm = nhà cái đang lỗ từ game."""
        total = burned + game_bet - game_paid
        return f"{'-' if total < 0 else ''}{money(abs(total))}"

    @app_commands.command(name="bankconfig", description="(Admin) Chọn kênh log và role nhà cái; xem số liệu hệ thống.")
    @app_commands.describe(kenhlog="Kênh gửi log chuyển tiền / vay / thu / thêm tiền", rolenhacai="Role được dùng /thutien và /addmoney")
    @app_commands.guild_only()
    async def cmd_bankconfig(self, interaction: discord.Interaction, kenhlog: Optional[discord.TextChannel] = None,
                             rolenhacai: Optional[discord.Role] = None) -> None:
        async def work() -> None:
            perms = interaction.permissions
            if not (perms.administrator or perms.manage_guild):
                raise BankError("Chỉ admin hoặc quản trị viên mới dùng được lệnh này.")
            gid = interaction.guild_id
            if kenhlog is not None:
                await self.bank.set_setting(gid, SETTING_LOG_CHANNEL, str(kenhlog.id))
            if rolenhacai is not None:
                await self.bank.set_setting(gid, SETTING_BANKER_ROLE, str(rolenhacai.id))
            log_id = await self.bank.get_setting(gid, SETTING_LOG_CHANNEL)
            role_id = await self.bank.get_setting(gid, SETTING_BANKER_ROLE)
            st = await self.bank.stats()
            embed = ui.make("⚙️ Cấu hình ItachiBank", fields=[
                ("Kênh log", f"<#{log_id}>" if log_id else "Chưa đặt", True),
                ("Role nhà cái", f"<@&{role_id}>" if role_id else "Chưa đặt", True),
                ("Số ví", str(st["wallets"]), True),
                ("💵 Tổng tiền mặt", money(st["cash"]), True),
                ("🏦 Tổng trong ngân hàng", money(st["bank"]), True),
                ("💳 Tổng dư nợ", money(st["debt"]), True),
                ("📈 Tiền sinh ra hôm nay", f"{money(st['minted_today'])}\n(mở ví, /daily, /addmoney)", True),
                ("📉 Tiền thu về hôm nay",
                 self._collected_text(st["burned_today"], st["game_bet_today"], st["game_paid_today"]), True),
            ])
            await self.reply(interaction, embed)
        await self.guard(interaction, work)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ItachiBank(bot))
