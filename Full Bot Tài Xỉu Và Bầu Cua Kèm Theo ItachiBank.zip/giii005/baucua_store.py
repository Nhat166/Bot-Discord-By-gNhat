"""Kho dữ liệu Bầu Cua: ván, cược, khóa cược, trả thưởng, hoàn tiền. Không phụ thuộc discord.

Dùng CHUNG cơ sở dữ liệu với ItachiBank (bảng baucua_rounds, baucua_bets). Tiền cược bị trừ khỏi ví ngay khi cược, cùng một
giao dịch với việc ghi cược. Bot dừng giữa ván thì lần khởi động sau hoàn lại toàn bộ cược của ván chưa chốt.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from ibank_bank import BankError, parse_utc
from ibank_database import Database
from ibank_money import MAX_AMOUNT, format_vnd
from ibank_store import WalletStore, _utc_text
from baucua_logic import ANIMALS, NAMES, multiplier, parse_faces

SCHEMA = (
    """CREATE TABLE IF NOT EXISTS baucua_rounds (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id    INTEGER NOT NULL,
        channel_id  INTEGER NOT NULL,
        status      TEXT    NOT NULL,           -- open, locked, settled, refunded
        started_at  TEXT    NOT NULL,
        settled_at  TEXT,
        dice        TEXT,                       -- 'ga,ca,cua'
        forced      TEXT,                       -- nhà cái bẻ: 'auto' (nhà cái ăn nhiều nhất) hoặc 'ga,ca,cua'
        forced_by   INTEGER
    )""",
    "CREATE INDEX IF NOT EXISTS ix_bc_rounds_guild ON baucua_rounds (guild_id, id)",
    """CREATE TABLE IF NOT EXISTS baucua_bets (
        round_id INTEGER NOT NULL,
        user_id  INTEGER NOT NULL,
        animal   TEXT    NOT NULL,
        amount   INTEGER NOT NULL CHECK (amount > 0),
        PRIMARY KEY (round_id, user_id, animal)
    )""",
)


@dataclass(frozen=True)
class BetResult:
    animal: str
    added: int
    animal_total: int     # tổng cược của người này vào con đó
    user_total: int       # tổng cược của người này ở ván (mọi con)
    cash: int


@dataclass(frozen=True)
class UserResult:
    user_id: int
    bet: int
    payout: int

    @property
    def net(self) -> int:
        return self.payout - self.bet


@dataclass(frozen=True)
class Settlement:
    round_id: int
    dice: tuple[str, str, str]
    users: list[UserResult]           # mọi người chơi, lãi nhiều nhất trước

    @property
    def winners(self) -> list[UserResult]:
        return [u for u in self.users if u.net > 0]

    @property
    def losers(self) -> list[UserResult]:
        return [u for u in self.users if u.net < 0]

    @property
    def total_payout(self) -> int:
        return sum(u.payout for u in self.users)


@dataclass(frozen=True)
class RoundResult:
    id: int
    dice: tuple[str, str, str]
    started_at: datetime


class BauCuaStore:
    def __init__(self, database: Database, wallets: WalletStore) -> None:
        self.db, self.wallets = database, wallets

    async def setup(self) -> None:
        def work(conn: sqlite3.Connection) -> None:
            for stmt in SCHEMA:
                conn.execute(stmt)
        await self.db.transaction(work)

    def _now(self) -> datetime:
        return self.wallets.clock()

    # -- vòng đời ván -----------------------------------------------------------------------------------
    def _refund(self, conn: sqlite3.Connection, round_id: int, note: str, now: datetime) -> int:
        total = 0
        for bet in conn.execute("SELECT user_id, SUM(amount) AS a FROM baucua_bets WHERE round_id = ? GROUP BY user_id", (round_id,)).fetchall():
            self.wallets._ensure(conn, bet["user_id"], now)
            self.wallets._apply(conn, bet["user_id"], bet["a"], "baucua_refund", f"Bầu cua #{round_id}: {note}", now)
            total += bet["a"]
        conn.execute("UPDATE baucua_rounds SET status = 'refunded', settled_at = ? WHERE id = ?", (_utc_text(now), round_id))
        return total

    async def refund_unfinished(self) -> tuple[int, int]:
        """Hoàn cược của mọi ván chưa chốt (bot tắt giữa chừng). Trả (số ván, số tiền hoàn)."""
        now = self._now()

        def work(conn: sqlite3.Connection) -> tuple[int, int]:
            rounds = conn.execute("SELECT id FROM baucua_rounds WHERE status IN ('open', 'locked')").fetchall()
            return len(rounds), sum(self._refund(conn, r["id"], "hoàn cược (bot dừng giữa ván)", now) for r in rounds)
        return await self.db.transaction(work)

    async def abandon_round(self, round_id: int) -> int:
        now = self._now()

        def work(conn: sqlite3.Connection) -> int:
            row = conn.execute("SELECT status FROM baucua_rounds WHERE id = ?", (round_id,)).fetchone()
            if row is None or row["status"] not in ("open", "locked"):
                return 0
            return self._refund(conn, round_id, "hoàn cược (hủy ván)", now)
        return await self.db.transaction(work)

    async def create_round(self, guild_id: int, channel_id: int) -> tuple[int, datetime]:
        now = self._now()

        def work(conn: sqlite3.Connection) -> int:
            return conn.execute("INSERT INTO baucua_rounds (guild_id, channel_id, status, started_at) VALUES (?, ?, 'open', ?)",
                                (guild_id, channel_id, _utc_text(now))).lastrowid
        return await self.db.transaction(work), now

    async def last_round_id(self, guild_id: int) -> int:
        row = await self.db.fetchone("SELECT COALESCE(MAX(id), 0) AS m FROM baucua_rounds WHERE guild_id = ?", (guild_id,))
        return int(row["m"])

    async def lock_round(self, round_id: int) -> None:
        def work(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE baucua_rounds SET status = 'locked' WHERE id = ? AND status = 'open'", (round_id,))
        await self.db.transaction(work)

    # -- cược ---------------------------------------------------------------------------------------------
    async def place_bet(self, round_id: int, user_id: int, animal: str, amount: Optional[int], *,
                        min_bet: int, max_bet: int = 0) -> BetResult:
        """Cược vào một con (amount=None: tất cả tiền mặt). Được cược nhiều con, cược thêm cùng con thì cộng dồn."""
        if animal not in ANIMALS:
            raise BankError("Con cược không hợp lệ.")
        now = self._now()

        def work(conn: sqlite3.Connection) -> BetResult:
            rnd = conn.execute("SELECT status FROM baucua_rounds WHERE id = ?", (round_id,)).fetchone()
            if rnd is None or rnd["status"] != "open":
                raise BankError("Ván này đã khóa cược, hãy chờ ván sau.")
            self.wallets._ensure(conn, user_id, now)
            cash = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (user_id,)).fetchone()["cash"]
            stake = cash if amount is None else amount
            if stake <= 0:
                raise BankError("Ví của bạn không có tiền mặt để cược.")
            if stake < min_bet:
                raise BankError(f"Mức cược tối thiểu là {format_vnd(min_bet)}.")
            user_total = conn.execute("SELECT COALESCE(SUM(amount), 0) AS s FROM baucua_bets WHERE round_id = ? AND user_id = ?",
                                      (round_id, user_id)).fetchone()["s"]
            if max_bet and user_total + stake > max_bet:
                raise BankError(f"Tổng cược mỗi ván tối đa {format_vnd(max_bet)} (bạn đã cược {format_vnd(user_total)}).")
            if user_total + stake > MAX_AMOUNT:
                raise BankError("Số tiền cược vượt mức tối đa cho phép.")
            new_cash = self.wallets._apply(conn, user_id, -stake, "baucua_bet", f"Bầu cua #{round_id}: cược {NAMES[animal]}", now)
            conn.execute("INSERT INTO baucua_bets (round_id, user_id, animal, amount) VALUES (?, ?, ?, ?) "
                         "ON CONFLICT (round_id, user_id, animal) DO UPDATE SET amount = amount + excluded.amount",
                         (round_id, user_id, animal, stake))
            animal_total = conn.execute("SELECT amount FROM baucua_bets WHERE round_id = ? AND user_id = ? AND animal = ?",
                                        (round_id, user_id, animal)).fetchone()["amount"]
            return BetResult(animal, stake, animal_total, user_total + stake, new_cash)
        return await self.db.transaction(work)

    async def my_bets(self, round_id: int, user_id: int) -> dict[str, int]:
        rows = await self.db.fetchall("SELECT animal, amount FROM baucua_bets WHERE round_id = ? AND user_id = ?", (round_id, user_id))
        return {r["animal"]: r["amount"] for r in rows}

    async def totals(self, round_id: int) -> dict[str, tuple[int, int]]:
        """{con: (số người cược, tổng tiền)} cho đủ 6 con."""
        out = {a: (0, 0) for a in ANIMALS}
        for r in await self.db.fetchall("SELECT animal, COUNT(*) AS n, SUM(amount) AS s FROM baucua_bets WHERE round_id = ? GROUP BY animal", (round_id,)):
            out[r["animal"]] = (r["n"], r["s"])
        return out

    # -- nhà cái bẻ ------------------------------------------------------------------------------------------
    async def set_force(self, round_id: int, mode: Optional[str], by_id: Optional[int]) -> None:
        """mode: None (bỏ bẻ), 'auto' (nhà cái ăn nhiều nhất) hoặc 'ga,ca,cua'."""
        if mode not in (None, "auto"):
            parse_faces(mode)

        def work(conn: sqlite3.Connection) -> None:
            row = conn.execute("SELECT status FROM baucua_rounds WHERE id = ?", (round_id,)).fetchone()
            if row is None or row["status"] not in ("open", "locked"):
                raise BankError("Ván này đã có kết quả, không bẻ được nữa.")
            conn.execute("UPDATE baucua_rounds SET forced = ?, forced_by = ? WHERE id = ?", (mode, by_id if mode else None, round_id))
        await self.db.transaction(work)

    async def get_force(self, round_id: int) -> tuple[Optional[str], Optional[int]]:
        row = await self.db.fetchone("SELECT forced, forced_by FROM baucua_rounds WHERE id = ?", (round_id,))
        return (row["forced"], row["forced_by"]) if row else (None, None)

    # -- chốt ván -----------------------------------------------------------------------------------------------
    async def settle(self, round_id: int, dice: tuple[str, str, str]) -> Settlement:
        """Ghi kết quả và trả thưởng: mỗi con trúng nhận tổng cược × (1 + số xúc xắc ra con đó)."""
        now = self._now()
        names = " - ".join(NAMES[d] for d in dice)

        def work(conn: sqlite3.Connection) -> Settlement:
            row = conn.execute("SELECT status FROM baucua_rounds WHERE id = ?", (round_id,)).fetchone()
            if row is None or row["status"] not in ("open", "locked"):
                raise BankError("Ván này đã được chốt rồi.")
            conn.execute("UPDATE baucua_rounds SET status = 'settled', settled_at = ?, dice = ? WHERE id = ?",
                         (_utc_text(now), ",".join(dice), round_id))
            per: dict[int, list[int]] = {}
            for bet in conn.execute("SELECT user_id, animal, amount FROM baucua_bets WHERE round_id = ?", (round_id,)).fetchall():
                entry = per.setdefault(bet["user_id"], [0, 0])
                entry[0] += bet["amount"]
                entry[1] += bet["amount"] * multiplier(dice, bet["animal"])
            users = []
            for uid, (bet_sum, payout) in per.items():
                if payout > 0:
                    self.wallets._ensure(conn, uid, now)
                    self.wallets._apply(conn, uid, payout, "baucua_win", f"Bầu cua #{round_id}: {names}", now)
                users.append(UserResult(uid, bet_sum, payout))
            users.sort(key=lambda u: (-u.net, u.user_id))
            return Settlement(round_id, dice, users)
        return await self.db.transaction(work)

    async def recent(self, guild_id: int, limit: int) -> list[RoundResult]:
        """Các ván đã chốt gần nhất của máy chủ, MỚI NHẤT TRƯỚC."""
        rows = await self.db.fetchall("SELECT * FROM baucua_rounds WHERE guild_id = ? AND status = 'settled' ORDER BY id DESC LIMIT ?",
                                      (guild_id, limit))
        return [RoundResult(r["id"], parse_faces(r["dice"]), parse_utc(r["started_at"])) for r in rows]

    async def bet_stats(self, round_ids: list[int]) -> dict[str, tuple[int, int]]:
        """{con: (số lượt cược, tổng tiền)} trong các ván đã cho."""
        out = {a: (0, 0) for a in ANIMALS}
        if not round_ids:
            return out
        marks = ",".join("?" * len(round_ids))
        for r in await self.db.fetchall(f"SELECT animal, COUNT(*) AS n, SUM(amount) AS s FROM baucua_bets WHERE round_id IN ({marks}) "
                                        f"GROUP BY animal", round_ids):
            out[r["animal"]] = (r["n"], r["s"])
        return out
