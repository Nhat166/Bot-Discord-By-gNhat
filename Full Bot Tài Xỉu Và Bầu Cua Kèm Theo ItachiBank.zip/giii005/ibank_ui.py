"""Giao diện chung: bảng (embed) có dòng chân "by: giii•" đẩy sang góc phải."""
from __future__ import annotations

from typing import Iterable, Optional

import discord

import ibank_config as config

BRAND = 0x2B6CB0
GREEN = 0x2F9E44
RED = 0xE03131
GOLD = 0xF08C00
GREY = 0x868E96

# Ký tự Braille trống (U+2800) không bị Discord cắt như dấu cách thường, nên dùng để đẩy chữ sang phải.
_PAD_CHAR = "⠀"


def footer_text() -> str:
    pad = _PAD_CHAR * max(0, config.FOOTER_PAD)
    return f"{pad}{config.FOOTER_TEXT}"


def finish(embed: discord.Embed) -> discord.Embed:
    """Gắn dòng chân vào MỌI bảng bot gửi."""
    embed.set_footer(text=footer_text())
    return embed


def make(title: str, description: str = "", *, color: int = BRAND,
         fields: Iterable[tuple[str, str, bool]] = ()) -> discord.Embed:
    embed = discord.Embed(title=title[:256], description=description[:4000] or None, color=color)
    for name, value, inline in fields:
        embed.add_field(name=name[:256], value=value[:1024] or "​", inline=inline)
    return finish(embed)


def success(description: str, *, title: str = "✅ Thành công", **kw) -> discord.Embed:
    return make(title, description, color=GREEN, **kw)


def error(description: str, *, title: str = "❌ Không thực hiện được", **kw) -> discord.Embed:
    return make(title, description, color=RED, **kw)


def warning(description: str, *, title: str = "⚠️ Lưu ý", **kw) -> discord.Embed:
    return make(title, description, color=GOLD, **kw)


def warning_daily(next_unix: int) -> discord.Embed:
    return warning(f"Bạn đã nhận quà hôm nay rồi. Nhận lại <t:{next_unix}:R> (0 giờ giờ Việt Nam).", title="🎁 Chưa thể nhận")


def info(description: str, *, title: str = "ℹ️ Thông tin", **kw) -> discord.Embed:
    return make(title, description, color=BRAND, **kw)


def author(embed: discord.Embed, user: discord.abc.User) -> discord.Embed:
    name = getattr(user, "display_name", None) or str(user)
    avatar = getattr(user, "display_avatar", None)
    embed.set_author(name=name[:256], icon_url=avatar.url if avatar else None)
    return embed
