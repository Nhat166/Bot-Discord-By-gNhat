"""Ví tiền VNĐ: mở ví, nhận /daily, cộng/trừ tiền có ghi sổ cái. Không phụ thuộc discord.

Mọi thay đổi số dư đi qua `_apply` trong MỘT giao dịch cơ sở dữ liệu, nên không thể âm tiền hay nhận /daily hai lần
dù bấm đồng thời. Các module sau này (ngân hàng, game) chỉ cần dùng `adjust`.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Callable, Optional

from ibank_database import Database

VN_TZ = timezone(timedelta(hours=7))


class WalletError(Exception):
    """Lỗi có nội dung thân thiện, hiện thẳng cho người dùng."""


class DailyCooldown(WalletError):
    def __init__(self, remaining: int) -> None:
        self.remaining = remaining  # số giây tới 00:00 giờ Việt Nam
        super().__init__("Bạn đã nhận /daily hôm nay rồi.")


class InsufficientFunds(WalletError):
    def __init__(self, cash: int, needed: int) -> None:
        self.cash, self.needed = cash, needed
        super().__init__("Không đủ tiền mặt.")


@dataclass(frozen=True)
class Wallet:
    user_id: int
    cash: int
    debt: int
    last_daily: Optional[str]
    created_at: str

    @property
    def total(self) -> int:
        return self.cash - self.debt


def _utc_text(now: datetime) -> str:
    return now.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def today_vn(now: datetime) -> str:
    return now.astimezone(VN_TZ).date().isoformat()


def seconds_until_reset(now: datetime) -> int:
    local = now.astimezone(VN_TZ)
    midnight = (local + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return max(1, int((midnight - local).total_seconds()))


class WalletStore:
    def __init__(self, database: Database, starting_balance: int,
                 clock: Callable[[], datetime] = lambda: datetime.now(timezone.utc)) -> None:
        self.db, self.starting_balance, self.clock = database, starting_balance, clock

    # -- hàm đồng bộ dùng bên trong giao dịch -----------------------------------------------
    def _ensure(self, conn: sqlite3.Connection, user_id: int, now: datetime) -> None:
        cur = conn.execute("INSERT OR IGNORE INTO wallets (user_id, cash, debt, last_daily, created_at) "
                           "VALUES (?, ?, 0, NULL, ?)", (user_id, self.starting_balance, _utc_text(now)))
        if cur.rowcount == 1 and self.starting_balance:
            conn.execute("INSERT INTO ledger (user_id, delta, balance_after, kind, note, created_at) "
                         "VALUES (?, ?, ?, 'start', 'Mở ví lần đầu', ?)",
                         (user_id, self.starting_balance, self.starting_balance, _utc_text(now)))

    @staticmethod
    def _row_to_wallet(row: sqlite3.Row) -> Wallet:
        return Wallet(row["user_id"], row["cash"], row["debt"], row["last_daily"], row["created_at"])

    def _apply(self, conn: sqlite3.Connection, user_id: int, delta: int, kind: str, note: str, now: datetime) -> int:
        row = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (user_id,)).fetchone()
        new_cash = row["cash"] + delta
        if new_cash < 0:
            raise InsufficientFunds(row["cash"], -delta)
        conn.execute("UPDATE wallets SET cash = ? WHERE user_id = ?", (new_cash, user_id))
        conn.execute("INSERT INTO ledger (user_id, delta, balance_after, kind, note, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                     (user_id, delta, new_cash, kind, note[:200], _utc_text(now)))
        return new_cash

    # -- API bất đồng bộ -----------------------------------------------------------------------
    async def get(self, user_id: int, *, create: bool = True) -> Optional[Wallet]:
        """Lấy ví. `create=True` mở ví mới (kèm số dư khởi đầu) nếu chưa có; False thì trả None nếu chưa có."""
        now = self.clock()

        def work(conn: sqlite3.Connection) -> Optional[Wallet]:
            if create:
                self._ensure(conn, user_id, now)
            row = conn.execute("SELECT * FROM wallets WHERE user_id = ?", (user_id,)).fetchone()
            return self._row_to_wallet(row) if row else None
        return await self.db.transaction(work)

    async def claim_daily(self, user_id: int, amount: int) -> tuple[int, Wallet]:
        """Nhận /daily (một lần mỗi ngày theo giờ Việt Nam). Trả (số tiền nhận, ví mới); đã nhận rồi thì ném DailyCooldown."""
        now = self.clock()
        today = today_vn(now)

        def work(conn: sqlite3.Connection) -> Wallet:
            self._ensure(conn, user_id, now)
            row = conn.execute("SELECT last_daily FROM wallets WHERE user_id = ?", (user_id,)).fetchone()
            if row["last_daily"] == today:
                raise DailyCooldown(seconds_until_reset(now))
            self._apply(conn, user_id, amount, "daily", f"/daily {today}", now)
            conn.execute("UPDATE wallets SET last_daily = ? WHERE user_id = ?", (today, user_id))
            return self._row_to_wallet(conn.execute("SELECT * FROM wallets WHERE user_id = ?", (user_id,)).fetchone())
        return amount, await self.db.transaction(work)

    async def adjust(self, user_id: int, delta: int, kind: str, note: str = "") -> Wallet:
        """Cộng (delta > 0) hoặc trừ (delta < 0) tiền mặt, có ghi sổ cái. Thiếu tiền thì ném InsufficientFunds."""
        now = self.clock()

        def work(conn: sqlite3.Connection) -> Wallet:
            self._ensure(conn, user_id, now)
            self._apply(conn, user_id, delta, kind, note, now)
            return self._row_to_wallet(conn.execute("SELECT * FROM wallets WHERE user_id = ?", (user_id,)).fetchone())
        return await self.db.transaction(work)
