"""Kho dữ liệu Tài Xỉu: ván, cược, khóa cược, trả thưởng, hoàn tiền. Không phụ thuộc discord.

Dùng CHUNG cơ sở dữ liệu với ItachiBank. Tiền cược bị trừ khỏi ví NGAY khi cược (cùng một giao dịch với việc ghi cược),
nên người chơi không thể rút/tiêu tiền đang cược. Bot tắt giữa chừng thì lần khởi động sau hoàn lại toàn bộ cược của
các ván chưa chốt (refund_unfinished). Trả thưởng nằm trong MỘT giao dịch nên không thể trả hai lần.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from ibank_bank import BankError, parse_utc
from ibank_database import Database
from ibank_money import MAX_AMOUNT, format_vnd
from ibank_store import WalletStore, _utc_text
from taixiu_logic import SIDE_NAMES, TAI, XIU, is_triple, side_of

SCHEMA = (
    """CREATE TABLE IF NOT EXISTS taixiu_rounds (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id    INTEGER NOT NULL,
        channel_id  INTEGER NOT NULL,
        status      TEXT    NOT NULL,           -- open, locked, settled, refunded
        started_at  TEXT    NOT NULL,
        settled_at  TEXT,
        d1 INTEGER, d2 INTEGER, d3 INTEGER,
        total       INTEGER,
        result      TEXT,                       -- tai | xiu (theo tổng điểm)
        triple      INTEGER NOT NULL DEFAULT 0,
        forced_side TEXT,                       -- nhà cái bẻ: tai | xiu
        forced_by   INTEGER                     -- người bẻ gần nhất
    )""",
    "CREATE INDEX IF NOT EXISTS ix_tx_rounds_guild ON taixiu_rounds (guild_id, id)",
    """CREATE TABLE IF NOT EXISTS taixiu_bets (
        round_id INTEGER NOT NULL,
        user_id  INTEGER NOT NULL,
        side     TEXT    NOT NULL,
        amount   INTEGER NOT NULL CHECK (amount > 0),
        PRIMARY KEY (round_id, user_id)
    )""",
)


@dataclass(frozen=True)
class BetResult:
    side: str
    added: int
    total: int          # tổng cược của người này ở ván
    cash: int           # tiền mặt còn lại


@dataclass(frozen=True)
class Totals:
    tai_count: int
    tai_sum: int
    xiu_count: int
    xiu_sum: int


@dataclass(frozen=True)
class Winner:
    user_id: int
    bet: int
    payout: int         # tiền nhận về (gồm cả tiền cược)

    @property
    def profit(self) -> int:
        return self.payout - self.bet


@dataclass(frozen=True)
class Settlement:
    round_id: int
    dice: tuple[int, int, int]
    total: int
    side: str
    triple: bool
    winners: list[Winner]
    losers: int
    lost_sum: int
    house_took_all: bool


@dataclass(frozen=True)
class RoundResult:
    id: int
    dice: tuple[int, int, int]
    total: int
    side: str
    triple: bool
    started_at: datetime


class TaiXiuStore:
    def __init__(self, database: Database, wallets: WalletStore) -> None:
        self.db, self.wallets = database, wallets

    async def setup(self) -> None:
        def work(conn: sqlite3.Connection) -> None:
            for stmt in SCHEMA:
                conn.execute(stmt)
        await self.db.transaction(work)

    def _now(self) -> datetime:
        return self.wallets.clock()

    # -- vòng đời ván -------------------------------------------------------------------------------
    async def refund_unfinished(self) -> tuple[int, int]:
        """Hoàn tiền cược của mọi ván chưa chốt (bot tắt giữa chừng). Trả (số ván, số tiền hoàn)."""
        now = self._now()

        def work(conn: sqlite3.Connection) -> tuple[int, int]:
            rounds = conn.execute("SELECT id FROM taixiu_rounds WHERE status IN ('open', 'locked')").fetchall()
            refunded = 0
            for r in rounds:
                for bet in conn.execute("SELECT user_id, amount FROM taixiu_bets WHERE round_id = ?", (r["id"],)).fetchall():
                    self.wallets._ensure(conn, bet["user_id"], now)
                    self.wallets._apply(conn, bet["user_id"], bet["amount"], "taixiu_refund",
                                        f"Tài xỉu #{r['id']}: hoàn cược (bot dừng giữa ván)", now)
                    refunded += bet["amount"]
                conn.execute("UPDATE taixiu_rounds SET status = 'refunded', settled_at = ? WHERE id = ?", (_utc_text(now), r["id"]))
            return len(rounds), refunded
        return await self.db.transaction(work)

    async def create_round(self, guild_id: int, channel_id: int) -> tuple[int, datetime]:
        now = self._now()

        def work(conn: sqlite3.Connection) -> int:
            cur = conn.execute("INSERT INTO taixiu_rounds (guild_id, channel_id, status, started_at) VALUES (?, ?, 'open', ?)",
                               (guild_id, channel_id, _utc_text(now)))
            return cur.lastrowid
        return await self.db.transaction(work), now

    async def last_round_id(self, guild_id: int) -> int:
        row = await self.db.fetchone("SELECT COALESCE(MAX(id), 0) AS m FROM taixiu_rounds WHERE guild_id = ?", (guild_id,))
        return int(row["m"])

    async def lock_round(self, round_id: int) -> None:
        def work(conn: sqlite3.Connection) -> None:
            conn.execute("UPDATE taixiu_rounds SET status = 'locked' WHERE id = ? AND status = 'open'", (round_id,))
        await self.db.transaction(work)

    async def abandon_round(self, round_id: int) -> int:
        """Hủy một ván chưa chốt và hoàn cược (dùng khi dừng bàn khẩn cấp). Trả số tiền hoàn."""
        now = self._now()

        def work(conn: sqlite3.Connection) -> int:
            row = conn.execute("SELECT status FROM taixiu_rounds WHERE id = ?", (round_id,)).fetchone()
            if row is None or row["status"] not in ("open", "locked"):
                return 0
            total = 0
            for bet in conn.execute("SELECT user_id, amount FROM taixiu_bets WHERE round_id = ?", (round_id,)).fetchall():
                self.wallets._ensure(conn, bet["user_id"], now)
                self.wallets._apply(conn, bet["user_id"], bet["amount"], "taixiu_refund", f"Tài xỉu #{round_id}: hoàn cược (hủy ván)", now)
                total += bet["amount"]
            conn.execute("UPDATE taixiu_rounds SET status = 'refunded', settled_at = ? WHERE id = ?", (_utc_text(now), round_id))
            return total
        return await self.db.transaction(work)

    # -- cược ---------------------------------------------------------------------------------------------
    async def place_bet(self, round_id: int, user_id: int, side: str, amount: Optional[int], *,
                        min_bet: int, max_bet: int = 0) -> BetResult:
        """Đặt cược (amount=None: tất cả tiền mặt). Cược thêm cùng bên được; cược bên kia trong cùng ván thì bị từ chối."""
        if side not in (TAI, XIU):
            raise BankError("Bên cược không hợp lệ.")
        now = self._now()

        def work(conn: sqlite3.Connection) -> BetResult:
            rnd = conn.execute("SELECT status FROM taixiu_rounds WHERE id = ?", (round_id,)).fetchone()
            if rnd is None or rnd["status"] != "open":
                raise BankError("Ván này đã khóa cược, hãy chờ ván sau.")
            self.wallets._ensure(conn, user_id, now)
            cash = conn.execute("SELECT cash FROM wallets WHERE user_id = ?", (user_id,)).fetchone()["cash"]
            old = conn.execute("SELECT side, amount FROM taixiu_bets WHERE round_id = ? AND user_id = ?", (round_id, user_id)).fetchone()
            if old is not None and old["side"] != side:
                raise BankError(f"Bạn đã cược **{SIDE_NAMES[old['side']]}** ở ván này, không cược thêm bên còn lại được.")
            stake = cash if amount is None else amount
            if stake <= 0:
                raise BankError("Ví của bạn không có tiền mặt để cược.")
            if stake < min_bet:
                raise BankError(f"Mức cược tối thiểu là {format_vnd(min_bet)}.")
            already = old["amount"] if old else 0
            if max_bet and already + stake > max_bet:
                raise BankError(f"Tổng cược mỗi ván tối đa {format_vnd(max_bet)} (bạn đã cược {format_vnd(already)}).")
            if already + stake > MAX_AMOUNT:
                raise BankError("Số tiền cược vượt mức tối đa cho phép.")
            new_cash = self.wallets._apply(conn, user_id, -stake, "taixiu_bet", f"Tài xỉu #{round_id}: cược {SIDE_NAMES[side]}", now)
            if old is None:
                conn.execute("INSERT INTO taixiu_bets (round_id, user_id, side, amount) VALUES (?, ?, ?, ?)", (round_id, user_id, side, stake))
            else:
                conn.execute("UPDATE taixiu_bets SET amount = amount + ? WHERE round_id = ? AND user_id = ?", (stake, round_id, user_id))
            return BetResult(side, stake, already + stake, new_cash)
        return await self.db.transaction(work)

    async def totals(self, round_id: int) -> Totals:
        rows = await self.db.fetchall("SELECT side, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM taixiu_bets "
                                      "WHERE round_id = ? GROUP BY side", (round_id,))
        by = {r["side"]: (r["n"], r["s"]) for r in rows}
        return Totals(*by.get(TAI, (0, 0)), *by.get(XIU, (0, 0)))

    # -- nhà cái bẻ cầu ---------------------------------------------------------------------------------
    async def set_force(self, round_id: int, side: Optional[str], by_id: Optional[int]) -> None:
        def work(conn: sqlite3.Connection) -> None:
            row = conn.execute("SELECT status FROM taixiu_rounds WHERE id = ?", (round_id,)).fetchone()
            if row is None or row["status"] not in ("open", "locked"):
                raise BankError("Ván này đã có kết quả, không bẻ được nữa.")
            conn.execute("UPDATE taixiu_rounds SET forced_side = ?, forced_by = ? WHERE id = ?", (side, by_id if side else None, round_id))
        await self.db.transaction(work)

    async def get_force(self, round_id: int) -> tuple[Optional[str], Optional[int]]:
        row = await self.db.fetchone("SELECT forced_side, forced_by FROM taixiu_rounds WHERE id = ?", (round_id,))
        return (row["forced_side"], row["forced_by"]) if row else (None, None)

    # -- chốt ván ---------------------------------------------------------------------------------------------
    async def settle(self, round_id: int, dice: tuple[int, int, int], *, triple_house: bool = False) -> Settlement:
        """Ghi kết quả và trả thưởng: thắng nhận lại gấp đôi tiền cược (cược + tiền thắng bằng đúng số cược)."""
        now = self._now()
        total, side, triple = sum(dice), side_of(sum(dice)), is_triple(dice)
        house_all = triple and triple_house

        def work(conn: sqlite3.Connection) -> Settlement:
            row = conn.execute("SELECT status FROM taixiu_rounds WHERE id = ?", (round_id,)).fetchone()
            if row is None or row["status"] not in ("open", "locked"):
                raise BankError("Ván này đã được chốt rồi.")
            conn.execute("UPDATE taixiu_rounds SET status = 'settled', settled_at = ?, d1 = ?, d2 = ?, d3 = ?, total = ?, "
                         "result = ?, triple = ? WHERE id = ?", (_utc_text(now), *dice, total, side, int(triple), round_id))
            winners: list[Winner] = []
            losers = lost = 0
            for bet in conn.execute("SELECT user_id, side, amount FROM taixiu_bets WHERE round_id = ? ORDER BY amount DESC, user_id",
                                    (round_id,)).fetchall():
                if bet["side"] == side and not house_all:
                    payout = bet["amount"] * 2
                    self.wallets._ensure(conn, bet["user_id"], now)
                    self.wallets._apply(conn, bet["user_id"], payout, "taixiu_win",
                                        f"Tài xỉu #{round_id}: {SIDE_NAMES[side]} thắng ({'-'.join(map(str, dice))})", now)
                    winners.append(Winner(bet["user_id"], bet["amount"], payout))
                else:
                    losers += 1
                    lost += bet["amount"]
            return Settlement(round_id, dice, total, side, triple, winners, losers, lost, house_all)
        return await self.db.transaction(work)

    async def bet_stats(self, round_ids: list[int]) -> dict[str, tuple[int, int]]:
        """Tổng cược theo bên trong các ván đã cho: {'tai': (số lượt cược, tổng tiền), 'xiu': (...)}."""
        out = {TAI: (0, 0), XIU: (0, 0)}
        if not round_ids:
            return out
        marks = ",".join("?" * len(round_ids))
        rows = await self.db.fetchall(f"SELECT side, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM taixiu_bets "
                                      f"WHERE round_id IN ({marks}) GROUP BY side", round_ids)
        for r in rows:
            out[r["side"]] = (r["n"], r["s"])
        return out

    async def recent(self, guild_id: int, limit: int) -> list[RoundResult]:
        """Các ván đã chốt gần nhất của máy chủ, MỚI NHẤT TRƯỚC."""
        rows = await self.db.fetchall("SELECT * FROM taixiu_rounds WHERE guild_id = ? AND status = 'settled' ORDER BY id DESC LIMIT ?",
                                      (guild_id, limit))
        return [RoundResult(r["id"], (r["d1"], r["d2"], r["d3"]), r["total"], r["result"], bool(r["triple"]), parse_utc(r["started_at"]))
                for r in rows]
