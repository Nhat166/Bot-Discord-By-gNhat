"""Định dạng và đọc số tiền VNĐ. Không phụ thuộc discord nên dùng lại được ở mọi module.

    format_vnd(1500000)   -> "1.500.000 VNĐ"
    parse_amount("1.5tr") -> 1500000      parse_amount("50k") -> 50000      parse_amount("2 tỷ") -> 2000000000

Quy tắc đọc số:
  * Hậu tố: k / nghìn / ngàn (x1.000), m / tr / triệu (x1.000.000), b / tỷ / ty (x1.000.000.000); có thể thêm "vnđ", "vnd", "đ".
  * CÓ hậu tố: một dấu "." hoặc "," là dấu thập phân ("1.5tr" = 1.500.000, "0,5k" = 500). Kết quả phải là số nguyên đồng.
  * KHÔNG có hậu tố: dấu "." hoặc "," chỉ là dấu ngăn hàng nghìn, phải đúng nhóm 3 chữ số ("1.500.000", "1,500" = 1500).
  * Khoảng trắng bị bỏ qua ("1 000 000" = 1000000).
"""
from __future__ import annotations

import re
import unicodedata
from decimal import Decimal, InvalidOperation

CURRENCY = "VNĐ"
MAX_AMOUNT = 10 ** 15  # trần chung để tránh số quá lớn (vẫn nằm gọn trong số nguyên 64 bit của SQLite)

_SUFFIXES = {
    "k": 10 ** 3, "nghin": 10 ** 3, "ngan": 10 ** 3,
    "m": 10 ** 6, "tr": 10 ** 6, "trieu": 10 ** 6,
    "b": 10 ** 9, "ty": 10 ** 9,
}
_CURRENCY_TAIL = re.compile(r"(vnd|dong|d)$")
_GROUPED = re.compile(r"^\d{1,3}([.,]\d{3})+$")
_DECIMAL = re.compile(r"^\d+([.,]\d+)?$")
_NUMBER_THEN_SUFFIX = re.compile(r"^([\d.,]+)([a-z]*)$")


ALL_WORDS = {"all", "tatca"}  # "all", "tất cả", "tat ca" (đã bỏ dấu và khoảng trắng)


def is_all(text: str) -> bool:
    """Người dùng gõ `all` / `tất cả` nghĩa là dùng toàn bộ số tiền có."""
    return re.sub(r"\s+", "", _fold(str(text or ""))) in ALL_WORDS


class AmountError(ValueError):
    """Số tiền không hợp lệ; nội dung là câu tiếng Việt hiện thẳng cho người dùng."""


def format_vnd(amount: int, *, unit: bool = True) -> str:
    text = f"{int(amount):,}".replace(",", ".")
    return f"{text} {CURRENCY}" if unit else text


def _fold(text: str) -> str:
    text = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in text if unicodedata.category(c) != "Mn").casefold()


def parse_amount(text: str, *, minimum: int = 1, maximum: int = MAX_AMOUNT) -> int:
    if text is None or not str(text).strip():
        raise AmountError("Bạn chưa nhập số tiền.")
    raw = re.sub(r"\s+", "", _fold(str(text)))
    raw = _CURRENCY_TAIL.sub("", raw)
    match = _NUMBER_THEN_SUFFIX.match(raw)
    if not match or not match.group(1):
        raise AmountError(f"Không hiểu số tiền `{str(text).strip()[:30]}`. Ví dụ: 50000, 50k, 1.5tr, 2 tỷ.")
    number, suffix = match.groups()
    if suffix:
        if suffix not in _SUFFIXES:
            raise AmountError(f"Không hiểu đơn vị `{suffix}`. Dùng k (nghìn), tr hoặc m (triệu), b hoặc tỷ.")
        if not _DECIMAL.match(number):
            raise AmountError("Số tiền có quá nhiều dấu chấm hoặc phẩy. Ví dụ đúng: 1.5tr.")
        try:
            value = Decimal(number.replace(",", ".")) * _SUFFIXES[suffix]
        except InvalidOperation:
            raise AmountError("Số tiền không hợp lệ.") from None
        if value != value.to_integral_value():
            raise AmountError("Số tiền phải là số nguyên đồng (ví dụ 1.5tr được, 1.0001k thì không).")
        amount = int(value)
    else:
        if number.isdigit():
            amount = int(number)
        elif _GROUPED.match(number):
            amount = int(re.sub(r"[.,]", "", number))
        else:
            raise AmountError("Số tiền không hợp lệ. Dùng 1.500.000 (nhóm 3 chữ số) hoặc viết tắt như 1.5tr.")
    if amount < minimum:
        raise AmountError(f"Số tiền tối thiểu là {format_vnd(minimum)}.")
    if amount > maximum:
        raise AmountError(f"Số tiền tối đa là {format_vnd(maximum)}.")
    return amount
