"""Phần dùng chung của các game bàn liên tục (Tài Xỉu, Bầu Cua): bàn chơi, gửi/sửa tin nhắn, bắt lỗi, kiểm tra role Nhà Cái.

Mỗi game là một Cog kế thừa GameBase và khai báo:
  KEY_CHANNEL / KEY_MSG / KEY_CAU   khóa cài đặt lưu kênh và id hai tin nhắn (khác nhau giữa các game)
  REST_TITLE                        tiêu đề tin nhắn khi bàn dừng
  rest_image()                      ảnh tin nhắn khi bàn dừng
  async _play_round(table)          chơi MỘT ván
"""
from __future__ import annotations

import asyncio
import io
import logging
from datetime import datetime
from typing import Awaitable, Callable, Optional

import discord

import ibank_ui as ui
from ibank_bank import BankStore
from ibank_money import AmountError, format_vnd
from ibank_store import VN_TZ, InsufficientFunds, WalletError

log = logging.getLogger("taixiu.base")

NO_PING = discord.AllowedMentions.none()
MISSING = discord.utils.MISSING
SETTING_BANKER_ROLE, SETTING_LOG_CHANNEL = "banker_role", "log_channel"   # dùng chung với ItachiBank


def money(amount: int) -> str:
    return format_vnd(amount)


def fmt_vn(moment: datetime) -> str:
    return moment.astimezone(VN_TZ).strftime("%H:%M:%S - %d/%m/%Y")


class Table:
    """Trạng thái một bàn (mỗi máy chủ một bàn cho mỗi game)."""

    def __init__(self, guild_id: int, channel_id: int) -> None:
        self.guild_id, self.channel_id = guild_id, channel_id
        self.message: Optional[discord.Message] = None
        self.cau: Optional[discord.Message] = None
        self.round_id = 0
        self.offset = 0                           # số hiển thị = round_id - offset (/reset chỉ đổi số này)
        self.lock_unix = 0
        self.phase = "idle"                       # idle, open, locked, result
        self.started: Optional[datetime] = None
        self.dirty = False
        self.stop = False
        self.task: Optional[asyncio.Task] = None
        self.images: dict[str, bytes] = {}

    @property
    def no(self) -> int:
        return max(1, self.round_id - self.offset)


class GameBase:
    KEY_CHANNEL = KEY_MSG = KEY_CAU = KEY_OFFSET = ""
    GAME_NAME = ""
    REST_TITLE = "🎲 BÀN TẠM NGHỈ"
    bot: discord.Client
    bank: BankStore
    tables: dict[int, Table]

    def rest_image(self) -> Optional[tuple[str, Optional[bytes]]]:
        return None

    async def _play_round(self, table: Table) -> None:     # pragma: no cover - lớp con ghi đè
        raise NotImplementedError

    async def refresh_open(self, table: Table) -> None:    # pragma: no cover - lớp con ghi đè
        raise NotImplementedError

    # -- số ván hiển thị (/reset) --------------------------------------------------------------------------
    def shown(self, guild_id: int, round_id: int) -> int:
        table = self.tables.get(guild_id)
        return table.no if table is not None and table.round_id == round_id else round_id

    async def reset_numbering(self, guild_id: int) -> str:
        """Đặt lại số ván hiển thị về #1. Chỉ đổi con số và sửa tin nhắn; không đụng tới ván, cược, tiền. Trả về lời mô tả."""
        table = self.tables.get(guild_id)
        if table is None or table.round_id == 0:
            base = await self.store.last_round_id(guild_id)                 # type: ignore[attr-defined]
            await self.bank.set_setting(guild_id, self.KEY_OFFSET, str(base))
            return "Bàn đang không chạy, ván kế tiếp sẽ là **#1**."
        current = table.phase in ("open", "locked")
        table.offset = table.round_id - 1 if current else table.round_id
        await self.bank.set_setting(guild_id, self.KEY_OFFSET, str(table.offset))
        if table.phase == "open":
            await self.refresh_open(table)
        return "Ván hiện tại đã thành **#1**." if current else "Ván kế tiếp sẽ là **#1**."

    # -- trả lời người dùng ----------------------------------------------------------------------------
    async def reply(self, interaction: discord.Interaction, embed: discord.Embed, *, view=MISSING, edit: bool = False) -> None:
        kwargs: dict = {"embed": embed, "allowed_mentions": NO_PING}
        if edit and interaction.message is not None and not interaction.response.is_done():
            if view is not MISSING:
                kwargs["view"] = view
            await interaction.response.edit_message(**kwargs)
            return
        if view is not MISSING and view is not None:
            kwargs["view"] = view
        if interaction.response.is_done():
            await interaction.followup.send(ephemeral=True, **kwargs)
        else:
            await interaction.response.send_message(ephemeral=True, **kwargs)

    async def guard(self, interaction: discord.Interaction, work: Callable[[], Awaitable[None]]) -> None:
        try:
            await work()
        except InsufficientFunds as exc:
            await self._safe(interaction, ui.error(f"Không đủ tiền mặt: bạn có **{money(exc.cash)}**, cần **{money(exc.needed)}**."))
        except (WalletError, AmountError) as exc:
            await self._safe(interaction, ui.error(str(exc)))
        except discord.HTTPException as exc:
            log.warning("Lỗi Discord khi xử lý: %s", exc)
            await self._safe(interaction, ui.error("Discord báo lỗi, bạn thử lại sau nhé."))
        except Exception:  # noqa: BLE001
            log.exception("Lỗi không mong muốn")
            await self._safe(interaction, ui.error("Có lỗi không mong muốn. Bạn thử lại nhé."))

    async def _safe(self, interaction: discord.Interaction, embed: discord.Embed) -> None:
        try:
            await self.reply(interaction, embed)
        except discord.HTTPException:
            pass

    # -- quyền ------------------------------------------------------------------------------------------------
    async def is_house(self, interaction: discord.Interaction) -> bool:
        """Chỉ người ĐANG có role Nhà Cái (đặt bằng /bankconfig của ItachiBank). Admin không có role cũng không được."""
        if interaction.guild_id is None:
            return False
        role_id = await self.bank.get_setting(interaction.guild_id, SETTING_BANKER_ROLE)
        return bool(role_id) and any(r.id == int(role_id) for r in getattr(interaction.user, "roles", []))

    @staticmethod
    def is_admin(interaction: discord.Interaction) -> bool:
        perms = interaction.permissions
        return bool(perms.administrator or perms.manage_guild)

    async def log_to(self, guild_id: int, embed: discord.Embed) -> None:
        raw = await self.bank.get_setting(guild_id, SETTING_LOG_CHANNEL)
        guild = self.bot.get_guild(guild_id)
        channel = guild.get_channel(int(raw)) if guild and raw else None
        if channel is None:
            return
        try:
            await channel.send(embed=embed, allowed_mentions=NO_PING)
        except discord.HTTPException as exc:
            log.warning("Không gửi được log: %s", exc)

    # -- gửi / sửa tin nhắn của bàn ------------------------------------------------------------------------
    async def _channel(self, table: Table):
        channel = self.bot.get_channel(table.channel_id)
        if channel is None:
            try:
                channel = await self.bot.fetch_channel(table.channel_id)
            except discord.HTTPException:
                return None
        return channel

    async def _publish(self, table: Table, slot: str, embed: discord.Embed, *, image: Optional[tuple[str, Optional[bytes]]] = None,
                       view=MISSING) -> None:
        """Sửa tin nhắn `slot` ('message' = ván, 'cau' = cầu); chưa có hoặc đã bị xóa thì gửi tin mới. Không bao giờ ném lỗi Discord."""
        def new_file() -> Optional[discord.File]:
            if image is None:
                return None
            name, data = image
            data = data or table.images.get(name)
            return discord.File(io.BytesIO(data), filename=name) if data else None

        if image is not None:
            name, data = image
            if data and "result" not in name:      # chỉ nhớ ảnh cố định; ảnh kết quả mỗi ván một tên
                table.images[name] = data
            embed.set_image(url=f"attachment://{name}")
        message = getattr(table, slot)
        if message is not None:
            kwargs: dict = {"embed": embed, "allowed_mentions": NO_PING}
            if view is not MISSING:
                kwargs["view"] = view
            try:
                if image is not None and image[1]:
                    await message.edit(attachments=[new_file()], **kwargs)
                else:
                    await message.edit(**kwargs)
                return
            except discord.NotFound:
                setattr(table, slot, None)
            except discord.HTTPException as exc:
                log.warning("Không sửa được tin nhắn bàn: %s", exc)
                return
        channel = await self._channel(table)
        if channel is None:
            log.warning("Không thấy kênh %s của bàn", table.channel_id)
            return
        send: dict = {"embed": embed, "allowed_mentions": NO_PING}
        file = new_file()
        if file is not None:
            send["file"] = file
        if view is not MISSING and view is not None:
            send["view"] = view
        try:
            sent = await channel.send(**send)
        except discord.HTTPException as exc:
            log.warning("Không gửi được tin nhắn bàn: %s", exc)
            return
        setattr(table, slot, sent)
        await self.bank.set_setting(table.guild_id, self.KEY_MSG if slot == "message" else self.KEY_CAU, str(sent.id))

    # -- vòng đời bàn ----------------------------------------------------------------------------------------
    def start_table(self, table: Table) -> None:
        self.tables[table.guild_id] = table
        table.task = asyncio.create_task(self._run(table), name=f"{self.KEY_CHANNEL}-{table.guild_id}")

    async def resume_tables(self) -> None:
        for guild in list(self.bot.guilds):
            raw = await self.bank.get_setting(guild.id, self.KEY_CHANNEL)
            if not raw or guild.id in self.tables:
                continue
            table = Table(guild.id, int(raw))
            channel = await self._channel(table)
            if channel is None:
                log.warning("Không thấy kênh bàn %s ở máy chủ %s, bỏ qua.", raw, guild.id)
                continue
            for slot, key in (("message", self.KEY_MSG), ("cau", self.KEY_CAU)):
                mid = await self.bank.get_setting(guild.id, key)
                if mid:
                    try:
                        setattr(table, slot, await channel.fetch_message(int(mid)))
                    except discord.HTTPException:
                        pass
            self.start_table(table)
            log.info("Đã mở lại bàn %s ở kênh %s (máy chủ %s)", self.KEY_CHANNEL, raw, guild.id)

    async def _run(self, table: Table) -> None:
        try:
            while not table.stop:
                try:
                    table.offset = int(await self.bank.get_setting(table.guild_id, self.KEY_OFFSET) or 0)
                    await self._play_round(table)
                except asyncio.CancelledError:
                    raise
                except Exception:  # noqa: BLE001
                    log.exception("Lỗi trong ván, hoàn cược và chơi tiếp")
                    if table.round_id:
                        try:
                            await self.store.abandon_round(table.round_id)   # type: ignore[attr-defined]
                        except Exception:  # noqa: BLE001
                            log.exception("Không hoàn được cược")
                    await asyncio.sleep(5)
            await self._publish(table, "message", ui.make(self.REST_TITLE, "Bàn đã dừng. Hẹn gặp lại!", color=ui.GREY),
                                image=self.rest_image(), view=None)
        finally:
            if self.tables.get(table.guild_id) is table:
                del self.tables[table.guild_id]
