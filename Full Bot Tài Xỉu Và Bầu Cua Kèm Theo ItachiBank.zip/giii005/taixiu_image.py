"""Vẽ ảnh cho bàn Tài Xỉu bằng Pillow (không cần file ảnh có sẵn): bát úp, đang lắc, và kết quả 3 xúc xắc.

Ảnh được vẽ ở độ phân giải gấp đôi rồi thu nhỏ để mép mịn. Font chữ dùng DejaVu Sans Bold đi kèm (taixiu_fonts/) nên
tiếng Việt có dấu hiển thị đúng trên mọi hệ điều hành; thiếu font thì thử font hệ thống, cuối cùng mới dùng font mặc định.
"""
from __future__ import annotations

import io
import math
import random
from pathlib import Path
from typing import Sequence

from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 960, 420
SS = 2                                   # hệ số vẽ gấp đôi
FONT_DIR = Path(__file__).resolve().parent / "taixiu_fonts"
_FONT_CANDIDATES = [
    FONT_DIR / "DejaVuSans-Bold.ttf",
    Path("C:/Windows/Fonts/arialbd.ttf"),
    Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf"),
    Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
]

GOLD = (255, 205, 96)
GOLD_DARK = (176, 128, 40)
GREEN = (47, 158, 68)
BLUE = (47, 108, 214)
FELT_TOP, FELT_BOTTOM = (14, 86, 62), (6, 38, 28)


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for path in _FONT_CANDIDATES:
        try:
            return ImageFont.truetype(str(path), size * SS)
        except OSError:
            continue
    return ImageFont.load_default(size * SS)


def _lerp(a: Sequence[int], b: Sequence[int], t: float) -> tuple[int, int, int]:
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))  # type: ignore[return-value]


def _background() -> Image.Image:
    w, h = W * SS, H * SS
    img = Image.new("RGB", (w, h))
    px = ImageDraw.Draw(img)
    for y in range(h):
        px.line([(0, y), (w, y)], fill=_lerp(FELT_TOP, FELT_BOTTOM, y / h))
    # tối dần ra mép
    vignette = Image.new("L", (w, h), 0)
    ImageDraw.Draw(vignette).ellipse((-w * 0.15, -h * 0.35, w * 1.15, h * 1.35), fill=255)
    vignette = vignette.filter(ImageFilter.GaussianBlur(120 * SS / 2))
    dark = Image.new("RGB", (w, h), (2, 14, 10))
    img = Image.composite(img, dark, vignette)
    d = ImageDraw.Draw(img)
    for inset, width, color in ((14, 5, GOLD), (26, 2, GOLD_DARK)):
        d.rounded_rectangle((inset * SS, inset * SS, w - inset * SS, h - inset * SS), radius=34 * SS,
                            outline=color, width=width * SS)
    return img


def _text_center(img: Image.Image, xy: tuple[float, float], text: str, size: int, fill, *, stroke: int = 0,
                 stroke_fill=(0, 0, 0)) -> None:
    d = ImageDraw.Draw(img)
    d.text((xy[0] * SS, xy[1] * SS), text, font=_font(size), fill=fill, anchor="mm",
           stroke_width=stroke * SS, stroke_fill=stroke_fill)


def _shadow(img: Image.Image, box: tuple[float, float, float, float], blur: int = 14, alpha: int = 120) -> None:
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).ellipse(tuple(v * SS for v in box), fill=(0, 0, 0, alpha))
    layer = layer.filter(ImageFilter.GaussianBlur(blur * SS))
    img.paste(layer, (0, 0), layer)


# --- xúc xắc ---------------------------------------------------------------------------------------
_PIPS = {
    1: [(1, 1)],
    2: [(0, 0), (2, 2)],
    3: [(0, 0), (1, 1), (2, 2)],
    4: [(0, 0), (2, 0), (0, 2), (2, 2)],
    5: [(0, 0), (2, 0), (1, 1), (0, 2), (2, 2)],
    6: [(0, 0), (2, 0), (0, 1), (2, 1), (0, 2), (2, 2)],
}


def _die_tile(value: int, size: int) -> Image.Image:
    s = size * SS
    tile = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    r = int(s * 0.18)
    d.rounded_rectangle((0, 0, s - 1, s - 1), radius=r, fill=(214, 214, 220))                 # viền dưới
    d.rounded_rectangle((int(s * 0.02), int(s * 0.02), s - 1 - int(s * 0.04), s - 1 - int(s * 0.05)), radius=r,
                        fill=(252, 252, 250))
    d.rounded_rectangle((int(s * 0.07), int(s * 0.06), s - 1 - int(s * 0.09), int(s * 0.45)), radius=r,
                        fill=(255, 255, 255))                                                   # ánh sáng phía trên
    pip = (200, 30, 40) if value in (1, 4) else (24, 24, 30)
    pr = s * (0.115 if value != 1 else 0.17)
    for gx, gy in _PIPS[value]:
        cx, cy = s * (0.27 + 0.23 * gx), s * (0.27 + 0.23 * gy)
        d.ellipse((cx - pr, cy - pr, cx + pr, cy + pr), fill=pip)
        d.ellipse((cx - pr * 0.45, cy - pr * 0.55, cx - pr * 0.05, cy - pr * 0.15), fill=_lerp(pip, (255, 255, 255), 0.45))
    return tile


def _paste_die(img: Image.Image, value: int, center: tuple[float, float], size: int, angle: float = 0) -> None:
    _shadow(img, (center[0] - size * 0.5, center[1] + size * 0.28, center[0] + size * 0.5, center[1] + size * 0.62),
            blur=int(size * 0.12), alpha=130)
    tile = _die_tile(value, size).rotate(angle, resample=Image.BICUBIC, expand=True)
    img.paste(tile, (int(center[0] * SS - tile.width / 2), int(center[1] * SS - tile.height / 2)), tile)


# --- bát úp ----------------------------------------------------------------------------------------
def _bowl(img: Image.Image, center: tuple[float, float], width: int, tilt: float = 0) -> None:
    cx, cy = center
    w, h = width, int(width * 0.62)
    s_w, s_h = w * SS, h * SS
    layer = Image.new("RGBA", (s_w, int(s_h * 1.25)), (0, 0, 0, 0))
    # thân bát: nửa trên hình elip tô gradient đỏ sẫm → đỏ tươi
    body = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    bd = ImageDraw.Draw(body)
    for y in range(s_h):
        t = y / s_h
        bd.line([(0, y), (s_w, y)], fill=_lerp((236, 70, 62), (120, 14, 22), t ** 0.8) + (255,))
    mask = Image.new("L", layer.size, 0)
    ImageDraw.Draw(mask).pieslice((0, 0, s_w - 1, s_h * 2 - 1), 180, 360, fill=255)
    layer.paste(body, (0, 0), mask)
    d = ImageDraw.Draw(layer)
    # viền vàng ở miệng bát
    rim_y = s_h
    d.ellipse((-s_w * 0.02, rim_y - s_h * 0.11, s_w * 1.02, rim_y + s_h * 0.17), fill=GOLD_DARK)
    d.ellipse((s_w * 0.0, rim_y - s_h * 0.12, s_w * 1.0, rim_y + s_h * 0.11), fill=GOLD)
    # bóng sáng
    shine = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    ImageDraw.Draw(shine).ellipse((s_w * 0.18, s_h * 0.12, s_w * 0.46, s_h * 0.4), fill=(255, 255, 255, 120))
    shine = shine.filter(ImageFilter.GaussianBlur(10 * SS))
    layer.alpha_composite(shine)
    # núm cầm
    d = ImageDraw.Draw(layer)
    d.ellipse((s_w * 0.44, -s_h * 0.0 - s_h * 0.04, s_w * 0.56, s_h * 0.1), fill=GOLD)
    layer = layer.rotate(tilt, resample=Image.BICUBIC, expand=True)
    _shadow(img, (cx - w * 0.6, cy + h * 0.46, cx + w * 0.6, cy + h * 0.72), blur=int(w * 0.04), alpha=140)
    img.paste(layer, (int(cx * SS - layer.width / 2), int(cy * SS - layer.height * 0.55)), layer)


def _chip(img: Image.Image, center: tuple[float, float], radius: int, color, label: str, sub: str) -> None:
    d = ImageDraw.Draw(img)
    cx, cy, r = center[0] * SS, center[1] * SS, radius * SS
    _shadow(img, (center[0] - radius, center[1] + radius * 0.6, center[0] + radius, center[1] + radius * 1.15), blur=8, alpha=120)
    d = ImageDraw.Draw(img)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(250, 250, 250))
    d.ellipse((cx - r * 0.92, cy - r * 0.92, cx + r * 0.92, cy + r * 0.92), fill=color)
    d.ellipse((cx - r * 0.74, cy - r * 0.74, cx + r * 0.74, cy + r * 0.74), outline=(255, 255, 255), width=3 * SS)
    # vạch trắng quanh chip
    for i in range(8):
        a = math.radians(i * 45)
        d.line([(cx + math.cos(a) * r * 0.78, cy + math.sin(a) * r * 0.78), (cx + math.cos(a) * r * 0.98, cy + math.sin(a) * r * 0.98)],
               fill=(255, 255, 255), width=6 * SS)
    _text_center(img, (center[0], center[1] - 7), label, int(radius * 0.46), (255, 255, 255), stroke=2, stroke_fill=(0, 40, 20))
    _text_center(img, (center[0], center[1] + radius * 0.38), sub, int(radius * 0.24), (255, 255, 255))


def _finish(img: Image.Image) -> bytes:
    out = img.resize((W, H), Image.LANCZOS).convert("RGB")
    buf = io.BytesIO()
    out.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def _title(img: Image.Image, sub: str) -> None:
    _text_center(img, (W / 2, 76), "TÀI XỈU", 62, GOLD, stroke=3, stroke_fill=(70, 40, 0))
    _text_center(img, (W / 2, 126), sub, 21, (225, 240, 230))


# --- ba ảnh công khai --------------------------------------------------------------------------------
def betting_image() -> bytes:
    img = _background()
    _title(img, "XỈU 3–10   ·   TÀI 11–18")
    _chip(img, (190, 262), 74, GREEN, "TÀI", "11 – 18")
    _chip(img, (770, 262), 74, BLUE, "XỈU", "3 – 10")
    _bowl(img, (480, 268), 236)
    for x, v, a in ((385, 3, -14), (575, 5, 12)):
        _paste_die(img, v, (x, 338), 38, a)
    _text_center(img, (W / 2, 374), "Mời quý khách đặt cược", 19, (225, 240, 230))
    return _finish(img)


def shaking_image() -> bytes:
    img = _background()
    _title(img, "ĐANG LẮC XÚC XẮC...")
    d = ImageDraw.Draw(img)
    rnd = random.Random(7)
    for i in range(14):                                       # vạch chuyển động
        x = rnd.randint(260, 700) * SS
        y = rnd.randint(180, 340) * SS
        L = rnd.randint(50, 120) * SS
        d.line([(x, y), (x + L, y - L * 0.08)], fill=(255, 255, 255), width=3 * SS)
    img = img.filter(ImageFilter.GaussianBlur(0.4 * SS))
    for cx, v, a in ((300, 2, 25), (665, 6, -30), (480, 4, 10)):
        _paste_die(img, v, (cx, 335 + (8 if cx == 480 else -18)), 50, a)
    _bowl(img, (480, 262), 250, tilt=-9)
    for cx in (320, 640):
        ImageDraw.Draw(img).arc(((cx - 58) * SS, 195 * SS, (cx + 58) * SS, 355 * SS), 200 if cx < 480 else 300,
                                 260 if cx < 480 else 360, fill=GOLD, width=5 * SS)
    return _finish(img)


def result_image(dice: Sequence[int], side: str, triple_house: bool = False) -> bytes:
    """side: 'tai' | 'xiu'. Ba xúc xắc, tổng điểm và nhãn kết quả."""
    total = sum(dice)
    img = _background()
    _title(img, "KẾT QUẢ")
    for x, v, a in zip((310, 480, 650), dice, (-8, 5, 10)):
        _paste_die(img, v, (x, 240), 116, a)
    color = GREEN if side == "tai" else BLUE
    label = "TÀI" if side == "tai" else "XỈU"
    d = ImageDraw.Draw(img)
    pill = (330 * SS, 336 * SS, 630 * SS, 394 * SS)
    d.rounded_rectangle(pill, radius=29 * SS, fill=color, outline=(255, 255, 255), width=3 * SS)
    _text_center(img, (W / 2, 366), f"{total}  ·  {label}", 34, (255, 255, 255), stroke=2, stroke_fill=(0, 30, 20))
    return _finish(img)


if __name__ == "__main__":      # xem thử: python taixiu_image.py
    for name, data in (("tx_betting.png", betting_image()), ("tx_shaking.png", shaking_image()),
                       ("tx_result.png", result_image((4, 5, 6), "tai"))):
        Path(name).write_bytes(data)
        print("đã ghi", name, len(data), "byte")
