"""Cấu hình bot Tài Xỉu, đọc từ taixiu.env (xem taixiu.env.example).

Bot này có token và file cấu hình RIÊNG (taixiu.env / TAIXIU_*), nhưng DÙNG CHUNG cơ sở dữ liệu và ví với ItachiBank:
đường dẫn db, số tiền khởi đầu và dòng chân "by: giii•" lấy từ ibank_config (ibank.env) nên hai bot luôn khớp nhau.
"""
from __future__ import annotations

import os

from dotenv import load_dotenv

import ibank_config as ibank
from ibank_money import AmountError, parse_amount

BASE_DIR = ibank.BASE_DIR
load_dotenv(BASE_DIR / "taixiu.env")


def _get_str(name: str, default: str = "") -> str:
    return (os.getenv(name) or default).strip()


def _get_int(name: str, default: int) -> int:
    raw = _get_str(name)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        raise SystemExit(f"Biến môi trường {name} phải là số nguyên (hiện là {raw!r}).") from None


def _get_money(name: str, default: int, *, minimum: int = 1) -> int:
    raw = _get_str(name)
    if not raw:
        return default
    try:
        return parse_amount(raw, minimum=minimum)
    except AmountError as exc:
        raise SystemExit(f"Biến môi trường {name} không hợp lệ ({raw!r}): {exc}") from None


TOKEN = _get_str("TAIXIU_TOKEN")
GUILD_ID = _get_int("TAIXIU_GUILD_ID", 0)          # để trống: đồng bộ lệnh / toàn cầu (chậm hơn)

# Dùng chung với ItachiBank
DATABASE_PATH = ibank.DATABASE_PATH
STARTING_BALANCE = ibank.STARTING_BALANCE

# Thời gian mỗi ván (giây)
BET_SECONDS = max(10, _get_int("TAIXIU_BET_SECONDS", 40))
SHAKE_SECONDS = max(1, _get_int("TAIXIU_SHAKE_SECONDS", 3))
RESULT_SECONDS = max(2, _get_int("TAIXIU_RESULT_SECONDS", 6))

# Mức cược
MIN_BET = _get_money("TAIXIU_MIN_BET", 1_000)
MAX_BET = _get_money("TAIXIU_MAX_BET", 0, minimum=0)   # tổng cược một người ở một ván; 0 = không giới hạn (chỉ cần đủ tiền mặt)

# 1 = ra bộ ba (3 xúc xắc giống nhau) thì nhà cái ăn hết, 0 = vẫn tính Tài/Xỉu theo tổng điểm
TRIPLE_HOUSE = _get_int("TAIXIU_TRIPLE_HOUSE", 0) == 1

HISTORY_SIZE = 10          # số ván hiện ở tin nhắn "cầu"

# Bầu Cua: emoji của ô "Bầu" (Discord không có emoji trái bầu; 🍐 giống hình trái bầu nhất, có thể đổi)
BAUCUA_BAU_EMOJI = _get_str("BAUCUA_BAU_EMOJI", "🍐")
