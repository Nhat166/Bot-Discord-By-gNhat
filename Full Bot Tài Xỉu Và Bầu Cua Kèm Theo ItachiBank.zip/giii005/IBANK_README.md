# ItachiBank — ví, ngân hàng, vay tiền (VNĐ ảo)

Bot **hoàn toàn mới**, chỉ dùng lệnh `/`. Không cần bật Privileged Intents. VNĐ trong bot là tiền ảo, không có giá trị quy đổi.

## Chạy bot
1. Developer Portal → New Application → Bot → **Reset Token** → copy token. Không dùng chung token với bot cũ hoặc bot ghi chú.
2. Mời bot vào server với scope **`bot`** và **`applications.commands`**. Quyền cần: Send Messages, Embed Links (và View Channel ở kênh log).
3. Copy `ibank.env.example` → `ibank.env`, điền `IBANK_TOKEN` và `IBANK_GUILD_ID` (để lệnh `/` hiện ngay).
4. `pip install -r ibank_requirements.txt`
5. `python ibank_main.py` (chạy ở một cửa sổ terminal riêng).
6. Trong server, admin gõ `/bankconfig` để chọn **kênh log** và **role nhà cái**.

`ibank.env`, `data/ibank.db` và `ibank.log` nằm cạnh `ibank_main.py`, nên chạy từ thư mục nào cũng được.

## Lệnh
| Lệnh | Ai dùng | Làm gì |
|---|---|---|
| `/vi` | mọi người | Ví: tiền mặt, tiền nợ, ngân hàng, tổng tài sản; nút **Nhận /daily**, **Nộp vào tài khoản** |
| `/daily` | mọi người | Nhận ngẫu nhiên 50.000–500.000 VNĐ, đặt lại lúc 0 giờ giờ Việt Nam |
| `/lichsu [thanhvien]` | mọi người; xem người khác: admin/nhà cái | Lịch sử giao dịch (nộp, rút, chuyển, nhận tiền, /daily, vay...), 10 dòng/trang, nút Trước/Sau |
| `/tao hoten sotaikhoan` | mọi người | Mở tài khoản (tối đa 3 mỗi người, số mặc định 8–12 chữ số, không trùng; đổi bằng `IBANK_ACCOUNT_NUMBER_MIN` / `IBANK_ACCOUNT_NUMBER_MAX` trong `ibank.env`) |
| `/bank [taikhoan]` | mọi người | Thông tin tài khoản + nút **Nộp tiền**, **Rút ra ví**, **Chuyển tiền** |
| `/bankinfo [thanhvien]` | mọi người; xem người khác: admin/nhà cái | Ví + tất cả tài khoản |
| `/vay thanhvien sotien [songay]` | mọi người | Gửi đơn xin vay (không lãi, mặc định 7 ngày) |
| `/checkvay` | mọi người | Xem đơn xin vay gửi cho bạn, bấm **Chấp nhận / Từ chối** |
| `/tratien` | mọi người | Trả nợ (để trống số tiền = trả hết) — lệnh bổ sung |
| `/thutien thanhvien sotien [lydo]` | admin, quản trị viên, role nhà cái | Thu tiền mặt trong ví (tiền biến mất) |
| `/addmoney thanhvien sotien [lydo]` | admin, quản trị viên, role nhà cái | Thêm tiền mặt vào ví |
| `/bankconfig [kenhlog] [rolenhacai]` | admin, quản trị viên | Đặt kênh log / role nhà cái; xem số liệu hệ thống |

Số tiền nhập được: `50000`, `50k`, `1.5tr`, `1m`, `2 tỷ`, `1.000.000`.

## Quy tắc
- Ví đầu tiên có **200.000 VNĐ**, tạo khi dùng bot lần đầu.
- **Ví = tiền mặt** dùng cho game. **Ngân hàng** = tài khoản như ngoài đời, không phí, không lãi; tiền trong ngân hàng muốn chơi game phải rút ra ví.
- Chuyển tiền: nhập số tiền, số tài khoản nhận, lý do. Người chuyển nhận biên lai riêng, người nhận được nhắn riêng (nếu mở tin nhắn riêng), và có bản ghi trong kênh log.
- Vay: người cho vay duyệt trong 24 giờ (quá hạn đơn tự hủy). Khi chấp nhận, tiền mặt chuyển từ ví người cho vay sang ví người vay. Quá hạn trả, bot **tự trừ tiền mặt trong ví** người vay (tối đa số đang có, phần còn lại vẫn là nợ và tiếp tục được trừ khi ví có tiền). Mỗi người tối đa 3 đơn chờ, 3 khoản đang nợ.
- Chuyển tiền và vay yêu cầu ở server **tối thiểu 3 ngày** (chống tài khoản phụ gom tiền).
- `/thutien` chỉ thu tối đa số tiền mặt đang có.
- **Số liệu hệ thống** (tổng tiền, tiền sinh ra / thu về hôm nay) xem bằng `/bankconfig`.

## Dòng chân "by: giii•"
Gắn vào mọi bảng bot gửi. Discord không cho căn phải dòng chân, nên bot chèn ký tự trống phía trước để đẩy chữ sang phải. Điện thoại màn hình hẹp có thể xuống dòng: giảm `IBANK_FOOTER_PAD` (ví dụ 20). Đổi chữ bằng `IBANK_FOOTER_TEXT`.

## Tên không trùng với bot khác
| | Bot cũ | Bot ghi chú | ItachiBank |
|---|---|---|---|
| Khởi chạy | `main.py` | `ghichu_main.py` | `ibank_main.py` |
| Cấu hình / biến | `.env` / `DISCORD_TOKEN` | `ghichu.env` / `GHICHU_*` | `ibank.env` / `IBANK_*` |
| Dữ liệu / log | cơ sở dữ liệu riêng, `bot.log` | `data/ghichu.db`, `ghichu.log` | `data/ibank.db`, `ibank.log` |

## Đang có / chưa có
Đã có: ví, `/daily`, tài khoản, nộp/rút/chuyển, vay, thu/thêm tiền, log, thu nợ tự động.
Chưa có (làm ở bước sau): Tiến Lên Itachi, Đua thú, Bầu cua/Tài xỉu, Ma Sói.
